"""Tạo biểu tượng "BDS Studio.app" cho máy dựng trên Mac (bộ cài install_mac.command gọi ở bước B5).

Kết quả:
  ~/Applications/BDS Studio.app      (Launchpad, Spotlight thấy; kéo vào Dock được)
  ~/Desktop/BDS Studio.app           liên kết (symlink) tới gói trên – bấm đúp như ứng dụng thường
  ~/Desktop/BDS Studio.command       (lối tắt cũ của bộ cài) bị xoá khi cài lại
Gói:
  Contents/Info.plist                CFBundleName "BDS Studio", LSUIElement = true (không hiện Dock/không cửa sổ)
  Contents/MacOS/applet              chương trình mồi CHÍP GỐC (osacompile – có sẵn trong macOS, bản universal)
  Contents/Resources/Scripts/main.scpt   AppleScript: do shell script → Contents/Resources/launcher
  Contents/Resources/launcher        shell: .venv/bin/python app/launcher.py (chạy nền, nhật ký ~/.bds_studio/logs)
  Contents/Resources/AppIcon.icns    biểu tượng ngôi nhà vàng (sips + iconutil từ icon-512.png; dự phòng: ghi icns bằng Python)
Vì sao không để tệp shell làm CFBundleExecutable: trên Mac chip Apple, gói có "chương trình chính" là script bị macOS coi là
chương trình Intel → đòi cài Rosetta. Chỉ khi máy không có osacompile mới dùng cách đó (kèm LSArchitecturePriority arm64).
Gatekeeper: gói được TẠO NGAY TRÊN MÁY (không tải từ mạng) nên không có cờ com.apple.quarantine → Gatekeeper không kiểm,
không cần chứng chỉ Apple. Bộ cài vẫn gỡ cờ (xattr -cr) và ký ad-hoc (codesign -s -, có sẵn trong macOS) sau khi sửa Info.plist.

Dùng:  .venv/bin/python app/mac_app.py --engine DIR [--apps-dir ~/Applications] [--desktop ~/Desktop] [--dry-run]
In ra 1 dòng tóm tắt. Mã thoát: 0 xong · 3 xong nhưng thiếu phần (biểu tượng / lối tắt màn hình nền / cách dự phòng) · 1 lỗi.
"""
import os
import plistlib
import re
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

APP_NAME = 'BDS Studio'
MARKER = 'bds_studio_app'                     # tệp đánh dấu trong Contents/Resources: gói do bộ cài tạo → được thay
DEFAULT_BUNDLE_ID = 'vn.bdsstudio.engine'     # trung tính (không gắn tên miền riêng) – đổi bằng BDS_BUNDLE_ID
LSREGISTER = '/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
# Tên tệp trong .iconset theo quy ước của iconutil: (tên, cạnh px). Nguồn 512 px → bỏ 512@2x (1024 px, phóng to sẽ mờ).
ICONSET = [('icon_16x16.png', 16), ('icon_16x16@2x.png', 32), ('icon_32x32.png', 32), ('icon_32x32@2x.png', 64),
           ('icon_128x128.png', 128), ('icon_128x128@2x.png', 256), ('icon_256x256.png', 256),
           ('icon_256x256@2x.png', 512), ('icon_512x512.png', 512)]
# Mã loại ICNS chứa PNG (macOS 10.7+) cho cách dự phòng không cần iconutil
ICNS_TYPES = [(b'icp4', 16), (b'icp5', 32), (b'ic11', 32), (b'ic12', 64), (b'ic07', 128), (b'ic13', 256),
              (b'ic08', 256), (b'ic14', 512), (b'ic09', 512)]

APPLESCRIPT = '''-- BDS Studio: mở máy dựng chạy nền (bộ cài tạo – không sửa tay)
try
\tdo shell script "/bin/bash " & quoted form of (POSIX path of (path to me) & "Contents/Resources/launcher") & " >/dev/null 2>&1"
end try
'''


def bundle_id() -> str:
    v = os.environ.get('BDS_BUNDLE_ID', '').strip()
    return v if re.fullmatch(r'[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+', v or '') else DEFAULT_BUNDLE_ID


def info_plist(executable: str, version: str, bid: str, icon: bool, base: dict = None, script_exec: bool = False) -> dict:
    """Nội dung Info.plist. base = Info.plist osacompile tạo (giữ các khoá chương trình mồi cần), ta ghi đè khoá của mình."""
    d = dict(base or {})
    d.pop('CFBundleIconName', None)            # có khoá này macOS lấy biểu tượng từ Assets.car (của AppleScript) thay vì .icns
    d.update({
        'CFBundleDevelopmentRegion': 'vi',
        'CFBundleDisplayName': APP_NAME,
        'CFBundleName': APP_NAME,
        'CFBundleExecutable': executable,
        'CFBundleIdentifier': bid,
        'CFBundleInfoDictionaryVersion': '6.0',
        'CFBundlePackageType': 'APPL',
        'CFBundleShortVersionString': version,
        'CFBundleVersion': version,
        'LSApplicationCategoryType': 'public.app-category.productivity',
        'LSMinimumSystemVersion': '11.0',
        'LSUIElement': True,                   # chạy ẩn: không hiện trên Dock, không cửa sổ (biểu tượng chỉ mở máy dựng rồi thoát)
        'NSHighResolutionCapable': True,
    })
    if icon:
        d['CFBundleIconFile'] = 'AppIcon'
    else:
        d.pop('CFBundleIconFile', None)
    if script_exec:
        d['LSArchitecturePriority'] = ['arm64', 'x86_64']
    return d


def plist_bytes(d: dict) -> bytes:
    return plistlib.dumps(d, fmt=plistlib.FMT_XML, sort_keys=True)


def sh_quote(s: str) -> str:
    return "'" + s.replace("'", "'\\''") + "'"


def launcher_script(engine_dir: str) -> str:
    """Shell trong gói: mở máy dựng chạy nền bằng Python của .venv; thiếu thì báo bằng hộp thoại."""
    return f'''#!/bin/bash
# BDS Studio – mở máy dựng chạy nền rồi mở app trong trình duyệt (bộ cài install_mac.command tạo – không sửa tay).
# Tắt máy dựng: bash "$0" --stop
# shellcheck disable=SC2016  # đường dẫn ghi nguyên văn (có thể chứa $, dấu nháy)
ENGINE_DIR={sh_quote(engine_dir)}
DATA_DIR="${{BDS_DATA_DIR:-$HOME/.bds_studio}}"
LOG_DIR="$DATA_DIR/logs"
mkdir -p "$LOG_DIR" 2>/dev/null
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH" PYTHONIOENCODING=utf-8
VPY="$ENGINE_DIR/.venv/bin/python"
if [ -x "$VPY" ] && [ -f "$ENGINE_DIR/app/launcher.py" ] && cd "$ENGINE_DIR"; then
  exec "$VPY" app/launcher.py "$@" >>"$LOG_DIR/launcher.log" 2>&1
fi
/usr/bin/osascript -e 'display alert "BDS Studio" message "Không tìm thấy máy dựng (thư mục BDS_Studio_Engine đã bị chuyển hoặc xoá?). Mở thư mục BDS_Studio_Engine và chạy lại install_mac.command – biểu tượng sẽ được tạo lại."' >/dev/null 2>&1
exit 1
'''


# ---------------- chạy lệnh ngoài ----------------
def tool(name: str):
    return shutil.which(name) or next((p for p in (f'/usr/bin/{name}', f'/bin/{name}') if os.access(p, os.X_OK)), None)


def run(cmd, timeout=120) -> bool:
    try:
        return subprocess.run([str(c) for c in cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              timeout=timeout, check=False).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


# ---------------- biểu tượng ----------------
def find_icon_png(engine_dir: Path):
    for c in (engine_dir / 'assets' / 'icon-512.png', engine_dir / 'web' / 'assets' / 'icon-512.png',
              engine_dir.parent / 'web' / 'assets' / 'icon-512.png'):
        if c.is_file():
            return c
    return None


def icns_iconutil(png: Path, out: Path, work: Path) -> bool:
    sips, iconutil = tool('sips'), tool('iconutil')
    if not (sips and iconutil):
        return False
    iset = work / 'AppIcon.iconset'
    shutil.rmtree(iset, ignore_errors=True)
    iset.mkdir(parents=True)
    for name, px in ICONSET:
        if not run([sips, '-z', px, px, png, '--out', iset / name], timeout=60):
            return False
    return run([iconutil, '-c', 'icns', iset, '-o', out]) and out.is_file() and out.stat().st_size > 0


def icns_python(png: Path, out: Path) -> bool:
    """Dự phòng: ghi .icns (các ảnh PNG bên trong) bằng Pillow của .venv."""
    try:
        import io
        from PIL import Image
        src = Image.open(png).convert('RGBA')
        chunks = b''
        for code, px in ICNS_TYPES:
            buf = io.BytesIO()
            src.resize((px, px), Image.LANCZOS).save(buf, format='PNG', optimize=True)
            data = buf.getvalue()
            chunks += code + struct.pack('>I', len(data) + 8) + data
        out.write_bytes(b'icns' + struct.pack('>I', len(chunks) + 8) + chunks)
        return True
    except Exception:  # noqa: BLE001
        return False


def make_icns(png, out: Path, work: Path):
    """Trả 'iconutil' | 'python' | None (không có biểu tượng – gói vẫn chạy, chỉ hiện biểu tượng mặc định)."""
    if png is None:
        return None
    if icns_iconutil(png, out, work):
        return 'iconutil'
    out.unlink(missing_ok=True)
    if icns_python(png, out):
        return 'python'
    out.unlink(missing_ok=True)
    return None


# ---------------- gói .app ----------------
def is_ours(app: Path) -> bool:
    if (app / 'Contents' / 'Resources' / MARKER).is_file():
        return True
    try:
        return plistlib.loads((app / 'Contents' / 'Info.plist').read_bytes()).get('CFBundleIdentifier') == bundle_id()
    except Exception:  # noqa: BLE001
        return False


def build_bundle(engine_dir: Path, app: Path, work: Path) -> dict:
    """Dựng gói ở `app` (thư mục chưa tồn tại). Trả {'kind': 'applet'|'script', 'icon': ...}."""
    contents = app / 'Contents'
    res = contents / 'Resources'
    kind = 'script'
    osacompile = tool('osacompile')
    base = {}
    if osacompile:
        src = work / 'main.applescript'
        src.write_text(APPLESCRIPT, encoding='utf-8')
        if run([osacompile, '-o', app, src]) and (contents / 'MacOS' / 'applet').is_file():
            kind = 'applet'
            try:
                base = plistlib.loads((contents / 'Info.plist').read_bytes())
            except Exception:  # noqa: BLE001
                base = {}
            (res / 'Assets.car').unlink(missing_ok=True)      # biểu tượng AppleScript mặc định
            (res / 'applet.icns').unlink(missing_ok=True)
        else:
            shutil.rmtree(app, ignore_errors=True)
    res.mkdir(parents=True, exist_ok=True)
    (contents / 'MacOS').mkdir(parents=True, exist_ok=True)
    launcher = res / 'launcher'
    launcher.write_text(launcher_script(str(engine_dir)), encoding='utf-8')
    launcher.chmod(0o755)
    if kind == 'script':        # không có osacompile: chương trình chính là shell (Mac chip Apple có thể hỏi Rosetta)
        exe = contents / 'MacOS' / 'launcher'
        exe.write_text('#!/bin/bash\nexec /bin/bash "$(dirname "$0")/../Resources/launcher" "$@"\n', encoding='utf-8')
        exe.chmod(0o755)
        (contents / 'PkgInfo').write_bytes(b'APPL????')
    icon = make_icns(find_icon_png(engine_dir), res / 'AppIcon.icns', work)
    (res / MARKER).write_text('Gói do bộ cài BDS Studio tạo – cài lại sẽ thay gói này.\n', encoding='utf-8')
    plist = info_plist('applet' if kind == 'applet' else 'launcher', common.VERSION, bundle_id(), bool(icon),
                       base=base, script_exec=kind == 'script')
    (contents / 'Info.plist').write_bytes(plist_bytes(plist))
    plutil = tool('plutil')
    if plutil and not run([plutil, '-lint', contents / 'Info.plist']):
        raise RuntimeError('Info.plist không hợp lệ (plutil -lint)')
    xattr = tool('xattr')
    if xattr:
        run([xattr, '-cr', app])                   # không cờ quarantine / Finder info → codesign + Gatekeeper êm
    codesign = tool('codesign')
    signed = bool(codesign) and run([codesign, '--force', '--deep', '--sign', '-', app])
    return {'kind': kind, 'icon': icon, 'signed': signed}


def remove_path(p: Path) -> None:
    if p.is_symlink() or p.is_file():
        p.unlink()
    elif p.is_dir():
        shutil.rmtree(p)


def old_command_shortcut(p: Path) -> bool:
    """Lối tắt BDS Studio.command do bộ cài bản cũ tạo (không xoá tệp người dùng tự viết)."""
    try:
        t = p.read_text(encoding='utf-8', errors='replace')
    except OSError:
        return False
    return len(t) < 4096 and ('bộ cài tạo' in t or 'start_mac.command' in t)


def install(engine_dir: Path, apps_dir: Path, desktop: Path, dry: bool = False) -> dict:
    engine_dir = engine_dir.resolve()
    app = apps_dir / f'{APP_NAME}.app'
    link = desktop / f'{APP_NAME}.app'
    old_cmd = desktop / f'{APP_NAME}.command'
    if dry:
        return {'ok': True, 'dry': True, 'app': str(app), 'desktop': str(link)}
    if (app.exists() or app.is_symlink()) and not is_ours(app):
        raise RuntimeError(f'{app} đã có (không phải do bộ cài tạo) – đổi tên/xoá gói đó rồi chạy lại')
    apps_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='.bds_app_', dir=str(apps_dir)))
    try:
        info = build_bundle(engine_dir, work / f'{APP_NAME}.app', work)
        if app.exists() or app.is_symlink():
            remove_path(app)                       # cài lại: thay gói cũ của chính bộ cài
        os.replace(work / f'{APP_NAME}.app', app)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    os.utime(app)                                  # Finder/Dock đọc lại biểu tượng
    if os.access(LSREGISTER, os.X_OK):
        run([LSREGISTER, '-f', app])
    desktop_ok = False
    try:
        desktop.mkdir(parents=True, exist_ok=True)
        if link.is_symlink() or (link.is_dir() and is_ours(link)):
            remove_path(link)
        if not link.exists():
            link.symlink_to(app)
            desktop_ok = True
        if old_cmd.is_file() and old_command_shortcut(old_cmd):
            old_cmd.unlink()
    except OSError:
        desktop_ok = False
    info.update({'ok': True, 'app': str(app), 'desktop': str(link) if desktop_ok else ''})
    return info


def summary(r: dict) -> str:
    if r.get('dry'):
        return f"Sẽ tạo {r['app']} (biểu tượng ngôi nhà vàng, mở không hiện cửa sổ Terminal) + lối tắt trên màn hình nền"
    where = "màn hình nền + Ứng dụng (Launchpad)" if r.get('desktop') else "Ứng dụng (Launchpad) – chưa đặt được lên màn hình nền"
    icon = '' if r.get('icon') else ' – chưa tạo được biểu tượng ngôi nhà (dùng biểu tượng mặc định)'
    kind = ' – máy thiếu osacompile nên dùng cách dự phòng (Mac chip Apple có thể hỏi cài Rosetta)' if r.get('kind') == 'script' else ''
    return f"Đã tạo 'BDS Studio' ở {where}{icon}{kind}"


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    def opt(name, default):
        return Path(argv[argv.index(name) + 1]).expanduser() if name in argv else default
    home = Path.home()
    engine_dir = opt('--engine', common.ENGINE_ROOT)
    try:
        r = install(engine_dir, opt('--apps-dir', home / 'Applications'), opt('--desktop', home / 'Desktop'),
                    dry='--dry-run' in argv)
    except Exception as e:  # noqa: BLE001
        print(f'Không tạo được BDS Studio.app: {e}')
        return 1
    print(summary(r))
    return 0 if r.get('dry') or (r.get('icon') and r.get('kind') == 'applet' and r.get('desktop')) else 3


if __name__ == '__main__':
    sys.exit(main())
