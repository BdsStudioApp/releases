"""Cầu nối "qua đêm": job `video_map` do Nguồn ý tưởng (duyệt 21h) hoặc phòng Nhân viên tạo → dự án cảnh (cfg.json
dựng được bằng render_map) → hàng đợi thông minh dựng NHÁP 480p (queue_smart, loại 'preview') → kết quả vào Chờ duyệt.

Job nhận (CONTRACT §1/§9, bảng `jobs`):
  - Ý tưởng duyệt 21h (web/packs/bds/_lib/ideas.js batchJobs): status `queued`, input {overnight:true, scenes:[{kind,title,facts}], title, topic, sources}
  - Phòng Nhân viên (web/packs/bds/_lib/staff.js renderJob + staff.py): status `waiting_approval`, input {from_staff:true, script}
Kết quả ghi vào output.draft = {state: queued|running|done|error, res:'480p', queue_id, project, file, duration, error, at};
job ý tưởng chuyển `running` khi vào hàng rồi `waiting_approval` khi có nháp (7h anh duyệt ở Chờ duyệt).

Hai đường:
  1) Máy dựng tự kéo bằng vé `engine.token` (app đóng): StaffRunner gọi Bridge.sync(client) khi chạy phòng + mỗi 10 phút 21h–7h.
  2) App đang mở trên máy này: POST /scenes/overnight {jobs:[...]} → trả các dòng đã cập nhật; GET /scenes/overnight → dòng có nháp xong.
Dàn cảnh thiếu dữ liệu bản đồ (không toạ độ) → cảnh "thẻ số liệu" (không bịa vị trí). Bản đồ nền = dữ liệu OSM vector có sẵn
của dự án mẫu (engine/projects/_mau_moi) – không tải tile.
"""
import copy
import json
import os
import re
import threading
import time
from pathlib import Path

import common

PREFIX = 'dem_'
RES = '480p'
PULL_EVERY_S = 600
WINDOW = (21, 7)                      # 21h → 7h sáng: kéo job mới để dựng qua đêm
MAX_SCENES = 8
KIND_KICKER = {'hook': 'Tin chính', 'map': 'Vị trí', 'stat': 'Số liệu', 'compare': 'So sánh', 'timeline': 'Mốc thời gian',
               'doc': 'Văn bản', 'checklist': 'Cần nhớ'}
GLOBAL_KEYS = ('format', 'origin', 'geo', 'names', 'extent_m', 'base_m_per_px', 'brand', 'footer')
# chữ MẪU của dự án mẫu ở bản bán (tools/sale_build.mjs quét tên kênh của chủ → chữ mẫu) – không bao giờ in lên video của khách
PLACEHOLDER_CHANNELS = ('Tên của bạn | Thương hiệu của bạn', 'Kênh của bạn')


def _parse(v):
    if isinstance(v, dict):
        return dict(v)
    try:
        d = json.loads(v or '{}')
        return d if isinstance(d, dict) else {}
    except (TypeError, ValueError):
        return {}


def _txt(s, n=120):
    return re.sub(r'\s+', ' ', str(s or '')).strip()[:n]


def project_name(job_id):
    s = re.sub(r'[^A-Za-z0-9_-]+', '_', str(job_id or ''))[:60].strip('_')
    if not s:
        raise ValueError('Job thiếu id')
    return PREFIX + s


def wants(row):
    """Job video_map cần dựng nháp qua đêm (chưa có output.draft)."""
    if not isinstance(row, dict) or row.get('type') != 'video_map' or int(row.get('deleted') or 0):
        return False
    inp, out = _parse(row.get('input')), _parse(row.get('output'))
    if out.get('draft') or out.get('rejected'):
        return False
    if inp.get('overnight') and row.get('status') == 'queued':
        return bool(inp.get('scenes') or inp.get('script') or inp.get('title'))
    if inp.get('from_staff') and row.get('status') == 'waiting_approval':
        return bool(inp.get('script') or inp.get('scenes'))
    return False


# ───────────────────────── dàn cảnh → cfg.json ─────────────────────────
def _template():
    try:
        return json.loads((common.TEMPLATE_PROJECT / 'cfg.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {'format': '9:16'}


def _split_fact(t):
    m = re.match(r'^\s*([\d][\d.,]*)\s*(.*)$', str(t or ''))
    return (m.group(1), _txt(m.group(2), 24)) if m else (None, '')


def _host(u):
    m = re.match(r'^https?://(?:www\.)?([^/:?#]+)', str(u or ''))
    return m.group(1) if m else ''


def _facts(sc):
    out = []
    for f in sc.get('facts') or []:
        if isinstance(f, dict) and _txt(f.get('text')):
            out.append({'text': _txt(f.get('text'), 60), 'source': str(f.get('source') or '')})
        elif isinstance(f, str) and _txt(f):
            out.append({'text': _txt(f, 60), 'source': ''})
    return out


def _map_points(sc):
    """Toạ độ cảnh bản đồ nếu dàn cảnh có (ll hoặc items[{name, ll}]). Không có → None (dùng thẻ số liệu)."""
    pts = []
    if isinstance(sc.get('ll'), (list, tuple)) and len(sc['ll']) == 2:
        pts.append({'name': _txt(sc.get('place') or sc.get('title'), 40), 'll': sc['ll']})
    for it in sc.get('items') or []:
        if isinstance(it, dict) and isinstance(it.get('ll'), (list, tuple)) and len(it['ll']) == 2:
            pts.append({'name': _txt(it.get('name'), 40) or 'Điểm', 'll': it['ll']})
    good = []
    for p in pts:
        try:
            lat, lon = float(p['ll'][0]), float(p['ll'][1])
        except (TypeError, ValueError):
            continue
        if 8 <= lat <= 24 and 102 <= lon <= 110:          # trong lãnh thổ VN
            good.append({'name': p['name'], 'll': [lat, lon]})
    return good or None


def _card_scene(kind, title, facts, sub):
    vals = [(f, _split_fact(f['text'])) for f in facts]
    card = {'title': _txt(title, 40) or KIND_KICKER.get(kind, 'Số liệu')}
    if kind == 'checklist':
        card['list'] = [_txt(f['text'], 60) for f in facts][:3] or ['Kiểm văn bản gốc', 'Hỏi rõ tiến độ', 'Theo dõi kênh để xem tiếp']
    else:
        num = next(((f, v) for f, v in vals if v[0]), None)
        if num:
            f, (value, unit) = num
            card['big'] = {'value': value, 'unit': unit, 'note': 'Nguồn: ' + (_host(f['source']) or 'đang kiểm chứng')}
        rows = [[KIND_KICKER.get(kind, 'Mục'), f['text']] for f, v in vals if not (num and f is num[0])][:4]
        if rows:
            card['rows'] = rows
        if not num and not rows:
            card['rows'] = [['Số liệu', 'Đang kiểm chứng']]
    return {'card': card, 'subs': [sub], 'dur': 5.0}


def outline_to_cfg(inp):
    """input của job (scenes outline hoặc script) → cfg.json tối thiểu cho render_map (mẫu cảnh studio)."""
    tpl = _template()
    cfg = {k: copy.deepcopy(tpl[k]) for k in GLOBAL_KEYS if k in tpl}
    cfg.setdefault('format', '9:16')
    cfg.update({'legend': False, 'sfx': False, 'make_cover': False, 'items': [], 'scenes': []})
    title = _txt(inp.get('title') or inp.get('topic'), 90) or 'Video nháp'
    src = next((s.get('url') for s in inp.get('sources') or [] if isinstance(s, dict) and s.get('url')), '') or inp.get('url') or ''
    outline = [s for s in (inp.get('scenes') or []) if isinstance(s, dict)]
    if not outline and inp.get('script'):
        parts = [p for p in re.split(r'\n+|(?<=[.!?])\s+', str(inp['script'])) if _txt(p)]
        parts = [re.sub(r'^[A-ZĐ ]{2,12}:\s*', '', _txt(p, 160)) for p in parts]
        outline = [{'kind': 'hook', 'title': parts[0] if parts else title}] + \
                  [{'kind': 'stat', 'title': title, 'say': p} for p in parts[1:MAX_SCENES - 1]] + [{'kind': 'checklist', 'title': 'Cần nhớ'}]
    if not outline:
        outline = [{'kind': 'hook', 'title': title}]
    n_items = 0
    for i, sc in enumerate(outline[:MAX_SCENES]):
        kind = str(sc.get('kind') or 'stat')
        stitle = _txt(sc.get('title'), 80) or title
        facts = _facts(sc)
        sub = _txt(sc.get('say') or sc.get('sub') or (stitle + ('. ' + ', '.join(f['text'] for f in facts[:2]) if facts else '')), 150)
        if kind == 'hook':
            out = {'hook': {'text': _txt(title if i == 0 else stitle, 70)}, 'subs': [sub if sub != stitle else title], 'dur': 3.5}
        elif kind == 'map' and _map_points(sc):
            ids = []
            for p in _map_points(sc)[:4]:
                n_items += 1; iid = f'p{n_items}'
                cfg['items'].append({'id': iid, 'name': p['name'], 'kind': 'star', 'color': '#FF8A3D', 'll': p['ll'], 'always_label': True})
                ids.append(iid)
            out = {'camera': {'fit': ids, 'pad': 0.6, 'min_km': 4}, 'show': ids, 'pop': ids, 'subs': [sub], 'dur': 5.5}
            if len(ids) >= 2:
                out['measure'] = [[ids[0], ids[1]]]
        else:
            out = _card_scene(kind, stitle, facts, sub)          # thiếu dữ liệu bản đồ → thẻ số liệu
        out['title'] = {'kicker': KIND_KICKER.get(kind, 'Tin'), 'text': stitle}
        fsrc = next((f['source'] for f in facts if f['source']), '') or src
        if fsrc:
            out['source'] = fsrc
        out['studio'] = {'from_outline': kind, 'kind': 'mo_dau' if kind == 'hook' else 'ban_do' if 'camera' in out else
                         'danh_sach' if kind == 'checklist' else 'the_so_lieu'}
        cfg['scenes'].append(out)
    if not cfg['items']:
        cfg.pop('extent_m', None)            # không mục nào: khung bản đồ theo nền mẫu
    cfg['title'] = title
    # QA 18/11: tên kênh của chính người dùng (job gửi kèm) – không có thì KHÔNG in chữ mẫu của dự án mẫu (bản bán:
    # "Tên của bạn | Thương hiệu của bạn") lên bản nháp.
    if _txt(inp.get('channel'), 60):
        cfg.setdefault('brand', {})['channel'] = _txt(inp.get('channel'), 60)
    elif isinstance(cfg.get('brand'), dict) and _txt(cfg['brand'].get('channel')) in PLACEHOLDER_CHANNELS:
        cfg['brand'].pop('channel', None)
    return cfg


# ───────────────────────── cầu nối hàng đợi ─────────────────────────
class Bridge:
    def __init__(self, queue_fn, path=None, clock=time.time):
        self.queue_fn = queue_fn                 # → SmartQueue (tạo lười: scenes.services(app)[0])
        self.path = Path(path) if path else common.data_dir() / 'overnight.json'
        self.clock = clock
        self.lock = threading.Lock()
        self.last_pull = 0.0
        self.map = self._load()                  # job_id → {queue_id, project, row, pushed}

    def _load(self):
        try:
            d = json.loads(self.path.read_text(encoding='utf-8'))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self):
        try:
            keep = dict(sorted(self.map.items(), key=lambda kv: kv[1].get('at', 0))[-200:])
            tmp = self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(keep, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, self.path)
        except OSError:
            pass

    def enqueue(self, row):
        """Tạo dự án cảnh + xếp 'preview' (480p, đã duyệt) → dòng job cập nhật (đưa lên máy chủ/app) hoặc None."""
        import scenes
        if not wants(row):
            return None
        jid = str(row['id'])
        with self.lock:
            m = self.map.get(jid)
            if m:                                  # đã xếp (máy chủ chưa kịp nhận) → trả lại dòng cũ, không xếp trùng
                return self._row(row, {'state': 'queued', 'queue_id': m['queue_id'], 'project': m['project']}, running=True)
        inp = _parse(row.get('input'))
        cfg = outline_to_cfg(inp)
        name = project_name(jid)
        scenes.save_cfg(name, cfg)
        q = self.queue_fn()
        it = q.submit('preview', name, voice=False, now=False, approved=True, title=f'Nháp {RES} qua đêm · ' + _txt(inp.get('title') or row.get('title'), 60))
        with self.lock:
            self.map[jid] = {'queue_id': it['id'], 'project': name, 'at': common.now_ms(), 'pushed': False,
                             'row': {k: row.get(k) for k in ('id', 'type', 'title', 'status', 'input', 'output', 'cost_estimate', 'deleted')}}
            self._save()
        return self._row(row, {'state': 'queued', 'queue_id': it['id'], 'project': name}, running=True)

    @staticmethod
    def _row(row, draft, running=False):
        out = _parse(row.get('output'))
        out['draft'] = dict(draft, res=RES, at=common.now_ms())
        status = row.get('status')
        if running and status == 'queued':
            status = 'running'
        r = dict(row, status=status, output=json.dumps(out, ensure_ascii=False), updated_at=common.now_ms())
        return r

    def results(self, fresh=None, include_pushed=False):
        """Job đã dựng xong/lỗi → dòng cập nhật (status waiting_approval + output.draft). fresh: {id: row mới nhất}."""
        q = self.queue_fn()
        out = []
        with self.lock:
            items = list(self.map.items())
        for jid, m in items:
            if m.get('pushed') and not include_pushed:
                continue
            it = q.get(m['queue_id'])
            st = (it or {}).get('state') or 'error'
            if st in ('queued', 'running'):
                continue
            base = (fresh or {}).get(jid) or m['row']
            if int(base.get('deleted') or 0) or _parse(base.get('output')).get('rejected'):
                with self.lock:
                    m['pushed'] = True
                continue
            if st == 'done':
                res = (it or {}).get('result') or {}
                draft = {'state': 'done', 'queue_id': m['queue_id'], 'project': m['project'], 'file': f'/scenes/file/{m["queue_id"]}/mp4',
                         'duration': res.get('duration'), 'width': res.get('width'), 'height': res.get('height')}
            else:
                draft = {'state': 'error', 'queue_id': m['queue_id'], 'project': m['project'],
                         'error': _txt((it or {}).get('error') or 'Hàng đợi đã dọn job này – dựng lại ở Dựng & Sửa', 300)}
            r = self._row(base, draft)
            r['status'] = 'waiting_approval'
            out.append(r)
        return out

    def ack(self, ids):
        with self.lock:
            for i in ids or []:
                if str(i) in self.map:
                    self.map[str(i)]['pushed'] = True
            self._save()

    def handle_rows(self, rows):
        ups = []
        for r in rows or []:
            try:
                u = self.enqueue(r)
            except (ValueError, KeyError, OSError) as e:
                u = self._row(r, {'state': 'error', 'error': _txt(str(e), 300)})
                u['status'] = 'waiting_approval'
            if u:
                ups.append(u)
        return ups

    # ---------- đường 1: vé máy dựng (app đóng) ----------
    def sync(self, client, rows=None, log=lambda s: None):
        """Kéo job (hoặc dùng rows vừa kéo), xếp nháp mới, đẩy kết quả đã xong. Trả {queued, done}."""
        if rows is None:
            data = client.call('sync.pull', {'since': 0, 'tables': ['jobs']}) or {}
            rows = ((data.get('changes') or {}).get('jobs')) or []
        self.last_pull = self.clock()
        fresh = {str(r.get('id')): r for r in rows if isinstance(r, dict)}
        ups = self.handle_rows([r for r in rows if wants(r)])
        done = self.results(fresh)
        ops = [{'table': 'jobs', 'op': 'upsert', 'row': r} for r in ups + done]
        if ops:
            client.call('sync.push', {'ops': ops})
            self.ack([r['id'] for r in done])
            log(f'🎬 Nháp {RES} qua đêm: xếp {len(ups)} job, gửi {len(done)} kết quả vào Chờ duyệt.')
        return {'queued': len(ups), 'done': len(done)}

    def due(self, now=None):
        """Mỗi 10 phút trong 21h–7h, hoặc khi còn kết quả chưa gửi."""
        t = now if now is not None else self.clock()
        h = time.localtime(t).tm_hour
        pending = any(not m.get('pushed') for m in self.map.values())
        in_win = h >= WINDOW[0] or h < WINDOW[1]
        return (in_win or pending) and t - self.last_pull >= PULL_EVERY_S
