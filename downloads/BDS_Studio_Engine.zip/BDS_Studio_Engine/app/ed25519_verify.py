"""Kiểm chữ ký ed25519 thuần Python (không cần thư viện ngoài) – dùng cho máy dựng tự cập nhật.

Nguồn: mã tham chiếu trong RFC 8032 "Edwards-Curve Digital Signature Algorithm (EdDSA)", mục 6 (Ed25519 Python illustration),
https://www.rfc-editor.org/rfc/rfc8032#section-6 – chỉ giữ phần KIỂM chữ ký (không có hàm ký / sinh khoá).
Giấy phép: mã trong RFC là "Code Components" theo IETF Trust Legal Provisions → Simplified BSD License:
  Copyright (c) 2017 IETF Trust and the persons identified as authors of the code. All rights reserved.
  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following
  conditions are met: (1) Redistributions of source code must retain the above copyright notice, this list of conditions and the
  following disclaimer. (2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
  the following disclaimer in the documentation and/or other materials provided with the distribution. (3) Neither the name of
  Internet Society, IETF or IETF Trust, nor the names of specific contributors, may be used to endorse or promote products derived
  from this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
Thay đổi của BDS Studio: đổi tên hàm, verify() trả False thay vì ném lỗi khi độ dài sai, dùng hashlib.sha512.
Chỉ dùng để KIỂM chữ ký công khai (không có bí mật) nên không cần chạy thời gian hằng định.
"""
import hashlib

p = 2**255 - 19                                                        # số nguyên tố của trường
d = -121665 * pow(121666, p - 2, p) % p                                # hệ số đường cong
q = 2**252 + 27742317777372353535851937790883648493                    # bậc nhóm (L)
_SQRT_M1 = pow(2, (p - 1) // 4, p)


def _inv(x):
    return pow(x, p - 2, p)


def _sha512_modq(s):
    return int.from_bytes(hashlib.sha512(s).digest(), 'little') % q


def point_add(P, Q):
    A, B = (P[1] - P[0]) * (Q[1] - Q[0]) % p, (P[1] + P[0]) * (Q[1] + Q[0]) % p
    C, D = 2 * P[3] * Q[3] * d % p, 2 * P[2] * Q[2] % p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % p, G * H % p, F * G % p, E * H % p)


def point_mul(s, P):
    Q = (0, 1, 1, 0)                                                   # phần tử trung hoà
    while s > 0:
        if s & 1:
            Q = point_add(Q, P)
        P = point_add(P, P)
        s >>= 1
    return Q


def point_equal(P, Q):
    if (P[0] * Q[2] - Q[0] * P[2]) % p != 0:
        return False
    if (P[1] * Q[2] - Q[1] * P[2]) % p != 0:
        return False
    return True


def _recover_x(y, sign):
    if y >= p:
        return None
    x2 = (y * y - 1) * _inv(d * y * y + 1) % p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p != 0:
        x = x * _SQRT_M1 % p
    if (x * x - x2) % p != 0:
        return None
    if (x & 1) != sign:
        x = p - x
    return x


_GY = 4 * _inv(5) % p
_GX = _recover_x(_GY, 0)
G = (_GX, _GY, 1, _GX * _GY % p)                                       # điểm cơ sở


def point_compress(P):
    zinv = _inv(P[2])
    x = P[0] * zinv % p
    y = P[1] * zinv % p
    return int.to_bytes(y | ((x & 1) << 255), 32, 'little')


def point_decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, 'little')
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % p)


def verify(public, msg, signature):
    """True khi signature (64 byte) là chữ ký ed25519 hợp lệ của msg (bytes) bằng khoá công khai public (32 byte)."""
    if not isinstance(public, (bytes, bytearray)) or not isinstance(signature, (bytes, bytearray)):
        return False
    if len(public) != 32 or len(signature) != 64:
        return False
    A = point_decompress(bytes(public))
    if not A:
        return False
    Rs = bytes(signature[:32])
    R = point_decompress(Rs)
    if not R:
        return False
    s = int.from_bytes(signature[32:], 'little')
    if s >= q:
        return False
    h = _sha512_modq(Rs + bytes(public) + bytes(msg))
    sB = point_mul(s, G)
    hA = point_mul(h, A)
    return point_equal(sB, point_add(R, hA))
