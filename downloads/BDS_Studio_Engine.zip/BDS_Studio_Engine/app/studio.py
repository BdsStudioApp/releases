"""Studio GĐ1 (giao diện cũ) – nay ở /studio. Dự án lưu ở ~/BDS Studio/Du an/<tên>/cfg.json.
Việc dựng đi qua hàng đợi chung (không chạy chồng với Ollama), kết quả ở ~/BDS Studio/Video/."""
import json
import re
import shutil

import common

NAME_RE = re.compile(r'^[\w\-\.]{1,80}$', re.UNICODE)


def pdir(name):
    if not NAME_RE.match(name or '') or name.startswith('.'):
        raise ValueError('Tên dự án không hợp lệ')
    return common.projects_dir() / name


def ensure_template():
    d = common.projects_dir() / '_mau_moi'
    if not (d / 'cfg.json').is_file() and (common.TEMPLATE_PROJECT / 'cfg.json').is_file():
        d.mkdir(parents=True, exist_ok=True)
        shutil.copy(common.TEMPLATE_PROJECT / 'cfg.json', d / 'cfg.json')


def list_projects(manager):
    ensure_template()
    out = []
    for d in sorted(common.projects_dir().iterdir()):
        if (d / 'cfg.json').is_file():
            js = [j for j in manager.list() if (manager.jobs[j['id']].get('_spec_summary') or {}).get('name') == d.name]
            outs = [{'job': j['id'], 'key': k, 'file': f} for j in js if j['state'] == 'done' for k, f in j['outputs'].items()]
            out.append({'name': d.name, 'outputs': outs[:12]})
    return out


def read_cfg(name):
    return (pdir(name) / 'cfg.json').read_text(encoding='utf-8')


def save_cfg(name, txt):
    json.loads(txt)
    (pdir(name) / 'cfg.json').write_text(txt, encoding='utf-8')


def new_project(name):
    d = pdir(name)
    if d.exists():
        raise FileExistsError('Dự án đã có')
    d.mkdir(parents=True)
    shutil.copy(common.TEMPLATE_PROJECT / 'cfg.json', d / 'cfg.json')


def run(manager, name, mode):
    d = pdir(name)
    cfg = json.loads((d / 'cfg.json').read_text(encoding='utf-8'))
    return manager.submit({'type': 'video_map', 'cfg': cfg, 'mode': mode, 'name': name, 'project_dir': str(d)})


PAGE = r'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BDS Video Studio</title><style>
:root{--bg:#0d1420;--panel:#152031;--line:#26364d;--tx:#e8eef6;--mut:#93a4ba;--acc:#ff8a3d}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:14px -apple-system,system-ui,sans-serif}
header{padding:12px 18px;border-bottom:1px solid var(--line);display:flex;gap:12px;align-items:center}
header b{color:var(--acc);font-size:16px}main{display:grid;grid-template-columns:220px 1fr 420px;gap:12px;padding:12px;height:calc(100vh - 50px)}
.box{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px;overflow:auto}
.proj{padding:7px 9px;border-radius:7px;cursor:pointer}.proj.on{background:#22344f}.proj small{color:var(--mut)}
textarea{width:100%;height:calc(100% - 46px);background:#0a111b;color:#d6e2f0;border:1px solid var(--line);border-radius:8px;font:12px ui-monospace,Menlo,monospace;padding:8px}
button{background:#22344f;color:var(--tx);border:1px solid var(--line);border-radius:7px;padding:7px 11px;cursor:pointer;margin:0 6px 6px 0}
button.pri{background:var(--acc);color:#111;border:0;font-weight:600}pre{white-space:pre-wrap;font:11px ui-monospace,Menlo,monospace;color:#b8c7da;max-height:220px;overflow:auto}
#prev img,#prev video{max-width:100%;border-radius:8px;margin-top:8px}a{color:#7fc4ff}.mut{color:var(--mut)}
</style></head><body><header><b>BDS Video Studio</b><span class="mut">Giai đoạn 1 · dựng bản đồ offline · <a href="/">về BDS Studio</a></span></header>
<main><div class="box"><div id="plist"></div><hr style="border-color:#26364d"><button onclick="newp()">+ Dự án mới</button></div>
<div class="box"><div><button onclick="save()">Lưu</button><button onclick="run('check')">Kiểm tra</button><button onclick="run('stills')">Ảnh nháp</button>
<button class="pri" onclick="run('gif')">Xuất GIF</button><button class="pri" onclick="run('mp4')">Xuất MP4</button><span id="cur" class="mut"></span></div>
<textarea id="cfg" spellcheck="false"></textarea></div>
<div class="box"><b>Tiến trình</b><pre id="log">Chọn dự án bên trái.</pre><b>Kết quả</b><div id="outs"></div><div id="prev"></div></div></main>
<script>
let cur=null,timer=null;const A='/studio/api';
async function j(u,o){const r=await fetch(u,o);if(!r.ok)throw new Error(await r.text());return r.json()}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function load(){const ps=await j(A+'/projects');plist.innerHTML=ps.map(p=>`<div class="proj ${p.name==cur?'on':''}" data-n="${esc(p.name)}">${esc(p.name)}<br><small>${p.outputs.length} tệp</small></div>`).join('');
 plist.querySelectorAll('.proj').forEach(e=>e.onclick=()=>pick(e.dataset.n));if(cur)showOuts(ps.find(p=>p.name==cur))}
async function pick(n){cur=n;cfg.value=await (await fetch(A+'/project/'+encodeURIComponent(n))).text();document.getElementById('cur').textContent=' · '+n;load()}
function showOuts(p){if(!p)return;outs.innerHTML=p.outputs.map(o=>`<div><a href="/files/${o.job}/${encodeURIComponent(o.key)}" target="_blank">${esc(o.file)}</a> <a class="mut" href="#" data-u="/files/${o.job}/${encodeURIComponent(o.key)}" data-f="${esc(o.file)}">xem</a></div>`).join('')||'<span class="mut">Chưa có</span>';
 outs.querySelectorAll('a[data-u]').forEach(a=>a.onclick=e=>{e.preventDefault();pv(a.dataset.u,a.dataset.f)})}
function pv(u,f){u+='?t='+Date.now();prev.innerHTML=f.endsWith('.mp4')?`<video src="${u}" controls loop autoplay muted></video>`:`<img src="${u}">`}
async function save(){if(!cur)return;try{JSON.parse(cfg.value)}catch(e){alert('JSON lỗi: '+e.message);return}await j(A+'/project/'+encodeURIComponent(cur),{method:'POST',body:cfg.value});log.textContent='Đã lưu.'}
async function run(m){if(!cur)return;await save();const r=await j(A+'/run/'+encodeURIComponent(cur)+'?mode='+m,{method:'POST'});poll(r.job,m)}
function poll(id,m){clearInterval(timer);timer=setInterval(async()=>{const s=await j('/jobs/'+id);log.textContent=(s.state=='queued'?'Đang xếp hàng…\n':'')+s.log;log.scrollTop=1e9;if(s.state=='done'||s.state=='error'){clearInterval(timer);await load();if(s.state=='done'){const k=m=='gif'?'gif':m=='mp4'?'mp4':m=='stills'?'contact':null;if(k&&s.outputs[k])pv('/files/'+id+'/'+k,s.outputs[k])}}},800)}
async function newp(){const n=prompt('Tên dự án (không dấu, không cách, vd: cau_tran_hung_dao):');if(!n)return;await j(A+'/new/'+encodeURIComponent(n),{method:'POST'});await pick(n)}
load();
</script></body></html>'''
