"""Báo cáo cài đặt + quét máy + phần mở rộng của máy dựng (thợ I, bản để bán – CHƯA phát hành trong 1.0.4).

  GET/POST /install/origins   nguồn app tin cậy (app riêng từng khách): {add|remove|primary: 'https://…'} – common.py
  GET/POST /install/launch    biểu tượng mở đâu: {target: web|may} (launch.py – lần đầu thử web app, rồi giữ nguyên)
  GET  /install/report        báo cáo bộ cài lõi (install_mac.command / install_windows.ps1 ghi ~/.bds_studio/install_report.json)
  GET  /hw/scan               kết quả quét máy đã lưu (chưa có → quét nhanh, không đo thử)
  POST /hw/scan {bench?}      quét lại (bench:true = đo thử dựng 10 giây) → lưu ~/.bds_studio/hwscan.json
  GET  /packs/list            phần mở rộng cài sau (Ollama, tạo ảnh/Video AI trên máy) + máy có hợp không
  POST /packs/install {id}    cài phần mở rộng – CHƯA có (trả PACK_NOT_READY); khi làm: chỉ tải từ kho phát hành có ký số,
                              KHÔNG nhận tệp từ người dùng (quyết định 16/11 "không cho khách tự cập nhật qua file").

Định dạng báo cáo (schema 1) – xem parse_report() và docs/CONTRACT.md mục "1.0.6-I".

Dòng lệnh (máy kiểm thử GitHub, bộ phận hỗ trợ):  python app/install_api.py [--dry] [--json] [--expect-reuse]
  in tóm tắt + bước nào ⚠/✗ kèm chi tiết; thoát 0 khi cài trọn (result ok; --dry: result dry), 1 nếu chưa;
  --expect-reuse: thêm điều kiện B2–B4 báo "Đã có…" (lần chạy lại không cài lại Python/ffmpeg/thư viện).
"""
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import common
import hwscan

REPORT_SCHEMA = 1
STEP_STATUS = ('ok', 'skipped', 'warn', 'failed', 'dry', 'pending')
STEP_IDS = ('B0', 'B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B9')   # B8 quét nhanh + chọn cách xử lý video · B9 Video AI offline

# Phần mở rộng cài sau qua máy dựng – DANH SÁCH TẠM (chưa phát hành). min_tier khớp hwscan.recommend().
PACKS = [
    {'id': 'ai_offline_small', 'title': 'AI soạn trên máy – mô hình nhỏ', 'kind': 'ollama', 'size_gb': 2.5, 'min_tier': 'co_ban',
     'desc': 'Ollama + mô hình ~3–4 tỷ tham số: nháp tin Zalo, tóm tắt khách, dữ liệu không ra khỏi máy.'},
    {'id': 'ai_offline_medium', 'title': 'AI soạn trên máy – mô hình vừa', 'kind': 'ollama', 'size_gb': 5, 'min_tier': 'kha',
     'desc': 'Mô hình ~7–8 tỷ tham số, viết tốt hơn, cần 16 GB RAM.'},
    {'id': 'ai_offline_large', 'title': 'AI soạn trên máy – mô hình lớn', 'kind': 'ollama', 'size_gb': 9, 'min_tier': 'manh',
     'desc': 'Mô hình 14 tỷ tham số trở lên.'},
    {'id': 'image_ai_offline', 'title': 'Tạo ảnh AI trên máy', 'kind': 'model', 'size_gb': 7, 'min_tier': 'kha',
     'desc': 'Tạo ảnh minh hoạ không cần Internet.'},
    {'id': 'video_ai_offline', 'title': 'Video AI OFFLINE', 'kind': 'model', 'size_gb': 25, 'min_tier': 'manh',
     'desc': 'Tạo cảnh video bằng AI ngay trên máy – chỉ máy hạng Mạnh.'},
]


# ---------------- báo cáo cài đặt ----------------
def report_path(dry: bool = False) -> Path:
    env = os.environ.get('BDS_INSTALL_REPORT')
    if env and not dry:
        return Path(env).expanduser()
    return common.data_dir() / ('install_report_dry.json' if dry else 'install_report.json')


def _s(v, n=500):
    return '' if v is None else str(v)[:n]


def parse_report(raw) -> dict:
    """raw: chuỗi JSON / bytes / dict do bộ cài ghi → báo cáo đã chuẩn hoá + tóm tắt tiếng Việt.

    Chịu được: BOM UTF-8 (PowerShell), `steps` là 1 đối tượng thay vì mảng (PowerShell 5.1), thiếu trường, trạng thái lạ.
    Trả {valid, error?, report, result: ok|partial|failed|dry|unknown, failed_step, summary}.
    """
    if isinstance(raw, (bytes, bytearray)):
        raw = bytes(raw).decode('utf-8-sig', errors='replace')
    if isinstance(raw, str):
        try:
            raw = json.loads(raw.lstrip('﻿'))
        except ValueError as e:
            return {'valid': False, 'error': f'Báo cáo cài đặt hỏng: {e}', 'result': 'unknown', 'report': None,
                    'failed_step': None, 'summary': 'Báo cáo cài đặt bị hỏng – chạy lại bộ cài.'}
    if not isinstance(raw, dict):
        return {'valid': False, 'error': 'Báo cáo không phải đối tượng JSON', 'result': 'unknown', 'report': None,
                'failed_step': None, 'summary': 'Báo cáo cài đặt bị hỏng – chạy lại bộ cài.'}
    steps_in = raw.get('steps') or []
    if isinstance(steps_in, dict):
        steps_in = [steps_in]
    steps = []
    for st in steps_in if isinstance(steps_in, list) else []:
        if not isinstance(st, dict):
            continue
        status = _s(st.get('status'), 20).lower()
        steps.append({'id': _s(st.get('id'), 8), 'label': _s(st.get('label'), 200),
                      'status': status if status in STEP_STATUS else 'warn', 'code': _s(st.get('code'), 8),
                      'message': _s(st.get('message')), 'detail': _s(st.get('detail')),
                      'seconds': _num(st.get('seconds'))})
    mode = 'dry' if _s(raw.get('mode')) == 'dry' else 'real'
    failed = next((s for s in steps if s['status'] == 'failed'), None)
    err = raw.get('error') if isinstance(raw.get('error'), dict) else None
    if failed is None and err and err.get('code'):
        failed = next((s for s in steps if s['id'] == err.get('code')), None) or {
            'id': _s(err.get('code'), 8), 'label': '', 'status': 'failed', 'code': _s(err.get('code'), 8), 'message': _s(err.get('message'))}
    if mode == 'dry':
        result = 'dry'
    elif failed:
        result = 'failed'
    elif any(s['status'] == 'warn' for s in steps) or not raw.get('finished_at'):
        result = 'partial'
    else:
        result = 'ok'
    rep = {
        'schema': int(_num(raw.get('schema')) or 0), 'tool': _s(raw.get('tool'), 40), 'mode': mode,
        'os': _s(raw.get('os'), 20), 'os_version': _s(raw.get('os_version'), 60), 'arch': _s(raw.get('arch'), 20),
        'engine_dir': _s(raw.get('engine_dir'), 400), 'engine_version': _s(raw.get('engine_version'), 20),
        'started_at': _s(raw.get('started_at'), 40), 'finished_at': _s(raw.get('finished_at'), 40),
        'python': _s(raw.get('python'), 200), 'python_source': _s(raw.get('python_source'), 40),
        'ffmpeg': _s(raw.get('ffmpeg'), 200), 'ffmpeg_source': _s(raw.get('ffmpeg_source'), 40),
        'video': raw.get('video') if isinstance(raw.get('video'), bool) else None,
        'tier': _s(raw.get('tier'), 20), 'video_mode': _s(raw.get('video_mode'), 20), 'video_pack': _s(raw.get('video_pack'), 20),
        'steps': steps,
        'error': {'code': failed['code'] or failed['id'], 'message': failed['message']} if failed else None,
    }
    if result in ('ok', 'dry') and raw.get('video') is False and rep['video_mode'] == 'online':   # câu đầu [2]: chỉ AI trên mạng
        summary = 'Chỉ dùng AI trên mạng – không cài gì lên máy; làm video bằng AI trong web app (tính phí theo nhà cung cấp).'
    elif result in ('ok', 'dry') and raw.get('video') is False:   # câu đầu [3]: không làm video trên máy này → không cài gì
        summary = 'Không làm video trên máy này – không cài gì; dùng web app trên trình duyệt/điện thoại.'
    elif result == 'ok':
        summary = 'Đã cài xong Máy dựng video.'
    elif result == 'dry':
        summary = 'Chạy thử bộ cài (không cài gì).'
    elif result == 'failed':
        msg = failed['message'] or f"Lỗi {failed['id']}"
        summary = msg if 'chạy lại' in msg else msg + ' – bấm chạy lại bộ cài (bộ cài làm tiếp từ bước lỗi).'
    else:
        summary = 'Cài chưa trọn – mở bộ cài chạy lại để làm nốt.'
    return {'valid': rep['schema'] == REPORT_SCHEMA, 'report': rep, 'result': result,
            'failed_step': failed['id'] if failed else None, 'summary': summary,
            **({} if rep['schema'] == REPORT_SCHEMA else {'error': f"Phiên bản báo cáo lạ ({rep['schema']})"})}


def _num(v):
    try:
        return float(v) if v not in (None, '') else None
    except (TypeError, ValueError):
        return None


def read_report(dry: bool = False) -> dict:
    p = report_path(dry)
    try:
        data = p.read_bytes()
    except OSError:
        return {'ok': True, 'present': False, 'result': 'unknown', 'report': None, 'failed_step': None,
                'summary': 'Chưa có báo cáo cài đặt (máy dựng chạy từ mã nguồn hoặc bộ cài bản cũ).'}
    if len(data) > 2 * 2**20:
        return {'ok': True, 'present': True, 'valid': False, 'result': 'unknown', 'report': None, 'failed_step': None,
                'summary': 'Báo cáo cài đặt quá lớn – chạy lại bộ cài.'}
    res = parse_report(data)
    return dict(res, ok=True, present=True)


# ---------------- phần mở rộng ----------------
def packs_list(scan=None) -> dict:
    scan = scan or hwscan.load()
    tier = scan.get('tier') if scan else None
    disk = float(scan.get('free_disk_gb') or 0) if scan else None
    out = []
    for p in PACKS:
        fits = tier is not None and hwscan.TIERS.index(tier) >= hwscan.TIERS.index(p['min_tier'])
        out.append(dict(p, min_tier_label=hwscan.TIER_LABEL[p['min_tier']], fits=fits,
                        disk_ok=None if disk is None else disk >= p['size_gb'] * 1.5,
                        available=False, state='not_released'))
    return {'ok': True, 'tier': tier, 'scanned': scan is not None, 'packs': out,
            'note': 'Phần mở rộng sẽ tải từ kho phát hành có ký số khi phát hành – chưa cài được trong bản này.'}


def pack_install(body: dict):
    pid = str((body or {}).get('id') or '')
    pack = next((p for p in PACKS if p['id'] == pid), None)
    if not pack:
        return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có phần mở rộng này.'}}
    scan = hwscan.load()
    if scan and hwscan.TIERS.index(scan['tier']) < hwscan.TIERS.index(pack['min_tier']):
        return 409, {'ok': False, 'error': {'code': 'HW_TOO_WEAK', 'message':
                     f"Máy hạng {scan['tier_label']} – phần này cần hạng {hwscan.TIER_LABEL[pack['min_tier']]} trở lên.",
                     'tier': scan['tier'], 'min_tier': pack['min_tier']}}
    return 501, {'ok': False, 'error': {'code': 'PACK_NOT_READY', 'id': pid,
                 'message': 'Phần mở rộng này chưa phát hành – sẽ cài được ở bản sau (tải từ kho phát hành có ký số).'}}


# ---------------- định tuyến (server.py gọi) ----------------
def handle(app, method, p, q, h):
    if method == 'GET' and p == '/install/report':
        return 200, read_report(dry=q.get('dry') == '1')
    if p == '/install/launch':                      # biểu tượng BDS Studio mở web app dùng chung hay bản tại máy (launch.py)
        import launch
        if method == 'GET':
            return 200, launch.info()
        try:
            return 200, launch.set_target(str(h.json_body().get('target') or ''))
        except ValueError as e:
            return 400, {'ok': False, 'error': {'code': 'BAD_INPUT', 'message': str(e)}}
    if p == '/install/origins':                     # nguồn app tin cậy (app riêng từng khách): Cài đặt › Máy của tôi
        if method == 'GET':
            return 200, common.app_origins_info()
        if not common.is_allowed_origin(h.origin()) and h.origin() is not None:
            return 403, {'ok': False, 'error': {'code': 'ORIGIN_DENIED', 'message': 'Chỉ đổi được từ app đã được máy dựng tin cậy.'}}
        body = h.json_body()
        try:
            if body.get('remove'):
                common.remove_user_origin(str(body['remove']))
            if body.get('add'):
                common.add_user_origin(str(body['add']), how='user', primary=bool(body.get('primary')))
            elif body.get('primary'):
                common.add_user_origin(str(body['primary']), how='user', primary=True)
        except ValueError as e:
            return 400, {'ok': False, 'error': {'code': 'BAD_INPUT', 'message': str(e)}}
        return 200, common.app_origins_info()
    if p == '/hw/scan':
        busy = bool(app and app.jobs.busy())
        if method == 'GET':
            info = None if q.get('fresh') == '1' else hwscan.load()
            cached = info is not None
            if info is None:
                info = hwscan.scan_locked(bench=False, busy=busy)
                if info is None:
                    return 409, {'ok': False, 'error': {'code': 'BUSY', 'message': 'Đang quét máy – chờ vài giây.'}}
            return 200, dict(info, ok=True, cached=cached)
        body = h.json_body()
        info = hwscan.scan_locked(bench=bool(body.get('bench')), busy=busy)
        if info is None:
            return 409, {'ok': False, 'error': {'code': 'BUSY', 'message': 'Đang quét máy – chờ vài giây.'}}
        return 200, dict(info, ok=True, cached=False)
    if method == 'GET' and p == '/packs/list':
        return 200, packs_list()
    if method == 'POST' and p == '/packs/install':
        if not common.accept_origin(h.origin()):          # như /update: bắt buộc có Origin hợp lệ
            return 403, {'ok': False, 'error': {'code': 'ORIGIN_DENIED', 'message': 'Trang này không được phép cài phần mở rộng.'}}
        return pack_install(h.json_body())
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}


# ---------------- dòng lệnh ----------------
def _elapsed_s(rep: dict):
    try:
        a, b = (datetime.strptime(rep[k], '%Y-%m-%dT%H:%M:%SZ') for k in ('started_at', 'finished_at'))
        return int((b - a).total_seconds())
    except (KeyError, TypeError, ValueError):
        return None


def report_lines(res: dict) -> list:
    """Tóm tắt báo cáo thành vài dòng tiếng Việt: dòng đầu = kết quả · nguồn Python · nguồn ffmpeg · hạng máy · thời gian."""
    rep = res.get('report') or {}
    head = [res.get('summary') or '', 'python=' + (rep.get('python_source') or '?'),
            'ffmpeg=' + (rep.get('ffmpeg_source') or '?'), 'hạng=' + (rep.get('tier') or '?')]
    if rep.get('video_mode'):
        head.append('video=' + rep['video_mode'] + ('' if rep.get('video_pack') != 'skip' else ' (chưa cài Bộ công cụ dựng video)'))
    secs = _elapsed_s(rep)
    if secs is not None:
        head.append(f'chạy {secs} giây')
    out = [' · '.join(head)]
    for st in rep.get('steps') or []:
        if st['status'] in ('warn', 'failed'):
            out.append(f"  {st['id']} {'⚠' if st['status'] == 'warn' else '✗'} {st['message']}"
                       + (f" ({st['detail']})" if st.get('detail') else ''))
    return out


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    dry = '--dry' in argv
    res = read_report(dry=dry)
    if '--json' in argv:
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        print('\n'.join(report_lines(res)))
    rc = 0 if res.get('result') == ('dry' if dry else 'ok') else 1
    if '--expect-reuse' in argv:      # chạy lại bộ cài: Python, ffmpeg, .venv phải được giữ ("Đã có…"), không cài lại
        steps = {st['id']: st for st in (res.get('report') or {}).get('steps') or []}
        # B3 'skipped' = Bộ công cụ dựng video không cài (máy Cơ bản chọn không cài) – không phải cài lại
        redo = [i for i in ('B2', 'B3', 'B4') if not (steps.get(i, {}).get('message') or '').startswith('Đã có')
                and not (i == 'B3' and steps.get(i, {}).get('status') == 'skipped')]
        if redo:
            print('Chạy lại nhưng vẫn cài lại bước: ' + ', '.join(redo))
            rc = 1
    return rc


if __name__ == '__main__':
    common.console_utf8()           # cửa sổ lệnh Windows (cp1252) không in được chữ Việt → ép UTF-8 (lỗi CI 17/11)
    sys.exit(main())
