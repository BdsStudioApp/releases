"""Chạy MỘT lượt mô hình video mã nguồn mở trên máy (gói Video AI offline, thợ V) – tiến trình riêng, gọi từ videoai.start_run.

  python3 videoai_runner.py --args '{"model_dir", "pipeline": "wan"|"cogvideox", "prompt", "negative", "frames", "fps",
                                     "width", "height", "image", "out"}'

In ra "PROGRESS <0..1>" theo từng bước khử nhiễu; xong ghi MP4 vào "out". Cần torch + diffusers (cài bằng "Cài thư viện" trong app).
Chỉ mở mô hình đã tải về thư mục máy (local_files_only) – không tự tải gì thêm.
"""
import json
import sys


def device():
    import torch
    if torch.cuda.is_available():
        return 'cuda', torch.bfloat16
    if getattr(torch.backends, 'mps', None) and torch.backends.mps.is_available():
        return 'mps', torch.float16
    return 'cpu', torch.float32


def main():
    a = json.loads(sys.argv[sys.argv.index('--args') + 1])
    from diffusers import DiffusionPipeline
    from diffusers.utils import export_to_video, load_image
    dev, dtype = device()
    pipe = DiffusionPipeline.from_pretrained(a['model_dir'], torch_dtype=dtype, local_files_only=True)
    if dev == 'cuda':
        pipe.enable_model_cpu_offload()          # card 24 GB: tải dần từng phần (theo hướng dẫn của Wan / CogVideo)
    else:
        pipe.to(dev)
    steps = 50 if a['pipeline'] == 'cogvideox' else 40

    def cb(p, i, t, kw):
        print(f'PROGRESS {(i + 1) / steps:.3f}', flush=True)
        return kw
    kw = dict(prompt=a['prompt'], num_frames=int(a['frames']), num_inference_steps=steps, callback_on_step_end=cb)
    if a.get('negative'):
        kw['negative_prompt'] = a['negative']
    if a['pipeline'] == 'wan':
        kw.update(height=int(a['height']), width=int(a['width']))
    if a.get('image'):
        kw['image'] = load_image(a['image'])
    frames = pipe(**kw).frames[0]
    export_to_video(frames, a['out'], fps=int(a['fps']))
    print('PROGRESS 1.000', flush=True)


if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()
