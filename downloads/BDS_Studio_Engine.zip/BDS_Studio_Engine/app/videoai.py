"""Gói mở rộng "Video AI" (thợ V, Thử nghiệm – mặc định TẮT) – phần máy dựng.

Quyết định 16/11 (sổ lỗi 1.0.3 mục 16 + "MÁY DỰNG QUÉT CẤU HÌNH"): AI tạo cảnh đẹp hơn (nhân vật dẫn, phối cảnh, minh hoạ,
B-roll) rồi GHÉP vào video của máy dựng. Cảnh bản đồ / số liệu vẫn do máy dựng làm (không thay bằng AI). Cảnh phối cảnh 3D /
phong thủy ghi "ẢNH MINH HOẠ"; cảnh AI khác KHÔNG gắn nhãn chữ "AI" lên hình (người dùng tự bật nhãn nội dung AI của nền tảng).

  GET  /videoai/status                 hạng máy (hwscan của thợ I), danh mục mô hình offline + giấy phép, runtime, tiến độ
  GET  /videoai/clips                  clip đã nhập  ·  GET /videoai/clip/<id>  xem clip (video/mp4, hỗ trợ Range)
  POST /videoai/import?name=&provider=&kind=   thân = tệp clip (mp4/mov/webm ≤ 300 MB) – Flow tải về / Veo qua máy chủ
  POST /videoai/import_url             {url, provider, kind, prompt}  tải clip Kling/Runway (https, không mạng nội bộ)
  POST /videoai/insert                 {cfg, clip_id, at, kind, subs?, dur?, replace?}  → cfg có cảnh type "ai_clip"
  POST /videoai/flow_package           {title, scenes:[{prompt, seconds, aspect, title}], images:[{name, mime, b64}]} → .zip
  ── Offline (chỉ máy hạng Mạnh, mô hình giấy phép cho dùng thương mại – docs/VIDEO_AI_GIAY_PHEP.md) ──
  GET/POST /videoai/local/setup        cài thư viện chạy mô hình (torch + diffusers) – tải lớn, hỏi trước
  POST /videoai/mode                   {mode: online|offline|later} đổi cách xử lý video đã chọn lúc cài (videomode.py)
  POST /videoai/local/plan             {model} → giấy phép đối chiếu Hugging Face + dung lượng THẬT từng tệp
  GET/POST /videoai/local/download     {model, confirm_bytes} tải mô hình khi cần (không bao giờ kèm trong bộ cài)
  POST /videoai/local/delete           {model}
  POST /videoai/local/run              {model, prompt, negative?, seconds, aspect, image?} → {id}
  GET  /videoai/local/run/<id>         {state, progress, clip_id, error}   ·   POST /videoai/local/cancel {id}

Clip lưu ở <data_dir>/videoai/clips/<id>.<ext> (+ <id>.json). Đường dẫn tuyệt đối đi thẳng vào cfg (jobs._resolve_paths giữ nguyên).
"""
import base64
import hashlib
import importlib.util
import io
import ipaddress
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path

import common

MAX_CLIP_BYTES = 300 * 2**20
CLIP_EXT = ('.mp4', '.mov', '.webm', '.m4v')
KINDS = ('presenter', 'perspective', 'fengshui', 'illustration', 'broll')
LABEL_KINDS = ('perspective', 'fengshui')          # cảnh 3D / phong thủy → "ẢNH MINH HOẠ" (quyết định 16/11)
LABEL_TEXT = 'ẢNH MINH HOẠ'
# khoá cảnh do máy dựng vẽ (bản đồ, thẻ số liệu, bảng tin) – không được thay bằng clip AI
ENGINE_KEYS = ('camera', 'show', 'pop', 'draw', 'measure', 'card', 'panel', 'spotlight', 'labels', 'focus')
RUNNER = Path(__file__).with_name('videoai_runner.py')
HF_API = 'https://huggingface.co/api/models/'
HF_FILE = 'https://huggingface.co/{repo}/resolve/{rev}/{path}'
HF_HOSTS = ('huggingface.co',)
HF_HOST_SUFFIX = ('.huggingface.co', '.hf.co')      # tệp lớn chuyển hướng sang CDN của Hugging Face
UA = f'BDSStudio-Engine/{common.VERSION} (video ai)'
RUNTIME_PKGS = ['torch', 'diffusers', 'transformers', 'accelerate', 'imageio', 'imageio-ffmpeg', 'ftfy', 'sentencepiece']
DISK_RESERVE_GB = 5.0
# torch trên PyPI cho Windows là bản CHỈ CPU (whl ~127 MB, không có CUDA – đối chiếu pypi.org/pypi/torch/json 17/11/2026) → máy
# Windows card NVIDIA cài torch từ kho CUDA chính thức của PyTorch (lệnh "pip install torch --index-url …/whl/cu128" ở
# pytorch.org › Get Started). Kho này lỗi → cài torch PyPI (chạy CPU, rất chậm) và báo rõ. Mac/Linux: PyPI (Mac có MPS).
TORCH_INDEX_WIN = 'https://download.pytorch.org/whl/cu128'
# Dung lượng TẢI VỀ thư viện chạy mô hình (cộng từng tệp .whl Python 3.12 của bản mới nhất trên PyPI cùng thư viện phụ thuộc,
# đo bằng pypi.org/pypi/<gói>/json ngày 17/11/2026). Chiếm ổ sau khi giải nén nhiều hơn. Windows: torch bản CUDA tải từ
# download.pytorch.org – máy kiểm thử không vào được nên KHÔNG ghi số (dung lượng thật hiện trong nhật ký pip khi tải).
RUNTIME_DOWNLOAD = {'mac': 224770124, 'windows_without_torch': 106682984, 'checked': '2026-11-17'}
# Video AI ONLINE (khớp PROVIDERS trong web/packs/bds/videoai_taocanh/logic.js – test kiểm). App KHÔNG ghi sẵn giá:
# Chủ nhập bảng giá theo trang giá chính thức, app báo chi phí trước mỗi lần tạo.
ONLINE_PROVIDERS = [
    {'id': 'flow', 'name': 'Flow / Veo', 'cost': 'trừ tín dụng gói Gemini AI Pro của anh/chị (tính theo clip)'},
    {'id': 'veo_api', 'name': 'Veo API (Gemini API)', 'cost': 'trả phí theo giây video, bằng khoá Gemini của anh/chị'},
    {'id': 'runway', 'name': 'Runway', 'cost': 'trả phí theo tài khoản Runway của anh/chị (tín dụng theo giây)'},
    {'id': 'kling', 'name': 'Kling', 'cost': 'tài khoản Kling riêng (app chưa xác minh tài liệu API)'},
]

# ───────────── danh mục mô hình offline (giấy phép đối chiếu repo chính thức 16/11/2026 – docs/VIDEO_AI_GIAY_PHEP.md) ─────────────
COMMERCIAL_OK = ('apache-2.0', 'mit')        # chỉ giấy phép cho NGƯỜI DÙNG CUỐI dùng thương mại không điều kiện doanh thu / lãnh thổ
MODELS = [
    {'id': 'wan2.2-ti2v-5b', 'title': 'Wan 2.2 TI2V-5B – chữ/ảnh → video 720p', 'repo': 'Wan-AI/Wan2.2-TI2V-5B-Diffusers',
     'pipeline': 'wan', 'modes': ['t2v', 'i2v'], 'license': 'apache-2.0', 'width': 1280, 'height': 704, 'fps': 24, 'max_frames': 121,
     'vram_note': 'Wan công bố chạy được trên card 24 GB (vd RTX 4090) khi bật tải dần mô hình',
     'license_url': 'https://github.com/Wan-Video/Wan2.2/blob/main/LICENSE.txt', 'checked': '2026-11-16',
     'min_vram_gb': 24, 'size_bytes': 34201418400, 'size_checked': '2026-11-17'},
    {'id': 'wan2.1-t2v-1.3b', 'title': 'Wan 2.1 T2V-1.3B – chữ → video 480p (nhẹ)', 'repo': 'Wan-AI/Wan2.1-T2V-1.3B-Diffusers',
     'pipeline': 'wan', 'modes': ['t2v'], 'license': 'apache-2.0', 'width': 832, 'height': 480, 'fps': 16, 'max_frames': 81,
     'vram_note': 'Wan công bố cần khoảng 8,19 GB VRAM',
     'license_url': 'https://github.com/Wan-Video/Wan2.1/blob/main/LICENSE.txt', 'checked': '2026-11-16',
     'min_vram_gb': 8, 'size_bytes': 28928887859, 'size_checked': '2026-11-17'},
    {'id': 'cogvideox-2b', 'title': 'CogVideoX-2B – chữ → video 720×480', 'repo': 'THUDM/CogVideoX-2b',
     'pipeline': 'cogvideox', 'modes': ['t2v'], 'license': 'apache-2.0', 'width': 720, 'height': 480, 'fps': 8, 'max_frames': 49,
     'vram_note': 'CogVideo công bố diffusers FP16 từ khoảng 4 GB (có tải dần mô hình)',
     'license_url': 'https://github.com/zai-org/CogVideo#model-license', 'checked': '2026-11-16',
     'min_vram_gb': 4, 'size_bytes': 13775539179, 'size_checked': '2026-11-17'},
    # KHÔNG cho dùng – ghi lý do để người dùng hiểu vì sao không có trong danh sách
    {'id': 'cogvideox-5b', 'title': 'CogVideoX-5B', 'repo': 'THUDM/CogVideoX-5b', 'license': 'cogvideox',
     'blocked': 'Giấy phép CogVideoX: dùng thương mại phải đăng ký riêng với nhà phát hành, giới hạn 1 triệu lượt/tháng.',
     'license_url': 'https://github.com/zai-org/CogVideo/blob/main/MODEL_LICENSE', 'checked': '2026-11-16'},
    {'id': 'hunyuanvideo', 'title': 'HunyuanVideo / HunyuanVideo-1.5', 'repo': 'tencent/HunyuanVideo', 'license': 'tencent-hunyuan-community',
     'blocked': 'Giấy phép Tencent Hunyuan Community: không áp dụng ở EU, Anh, Hàn Quốc; trên 100 triệu người dùng/tháng phải xin phép – không đáp ứng "người dùng cuối dùng thương mại không điều kiện".',
     'license_url': 'https://github.com/Tencent-Hunyuan/HunyuanVideo/blob/main/LICENSE.txt', 'checked': '2026-11-16'},
    {'id': 'ltx-2', 'title': 'LTX-2 / LTX-2.x', 'repo': 'Lightricks/LTX-2', 'license': 'ltx-2-community',
     'blocked': 'Giấy phép LTX-2 Community: tổ chức doanh thu từ 10 triệu USD/năm phải mua giấy phép thương mại.',
     'license_url': 'https://github.com/Lightricks/LTX-2/blob/main/LICENSE-2', 'checked': '2026-11-16'},
    {'id': 'svd-xt', 'title': 'Stable Video Diffusion (SVD / SVD-XT)', 'repo': 'stabilityai/stable-video-diffusion-img2vid-xt',
     'license': 'svd-non-commercial',
     'blocked': 'Giấy phép trong repo chính thức là "Stable Video Diffusion NON-COMMERCIAL Community License" – không cho dùng thương mại.',
     'license_url': 'https://github.com/Stability-AI/generative-models/blob/main/model_licenses/LICENSE-SVD', 'checked': '2026-11-16'},
]


# size_bytes = tổng tệp plan() sẽ tải (Hugging Face API ?blobs=true, đo 17/11/2026 – chỉ để báo trước; lúc tải vẫn đo lại THẬT
# và bắt xác nhận đúng số đo mới). min_vram_gb lấy từ vram_note (công bố của nhà phát hành).
RECOMMEND_ORDER = ('wan2.2-ti2v-5b', 'wan2.1-t2v-1.3b', 'cogvideox-2b')   # đẹp nhất trước – chọn mô hình đầu tiên máy đủ VRAM


def usable_vram_gb(scan) -> float:
    """VRAM dùng được cho mô hình: card NVIDIA lớn nhất; chip Apple dùng bộ nhớ chung ~2/3 (phần còn lại cho hệ điều hành)."""
    gpus = (scan or {}).get('gpus') or []
    nv = max([float(g.get('vram_gb') or 0) for g in gpus if g.get('vendor') == 'nvidia'] or [0])
    apple = max([float(g.get('vram_gb') or 0) for g in gpus if g.get('vendor') == 'apple' and g.get('unified')] or [0])
    return max(nv, round(apple * 2 / 3, 1))


def recommended_model(scan=None):
    """Mô hình gợi ý cho máy này (giấy phép cho dùng thương mại + đủ VRAM). Không đủ cho mô hình nào → mô hình nhẹ nhất."""
    v = usable_vram_gb(scan)
    ok = [model(i) for i in RECOMMEND_ORDER if license_allows(model(i))]
    return next((m for m in ok if v >= m['min_vram_gb'] - 0.5), ok[-1])


def license_allows(m) -> bool:
    return bool(m) and not m.get('blocked') and str(m.get('license', '')).lower() in COMMERCIAL_OK


def model(mid):
    for m in MODELS:
        if m['id'] == mid:
            return m
    return None


def allowed_model(mid):
    m = model(str(mid or ''))
    if not m:
        raise KeyError('Không có mô hình này trong danh mục')
    if not license_allows(m):
        raise PermissionError(m.get('blocked') or 'Giấy phép mô hình không cho dùng thương mại')
    return m


class Refused(Exception):
    """Lỗi có mã + HTTP status riêng (TIER, LICENSE, BUSY…)."""
    def __init__(self, code, message, status=409):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


# ───────────── thư mục ─────────────
def root() -> Path:
    p = common.data_dir() / 'videoai'
    p.mkdir(parents=True, exist_ok=True)
    return p


def clips_dir() -> Path:
    p = root() / 'clips'; p.mkdir(parents=True, exist_ok=True); return p


def models_dir() -> Path:
    p = root() / 'models'; p.mkdir(parents=True, exist_ok=True); return p


def _save_json(p: Path, v):
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding='utf-8'); os.replace(tmp, p)


def _load_json(p: Path, d=None):
    try:
        return json.loads(Path(p).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return d


def _txt(s, n=200):
    return re.sub(r'\s+', ' ', str(s or '')).strip()[:n]


# ───────────── hạng máy (thợ I: engine/app/hwscan.py → hwscan.load()) ─────────────
def tier_info(d=None):
    """d: kết quả quét có sẵn (bộ cài bước B8 quét nhanh, chưa lưu) – không có thì đọc tệp quét đã lưu."""
    if d is None:
        try:
            import hwscan
            d = hwscan.load()
        except Exception:          # hwscan chưa có (bản cũ) / tệp quét hỏng
            d = None
    if not d:
        return None
    rec = next((r for r in d.get('recommendations') or [] if r.get('id') == 'video_ai_offline'), None)
    return {'tier': d.get('tier'), 'label': d.get('tier_label'), 'at': d.get('at'),
            'offline_show': bool(rec and rec.get('show')), 'offline_reason': (rec or {}).get('reason', '')}


def offline_gate(scan=None):
    """→ {allowed, reason}. Chỉ máy hạng Mạnh (đủ ổ trống) mới mở Video AI offline."""
    t = tier_info(scan)
    if not t:
        return {'allowed': False, 'reason': 'Chưa quét cấu hình máy – vào Cài đặt › Máy của tôi bấm "Quét lại máy".', 'tier': None}
    if t['tier'] != 'manh':
        return {'allowed': False, 'reason': f'Máy hạng {t.get("label") or t["tier"]} – Video AI ngay trên máy cần máy hạng Mạnh. Dùng AI trên mạng.', 'tier': t}
    if not t['offline_show']:
        return {'allowed': False, 'reason': t['offline_reason'] or 'Máy chưa đủ điều kiện chạy Video AI ngay trên máy.', 'tier': t}
    return {'allowed': True, 'reason': '', 'tier': t}


# ───────────── clip ─────────────
def sniff(data: bytes):
    if len(data) >= 12 and data[4:8] == b'ftyp':
        brand = data[8:12]
        return '.mov' if brand == b'qt  ' else '.mp4'
    if data[:4] == b'\x1aE\xdf\xa3':
        return '.webm'
    return None


def _probe_duration(p: Path):
    ff = common.which('ffprobe')
    if not ff:
        return None
    try:
        r = subprocess.run([ff, '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', str(p)],
                           capture_output=True, text=True, timeout=20)
        return round(float(r.stdout.strip()), 2) if r.returncode == 0 and r.stdout.strip() else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def import_bytes(data: bytes, name='', provider='', kind='', prompt='', extra=None) -> dict:
    if not data:
        raise ValueError('Tệp clip trống')
    if len(data) > MAX_CLIP_BYTES:
        raise ValueError(f'Clip quá lớn (tối đa {MAX_CLIP_BYTES // 2**20} MB)')
    ext = sniff(data)
    if not ext:
        raise ValueError('Không phải tệp video MP4/MOV/WEBM')
    cid = 'c' + time.strftime('%Y%m%d') + uuid.uuid4().hex[:8]
    p = clips_dir() / (cid + ext)
    p.write_bytes(data)
    meta = {'id': cid, 'file': str(p), 'ext': ext, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'name': _txt(name, 120), 'provider': _txt(provider, 40), 'kind': kind if kind in KINDS else '',
            'prompt': _txt(prompt, 2000), 'created_at': common.now_ms(), 'duration': _probe_duration(p)}
    meta.update(extra or {})
    _save_json(clips_dir() / (cid + '.json'), meta)
    return meta


def get_clip(cid):
    if not re.match(r'^c\d{8}[0-9a-f]{8}$', str(cid or '')):
        raise KeyError('Mã clip không hợp lệ')
    meta = _load_json(clips_dir() / (cid + '.json'))
    if not meta or not Path(meta.get('file', '')).is_file():
        raise KeyError('Không có clip này')
    return meta


def list_clips():
    out = []
    for f in sorted(clips_dir().glob('c*.json'), reverse=True):
        m = _load_json(f)
        if m and Path(m.get('file', '')).is_file():
            out.append({k: m.get(k) for k in ('id', 'name', 'provider', 'kind', 'size', 'duration', 'created_at')})
    return out[:200]


def _host_ok(host: str) -> bool:
    host = (host or '').lower().strip('[]')
    if not host or host in ('localhost',) or host.endswith(('.local', '.internal', '.localhost')):
        return False
    try:
        ip = ipaddress.ip_address(host)
        return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast)
    except ValueError:
        return '.' in host


def check_clip_url(u):
    pr = urllib.parse.urlparse(str(u or ''))
    if pr.scheme != 'https' or not _host_ok(pr.hostname or ''):
        raise ValueError('Chỉ nhận đường dẫn https công khai của clip')
    return pr.geturl()


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_clip_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _download(url, limit, opener=None, check=check_clip_url, timeout=60):
    check(url)
    op = opener or urllib.request.build_opener(_SafeRedirect())
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    buf = io.BytesIO()
    with op.open(req, timeout=timeout) as r:
        n = int(r.headers.get('Content-Length') or 0)
        if n and n > limit:
            raise ValueError(f'Tệp quá lớn ({n // 2**20} MB, tối đa {limit // 2**20} MB)')
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            buf.write(chunk)
            if buf.tell() > limit:
                raise ValueError(f'Tệp quá lớn (tối đa {limit // 2**20} MB)')
    return buf.getvalue()


def import_url(url, provider='', kind='', prompt='', opener=None):
    data = _download(check_clip_url(url), MAX_CLIP_BYTES, opener=opener)
    return import_bytes(data, name=urllib.parse.urlparse(url).path.rsplit('/', 1)[-1], provider=provider, kind=kind, prompt=prompt)


# ───────────── ghép vào cfg của máy dựng (hợp đồng với gói Video – thợ D) ─────────────
def engine_made(sc) -> bool:
    """Cảnh bản đồ / số liệu / bảng tin do máy dựng vẽ."""
    if not isinstance(sc, dict):
        return False
    if sc.get('type') == 'ai_clip':
        return False
    return any(sc.get(k) for k in ENGINE_KEYS)


def insert_clip(cfg, clip, at=None, kind='broll', subs=None, dur=None, replace=False):
    """cfg (dict) + clip (meta) → (cfg mới, vị trí, cảnh báo). Cảnh mới: {"type":"ai_clip", "media":{src,…}, "subs", "dur", "ai_clip":{…}}.
    - Cảnh bản đồ/số liệu KHÔNG bị thay (replace) – chỉ chèn cảnh AI xen giữa.
    - kind perspective/fengshui → media.ai = true + nhãn "ẢNH MINH HOẠ"; còn lại media.own = true (không nhãn chữ "AI")."""
    if not isinstance(cfg, dict) or not isinstance(cfg.get('scenes'), list):
        raise ValueError('cfg.json thiếu "scenes"')
    if kind not in KINDS:
        raise ValueError('Loại cảnh AI không hợp lệ')
    cfg = json.loads(json.dumps(cfg))
    scenes = cfg['scenes']
    n = len(scenes)
    at = n if at is None else int(at)
    if not 0 <= at <= (n - 1 if replace else n):
        raise ValueError('Vị trí cảnh không hợp lệ')
    warnings = []
    if replace and engine_made(scenes[at]):
        raise Refused('ENGINE_SCENE', 'Cảnh bản đồ / số liệu do máy dựng làm – không thay bằng AI. Chèn cảnh AI xen giữa.', 409)
    lines = [s for s in (subs if isinstance(subs, list) else []) if isinstance(s, (str, dict))][:4]
    if replace and not lines:
        lines = scenes[at].get('subs') or []
    clip_dur = clip.get('duration')
    d = float(dur) if dur else (clip_dur or 5.0)
    if clip_dur and d > clip_dur + 0.05:
        warnings.append(f'Clip dài {clip_dur:g} giây, cảnh {d:g} giây → khung cuối của clip được giữ đến hết cảnh.')
    label = kind in LABEL_KINDS
    media = {'src': clip['file']}
    if label:
        media.update(ai=True, label=LABEL_TEXT)
    else:
        media['own'] = True
    sc = {'type': 'ai_clip', 'subs': lines, 'dur': round(max(1.0, min(d, 20.0)), 2), 'media': media,
          'ai_clip': {'clip_id': clip['id'], 'provider': clip.get('provider') or '', 'kind': kind, 'label': label}}
    if replace:
        scenes[at] = sc
    else:
        scenes.insert(at, sc)
    return cfg, at, warnings


# ───────────── gói Flow (bàn giao tay – không điều khiển giao diện Flow) ─────────────
FLOW_URL = 'https://labs.google/fx/tools/flow'
IMG_EXT = {'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp'}


def flow_package(d) -> tuple:
    scenes = [s for s in (d.get('scenes') or []) if isinstance(s, dict) and _txt(s.get('prompt'), 10)][:20]
    if not scenes:
        raise ValueError('Chưa có lời nhắn cảnh nào')
    title = _txt(d.get('title'), 80) or 'Video AI'
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        guide = [f'GÓI FLOW – {title}', '',
                 f'1. Mở Google Flow: {FLOW_URL} (đăng nhập tài khoản có gói Gemini AI Pro).',
                 '2. Mỗi cảnh: tải ảnh tham chiếu (thư mục anh_tham_chieu) vào Ingredients, dán lời nhắn trong canh_XX.txt, xem số tín dụng Flow hiện rồi mới bấm tạo.',
                 '3. Tải clip về máy, trong app BDS Studio › Video AI bấm "Nhập clip" đúng cảnh.', '']
        for i, s in enumerate(scenes, 1):
            name = f'canh_{i:02d}.txt'
            body = (f'Cảnh {i}: {_txt(s.get("title"), 80)}\nThời lượng: {_txt(s.get("seconds"), 8)} giây · Khung: {_txt(s.get("aspect"), 8) or "9:16"}\n\n'
                    + str(s.get('prompt'))[:6000])
            z.writestr(name, body)
            guide.append(f'- {name}: {_txt(s.get("title"), 80)}')
        n_img = 0
        for im in (d.get('images') or [])[:12]:
            if not isinstance(im, dict):
                continue
            ext = IMG_EXT.get(str(im.get('mime')))
            if not ext:
                continue
            try:
                raw = base64.b64decode(str(im.get('b64') or ''), validate=True)
            except ValueError:
                continue
            if not raw or len(raw) > 8 * 2**20:
                continue
            n_img += 1
            base = re.sub(r'[^0-9A-Za-z_-]+', '_', _txt(im.get('name'), 40)) or f'anh_{n_img}'
            z.writestr(f'anh_tham_chieu/{n_img:02d}_{base}{ext}', raw)
        z.writestr('HUONG_DAN.txt', '\n'.join(guide) + '\n')
        z.writestr('loi_nhan.json', json.dumps({'title': title, 'flow_url': FLOW_URL, 'scenes': scenes}, ensure_ascii=False, indent=1))
    name = common.safe_name(title, 'video_ai') + '_flow.zip'
    return buf.getvalue(), name, n_img


# ───────────── OFFLINE: thư viện chạy mô hình ─────────────
class Task:
    """Việc nền một lúc một việc (cài thư viện / tải mô hình)."""
    def __init__(self):
        self.lock = threading.Lock()
        self.st = {'state': 'idle'}

    def status(self):
        with self.lock:
            return dict(self.st)

    def set(self, **kw):
        with self.lock:
            self.st.update(kw)

    def running(self):
        return self.status().get('state') == 'running'


SETUP = Task()
DOWNLOAD = Task()
RUNS = {}
RUNS_LOCK = threading.Lock()
_runtime_cache = {'at': 0, 'v': None}


def runtime_status(force=False):
    if not force and time.time() - _runtime_cache['at'] < 30 and _runtime_cache['v'] is not None:
        return _runtime_cache['v']
    v = {'torch': importlib.util.find_spec('torch') is not None, 'diffusers': importlib.util.find_spec('diffusers') is not None}
    v['ready'] = v['torch'] and v['diffusers']
    _runtime_cache.update(at=time.time(), v=v)
    return v


def pip_cmd(pkgs=None):
    return [sys.executable, '-m', 'pip', 'install', '--upgrade', '--disable-pip-version-check'] + list(pkgs or RUNTIME_PKGS)


def pip_cmds():
    """Các lệnh pip cài thư viện chạy mô hình, theo thứ tự. Windows: torch bản CUDA trước (kho PyTorch), rồi phần còn lại từ
    PyPI (torch đã có thì pip giữ nguyên – không --upgrade sang bản chỉ CPU vì thư viện khác chỉ cần torch có sẵn)."""
    if common.IS_WIN:
        return [pip_cmd(['torch']) + ['--index-url', TORCH_INDEX_WIN],
                pip_cmd([p for p in RUNTIME_PKGS if p != 'torch'])]
    return [pip_cmd()]


def run_setup(log=None) -> dict:
    """Cài thư viện chạy mô hình NGAY (không chạy nền). log(dòng) nhận từng dòng pip (bộ cài in ra làm tiến độ).
    → {ok, log (đuôi), error, torch_source}. Dùng chung cho POST /videoai/local/setup (chạy nền) và bộ cài bước B9."""
    tail, src = [], 'pypi'
    for i, cmd in enumerate(pip_cmds()):
        ok, out = _pip_stream(cmd, log)
        tail += out
        if not ok and common.IS_WIN and i == 0:            # kho CUDA lỗi → torch PyPI (chỉ CPU) để vẫn chạy được, báo rõ
            if log:
                log('Kho torch CUDA chưa tải được – cài torch bản thường (chỉ chạy CPU, rất chậm)')
            ok, out = _pip_stream(pip_cmd(['torch']), log)
            tail += out; src = 'pypi-cpu'
        elif ok and common.IS_WIN and i == 0:
            src = 'pytorch-cuda'
        if not ok:
            _runtime_cache['at'] = 0
            return {'ok': False, 'log': '\n'.join(tail)[-3000:], 'error': 'pip báo lỗi – xem nhật ký', 'torch_source': src}
    _runtime_cache['at'] = 0
    return {'ok': True, 'log': '\n'.join(tail)[-3000:], 'error': '', 'torch_source': src}


def _pip_stream(cmd, log):
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                             errors='replace', env=common.child_env())
    except OSError as e:
        return False, [f'Không chạy được pip: {e}']
    lines = []
    for line in p.stdout:
        line = line.rstrip()
        if line:
            lines = (lines + [line])[-60:]
            if log:
                log(line)
    return p.wait() == 0, lines


VERIFY_CODE = ('import json, torch, diffusers; mps = getattr(torch.backends, "mps", None); '
               'print(json.dumps({"torch": torch.__version__, "diffusers": diffusers.__version__, '
               '"cuda": bool(torch.cuda.is_available()), "mps": bool(mps and mps.is_available())}))')


def verify_runtime(timeout=300) -> dict:
    """NẠP THẬT torch + diffusers trong tiến trình riêng (find_spec chỉ thấy tệp, không biết Windows có chặn DLL hay không –
    Smart App Control chặn tệp .dll/.pyd chưa ký). → {ok, torch, diffusers, cuda, mps, error}."""
    try:
        p = subprocess.run([sys.executable, '-c', VERIFY_CODE], capture_output=True, text=True, encoding='utf-8', errors='replace',
                           timeout=timeout, env=common.child_env())
    except (OSError, subprocess.SubprocessError) as e:
        return {'ok': False, 'error': str(e)[:400]}
    if p.returncode == 0:
        try:
            return dict(json.loads(p.stdout.strip().splitlines()[-1]), ok=True, error='')
        except (ValueError, IndexError):
            pass
    return {'ok': False, 'error': ((p.stderr or '') + (p.stdout or '')).strip()[-600:]}


def start_setup(confirm=False):
    gate = offline_gate()
    if not gate['allowed']:
        raise Refused('TIER', gate['reason'])
    if not confirm:
        raise Refused('CONFIRM', 'Cài thư viện chạy mô hình tải nhiều GB từ PyPI (dung lượng thật hiện trong nhật ký khi tải). Bấm xác nhận để cài.', 400)
    if SETUP.running():
        return SETUP.status()
    SETUP.st = {'state': 'running', 'started_at': common.now_ms(), 'log': ''}

    def run():
        r = run_setup()
        SETUP.set(state='done' if r['ok'] else 'error', log=r['log'], finished_at=common.now_ms(), error=r['error'],
                  torch_source=r['torch_source'])
    threading.Thread(target=run, daemon=True, name='videoai-setup').start()
    return SETUP.status()


# ───────────── OFFLINE: tải mô hình khi cần ─────────────
def _hf_host_ok(u):
    pr = urllib.parse.urlparse(u)
    h = (pr.hostname or '').lower()
    if pr.scheme != 'https' or not (h in HF_HOSTS or h.endswith(HF_HOST_SUFFIX)):
        raise ValueError('Chỉ tải mô hình từ huggingface.co')
    return u


class _HFRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _hf_host_ok(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _hf_json(url, opener=None):
    _hf_host_ok(url)
    op = opener or urllib.request.build_opener(_HFRedirect())
    with op.open(urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'}), timeout=30) as r:
        return json.loads(r.read().decode('utf-8'))


def installed(mid) -> bool:
    return (models_dir() / mid / '.complete').is_file()


def plan(mid, opener=None):
    """Đối chiếu giấy phép trên trang mô hình Hugging Face + lấy dung lượng THẬT từng tệp (không đoán)."""
    m = allowed_model(mid)
    info = _hf_json(HF_API + m['repo'] + '?blobs=true', opener=opener)
    card = (info.get('cardData') or {}) if isinstance(info, dict) else {}
    lic = str(card.get('license') or '').lower()
    tags = [str(t).lower() for t in info.get('tags') or []]
    if lic != m['license'] and ('license:' + m['license']) not in tags:
        raise Refused('LICENSE', f'Giấy phép trên Hugging Face ("{lic or "không ghi"}") khác giấy phép đã kiểm ({m["license"]}) – không tải. Báo người phát triển kiểm lại.')
    rev = str(info.get('sha') or 'main')
    files = [{'path': s['rfilename'], 'size': int(s.get('size') or 0)} for s in info.get('siblings') or []
             if isinstance(s, dict) and s.get('rfilename') and not str(s['rfilename']).startswith('.')
             and not re.search(r'\.(md|png|jpe?g|gif|mp4|pdf)$', str(s['rfilename']), re.I)]
    if not files or any(f['size'] <= 0 for f in files):
        raise Refused('NO_SIZE', 'Hugging Face không trả dung lượng tệp – chưa tải được (không đoán dung lượng).')
    total = sum(f['size'] for f in files)
    free = common.free_disk_gb(models_dir())
    need_gb = round(total / 2**30 + DISK_RESERVE_GB, 1)
    return {'model': mid, 'repo': m['repo'], 'revision': rev, 'license': lic or m['license'], 'license_url': m['license_url'],
            'files': files, 'total_bytes': total, 'total_gb': round(total / 2**30, 2), 'free_disk_gb': free,
            'need_gb': need_gb, 'enough_disk': free >= need_gb}


def start_download(mid, confirm_bytes, opener=None, plan_fn=None):
    gate = offline_gate()
    if not gate['allowed']:
        raise Refused('TIER', gate['reason'])
    if DOWNLOAD.running():
        raise Refused('BUSY', 'Đang tải một mô hình khác – chờ xong.')
    pl = (plan_fn or plan)(mid, opener=opener)
    if int(confirm_bytes or 0) != pl['total_bytes']:
        raise Refused('CONFIRM', f'Cần xác nhận dung lượng {pl["total_gb"]} GB trước khi tải.', 400)
    if not pl['enough_disk']:
        raise Refused('DISK', f'Ổ đĩa còn {pl["free_disk_gb"]} GB, cần ≥ {pl["need_gb"]} GB (mô hình + {DISK_RESERVE_GB:g} GB dự phòng).')
    dest = models_dir() / mid
    dest.mkdir(parents=True, exist_ok=True)
    DOWNLOAD.st = {'state': 'running', 'model': mid, 'received': 0, 'total': pl['total_bytes'], 'file': '', 'started_at': common.now_ms()}

    def run():
        op = opener or urllib.request.build_opener(_HFRedirect())
        got = 0
        try:
            for f in pl['files']:
                target = dest / f['path']
                if not str(target.resolve()).startswith(str(dest.resolve())):
                    raise ValueError('Tên tệp không hợp lệ')
                if target.is_file() and target.stat().st_size == f['size']:
                    got += f['size']; DOWNLOAD.set(received=got); continue
                target.parent.mkdir(parents=True, exist_ok=True)
                part = target.with_name(target.name + '.part')
                url = HF_FILE.format(repo=pl['repo'], rev=pl['revision'], path=urllib.parse.quote(f['path']))
                DOWNLOAD.set(file=f['path'])
                with op.open(urllib.request.Request(_hf_host_ok(url), headers={'User-Agent': UA}), timeout=60) as r, open(part, 'wb') as out:
                    n = 0
                    while True:
                        if DOWNLOAD.status().get('state') == 'cancel':
                            raise InterruptedError('Đã huỷ tải')
                        chunk = r.read(1 << 20)
                        if not chunk:
                            break
                        out.write(chunk); n += len(chunk); DOWNLOAD.set(received=got + n)
                        if n > f['size']:
                            raise ValueError(f'{f["path"]}: lớn hơn dung lượng Hugging Face báo')
                if n != f['size']:
                    raise ValueError(f'{f["path"]}: tải thiếu ({n}/{f["size"]} byte)')
                os.replace(part, target); got += n
            _save_json(dest / '.complete', {k: pl[k] for k in ('model', 'repo', 'revision', 'license', 'total_bytes')})
            DOWNLOAD.set(state='done', received=got, finished_at=common.now_ms())
        except Exception as e:      # lỗi mạng / huỷ: giữ tệp .part, tải lại bỏ qua tệp đã đủ
            DOWNLOAD.set(state='error', error=str(e)[:300])
    threading.Thread(target=run, daemon=True, name='videoai-download').start()
    return DOWNLOAD.status()


def delete_model(mid):
    if not model(mid):
        raise KeyError('Không có mô hình này')
    if DOWNLOAD.running() and DOWNLOAD.status().get('model') == mid:
        raise Refused('BUSY', 'Mô hình đang tải – huỷ tải trước.')
    d = models_dir() / mid
    freed = common.dir_size(d) if d.exists() else 0
    shutil.rmtree(d, ignore_errors=True)
    return {'deleted': True, 'freed_bytes': freed}


# ───────────── OFFLINE: chạy mô hình ─────────────
ASPECTS = {'9:16': 'portrait', '16:9': 'landscape', '1:1': 'square'}


def frame_size(m, aspect):
    w, h = m['width'], m['height']                   # kích thước gốc ngang của mô hình
    if aspect == '9:16':
        return h, w
    if aspect == '1:1':
        return h, h
    return w, h


def runner_cmd(args: dict) -> list:
    return [sys.executable, str(RUNNER), '--args', json.dumps(args, ensure_ascii=False)]


def start_run(app, d, cmd_fn=None):
    gate = offline_gate()
    if not gate['allowed']:
        raise Refused('TIER', gate['reason'])
    m = allowed_model(d.get('model'))
    if not installed(m['id']):
        raise Refused('NOT_INSTALLED', 'Mô hình chưa tải về máy – bấm "Tải mô hình" trước.')
    if not cmd_fn and not runtime_status()['ready']:
        raise Refused('RUNTIME', 'Chưa cài thư viện chạy mô hình (torch + diffusers) – bấm "Cài thư viện".')
    prompt = str(d.get('prompt') or '').strip()
    if not prompt:
        raise ValueError('Thiếu lời nhắn cảnh')
    image = d.get('image') if isinstance(d.get('image'), dict) else None
    if image and 'i2v' not in m['modes']:
        raise ValueError('Mô hình này chỉ tạo từ chữ – bỏ ảnh tham chiếu hoặc chọn Wan 2.2 TI2V-5B')
    with RUNS_LOCK:
        if any(r['state'] == 'running' for r in RUNS.values()):
            raise Refused('BUSY', 'Đang tạo một cảnh AI khác trên máy – chờ xong.')
        if app and app.jobs.busy():
            raise Refused('BUSY', 'Máy đang dựng video – tạo cảnh AI sau khi dựng xong (không chạy chồng, tránh thiếu RAM).')
        if app and not app.jobs.ollama_enter():           # giữ chỗ: hàng dựng chờ đến khi tạo cảnh xong
            raise Refused('BUSY', 'Máy đang dựng video – thử lại sau.')
        rid = uuid.uuid4().hex[:10]
        RUNS[rid] = {'id': rid, 'state': 'running', 'progress': 0.0, 'model': m['id'], 'started_at': common.now_ms(), 'clip_id': None, 'error': ''}
    seconds = max(1.0, min(float(d.get('seconds') or 5), m['max_frames'] / m['fps']))
    frames = int(seconds * m['fps'])
    if m['pipeline'] == 'wan':
        frames = min(m['max_frames'], (frames + 2) // 4 * 4 + 1)   # Wan cần số khung 4k+1 (làm tròn lên, không quá giới hạn)
    aspect = d.get('aspect') if d.get('aspect') in ASPECTS else '9:16'
    w, hgt = frame_size(m, aspect)
    work = root() / 'runs' / rid
    work.mkdir(parents=True, exist_ok=True)
    img_path = ''
    if image:
        raw = base64.b64decode(str(image.get('b64') or ''), validate=True)
        img_path = str(work / ('ref' + IMG_EXT.get(str(image.get('mime')), '.png')))
        Path(img_path).write_bytes(raw)
    args = {'model_dir': str(models_dir() / m['id']), 'pipeline': m['pipeline'], 'prompt': prompt[:2000],
            'negative': str(d.get('negative') or '')[:1000], 'frames': frames, 'fps': m['fps'], 'width': w, 'height': hgt,
            'image': img_path, 'out': str(work / 'out.mp4')}
    cmd = (cmd_fn or runner_cmd)(args)

    def run():
        proc = None
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                                    errors='replace', env=common.child_env(), cwd=str(work))
            RUNS[rid]['pid'] = proc.pid
            tail = []
            for line in proc.stdout:
                mm = re.match(r'^PROGRESS\s+([0-9.]+)', line)
                if mm:
                    RUNS[rid]['progress'] = min(1.0, float(mm.group(1)))
                else:
                    tail = (tail + [line.rstrip()])[-30:]
            code = proc.wait()
            if RUNS[rid]['state'] == 'cancelled':
                return
            out = Path(args['out'])
            if code != 0 or not out.is_file():
                raise RuntimeError('Mô hình báo lỗi: ' + ' | '.join(tail[-4:])[:400])
            meta = import_bytes(out.read_bytes(), name=out.name, provider='local:' + m['id'], kind=d.get('kind') or '',
                                prompt=prompt, extra={'model': m['id'], 'license': m['license']})
            RUNS[rid].update(state='done', progress=1.0, clip_id=meta['id'], finished_at=common.now_ms())
        except Exception as e:
            if RUNS[rid]['state'] != 'cancelled':
                RUNS[rid].update(state='error', error=str(e)[:400])
        finally:
            if app:
                app.jobs.ollama_exit()
            shutil.rmtree(work, ignore_errors=True)
    threading.Thread(target=run, daemon=True, name='videoai-run').start()
    return {'id': rid, 'state': 'running', 'frames': frames, 'width': w, 'height': hgt}


def cancel_run(rid):
    r = RUNS.get(str(rid or ''))
    if not r:
        raise KeyError('Không có lượt tạo này')
    if r['state'] == 'running':
        r['state'] = 'cancelled'
        try:
            if r.get('pid'):
                os.kill(r['pid'], 15)
        except OSError:
            pass
    return dict(r)


def status():
    gate = offline_gate()
    out = []
    for m in MODELS:
        x = {k: m.get(k) for k in ('id', 'title', 'repo', 'license', 'license_url', 'checked', 'modes', 'vram_note', 'blocked')}
        x['allowed'] = license_allows(m)
        x['installed'] = x['allowed'] and installed(m['id'])
        out.append(x)
    import videomode                                # cách xử lý video chọn lúc cài (bước B8) + Bộ công cụ dựng video
    return {'gate': gate, 'models': out, 'runtime': runtime_status(), 'setup': SETUP.status(), 'download': DOWNLOAD.status(),
            'runs': [dict(r) for r in list(RUNS.values())[-10:]], 'clips': len(list_clips()), 'flow_url': FLOW_URL,
            'mode': videomode.status(gate)}


# ───────────── định tuyến ─────────────
def _err(code, msg, status=400):
    return status, {'ok': False, 'error': {'code': code, 'message': msg}}


def handle(app, method, p, q, hd):
    try:
        return _route(app, method, p, q, hd)
    except Refused as e:
        return _err(e.code, e.message, e.status)
    except PermissionError as e:
        return _err('LICENSE', str(e), 403)
    except KeyError as e:
        return _err('NOT_FOUND', str(e.args[0] if e.args else e), 404)
    except (urllib.error.URLError, OSError) as e:
        if isinstance(e, urllib.error.HTTPError):
            return _err('UPSTREAM', f'Máy chủ tệp trả lỗi HTTP {e.code}', 502)
        return _err('NETWORK', f'Không tải được: {getattr(e, "reason", e)}', 502)


def _route(app, method, p, q, hd):
    if method == 'GET':
        if p == '/videoai/status':
            return 200, dict(status(), ok=True)
        if p == '/videoai/clips':
            return 200, {'ok': True, 'clips': list_clips()}
        if p.startswith('/videoai/clip/'):
            meta = get_clip(p.rsplit('/', 1)[-1].split('.')[0])
            return hd.send_file(Path(meta['file']), {'X-Frame-Options': 'DENY'})
        if p == '/videoai/local/setup':
            return 200, dict(SETUP.status(), ok=True, runtime=runtime_status(force=True), packages=RUNTIME_PKGS)
        if p == '/videoai/local/download':
            return 200, dict(DOWNLOAD.status(), ok=True)
        if p.startswith('/videoai/local/run/'):
            r = RUNS.get(p.rsplit('/', 1)[-1])
            if not r:
                raise KeyError('Không có lượt tạo này')
            return 200, dict(r, ok=True)
        return _err('NOT_FOUND', 'Không có đường dẫn này', 404)
    if p == '/videoai/import':
        data = hd.body(limit=MAX_CLIP_BYTES)
        meta = import_bytes(data, name=q.get('name', ''), provider=q.get('provider', ''), kind=q.get('kind', ''), prompt=q.get('prompt', ''))
        return 200, dict(meta, ok=True)
    if p == '/videoai/import_url':
        d = hd.json_body()
        meta = import_url(d.get('url'), provider=_txt(d.get('provider'), 40), kind=d.get('kind', ''), prompt=d.get('prompt', ''))
        return 200, dict(meta, ok=True)
    if p == '/videoai/insert':
        d = hd.json_body()
        cfg = d.get('cfg')
        if isinstance(cfg, str):
            cfg = json.loads(cfg)
        clip = get_clip(d.get('clip_id'))
        new, at, warns = insert_clip(cfg, clip, d.get('at'), d.get('kind') or clip.get('kind') or 'broll', d.get('subs'), d.get('dur'), bool(d.get('replace')))
        return 200, {'ok': True, 'cfg': new, 'index': at, 'warnings': warns}
    if p == '/videoai/flow_package':
        data, name, n_img = flow_package(hd.json_body())
        return 200, data, 'application/zip', {'Content-Disposition': f'attachment; filename="{name}"', 'X-Images': str(n_img)}
    if p == '/videoai/mode':
        import videomode
        return 200, {'ok': True, 'mode': videomode.set_mode(hd.json_body().get('mode'), source='app')}
    if p == '/videoai/local/setup':
        return 200, dict(start_setup(bool(hd.json_body().get('confirm'))), ok=True)
    if p == '/videoai/local/plan':
        return 200, dict(plan(hd.json_body().get('model')), ok=True)
    if p == '/videoai/local/download':
        d = hd.json_body()
        if d.get('cancel'):
            if DOWNLOAD.running():
                DOWNLOAD.set(state='cancel')
            return 200, dict(DOWNLOAD.status(), ok=True)
        return 200, dict(start_download(d.get('model'), d.get('confirm_bytes')), ok=True)
    if p == '/videoai/local/delete':
        return 200, dict(delete_model(hd.json_body().get('model')), ok=True)
    if p == '/videoai/local/run':
        return 200, dict(start_run(app, hd.json_body()), ok=True)
    if p == '/videoai/local/cancel':
        return 200, dict(cancel_run(hd.json_body().get('id')), ok=True)
    return _err('NOT_FOUND', 'Không có đường dẫn này', 404)
