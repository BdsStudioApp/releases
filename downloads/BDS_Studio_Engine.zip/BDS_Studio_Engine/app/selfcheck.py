"""Tự kiểm tra + tự cài các thành phần của máy dựng.

check() -> [{id, name, ok, required, detail, fix, auto}]   (auto = /selfcheck/fix tự sửa được)
Fixer.start(video_pack=False) chạy nền: pip install -r requirements.txt vào .venv; tải ffmpeg nếu thiếu
(Mac: brew nếu có, không thì bản tĩnh evermeet.cx; Windows: gyan.dev essentials zip).
ffmpeg = "Bộ công cụ dựng video" (videomode.py): CHỈ bắt buộc/tự tải khi người dùng đã CHỌN gói (bộ cài [2]/[4], --video, hoặc nút
"Cài ngay"). Chưa chọn → TUỲ CHỌN (không báo thiếu, "Tự sửa" không tải – quy tắc chủ 17/11, mọi hạng máy); app bấm "Cài ngay" ở mục Bộ công cụ dựng video (màn Video) = POST /selfcheck/fix {video_pack:true} → ghi muốn cài + tải ffmpeg.
BDS_FIX_DRYRUN=1 → chỉ liệt kê việc sẽ làm (dùng khi kiểm tra tự động).
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

import common
import secrets_store

PY_PKGS = [('PIL', 'Pillow', True), ('numpy', 'numpy', True),
           ('keyring', 'keyring', False), ('pyzipper', 'pyzipper', False)]
FONT_FILES = ['Inter-Regular.otf', 'Inter-Medium.otf', 'Inter-SemiBold.otf', 'Inter-Bold.otf', 'Inter-ExtraBold.otf', 'Inter-Black.otf']
FFMPEG_MAC_URLS = {'ffmpeg': 'https://evermeet.cx/ffmpeg/getrelease/zip', 'ffprobe': 'https://evermeet.cx/ffmpeg/getrelease/ffprobe/zip'}
FFMPEG_WIN_URL = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'


def _item(id_, name, ok, required=True, detail='', fix='', auto=False):
    return {'id': id_, 'name': name, 'ok': bool(ok), 'required': required, 'detail': detail,
            'fix': '' if ok else fix, 'auto': bool(auto and not ok)}


def venv_dir() -> Path:
    return common.ENGINE_ROOT / '.venv'


def venv_python() -> Path:
    v = venv_dir()
    return v / ('Scripts/python.exe' if common.IS_WIN else 'bin/python')


def ollama_info(timeout=0.8):
    try:
        with urllib.request.urlopen(common.OLLAMA_URL + '/api/tags', timeout=timeout) as r:
            return {'running': True, 'models': [m.get('name') for m in json.loads(r.read()).get('models', [])]}
    except Exception:
        return {'running': False, 'models': []}


def check() -> list:
    out = []
    v = sys.version_info
    out.append(_item('python', 'Python 3.12+', v >= (3, 12), True, f'{v.major}.{v.minor}.{v.micro}',
                     'Chạy lại bộ cài (tự cài Python 3.12 cho riêng người dùng) hoặc tải Python 3.12+ tại https://www.python.org/downloads/.'))
    for mod, pkg, req in PY_PKGS:
        ok = importlib.util.find_spec(mod) is not None
        out.append(_item('pip_' + pkg.lower(), f'Thư viện {pkg}', ok, req, 'đã cài' if ok else 'chưa cài',
                         'Bấm "Tự sửa" (cài vào .venv của engine).', auto=True))
    pack_req = _pack_wanted()
    for tool in ('ffmpeg', 'ffprobe'):
        tv = common.tool_version(tool)
        how = ('Bấm "Tự sửa" (dùng Homebrew nếu có, không thì tải bản tĩnh).' if common.IS_MAC else
               'Bấm "Tự sửa" (tải bản essentials từ gyan.dev).' if common.IS_WIN else 'Cài bằng: sudo apt install ffmpeg')
        if not pack_req:
            how = 'Bộ công cụ dựng video (tuỳ chọn) chưa cài – cài trong app: Video › Chưa cài Bộ công cụ dựng video › "Cài ngay" khi cần dựng video trên máy.'
        out.append(_item(tool, tool + ('' if pack_req else ' (Bộ công cụ dựng video – tuỳ chọn)'), tv, pack_req,
                         f"{tv['version']} ({tv['path']})" if tv else 'không thấy', how, auto=common.IS_MAC or common.IS_WIN))
    missing = [f for f in FONT_FILES if not (common.FONTS_DIR / f).is_file()]
    out.append(_item('fonts', 'Phông chữ Inter', not missing, True, 'đủ' if not missing else 'thiếu ' + ', '.join(missing),
                     'Chép lại thư mục fonts trong BDS_Studio_Engine từ bộ cài.'))
    bvp = any(common.FONTS_DIR.glob('BeVietnamPro-*'))
    out.append(_item('font_bvp', 'Phông Be Vietnam Pro (tuỳ chọn)', bvp, False, 'có' if bvp else 'dùng Inter thay thế',
                     'Tải Be Vietnam Pro (Google Fonts) và chép file .ttf vào engine/fonts.'))
    data_ok = (common.DATA_FILES_DIR / 'hn_region_geo.txt').is_file()
    out.append(_item('data', 'Dữ liệu bản đồ Hà Nội', data_ok, True, str(common.DATA_FILES_DIR),
                     'Chép lại thư mục data trong BDS_Studio_Engine từ bộ cài.'))
    for nm, fn in (('render', common.RENDER_MAP), ('vbee', common.VBEE_TTS)):
        out.append(_item('script_' + nm, f'Bộ dựng {fn.name}', fn.is_file(), True, '', 'Chép lại thư mục engine trong BDS_Studio_Engine từ bộ cài.'))
    try:
        for d in (common.video_dir(), common.cache_dir(), common.data_dir()):
            t = d / '.w'; t.write_text('ok'); t.unlink()
        out.append(_item('folders', 'Thư mục làm việc', True, True, str(common.video_dir())))
    except OSError as e:
        out.append(_item('folders', 'Thư mục làm việc', False, True, str(e), 'Kiểm tra quyền ghi thư mục người dùng.'))
    free = common.free_disk_gb()
    out.append(_item('disk', 'Dung lượng trống ≥ 5 GB', free >= 5, False, f'{free} GB', 'Xoá bớt video cũ trong ~/BDS Studio/Video.'))
    ram = common.ram_gb()
    out.append(_item('ram', 'RAM', ram >= 4 or ram == 0, False, f'{ram} GB',
                     'Máy ít RAM: đóng bớt ứng dụng khi dựng video.'))
    ol = ollama_info()
    model = common.load_config().get('ollama_model', 'qwen2.5:3b')
    out.append(_item('ollama', 'Ollama (AI trên máy, tuỳ chọn)', ol['running'], False,
                     'đang chạy' if ol['running'] else 'chưa chạy',
                     'Tải tại https://ollama.com/download rồi mở ứng dụng Ollama.'))
    has_model = model in ol['models'] or (':' not in model and any(m.split(':')[0] == model for m in ol['models']))
    out.append(_item('ollama_model', f'Mô hình {model} (tuỳ chọn)', has_model, False, ', '.join(ol['models']) or '—',
                     f'Mở Terminal và chạy: ollama pull {model}'))
    st = secrets_store.status()
    out.append(_item('vbee', 'Khoá giọng đọc Vbee', all(st.values()), False,
                     ', '.join(f"{k}: {'có' if v else 'chưa'}" for k, v in st.items()),
                     'Nhập App-Id và Token trong app: Video → Khoá Vbee.'))
    out.append(_item('web', 'Giao diện web app', common.web_dir() is not None, False,
                     str(common.web_dir() or 'không thấy thư mục web'), 'Chép thư mục web vào engine/web.'))
    return out


def _pack_wanted() -> bool:
    try:
        import videomode
        return videomode.pack_wanted()
    except Exception:           # tệp lựa chọn hỏng → coi như CHƯA chọn: không tự tải ffmpeg
        return False


class Fixer:
    def __init__(self):
        self.state = {'state': 'idle', 'progress': 0.0, 'log': '', 'steps': []}
        self.lock = threading.Lock()

    def status(self):
        return dict(self.state)

    def start(self, video_pack=False):
        """video_pack=True: người dùng bấm cài Bộ công cụ dựng video → ghi lựa chọn rồi tải ffmpeg dù trước đó chọn không cài."""
        with self.lock:
            if self.state['state'] == 'running':
                return False
            self.state = {'state': 'running', 'progress': 0.0, 'log': '', 'steps': [], 'started': common.now_ms(),
                          'video_pack': bool(video_pack)}
        if video_pack:
            try:
                import videomode
                videomode.set_pack(True, source='app')
            except Exception as e:  # noqa: BLE001 – không ghi được lựa chọn vẫn cài
                self.log(f'⚠ chưa ghi được lựa chọn Bộ công cụ dựng video: {e}')
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def log(self, s):
        self.state['log'] += s + '\n'

    def _run(self):
        dry = os.environ.get('BDS_FIX_DRYRUN') == '1'
        try:
            items = {i['id']: i for i in check()}
            steps = []
            if any(not i['ok'] for k, i in items.items() if k.startswith('pip_')):
                steps.append(('pip', 'Cài thư viện Python vào .venv'))
            if (not items['ffmpeg']['ok'] or not items['ffprobe']['ok']) and (self.state.get('video_pack') or _pack_wanted()):
                steps.append(('ffmpeg', 'Cài ffmpeg (Bộ công cụ dựng video)'))
            self.state['steps'] = [s[1] for s in steps]
            if not steps:
                self.log('✓ Không thiếu gì cần tự cài.')
            for n, (kind, label) in enumerate(steps):
                self.log(f'▶ {label}')
                if dry:
                    self.log('  (chạy thử – không cài)')
                elif kind == 'pip':
                    self.fix_pip()
                elif kind == 'ffmpeg':
                    self.fix_ffmpeg()
                self.state['progress'] = (n + 1) / len(steps)
            left = [i for i in check() if i['required'] and not i['ok']]
            self.state['remaining'] = [i['name'] for i in left]
            self.log('✓ Xong.' if not left else '⚠ Còn thiếu: ' + ', '.join(i['name'] for i in left))
            self.state['state'] = 'done'
        except Exception as e:
            self.log(f'✗ {e}')
            self.state['state'] = 'error'
        self.state['progress'] = 1.0

    def _sh(self, cmd, timeout=1800):
        self.log('$ ' + ' '.join(str(c) for c in cmd))
        p = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout, env=common.child_env())
        self.log((p.stdout + p.stderr)[-1500:])
        if p.returncode != 0:
            raise RuntimeError(f'Lệnh lỗi ({p.returncode})')

    def fix_pip(self):
        py = venv_python()
        if not py.is_file():
            self._sh([sys.executable, '-m', 'venv', venv_dir()])
        self._sh([py, '-m', 'pip', 'install', '--upgrade', 'pip'])
        self._sh([py, '-m', 'pip', 'install', '-r', common.ENGINE_ROOT / 'requirements.txt'])
        self.log('  Đóng và mở lại BDS Studio để dùng thư viện mới.' if Path(sys.executable) != py else '')

    def _download(self, url, dest: Path):
        self.log(f'  tải {url}')
        req = urllib.request.Request(url, headers={'User-Agent': 'BDS-Studio-Engine'})
        with urllib.request.urlopen(req, timeout=120) as r, open(dest, 'wb') as f:
            total = int(r.headers.get('Content-Length') or 0); got = 0
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                f.write(b); got += len(b)
                if total:
                    self.state['download'] = round(got / total, 3)
        return dest

    def fix_ffmpeg(self):
        bd = common.bin_dir(); tmp = common.sub_cache('downloads')
        if common.IS_MAC:
            brew = shutil.which('brew') or next((p for p in ('/opt/homebrew/bin/brew', '/usr/local/bin/brew') if os.path.exists(p)), None)
            if brew:
                self._sh([brew, 'install', 'ffmpeg'], timeout=3600); return
            for tool, url in FFMPEG_MAC_URLS.items():
                z = self._download(url, tmp / f'{tool}.zip')
                with zipfile.ZipFile(z) as zf:
                    member = next(m for m in zf.namelist() if Path(m).name == tool)
                    (bd / tool).write_bytes(zf.read(member))
                os.chmod(bd / tool, 0o755)
                subprocess.run(['xattr', '-dr', 'com.apple.quarantine', str(bd / tool)], capture_output=True)
                z.unlink(missing_ok=True)
        elif common.IS_WIN:
            z = self._download(FFMPEG_WIN_URL, tmp / 'ffmpeg.zip')
            with zipfile.ZipFile(z) as zf:
                for m in zf.namelist():
                    if Path(m).name in ('ffmpeg.exe', 'ffprobe.exe'):
                        (bd / Path(m).name).write_bytes(zf.read(m))
            z.unlink(missing_ok=True)
        else:
            raise RuntimeError('Linux: cài bằng "sudo apt install ffmpeg".')
        self.log(f'  ffmpeg đặt tại {bd}')
