"""Mở máy dựng BDS Studio CHẠY NỀN (không cửa sổ Terminal / cửa sổ đen) rồi mở app trong trình duyệt.

Biểu tượng "BDS Studio" do bộ cài tạo gọi tệp này:
  Mac      ~/Applications/BDS Studio.app → Contents/Resources/launcher → .venv/bin/python app/launcher.py
  Windows  BDS Studio.lnk → .venv\\Scripts\\pythonw.exe app\\launcher.py        (pythonw: không có cửa sổ lệnh)
Việc làm:
  1. Máy dựng đã chạy (GET /health trả "bds-studio-engine") → chỉ mở trình duyệt.
  2. Chưa chạy → bật app/server.py --no-browser ở phiên riêng (tắt biểu tượng/launcher không tắt máy dựng),
     ghi nhật ký vào ~/.bds_studio/logs/engine.log, chờ /health rồi mở TRANG ĐẦU của app theo launch.py: lần đầu thử web app
     dùng chung (bản bán) 3 giây, không được thì http://127.0.0.1:8765/ – rồi GIỮ nguồn đó cho các lần sau.
  3. Không bật được → hộp thoại báo lỗi (Mac: osascript, Windows: MessageBox) kèm đường dẫn nhật ký.
Tuỳ chọn:  --stop  tắt máy dựng đang chạy nền   ·  --no-browser  không mở trình duyệt   ·  --port N
           --mo web|may  đổi nơi biểu tượng mở (địa chỉ app riêng | bản tại máy http://127.0.0.1) rồi mở
           --nguon-app <địa chỉ>  tin + mở địa chỉ app riêng (vd https://app.tenkhach.com) · --bo-nguon-app <địa chỉ>  bỏ
start_mac.command / start_windows.bat (mở có cửa sổ lệnh, đóng cửa sổ = tắt) vẫn dùng được như cũ.
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402
import launch  # noqa: E402

LOG_MAX_BYTES = 5 * 2 ** 20          # engine.log quá 5 MB → đổi thành engine.log.1 (giữ 1 bản cũ)
WAIT_S = 30.0
CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200


def log_dir() -> Path:
    p = common.data_dir() / 'logs'
    p.mkdir(parents=True, exist_ok=True)
    return p


def log(msg: str) -> None:
    try:
        with open(log_dir() / 'launcher.log', 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + msg + '\n')
    except OSError:
        pass


def rotate(path: Path, limit: int = LOG_MAX_BYTES) -> None:
    try:
        if path.stat().st_size > limit:
            os.replace(path, path.with_name(path.name + '.1'))
    except OSError:
        pass


def app_url(port: int) -> str:
    """Trang đầu của app ở nguồn đã chọn (launch.py: lần đầu thử web app dùng chung, rồi giữ nguyên)."""
    return launch.start_url(port)


def probe(port: int, timeout: float = 2.0) -> bool:
    """True nếu cổng đang chạy đúng máy dựng BDS Studio. Bỏ qua proxy của máy (proxy công ty có thể chặn 127.0.0.1)."""
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f'http://127.0.0.1:{port}/health', timeout=timeout) as r:
            d = json.loads(r.read().decode('utf-8', 'replace'))
        return isinstance(d, dict) and d.get('app') == 'bds-studio-engine'
    except Exception:
        return False


def server_cmd(port: int) -> list:
    """Lệnh bật máy dựng. Windows: python.exe (không phải pythonw) để ffmpeg… dùng chung một cửa sổ lệnh ẨN, không nháy cửa sổ."""
    exe = Path(sys.executable)
    if common.IS_WIN and exe.name.lower() == 'pythonw.exe' and exe.with_name('python.exe').is_file():
        exe = exe.with_name('python.exe')
    cmd = [str(exe), '-u', str(common.APP_DIR / 'server.py'), '--no-browser']
    if port != common.PORT:
        cmd += ['--port', str(port)]
    return cmd


def popen_kwargs() -> dict:
    """Tách hẳn khỏi tiến trình gọi: Mac/Linux phiên riêng (setsid); Windows không cửa sổ + nhóm tiến trình riêng."""
    if common.IS_WIN:
        return {'creationflags': CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP, 'close_fds': True}
    return {'start_new_session': True, 'close_fds': True}


def child_env() -> dict:
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUTF8'] = '1'
    if not common.IS_WIN:             # mở từ biểu tượng: PATH của macOS rất ngắn (/usr/bin:/bin…) → thêm chỗ Homebrew
        parts = env.get('PATH', '').split(os.pathsep) + common.EXTRA_BIN + ['/bin', '/usr/sbin', '/sbin']
        env['PATH'] = os.pathsep.join(dict.fromkeys(p for p in parts if p))
    return env


def start_background(port: int):
    logf_path = log_dir() / 'engine.log'
    rotate(logf_path)
    with open(logf_path, 'ab') as logf:
        logf.write(('\n=== ' + time.strftime('%Y-%m-%d %H:%M:%S') + f' bật máy dựng {common.VERSION} ===\n').encode('utf-8'))
        logf.flush()
        # stdin/stdout/stderr KHÔNG nối vào tiến trình gọi: AppleScript "do shell script" chờ tới khi mọi tiến trình
        # giữ ống ra của nó kết thúc – nối vào là biểu tượng treo tới lúc tắt máy dựng.
        return subprocess.Popen(server_cmd(port), cwd=str(common.ENGINE_ROOT), stdin=subprocess.DEVNULL,
                                stdout=logf, stderr=subprocess.STDOUT, env=child_env(), **popen_kwargs())


def wait_ready(port: int, proc=None, wait_s: float = WAIT_S) -> bool:
    end = time.time() + wait_s
    while time.time() < end:
        if probe(port, timeout=1.5):
            return True
        if proc is not None and proc.poll() is not None:
            return probe(port, timeout=1.5)      # tiến trình mới thoát vì máy dựng đã chạy sẵn (cổng bận) → vẫn được
        time.sleep(0.4)
    return False


def open_url(url: str) -> None:
    try:
        if common.IS_MAC:
            subprocess.run(['/usr/bin/open', url], timeout=20, check=False)
        elif common.IS_WIN:
            os.startfile(url)  # type: ignore[attr-defined]
        else:
            webbrowser.open(url)
    except Exception as e:  # noqa: BLE001
        log('không mở được trình duyệt: ' + str(e))


def notify(msg: str) -> None:
    """Hộp thoại cho người dùng (không có cửa sổ lệnh để in ra)."""
    log(msg)
    try:
        if common.IS_MAC:
            esc = msg.replace('\\', '\\\\').replace('"', '\\"')
            subprocess.run(['/usr/bin/osascript', '-e', f'display alert "BDS Studio" message "{esc}"'],
                           timeout=600, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif common.IS_WIN:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, 'BDS Studio', 0x40)  # type: ignore[attr-defined]
        else:
            print(msg)
    except Exception:  # noqa: BLE001
        print(msg)


def stop(port: int) -> int:
    if not probe(port):
        notify('Máy dựng BDS Studio đang không chạy.')
        return 0
    import server   # chỉ cần khi tắt: free_port chỉ tắt tiến trình python đang giữ cổng
    ok = server.free_port(port)
    notify('Đã tắt máy dựng BDS Studio.' if ok else 'Chưa tắt được máy dựng – khởi động lại máy là tắt.')
    return 0 if ok else 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    port = common.PORT
    if '--port' in argv:
        port = int(argv[argv.index('--port') + 1])
    if '--stop' in argv:
        return stop(port)
    if '--nguon-app' in argv or '--bo-nguon-app' in argv:   # địa chỉ app riêng của khách (tên miền riêng B, đổi địa chỉ…)
        flag = '--nguon-app' if '--nguon-app' in argv else '--bo-nguon-app'
        val = argv[argv.index(flag) + 1] if argv.index(flag) + 1 < len(argv) else ''
        try:
            if flag == '--nguon-app':
                o = common.add_user_origin(val, how='cli', primary=True)
                launch.save('web', 'user', o)
                notify('Máy dựng sẽ nhận yêu cầu từ ' + o + ' và biểu tượng BDS Studio mở địa chỉ này.')
            else:
                notify('Đã bỏ ' + val + '.' if common.remove_user_origin(val) else 'Không có địa chỉ ' + val + ' trong danh sách.')
        except ValueError as e:
            notify(str(e))
            return 2
        if '--no-browser' in argv:
            return 0
    if '--mo' in argv:
        want = (argv[argv.index('--mo') + 1] if argv.index('--mo') + 1 < len(argv) else '').lower()
        try:
            r = launch.set_target(want, port)
            log('đổi nơi mở app: ' + r['origin'])
        except ValueError as e:
            notify(str(e))
            return 2
    url = app_url(port)
    browser = '--no-browser' not in argv
    if probe(port):
        log('máy dựng đã chạy sẵn → mở ' + url)
    else:
        try:
            proc = start_background(port)
        except OSError as e:
            notify(f'Không bật được máy dựng ({e}). Chạy lại bộ cài trong thư mục BDS_Studio_Engine.')
            return 1
        log(f'bật máy dựng (pid {proc.pid}): ' + ' '.join(server_cmd(port)))
        if not wait_ready(port, proc):
            if proc.poll() is not None:
                notify('Máy dựng không bật được. Xem nhật ký: ' + str(log_dir() / 'engine.log')
                       + ' – chạy lại bộ cài nếu vẫn lỗi.')
                return 1
            log('máy dựng bật chậm – vẫn mở trình duyệt')
    if browser:
        open_url(url)
    return 0


if __name__ == '__main__':
    common.console_utf8()             # chạy bằng python.exe trong cửa sổ lệnh Windows (cp1252) → in chữ Việt không văng lỗi
    sys.exit(main())
