"""Mở app ở ĐÂU khi bấm biểu tượng "BDS Studio", khi bộ cài cài xong, khi máy dựng tự mở trình duyệt – MỘT quy tắc cho mọi nơi.

Chủ thử thật 17/11: cài xong tự mở https://<web app>/#/content/video → sai 2 chỗ: (a) màn Video không phải trang đầu; (b) web app
dùng chung chưa chạy nên trang lỗi. Quy tắc:
  - Luôn mở TRANG ĐẦU của app (gốc '/'); lần đầu app tự hiện Trợ lý cài đặt. Không mở thẳng màn Video.
  - 17/11 app riêng từng khách: nguồn web app = địa chỉ app RIÊNG mà máy dựng đã tin (common.user_origins – địa chỉ ĐÃ GHÉP NỐI bằng mã 6 số, pairing.py,
    hoặc người dùng đặt); app đã thật sự chạy ở đó nên dùng luôn, không thử mạng. Bản có LAUNCH_ORIGIN cố định: như dưới.
  - Nguồn: lần mở ĐẦU TIÊN thử web app dùng chung (common.LAUNCH_ORIGIN – chỉ bản bán, https, máy dựng nhận yêu cầu từ đó) bằng
    GET 3 giây: trả 200 và đúng trang BDS Studio → dùng; không thì http://127.0.0.1:<cổng>/ (web app nằm sẵn trong máy dựng).
  - Lưu lựa chọn vào <data_dir>/launch_origin.json và DÙNG LẠI các lần sau: địa chỉ máy chủ + phiên đăng nhập của app gắn với
    nguồn của trình duyệt – đổi qua lại sẽ tách đôi dữ liệu.
  - Đổi: python app/launcher.py --mo web|may   ·   app: Cài đặt › Máy của tôi › "Biểu tượng BDS Studio mở"   ·   GET/POST /install/launch
"""
import json
import os
import time
import urllib.request

import common

FILE = 'launch_origin.json'
PROBE_TIMEOUT = 3.0
TARGETS = ('web', 'may')


def path():
    return common.data_dir() / FILE


def local_origin(port=None) -> str:
    return f'http://127.0.0.1:{int(port or common.PORT)}'


def web_origin() -> str:
    """Nguồn web app của MÁY NÀY: (1) LAUNCH_ORIGIN cố định (https, máy dựng nhận yêu cầu từ đó); (2) không có → địa chỉ app RIÊNG
    của khách mà máy dựng đã tin (nguồn đầu trong <data_dir>/app_origins.json – ghép nối lần gần nhất – pairing.py, hoặc người dùng
    đặt ở Cài đặt › Máy của tôi / launcher.py --nguon-app). Không có gì → rỗng (mở bản tại máy)."""
    o = (common.LAUNCH_ORIGIN or '').rstrip('/')
    if o.startswith('https://') and common.is_allowed_origin(o):
        return o
    for u in common.user_origins():
        if u.startswith('https://'):
            return u
    return ''


def probe_web(origin: str, timeout: float = PROBE_TIMEOUT) -> bool:
    """GET origin/ trong `timeout` giây: phải trả 200 và đúng trang đầu BDS Studio (tiêu đề + core/app.js)."""
    try:
        req = urllib.request.Request(origin + '/', headers={'User-Agent': f'BDSStudio-Engine/{common.VERSION} (launch)'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if r.status != 200:
                return False
            body = r.read(512 * 1024)
        return b'<title>BDS Studio</title>' in body and b'core/app.js' in body
    except Exception:  # noqa: BLE001 – mạng lỗi, chứng chỉ, DNS… = chưa dùng được
        return False


def load():
    try:
        d = json.loads(path().read_text(encoding='utf-8'))
        return d if isinstance(d, dict) and d.get('target') in TARGETS else None
    except (OSError, ValueError):
        return None


def save(target: str, how: str, origin: str) -> dict:
    d = {'target': target, 'origin': origin, 'how': how, 'at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    p = path(); tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, p)
    return d


def resolve(port=None, probe=probe_web) -> dict:
    """→ {target: web|may, origin, url, saved_how}. Lần đầu thử web app rồi LƯU; các lần sau dùng đúng nguồn đã lưu."""
    w = web_origin()
    st = load()
    if st and st['target'] == 'may' and st.get('how') == 'no_web_app' and w:
        st = None                                # lúc lưu chưa có web app nào, nay đã có địa chỉ app riêng → thử lại (không tách đôi dữ liệu)
    if st and st['target'] == 'may':
        o = local_origin(port)
    elif st and st['target'] == 'web' and w:
        o = w
    elif st and st['target'] == 'web':          # đã lưu web mà bản này không còn web app → tạm mở tại máy (không ghi đè)
        o = local_origin(port)
    else:
        if st is None and w and w in common.user_origins() and w != (common.LAUNCH_ORIGIN or '').rstrip('/'):
            st = save('web', 'app_rieng', w); o = w      # địa chỉ app riêng: app đã thật sự chạy ở đó (đã gọi máy dựng) → không cần thử mạng
        elif w and probe(w):
            st = save('web', 'probe', w); o = w
        else:
            st = save('may', 'probe_failed' if w else 'no_web_app', local_origin(port)); o = local_origin(port)
    return {'target': 'web' if o == w and w else 'may', 'origin': o, 'url': o + '/', 'saved_how': (st or {}).get('how', ''),
            'web_origin': w}


def start_url(port=None, probe=probe_web) -> str:
    return resolve(port, probe)['url']


def set_target(target: str, port=None) -> dict:
    """Người dùng đổi: 'web' (địa chỉ app riêng / web app của bản này) | 'may' (http://127.0.0.1, bản trong máy dựng)."""
    if target not in TARGETS:
        raise ValueError('Chọn web hoặc may')
    w = web_origin()
    if target == 'web' and not w:
        raise ValueError('Chưa có địa chỉ app riêng (vd https://tenkhach.bdsstudio.app) – chỉ mở được bản tại máy (http://127.0.0.1). '
                         'Mở app của anh/chị một lần, hoặc đặt địa chỉ ở Cài đặt › Máy của tôi / launcher.py --nguon-app <địa chỉ>.')
    save(target, 'user', w if target == 'web' else local_origin(port))
    return info(port)


def info(port=None) -> dict:
    """Cho app (GET /install/launch): không thử mạng, chỉ đọc lựa chọn đã lưu."""
    st = load()
    w = web_origin()
    target = st['target'] if st and (st['target'] == 'may' or w) else 'may'
    o = w if target == 'web' else local_origin(port)
    return {'ok': True, 'target': target, 'origin': o, 'url': o + '/', 'web_origin': w, 'local_origin': local_origin(port),
            'saved': st is not None, 'how': (st or {}).get('how', '')}
