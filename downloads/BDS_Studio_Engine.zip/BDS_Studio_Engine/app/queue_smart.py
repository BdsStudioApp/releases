"""Hàng đợi thông minh cho việc dựng từng cảnh (Dựng & Sửa).

Luật (đã chốt):
  - Khi anh ĐANG DÙNG MÁY (có thao tác trong app gần đây, hoặc CPU máy đang cao do việc khác): chỉ chạy 1 job dựng
    rồi dừng, các job còn lại chờ máy rảnh – trừ việc anh vừa bấm cần ngay (xem trước, kiểm tra, ảnh khung) –
    và chỉ dùng 1 tiến trình vẽ để máy không ì.
  - Máy RẢNH (không thao tác ≥ 5 phút, CPU thấp) hoặc BAN ĐÊM 23h–6h: chạy liên tục mọi job đang chờ, đủ tiến trình.
  - Thứ tự: job đã DUYỆT trước, sau đó theo thứ tự anh kéo; "Chạy ngay" đưa lên đầu.
  - Chỉ 1 job một lúc (Mac 8 GB) và KHÔNG chạy cùng Ollama / job dựng khác: giữ khoá chung với JobManager
    (giữ ollama_active → JobManager đứng chờ; JobManager.busy() trả True → /ollama trả 409 BUSY).
"""
import datetime
import json
import os
import threading
import time
import traceback
import uuid

import common

KINDS = ('preview', 'final', 'thumbs', 'check')
KIND_LABEL = {'preview': 'Xem trước 480p', 'final': 'Bản nét 1080p', 'thumbs': 'Ảnh khung', 'check': 'Kiểm tra trước khi xuất'}
EST_S = {'preview': 60, 'final': 240, 'thumbs': 25, 'check': 30}
IDLE_AFTER_S = 300          # không thao tác 5 phút = máy rảnh
CPU_BUSY = 0.6              # tải 1 phút / số nhân
NIGHT = (23, 6)


class Activity:
    """Tín hiệu "anh đang dùng máy": lần thao tác gần nhất (app gọi /scenes/ping) + tải CPU."""

    def __init__(self, clock=time.time, load=None, hour=None):
        self.clock = clock
        self.last_ping = 0.0
        self.last_own_job = 0.0
        self._load = load
        self._hour = hour

    def ping(self):
        self.last_ping = self.clock()

    def load(self):
        if self._load is not None:
            return self._load()
        try:
            return os.getloadavg()[0] / max(1, os.cpu_count() or 1)
        except (AttributeError, OSError):      # Windows: không có loadavg → chỉ dựa thao tác
            return 0.0

    def hour(self):
        return self._hour() if self._hour else datetime.datetime.fromtimestamp(self.clock()).hour

    def mode(self):
        """('night'|'idle'|'busy', lý do)."""
        h = self.hour()
        if h >= NIGHT[0] or h < NIGHT[1]:
            return 'night', 'Ban đêm 23h–6h: chạy liên tục'
        now = self.clock()
        if now - self.last_ping < IDLE_AFTER_S:
            return 'busy', 'Anh đang dùng máy: chạy từng job một'
        # tải CPU ngay sau job của chính mình không tính (load 1 phút còn cao)
        if now - self.last_own_job > 90 and self.load() > CPU_BUSY:
            return 'busy', 'CPU đang cao do việc khác: chạy từng job một'
        return 'idle', 'Máy rảnh: chạy liên tục'


def order_key(it):
    return (0 if it.get('now') else 1, 0 if it.get('approved') else 1, it.get('order', 0))


def pick_next(items, mode, ran_in_busy):
    """Chọn job tiếp theo theo luật trên (thuần – để kiểm tra)."""
    q = sorted((i for i in items if i['state'] == 'queued'), key=order_key)
    if not q:
        return None
    if mode == 'busy' and ran_in_busy >= 1:
        q = [i for i in q if i.get('now')]          # đang dùng máy: đã chạy 1 job → chỉ việc anh vừa bấm cần ngay
    return q[0] if q else None


class SmartQueue:
    def __init__(self, manager=None, runner=None, activity=None, path=None, clock=time.time):
        self.manager = manager
        self.runner = runner
        self.activity = activity or Activity(clock=clock)
        self.clock = clock
        self.items = {}
        self.cv = threading.Condition()
        self.current = None
        self.ran_in_busy = 0
        self.path = path or (common.data_dir() / 'smart_queue.json')
        self.thread = None
        self._load()
        if manager is not None:
            self._attach(manager)

    # ---------- khoá chung với JobManager / Ollama ----------
    def _attach(self, m):
        orig_busy, orig_eta = m.busy, m.eta
        m.busy = lambda: orig_busy() or self.current is not None
        m.eta = lambda: orig_eta() + (self.eta() if self.current is not None else 0)
        self._orig_busy = orig_busy

    def _acquire(self):
        m = self.manager
        if m is None:
            return True
        with m.cv:
            if self._orig_busy() or m.ollama_active > 0:
                return False
            m.ollama_active += 1          # JobManager không bắt đầu job mới, Ollama bị từ chối (busy)
            return True

    def _release(self):
        m = self.manager
        if m is not None:
            m.ollama_exit()

    # ---------- lưu ----------
    def _load(self):
        try:
            for it in json.loads(self.path.read_text(encoding='utf-8')):
                if it.get('state') == 'running':
                    it['state'] = 'queued'; it['log'] = (it.get('log') or '') + '\n⚠ Máy dựng tắt giữa chừng – chạy lại.\n'
                self.items[it['id']] = it
        except (OSError, ValueError, AttributeError):
            pass

    def _save(self):
        try:
            keep = sorted(self.items.values(), key=lambda i: i['created'])[-80:]
            tmp = self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(keep, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, self.path)
        except OSError:
            pass

    # ---------- công khai ----------
    def public(self, it):
        d = {k: it.get(k) for k in ('id', 'kind', 'project', 'title', 'state', 'progress', 'approved', 'now', 'order', 'voice',
                                    'created', 'started', 'finished', 'error', 'result')}
        d.update(log=(it.get('log') or '')[-3000:], outputs={k: os.path.basename(v) for k, v in (it.get('outputs') or {}).items()},
                 kind_label=KIND_LABEL.get(it['kind'], it['kind']))
        return d

    def mode(self):
        return self.activity.mode()

    def snapshot(self):
        mode, why = self.mode()
        items = sorted(self.items.values(), key=lambda i: (i['state'] not in ('running',), i['state'] != 'queued', order_key(i), -i['created']))
        return {'mode': mode, 'reason': why, 'running': self.current['id'] if self.current else None,
                'items': [self.public(i) for i in items[:60]], 'eta_s': self.eta(),
                'held': mode == 'busy' and self.ran_in_busy >= 1 and any(i['state'] == 'queued' and not i.get('now') for i in self.items.values())}

    def eta(self):
        t = 0
        for i in self.items.values():
            if i['state'] == 'queued':
                t += EST_S.get(i['kind'], 60)
            elif i['state'] == 'running':
                p = i.get('progress') or 0; el = self.clock() - (i.get('started') or self.clock() * 1000) / 1000
                t += max(5, el / p * (1 - p)) if p > 0.05 else EST_S.get(i['kind'], 60)
        return int(t)

    def get(self, iid):
        return self.items.get(iid)

    def submit(self, kind, project, voice=False, now=False, approved=False, title=None):
        if kind not in KINDS:
            raise ValueError('Loại việc không hợp lệ')
        with self.cv:
            # cùng dự án + cùng loại đang chờ → gộp (bản mới nhất của cfg được đọc lúc chạy)
            for it in self.items.values():
                if it['state'] == 'queued' and it['project'] == project and it['kind'] == kind:
                    it['voice'] = it.get('voice') or voice; it['now'] = it.get('now') or now; it['approved'] = it.get('approved') or approved
                    self.cv.notify_all(); self._save(); return it
            iid = datetime.datetime.now().strftime('%m%d%H%M%S') + uuid.uuid4().hex[:4]
            order = max([i.get('order', 0) for i in self.items.values()] + [0]) + 1
            it = {'id': iid, 'kind': kind, 'project': project, 'title': title or f'{KIND_LABEL[kind]} · {project}', 'state': 'queued',
                  'progress': 0.0, 'approved': approved, 'now': now, 'voice': voice, 'order': order, 'created': common.now_ms(), 'log': ''}
            self.items[iid] = it
            self.cv.notify_all()
        self._save()
        return it

    def reorder(self, ids):
        with self.cv:
            known = [i for i in ids if i in self.items]
            for k, iid in enumerate(known, 1):
                self.items[iid]['order'] = k
            rest = sorted((i for i in self.items.values() if i['id'] not in known), key=lambda i: i.get('order', 0))
            for k, it in enumerate(rest, len(known) + 1):
                it['order'] = k
            self.cv.notify_all()
        self._save()
        return self.snapshot()

    def approve(self, iid, approved=True):
        it = self._need(iid); it['approved'] = bool(approved); self._save()
        with self.cv:
            self.cv.notify_all()

    def run_now(self, iid):
        it = self._need(iid)
        if it['state'] in ('error', 'done', 'cancelled'):
            it.update(state='queued', progress=0.0, error=None)
        it['now'] = True; it['order'] = min([i.get('order', 0) for i in self.items.values()] + [0]) - 1
        self._save()
        with self.cv:
            self.cv.notify_all()

    def remove(self, iid):
        it = self._need(iid)
        if it['state'] == 'running':
            raise ValueError('Job đang chạy – chờ xong rồi xoá')
        self.items.pop(iid, None); self._save()

    def _need(self, iid):
        it = self.items.get(iid)
        if not it:
            raise KeyError('Không có job này')
        return it

    # ---------- vòng chạy ----------
    def step(self):
        """Chạy tối đa 1 job nếu luật cho phép. Trả job đã chạy hoặc None (dùng trong thread và trong kiểm tra)."""
        mode, _ = self.mode()
        if mode != 'busy':
            self.ran_in_busy = 0
        with self.cv:
            it = pick_next(list(self.items.values()), mode, self.ran_in_busy)
            if not it:
                return None
            if not self._acquire():
                return None
            it['state'] = 'running'; it['started'] = common.now_ms(); it['progress'] = 0.0; self.current = it
        workers = 1 if mode == 'busy' else None
        log = lambda s: it.__setitem__('log', (it.get('log') or '') + s)
        prog = lambda p: it.__setitem__('progress', round(max(it.get('progress', 0), min(0.99, p)), 3))
        try:
            try:
                import jobs
                jobs.unload_ollama()           # nhả mô hình Ollama khỏi RAM trước khi dựng
            except Exception:
                pass
            res = self.runner(it, log, prog, workers) if self.runner else {}
            it['outputs'] = (res or {}).get('outputs') or {}
            it['result'] = (res or {}).get('result')
            it['state'] = 'done'; it['progress'] = 1.0
        except Exception as e:
            it['state'] = 'error'; it['error'] = str(e)[:500]; log(f'\n✗ {e}\n')
            if os.environ.get('BDS_DEBUG'):
                log(traceback.format_exc())
        finally:
            it['finished'] = common.now_ms(); it['now'] = False
            self.current = None
            self.activity.last_own_job = self.clock()
            if mode == 'busy':
                self.ran_in_busy += 1
            self._release()
            try:
                common.prune_cache()
            except Exception:
                pass
            self._save()
        return it

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._loop, daemon=True, name='bds-scenes')
            self.thread.start()

    def _loop(self):
        while True:
            try:
                ran = self.step()
            except Exception:
                ran = None
            if ran is None:
                with self.cv:
                    self.cv.wait(2.0)
