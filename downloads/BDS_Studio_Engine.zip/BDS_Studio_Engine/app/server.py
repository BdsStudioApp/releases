#!/usr/bin/env python3
"""BDS Studio – máy dựng video trên máy (Mac / Windows), http://127.0.0.1:8765 (chỉ máy này, không mở ra mạng).

  /                web app BDS Studio (thư mục web/ cạnh engine)   ·   /studio  giao diện dựng GĐ1
  GET  /health                 tình trạng máy dựng
  POST /staff/run  ·  GET /staff/status   nhân viên AI (Gemini qua máy chủ / Ollama) – xem app/staff.py
  POST /remote/link, /remote/unlink · GET /remote/status   máy dựng nhận việc "Gửi máy tính dựng" từ điện thoại – xem app/remote.py
  GET  /selfcheck              danh sách thành phần ✓/✗ + cách sửa
  POST /selfcheck/fix          tự cài phần thiếu (GET /selfcheck/fix xem tiến độ)
  POST /jobs                   {type:"video_map", cfg, mode} | {type:"video_flow", clips, script, voice}
  GET  /jobs, /jobs/<id>       tiến độ        ·  GET /files/<job>/<tên> tải kết quả
  POST /upload?name=a.mp4      tải clip/nhạc lên (thân = tệp) → {path}
  POST /ollama                 chuyển tới Ollama (409 BUSY khi đang dựng)
  GET  /ollama/api/tags · POST /ollama/api/generate   cầu nối Ollama cho web app (Ollama chặn trang lạ nên web không gọi thẳng được)
  POST /secrets                lưu khoá Vbee vào keychain   ·  GET /secrets chỉ trả có/không
  GET  /news?feeds=&since=     tin RSS cho Nguồn ý tưởng (news.py)
  GET/POST /video/*             gói Video: dàn cảnh đã duyệt → cfg (tra OSM), khoảng cách đường đi, tải video lên Drive (videopack.py)
  GET/POST /videoai/*           gói Video AI (thử nghiệm): nhập clip AI online / tạo offline (máy hạng Mạnh) → cảnh "ai_clip" (videoai.py)
  GET/POST /scenes/*            Dựng & Sửa từng cảnh: xem trước 480p, kiểm tra trước xuất, hàng đợi thông minh, kho bản đồ (scenes.py)
  GET  /install/report  ·  GET/POST /hw/scan  ·  GET /packs/list  ·  POST /packs/install   bộ cài lõi + quét máy (install_api.py)
  GET/POST /config             cấu hình (giới hạn bộ nhớ đệm…)
  POST /migrate/export, /migrate/import    chuyển máy
  GET  /update                 phiên bản + các bản sao lưu + trạng thái cập nhật tự động (auto)
  POST /update/auto            tự tải bản mới ĐÃ KÝ SỐ từ  (release.json + chữ ký ed25519 + sha256 từng tệp)
                               rồi cài; thân {"silent":true} = app tự gọi ở nền: đang dựng thì chờ dựng xong mới cài (tiến độ: GET /update → auto)
  POST /update/rollback        khôi phục bản trước (cả hai: chỉ nguồn được phép, rồi tự khởi động lại)
  (16/11: BỎ hẳn POST /update nhận zip thủ công – khách không tự cập nhật bằng file; chỉ còn kênh có ký số.)

Chạy:  python3 app/server.py [--no-browser] [--port 8765]
"""
import json
import mimetypes
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common          # noqa: E402
import jobs as jobs_mod  # noqa: E402
import migrate         # noqa: E402
import news           # noqa: E402
import secrets_store   # noqa: E402
import selfcheck       # noqa: E402
import launch          # noqa: E402  (mở trang đầu app, đúng nguồn đã chọn)
import staff as staff_mod  # noqa: E402
import studio          # noqa: E402
import updater         # noqa: E402
import remote as remote_mod  # noqa: E402  (17/11: hàng chờ "Gửi máy tính dựng" từ điện thoại)
import pairing         # noqa: E402  (M1 17/11: ghép nối app ↔ máy dựng bằng mã 6 số – thay tự ghim địa chỉ đầu tiên)

os.environ['PATH'] = common.child_path()
MAX_JSON = 20 * 2**20
MAX_UPLOAD = 4 * 2**30
UPLOAD_EXT = jobs_mod.MEDIA_EXT
# Header bảo mật cho app web phục vụ tại http://127.0.0.1:8765 – giống web/_headers (Cloudflare Pages);
# connect-src thêm nguồn web app + kho phát hành của máy cài (S: de-hardcode – mặc định bản của anh qua common.APP_ORIGIN/RELEASE_ORIGIN).
# 17/11: CSP so khớp nguồn có đường dẫn theo ĐÚNG đường dẫn (…/main không gồm …/main/release.json) → chỉ lấy scheme://host[:port].
def _csp_origin(u):
    try:
        from urllib.parse import urlsplit
        x = urlsplit(str(u or '').strip())
        return f'{x.scheme}://{x.netloc}' if x.scheme in ('http', 'https') and x.netloc else ''
    except Exception:  # noqa: BLE001
        return ''


_CONNECT_ORIGINS = ' '.join(dict.fromkeys(o for o in (_csp_origin(common.APP_ORIGIN), _csp_origin(common.RELEASE_ORIGIN)) if o))
LOCAL_CSP = ("default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
             "font-src https://fonts.gstatic.com 'self'; "
             f"connect-src 'self' {_CONNECT_ORIGINS} https://script.google.com https://script.googleusercontent.com "
             "http://127.0.0.1:8765 http://127.0.0.1:11434 http://localhost:11434; "
             "img-src 'self' data: blob: http://127.0.0.1:8765; media-src 'self' blob: http://127.0.0.1:8765; "
             "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'; manifest-src 'self'; worker-src 'self'")
STATIC_HEADERS = {
    'Content-Security-Policy': LOCAL_CSP,
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
}
CTYPES = {'.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
          '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
          '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
          '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf',
          '.mp4': 'video/mp4', '.gif': 'image/gif', '.srt': 'text/plain; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
          '.zip': 'application/zip', '.wav': 'audio/wav', '.mp3': 'audio/mpeg'}
NO_WEB_PAGE = '''<!doctype html><meta charset="utf-8"><title>BDS Studio</title>
<body style="font:16px system-ui;background:#0F1E33;color:#F7F3EA;padding:32px"><h2 style="color:#C9A24A">Máy dựng BDS Studio đang chạy</h2>
<p>Chưa thấy thư mục <code>web/</code> cạnh engine. Mở <a style="color:#C9A24A" href="/studio">Studio dựng video</a>.</p></body>'''


class App:
    def __init__(self):
        self.jobs = jobs_mod.JobManager()
        self.fixer = selfcheck.Fixer()
        self.updater = updater.Updater()
        self.staff = staff_mod.StaffRunner(self.jobs)
        self.staff.get_bridge = self._overnight_bridge      # job video_map → nháp 480p qua đêm (overnight.py)
        self.staff.start_scheduler()
        self.remote = remote_mod.RemoteRunner(self)          # đã liên kết (remote.json) → tự hỏi việc từ điện thoại
        self.remote.start_if_linked()
        self._ollama_cache = (0, None)

    def _overnight_bridge(self):
        import scenes
        return scenes.overnight_bridge(self)

    def ollama(self):
        t, v = self._ollama_cache
        if time.time() - t > 3 or v is None:
            v = selfcheck.ollama_info(); self._ollama_cache = (time.time(), v)
        return v

    def health(self):
        ffm = common.tool_version('ffmpeg')
        return {'ok': True, 'app': 'bds-studio-engine', 'version': common.VERSION, 'os': f'{platform.system()} {platform.release()}',
                'os_family': {'Darwin': 'mac', 'Windows': 'windows'}.get(common.OS_NAME, 'linux'),
                'ram_gb': common.ram_gb(), 'ffmpeg': ffm['version'] if ffm else None,
                'python': platform.python_version(), 'ollama': self.ollama(),
                'vbee_configured': secrets_store.vbee_configured(), 'free_disk_gb': common.free_disk_gb(),
                'busy': self.jobs.busy(), 'eta_s': self.jobs.eta() if self.jobs.busy() else 0,
                'web': common.web_dir() is not None, 'video_dir': str(common.video_dir()), **_video_health()}


def _video_health():
    """Cách xử lý video chọn lúc cài + Bộ công cụ dựng video (videomode.py) – lỗi đọc tệp không làm hỏng /health."""
    try:
        import videomode
        return videomode.health_info()
    except Exception:  # noqa: BLE001
        return {}


APP = None


def err(code, message, status=400, **extra):
    return status, {'ok': False, 'error': dict({'code': code, 'message': message}, **extra)}


class Handler(BaseHTTPRequestHandler):
    server_version = 'BDSStudioEngine/' + common.VERSION
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        if os.environ.get('BDS_DEBUG'):
            super().log_message(*a)

    # ---------- bảo vệ ----------
    def origin(self):
        return self.headers.get('Origin')

    def origin_ok(self):
        o = self.origin()
        return o is None or common.accept_origin(o)          # khớp chính xác (nguồn cố định / nguồn app tin cậy – common.py)

    def host_ok(self):
        host = (self.headers.get('Host') or '').rsplit(':', 1)[0].strip('[]').lower()
        return host in ('127.0.0.1', 'localhost', '::1', '')

    def cors(self):
        o = self.origin()
        if getattr(self, '_no_cors', False):              # trang /ghep + form xác nhận: không bao giờ cho trang khác đọc
            return
        if common.accept_origin(o) or (o and o == getattr(self, '_pair_cors', None)):   # _pair_cors: chỉ /pair/start|status (pairing.py)
            self.send_header('Access-Control-Allow-Origin', o)
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Filename')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Expose-Headers', 'Content-Disposition, X-Encryption')
            self.send_header('Access-Control-Max-Age', '600')
            if self.headers.get('Access-Control-Request-Private-Network'):
                self.send_header('Access-Control-Allow-Private-Network', 'true')

    def send(self, status, body, ctype='application/json; charset=utf-8', headers=None):
        if isinstance(body, (dict, list)):
            b = json.dumps(body, ensure_ascii=False).encode('utf-8')
        elif isinstance(body, str):
            b = body.encode('utf-8')
        else:
            b = body or b''
        self.send_response(status)
        if int(self.headers.get('Content-Length') or 0) and not getattr(self, '_consumed', False):
            self.close_connection = True                  # thân yêu cầu chưa đọc → đóng kết nối cho sạch
            self.send_header('Connection', 'close')
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.cors()
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(b)

    def body(self, limit=MAX_JSON):
        n = int(self.headers.get('Content-Length') or 0)
        if n > limit:
            raise ValueError('Dữ liệu quá lớn')
        self._consumed = True
        return self.rfile.read(n) if n else b''

    def json_body(self):
        b = self.body()
        if not b:
            return {}
        d = json.loads(b.decode('utf-8'))
        if not isinstance(d, dict):
            raise ValueError('Cần một đối tượng JSON')
        return d

    # ---------- định tuyến ----------
    def do_OPTIONS(self):
        self._pair_cors = None; self._no_cors = False
        if not self.host_ok():
            return self.send(*err('BAD_HOST', 'Host không hợp lệ', 403))
        if urlparse(self.path).path in ('/pair/start', '/pair/status') and pairing.eligible(self.origin()):
            self._pair_cors = self.origin()                # app chưa ghép xin ghép (preflight mạng riêng của Chrome)
        elif not common.accept_origin(self.origin()):
            self.send_response(403); self.send_header('Content-Length', '0'); self.send_header('Connection', 'close')
            self.close_connection = True; self.end_headers(); return
        self.send_response(204); self.send_header('Content-Length', '0'); self.cors(); self.end_headers()

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self._dispatch('GET')

    def do_POST(self):
        self._dispatch('POST')

    def _dispatch(self, method):
        self._pair_cors = None; self._no_cors = False      # kết nối giữ (HTTP/1.1) dùng lại handler → đặt lại mỗi yêu cầu
        if not self.host_ok():
            return self.send(*err('BAD_HOST', 'Chỉ nhận yêu cầu tới 127.0.0.1', 403))
        u = urlparse(self.path); p = unquote(u.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        pair = p == '/ghep' or p.startswith('/pair/')       # ghép nối: tự kiểm Origin riêng (pairing.handle)
        if method != 'GET' and not pair and not self.origin_ok():
            return self.send(*err('ORIGIN_DENIED', 'Trang này không được phép gọi máy dựng.', 403))
        try:
            r = pairing.handle(self, method, p, q) if pair else (self.route_get if method == 'GET' else self.route_post)(p, q)
            if r is not None:
                self.send(*r)
        except updater.UpdateError as e:
            self.send(*err(e.code, e.message, e.status, **e.extra))
        except FileExistsError as e:
            self.send(*err('CONFLICT', str(e), 409))
        except (ValueError, KeyError, json.JSONDecodeError) as e:
            self.send(*err('BAD_INPUT', str(e), 400))
        except Exception as e:      # không để sập máy chủ
            self.send(*err('INTERNAL', f'Lỗi máy dựng: {e}', 500))

    def route_get(self, p, q):
        a = APP
        if p == '/health':
            return 200, a.health()
        if p.startswith('/remote/'):                       # hàng chờ "Gửi máy tính dựng" (remote.py)
            return remote_mod.handle(a, 'GET', p, q, self)
        if p == '/staff/status':
            return 200, dict(a.staff.status(), ok=True)
        if p == '/ollama/api/tags':       # cầu nối: app web gọi Ollama qua máy dựng (Ollama chặn trang lạ – CORS; app riêng của khách không gọi thẳng được)
            return self.ollama_tags()
        if p == '/selfcheck':
            items = selfcheck.check()
            return 200, {'ok': all(i['ok'] for i in items if i['required']), 'items': items}
        if p == '/selfcheck/fix':
            return 200, dict(a.fixer.status(), ok=True)
        if p == '/jobs':
            return 200, {'ok': True, 'jobs': a.jobs.list(), 'busy': a.jobs.busy(), 'eta_s': a.jobs.eta()}
        if p.startswith('/jobs/'):
            j = a.jobs.get(p.split('/')[2])
            if not j:
                return err('NOT_FOUND', 'Không có job này', 404)
            return 200, dict(a.jobs.public(j), ok=True)
        if p.startswith('/files/'):
            return self.serve_output(p)
        if p == '/secrets':
            return 200, {'ok': True, 'status': secrets_store.status(), 'backend': secrets_store.backend()}
        if p == '/news':
            # L2 (17/11): GET /news tải URL do người gọi chọn → chỉ app đã tin (CORS) hoặc chính trang máy dựng / công cụ không phải trình duyệt;
            # trang lạ gọi "no-cors" (Origin trống nhưng Sec-Fetch-Site: cross-site) bị chặn – không dò được mạng nội bộ qua máy dựng.
            o, site = self.origin(), (self.headers.get('Sec-Fetch-Site') or '').lower()
            if (o and not common.accept_origin(o)) or (not o and site not in ('', 'same-origin', 'none')):
                return err('ORIGIN_DENIED', 'Trang này không được phép gọi máy dựng.', 403)
            return 200, news.handle(q)
        if p == '/config':
            return 200, {'ok': True, 'config': common.load_config()}
        if p == '/update':
            return 200, a.updater.status()
        if p in ('/studio', '/studio/'):
            return 200, studio.PAGE, 'text/html; charset=utf-8'
        if p == '/studio/api/projects':
            return 200, studio.list_projects(a.jobs)
        if p.startswith('/studio/api/project/'):
            return 200, studio.read_cfg(p.split('/', 4)[4]), 'text/plain; charset=utf-8'
        if p.startswith('/video/'):                        # gói Video: soạn kịch bản → cfg, Drive (videopack.py)
            import videopack
            return videopack.handle(a, 'GET', p, q, self)
        if p.startswith('/videoai/'):                      # gói Video AI (thợ V, thử nghiệm): clip AI → cảnh "ai_clip" (videoai.py)
            import videoai
            return videoai.handle(a, 'GET', p, q, self)
        if p.startswith('/scenes/'):                       # Dựng & Sửa theo từng cảnh (scenes.py)
            import scenes
            return scenes.handle(a, 'GET', p, q, self)
        if p.startswith(('/hw/', '/install/')) or p in ('/packs/list', '/packs/install'):  # quét máy, báo cáo bộ cài, phần mở rộng (install_api.py). Chỉ đúng 2 API gói – /packs/<gói>/… là tệp tĩnh của web app (pack.json…), sửa lỗi 404 khi app chạy tại 127.0.0.1
            import install_api
            return install_api.handle(a, 'GET', p, q, self)
        return self.serve_static(p)

    def route_post(self, p, q):
        a = APP
        if p.startswith('/remote/'):                       # liên kết / bỏ liên kết máy dựng với tài khoản (remote.py)
            return remote_mod.handle(a, 'POST', p, q, self)
        if p == '/staff/run':
            return 200, a.staff.start(self.json_body())
        if p == '/jobs':
            spec = {k: v for k, v in self.json_body().items() if not k.startswith('_')}
            if spec.get('type') in ('video_map', 'video_flow') and not common.which('ffmpeg'):
                return err('VIDEO_PACK_MISSING', 'Chưa cài Bộ công cụ dựng video (ffmpeg) – vào Video › Chưa cài Bộ công cụ dựng video › bấm "Cài ngay", '
                           'hoặc dùng Video AI online (thu phí riêng).', 409)
            jid = a.jobs.submit(spec)
            return 200, {'ok': True, 'id': jid, 'state': a.jobs.get(jid)['state'], 'eta_s': a.jobs.eta()}
        if p == '/upload':
            return self.upload(q)
        if p in ('/update/rollback', '/update/auto'):                # POST /update (zip thủ công) đã bỏ → 404
            return self.update(p, q)
        if p == '/ollama/api/generate':   # cầu nối kiểu Ollama (trả {response, prompt_eval_count, eval_count}) cho app web
            return self.ollama(native=True)
        if p == '/ollama':
            return self.ollama()
        if p == '/secrets':
            d = self.json_body(); where = None
            for k in secrets_store.ALLOWED_KEYS:
                if k in d:
                    if not isinstance(d[k], str) or len(d[k]) > 4096:
                        raise ValueError('Giá trị khoá không hợp lệ')
                    where = secrets_store.set_secret(k, d[k])
            if where is None:
                raise ValueError('Cần VBEE_APP_ID hoặc VBEE_TOKEN')
            return 200, {'ok': True, 'stored': where, 'status': secrets_store.status()}
        if p == '/selfcheck/fix':
            started = a.fixer.start(video_pack=bool(self.json_body().get('video_pack')))
            return 200, dict(a.fixer.status(), ok=True, started=started)
        if p == '/config':
            return 200, {'ok': True, 'config': common.save_config(self.json_body())}
        if p == '/cache/prune':
            return 200, dict(common.prune_cache(), ok=True)
        if p == '/migrate/export':
            d = self.json_body()
            data, info = migrate.export_zip(d.get('password') or None)
            fn = Path(info['saved_to']).name
            return 200, data, 'application/zip', {'Content-Disposition': f'attachment; filename="{fn}"',
                                                   'X-Encryption': info['encryption']}
        if p == '/migrate/import':
            data = self.body(limit=500 * 2**20)
            res = migrate.import_zip(data, q.get('password') or self.headers.get('X-Password'), q.get('overwrite') == '1')
            return 200, dict(res, ok=True)
        if p.startswith('/studio/api/project/'):
            studio.save_cfg(p.split('/', 4)[4], self.body().decode('utf-8')); return 200, {'ok': True}
        if p.startswith('/studio/api/new/'):
            studio.new_project(p.split('/', 4)[4]); return 200, {'ok': True}
        if p.startswith('/studio/api/run/'):
            jid = studio.run(a.jobs, p.split('/', 4)[4], q.get('mode', 'check'))
            return 200, {'ok': True, 'job': jid}
        if p.startswith('/video/'):                        # gói Video: soạn kịch bản → cfg, Drive (videopack.py)
            import videopack
            return videopack.handle(a, 'POST', p, q, self)
        if p.startswith('/videoai/'):                      # gói Video AI (thợ V, thử nghiệm): clip AI → cảnh "ai_clip" (videoai.py)
            import videoai
            return videoai.handle(a, 'POST', p, q, self)
        if p.startswith('/scenes/'):                       # Dựng & Sửa theo từng cảnh (scenes.py)
            import scenes
            return scenes.handle(a, 'POST', p, q, self)
        if p.startswith(('/hw/', '/install/')) or p in ('/packs/list', '/packs/install'):  # quét máy, báo cáo bộ cài, phần mở rộng (install_api.py). Chỉ đúng 2 API gói – /packs/<gói>/… là tệp tĩnh của web app (pack.json…), sửa lỗi 404 khi app chạy tại 127.0.0.1
            import install_api
            return install_api.handle(a, 'POST', p, q, self)
        return err('NOT_FOUND', 'Không có đường dẫn này', 404)

    # ---------- tự cập nhật ----------
    def update(self, p, q):
        a = APP
        if not common.accept_origin(self.origin()):      # bắt buộc có Origin hợp lệ (không nhận yêu cầu không rõ nguồn)
            return err('ORIGIN_DENIED', 'Trang này không được phép cập nhật máy dựng.', 403)
        if p == '/update/auto':                              # chạy nền; client theo dõi GET /update → auto.state
            try:
                silent = bool((json.loads(self.body() or b'{}') or {}).get('silent'))
            except (ValueError, AttributeError):
                silent = False
            st = a.updater.auto.start(busy=a.jobs.busy, defer=silent)
            return 200, {'ok': True, 'started': True, 'auto': st}
        self.body()
        res = a.updater.rollback(busy=a.jobs.busy())
        a.updater.schedule_restart()
        return 200, res

    # ---------- Ollama ----------
    def ollama_tags(self):
        try:
            req = urllib.request.Request(common.OLLAMA_URL + '/api/tags', headers={'Accept': 'application/json'})
            with urllib.request.urlopen(req, timeout=4) as r:
                return 200, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return err('AI_ERROR', f'Ollama trả lỗi {e.code}.', 502)
        except (urllib.error.URLError, OSError, TimeoutError, ValueError) as e:
            return err('OLLAMA_OFFLINE', f'Ollama chưa chạy hoặc không kết nối được ({e}). Mở Ollama (biểu tượng con lạc đà) rồi thử lại.', 503)

    def ollama(self, native=False):
        a = APP
        d = self.json_body()
        if not a.jobs.ollama_enter():
            eta = a.jobs.eta()
            return 409, {'ok': False, 'error': {'code': 'BUSY', 'eta_s': eta,
                         'message': f'Máy đang dựng video, AI trên máy tạm nghỉ để đủ RAM (còn khoảng {max(1, round(eta / 60))} phút).'}}, \
                'application/json; charset=utf-8', {'Retry-After': str(max(5, eta))}
        try:
            cfg = common.load_config()
            payload = {'model': d.get('model') or cfg['ollama_model'], 'prompt': str(d.get('prompt', '')), 'stream': False}
            for k in ('system', 'format', 'options', 'images', 'keep_alive'):
                if k in d:
                    payload[k] = d[k]
            payload.setdefault('keep_alive', '5m')
            req = urllib.request.Request(common.OLLAMA_URL + '/api/generate', method='POST',
                                         data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
            try:
                with urllib.request.urlopen(req, timeout=float(cfg.get('ollama_timeout_s', 120))) as r:
                    res = json.loads(r.read())
            except urllib.error.HTTPError as e:
                return err('AI_ERROR', f'Ollama trả lỗi {e.code}: {e.read()[:200].decode("utf-8", "replace")}', 502)
            except (urllib.error.URLError, OSError, TimeoutError) as e:
                return err('OLLAMA_OFFLINE', f'Ollama chưa chạy hoặc quá thời gian ({e}).', 503)
            if native:
                return 200, {'ok': True, 'response': res.get('response', ''), 'model': res.get('model'),
                             'prompt_eval_count': res.get('prompt_eval_count', 0), 'eval_count': res.get('eval_count', 0)}
            return 200, {'ok': True, 'text': res.get('response', ''), 'model': res.get('model'),
                         'tokens_in': res.get('prompt_eval_count', 0), 'tokens_out': res.get('eval_count', 0)}
        finally:
            a.jobs.ollama_exit()

    # ---------- tệp ----------
    def upload(self, q):
        name = q.get('name') or self.headers.get('X-Filename') or 'clip.mp4'
        ext = Path(name).suffix.lower()
        if ext not in UPLOAD_EXT:
            raise ValueError('Chỉ nhận video/ảnh/âm thanh (' + ', '.join(UPLOAD_EXT) + ')')
        n = int(self.headers.get('Content-Length') or 0)
        if n <= 0 or n > MAX_UPLOAD:
            raise ValueError('Kích thước tệp không hợp lệ')
        dest = common.sub_cache('uploads') / f'{uuid.uuid4().hex[:10]}_{common.safe_name(Path(name).stem, "clip")}{ext}'
        left = n; self._consumed = True
        with open(dest, 'wb') as f:
            while left > 0:
                b = self.rfile.read(min(1 << 20, left))
                if not b:
                    break
                f.write(b); left -= len(b)
        if left:
            dest.unlink(missing_ok=True); raise ValueError('Tải lên bị ngắt')
        return 200, {'ok': True, 'path': str(dest), 'name': name, 'size': n}

    def serve_output(self, p):
        parts = p.split('/')
        if len(parts) != 4:
            return err('NOT_FOUND', 'Không thấy tệp', 404)
        j = APP.jobs.get(parts[2])
        if not j:
            return err('NOT_FOUND', 'Không có job này', 404)
        outs = j.get('outputs') or {}
        f = outs.get(parts[3]) or next((v for v in outs.values() if os.path.basename(v) == parts[3]), None)
        if not f or not os.path.isfile(f):
            return err('NOT_FOUND', 'Không thấy tệp (có thể đã bị dọn)', 404)
        dl = {'Content-Disposition': f'inline; filename="{Path(f).name.encode("ascii", "ignore").decode() or "video.mp4"}"',
              'X-Frame-Options': 'DENY', 'Content-Security-Policy': "frame-ancestors 'none'; sandbox"}
        return self.send_file(Path(f), dl)

    def send_file(self, f: Path, headers=None):
        size = f.stat().st_size
        ctype = CTYPES.get(f.suffix.lower()) or mimetypes.guess_type(str(f))[0] or 'application/octet-stream'
        rng = self.headers.get('Range')
        start, end, status = 0, size - 1, 200
        if rng and rng.startswith('bytes='):
            a_, _, b_ = rng[6:].split(',')[0].partition('-')
            try:
                if a_:
                    start = int(a_); end = int(b_) if b_ else size - 1
                else:
                    start = max(0, size - int(b_))
                end = min(end, size - 1)
                if start > end:
                    raise ValueError
                status = 206
            except ValueError:
                self.send_response(416); self.send_header('Content-Range', f'bytes */{size}')
                self.send_header('Content-Length', '0'); self.cors(); self.end_headers(); return None
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(end - start + 1))
        if status == 206:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.send_header('X-Content-Type-Options', 'nosniff')
        cache = 'no-cache' if f.suffix in ('.html', '.js', '.mjs', '.json', '.webmanifest', '.css') else 'max-age=3600'
        self.send_header('Cache-Control', cache)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.cors(); self.end_headers()
        if self.command == 'HEAD':
            return None
        with open(f, 'rb') as fh:
            fh.seek(start); left = end - start + 1
            while left > 0:
                b = fh.read(min(1 << 20, left))
                if not b:
                    break
                try:
                    self.wfile.write(b)
                except (BrokenPipeError, ConnectionResetError):
                    break
                left -= len(b)
        return None

    def serve_static(self, p):
        host = (self.headers.get('Host') or '')
        if host.startswith('localhost'):      # cùng nguồn http://127.0.0.1:8765 (CORS chỉ cho 2 nguồn)
            self.send_response(302); self.send_header('Location', f'http://127.0.0.1:{host.rsplit(":", 1)[-1]}{self.path}')
            self.send_header('Content-Length', '0'); self.end_headers(); return None
        web = common.web_dir()
        if web is None:
            if p == '/':
                return 200, NO_WEB_PAGE, 'text/html; charset=utf-8'
            return err('NOT_FOUND', 'Không có đường dẫn này', 404)
        rel = p.lstrip('/') or 'index.html'
        base = web.resolve()
        f = (base / rel).resolve()
        if not common._inside(f, base):
            return err('NOT_FOUND', 'Không có', 404)
        if f.is_dir():
            f = f / 'index.html'
        if not f.is_file() or any(part.startswith('.') for part in f.relative_to(base).parts):
            return err('NOT_FOUND', 'Không có tệp này', 404)
        return self.send_file(f, STATIC_HEADERS)


def make_server(port=None, host='127.0.0.1'):
    global APP
    if APP is None:
        APP = App()
    srv = ThreadingHTTPServer((host, common.PORT if port is None else port), Handler)
    srv.daemon_threads = True
    return srv


def probe_engine(port, timeout=2.0):
    """True nếu cổng đang chạy đúng máy dựng BDS Studio (bản mới)."""
    import urllib.request
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/health', timeout=timeout) as r:
            d = json.loads(r.read().decode('utf-8', 'replace'))
            return isinstance(d, dict) and d.get('app') == 'bds-studio-engine'
    except Exception:
        return False


def _pids_on_port(port):
    pids = set()
    try:
        if common.OS_NAME == 'Windows':
            out = subprocess.run(['netstat', '-ano', '-p', 'tcp'], capture_output=True, text=True, timeout=10).stdout
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 5 and parts[1].endswith(':' + str(port)) and parts[3].upper() == 'LISTENING':
                    pids.add(int(parts[4]))
        else:
            out = subprocess.run(['lsof', '-nP', '-ti', f'tcp:{port}', '-sTCP:LISTEN'], capture_output=True, text=True, timeout=10).stdout
            pids = {int(x) for x in out.split() if x.strip().isdigit()}
    except Exception:
        pass
    pids.discard(os.getpid())
    return pids


def free_port(port, wait_s=6.0):
    """Tắt chương trình Python cũ đang giữ cổng (chỉ tắt tiến trình python – không đụng chương trình khác)."""
    import signal, time as _t
    killed = False
    for pid in _pids_on_port(port):
        name = ''
        try:
            if common.OS_NAME == 'Windows':
                name = subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/FO', 'CSV', '/NH'], capture_output=True, text=True, timeout=10).stdout.lower()
            else:
                name = subprocess.run(['ps', '-p', str(pid), '-o', 'command='], capture_output=True, text=True, timeout=10).stdout.lower()
        except Exception:
            pass
        if 'python' not in name:
            print('  Cổng đang dùng bởi chương trình khác (không phải máy dựng):', name.strip()[:120])
            continue
        try:
            if common.OS_NAME == 'Windows':
                subprocess.run(['taskkill', '/PID', str(pid), '/F'], capture_output=True, timeout=10)
            else:
                os.kill(pid, signal.SIGTERM)
            killed = True
        except Exception:
            pass
    if not killed:
        return False
    end = _t.time() + wait_s
    while _t.time() < end:
        if not _pids_on_port(port):
            return True
        _t.sleep(0.3)
    return not _pids_on_port(port)


def main():
    common.console_utf8()                          # cửa sổ lệnh Windows không phải UTF-8 → không để lỗi in chữ Việt
    port = common.PORT
    if '--port' in sys.argv:
        port = int(sys.argv[sys.argv.index('--port') + 1])
    if '--after-update' in sys.argv:                 # vừa tự cập nhật: bản cũ có thể chưa nhả cổng (Windows) → chờ một chút
        for _ in range(40):
            try:
                srv = make_server(port); break
            except OSError:
                time.sleep(0.5)
        else:
            srv = None
        if srv is not None:
            print('BDS Studio đã cập nhật lên bản', common.VERSION)
            print('BDS Studio đang chạy:', f'http://127.0.0.1:{port}/', '(đóng cửa sổ này để tắt)')
            threading.Thread(target=common.prune_cache, daemon=True).start()
            try:
                srv.serve_forever()
            except KeyboardInterrupt:
                pass
            return
    try:
        srv = make_server(port)
    except OSError:
        url = f'http://127.0.0.1:{port}/'
        if probe_engine(port):
            print('BDS Studio đã chạy sẵn:', url)
            if '--no-browser' not in sys.argv:
                webbrowser.open(launch.start_url(port))     # trang đầu, đúng nguồn đã chọn (launch.py)
            return
        # Cổng bị chương trình khác chiếm (thường là máy dựng bản cũ "BDS Video Studio") → tắt nó rồi chạy bản mới
        print('Cổng', port, 'đang bị chương trình cũ chiếm – đang tắt chương trình cũ…')
        if not free_port(port):
            print('✗ Không tắt được chương trình đang chiếm cổng', port + '.', 'Hãy đóng cửa sổ "BDS Video" cũ (hoặc khởi động lại máy) rồi mở lại BDS Studio.')
            return
        srv = make_server(port)
    url = f'http://127.0.0.1:{port}/'
    print('BDS Studio đang chạy:', url, '(đóng cửa sổ này để tắt)')
    print('Video lưu ở:', common.video_dir())
    threading.Thread(target=common.prune_cache, daemon=True).start()
    if '--no-browser' not in sys.argv:                 # trang đầu, đúng nguồn đã chọn (launch.py) – không mở thẳng màn Video
        threading.Timer(0.8, lambda: webbrowser.open(launch.start_url(port))).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
