"""Bí mật (VBEE_APP_ID, VBEE_TOKEN): lưu trong keychain hệ điều hành qua `keyring`.

Keyring lỗi/không có → file dự phòng <data_dir>/secrets.json (chmod 600), data_dir mặc định ~/.bds_studio.
KHÔNG BAO GIỜ ghi vào thư mục engine; không bao giờ trả giá trị bí mật qua API.
"""
import json
import os
from pathlib import Path

import common

SERVICE = 'BDS Studio'
ALLOWED_KEYS = ('VBEE_APP_ID', 'VBEE_TOKEN')
OPTIONAL_KEYS = ('GEOAPIFY_KEY',)   # gói Video: khoảng cách đường đi (tuỳ chọn) – lưu qua /video/road, không tính vào status()


def _keyring():
    if os.environ.get('BDS_NO_KEYRING') == '1':
        return None
    try:
        import keyring
        from keyring.backends import fail
        kr = keyring.get_keyring()
        if isinstance(kr, fail.Keyring) or 'fail' in type(kr).__module__ or 'null' in type(kr).__module__.lower():
            return None
        return keyring
    except Exception:
        return None


def _file() -> Path:
    p = common.data_dir() / 'secrets.json'
    assert not common._inside(p, common.ENGINE_ROOT)
    return p


def _read_file() -> dict:
    try:
        return json.loads(_file().read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def _write_file(d: dict):
    p = _file()
    tmp = p.with_suffix('.tmp')
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(d, f)
    os.replace(tmp, p)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass


def set_secret(key: str, value: str) -> str:
    """Trả về nơi lưu: 'keychain' | 'file'."""
    if key not in ALLOWED_KEYS + OPTIONAL_KEYS:
        raise ValueError('Khoá không được phép: ' + key)
    value = (value or '').strip()
    kr = _keyring()
    if kr:
        try:
            if value:
                kr.set_password(SERVICE, key, value)
            else:
                try:
                    kr.delete_password(SERVICE, key)
                except Exception:
                    pass
            d = _read_file()
            if key in d:            # dọn bản cũ trong file dự phòng
                d.pop(key); _write_file(d)
            return 'keychain'
        except Exception:
            pass
    d = _read_file()
    if value:
        d[key] = value
    else:
        d.pop(key, None)
    _write_file(d)
    return 'file'


def get_secret(key: str):
    kr = _keyring()
    if kr:
        try:
            v = kr.get_password(SERVICE, key)
            if v:
                return v
        except Exception:
            pass
    return _read_file().get(key) or None


def status() -> dict:
    return {k: bool(get_secret(k)) for k in ALLOWED_KEYS}


def vbee_configured() -> bool:
    return bool(get_secret('VBEE_APP_ID')) and bool(get_secret('VBEE_TOKEN'))


def vbee_env() -> dict:
    """Biến môi trường cho tiến trình vbee_tts.py (không ghi ra đĩa)."""
    env = {}
    a, t = get_secret('VBEE_APP_ID'), get_secret('VBEE_TOKEN')
    if a:
        env['VBEE_APP_ID'] = a
    if t:
        env['VBEE_TOKEN'] = t
    return env


def backend() -> str:
    return 'keychain' if _keyring() else 'file'
