"""Cách xử lý video của máy này (bộ cài bước B8 hỏi, app đổi lại được) + "Bộ công cụ dựng video" (ffmpeg) tuỳ chọn.

Yêu cầu chủ 17/11 (thử bộ cài thật trên Windows: "lúc cài chưa có tuỳ chọn khách cài bản offline hay online cho việc xử lý video"):
  - Bộ cài quét nhanh máy NGAY sau khi có Python (B8, trước ffmpeg B3) rồi mới quyết định phần video nặng:
      Cơ bản → chỉ cài lõi; Bộ công cụ dựng video (ffmpeg) KHÔNG tự cài – tuỳ chọn (cài sau trong app hoặc chạy lại bộ cài --video)
      Khá    → cài Bộ công cụ dựng video như cũ; Video AI chỉ chạy ONLINE
      Mạnh   → 3 lựa chọn: Online · Offline trên máy này (thư viện + mô hình mở giấy phép thương mại) · Để sau
  - Mặc định ONLINE, tự chọn sau 60 giây (cài không người trông vẫn xong). Chạy lại bộ cài: GIỮ lựa chọn cũ (không hỏi lại)
    trừ khi chạy với --chon-video hoặc đặt biến môi trường.
  - Offline: bước B9 cài thư viện chạy mô hình bằng ĐÚNG hàm của videoai.py (run_setup) rồi NẠP THẬT để kiểm; Windows bật
    Smart App Control chặn tệp chưa ký → chuyển Online, giải thích rõ. Mô hình chỉ tải khi người dùng xác nhận dung lượng.

Tệp: <data_dir>/video_mode.json  (Windows %USERPROFILE%\\.bds_studio\\video_mode.json · Mac ~/.bds_studio/video_mode.json)
  {schema:1, mode: online|offline|later, video_pack: install|skip, tier, source: installer|app|env, chosen_at,
   offline_model, offline_download: now|later, fallback:{from, reason, at}|null, sac:{state,label}|null, runtime:{…}|null}

Biến môi trường (kiểm thử / cài hàng loạt):
  BDS_VIDEO_MODE=online|offline|later   chọn sẵn, không hỏi     BDS_VIDEO_PACK=1|0   cài / không cài Bộ công cụ dựng video
  BDS_VIDEO_DOWNLOAD=now|later          offline: tải mô hình ngay hay để sau
  BDS_VIDEO_TIMEOUT=60                  số giây chờ trả lời     BDS_HW_TIER=co_ban|kha|manh   giả hạng máy (chỉ kiểm thử)

Dòng lệnh (bộ cài gọi):
  python app/videomode.py choose  --out TỆP [--ci] [--dry] [--ask] [--pack yes|no]   bước B8 (Python gốc, chưa cần .venv)
  python app/videomode.py offline --out TỆP [--ci] [--dry]                            bước B9 (Python của .venv)
  python app/videomode.py show                                                        in lựa chọn đang lưu
TỆP nhận các dòng KHOÁ=giá trị cho bộ cài đọc: STATUS (ok|warn|dry|skipped) · MSG · MODE · PACK · TIER · DOWNLOAD.
"""
import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common  # noqa: E402
import hwscan  # noqa: E402

SCHEMA = 2                 # 2 (17/11 chiều): video_pack chỉ 'install' khi người dùng CHỌN gói; tệp schema 1 được sửa khi đọc
MODES = ('online', 'offline', 'later')
MODE_LABEL = {'online': 'Online – Video AI qua dịch vụ trực tuyến', 'offline': 'Offline – Video AI chạy trên máy này',
              'later': 'Để sau – chưa làm Video AI'}
PACK_TITLE = 'Bộ công cụ dựng video'
PACK_WHAT = 'ffmpeg – dựng video bản đồ/quy hoạch ngay trên máy'
PACK_SIZE = {'windows': 'tải ~100–200 MB', 'mac': 'tải ~80 MB (Homebrew có thể lâu hơn)', 'linux': 'cài bằng apt'}
WEAK_WARNING = 'Máy yếu: video dựng trên máy sẽ không đẹp và giật – chỉ nên dùng để làm video mẫu.'
ONLINE_PAID = 'Video AI chạy qua dịch vụ AI trực tuyến – thu phí riêng, tuỳ mô hình/nhà cung cấp'
DEFAULT_TIMEOUT = 60
SAC_LABEL = {0: 'tắt', 1: 'đang bật', 2: 'đang đánh giá (Evaluation)'}
# Khoá Microsoft ghi trong tài liệu App Control for Business (learn.microsoft.com, mục tắt Smart App Control hàng loạt):
# HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy › VerifiedAndReputablePolicyState. 0 = tắt (Microsoft ghi rõ);
# 1 = bật, 2 = đánh giá (nguồn thứ ba, chưa có trang Microsoft nêu) → chỉ dùng để GIẢI THÍCH, không chặn cứng.
SAC_KEY = r'SYSTEM\CurrentControlSet\Control\CI\Policy'
SAC_VALUE = 'VerifiedAndReputablePolicyState'


# ---------------- lưu / đọc ----------------
def path(dry: bool = False) -> Path:
    return common.data_dir() / ('video_mode_dry.json' if dry else 'video_mode.json')


def load(dry: bool = False):
    try:
        d = json.loads(path(dry).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return None
    if not isinstance(d, dict) or d.get('mode') not in MODES or d.get('schema') not in (1, SCHEMA):
        return None
    if d.get('schema') == 1:
        d = migrate(d)
        try:
            save(d, dry)
        except OSError:
            pass
    return d


def migrate(d: dict) -> dict:
    """Tệp do bộ cài bản đầu ghi (schema 1): máy Khá/Mạnh chọn Online/Để sau vẫn bị đặt video_pack=install ("cài như cũ") – đúng
    lỗi chủ gặp 17/11 (chọn [3] mà vẫn cài ffmpeg). Chỉ giữ 'install' khi chắc người dùng đã CHỌN: Offline, hoặc máy Cơ bản +
    Online ([4] bản đầu – Cơ bản chọn [1] thì đã là skip). Còn lại → skip."""
    d = dict(d)
    explicit = d.get('mode') == 'offline' or (d.get('tier') == 'co_ban' and d.get('mode') == 'online')
    if d.get('video_pack') == 'install' and not explicit:
        d.update(video_pack='skip', migrated={'from': 1, 'at': now_iso(), 'reason':
                 'bộ cài bản đầu tự đặt cài Bộ công cụ dựng video khi chọn ' + MODE_LABEL[d['mode']].split(' –')[0] + ' – nay không cài'})
    d['schema'] = SCHEMA
    return d


def save(state: dict, dry: bool = False) -> dict:
    st = dict(state, schema=SCHEMA)
    p = path(dry); tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, p)
    return st


def now_iso() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


# ---------------- Bộ công cụ dựng video ----------------
def pack_installed() -> bool:
    return bool(common.which('ffmpeg') and common.which('ffprobe'))


def pack_wanted(state=None) -> bool:
    """Người dùng ĐÃ CHỌN Bộ công cụ dựng video chưa. Chưa có tệp lựa chọn → CHƯA (không tự cài ffmpeg ở bất kỳ đâu)."""
    st = state if state is not None else load()
    return (st or {}).get('video_pack') == 'install'


def pack_status(state=None, tier=None) -> dict:
    st = state if state is not None else load()
    if tier is None:
        tier = (st or {}).get('tier') or ((hwscan.load() or {}).get('tier'))
    inst = pack_installed()
    wanted = pack_wanted(st)
    return {'title': PACK_TITLE, 'what': PACK_WHAT, 'installed': inst, 'wanted': wanted,
            'state': 'installed' if inst else ('missing' if wanted else 'optional'),
            'label': 'đã cài' if inst else ('chưa cài – thiếu' if wanted else 'chưa cài – tuỳ chọn'),
            'weak': tier == 'co_ban', 'warning': WEAK_WARNING if tier == 'co_ban' else '',
            'install_hint': 'Cài trong app: Video › Chưa cài Bộ công cụ dựng video › "Cài ngay" (hoặc Tự kiểm tra › Tự sửa), '
                            'hoặc chạy lại bộ cài với --video.'}


def set_pack(wanted: bool, source: str = 'app') -> dict:
    st = load() or {'mode': 'online', 'tier': (hwscan.load() or {}).get('tier', ''), 'chosen_at': now_iso(), 'source': source}
    st['video_pack'] = 'install' if wanted else 'skip'
    return save(st)


# ---------------- trạng thái cho app ----------------
def status(gate=None) -> dict:
    """GET /videoai/status › mode. gate: kết quả videoai.offline_gate() (đỡ đọc tệp quét 2 lần)."""
    st = load()
    if gate is None:
        import videoai
        gate = videoai.offline_gate()
    mode = (st or {}).get('mode') or 'online'
    return {'mode': mode, 'label': MODE_LABEL[mode], 'chosen': st is not None,
            'source': (st or {}).get('source') or '', 'chosen_at': (st or {}).get('chosen_at') or '',
            'tier': (st or {}).get('tier') or '', 'offline_model': (st or {}).get('offline_model') or '',
            'fallback': (st or {}).get('fallback'), 'offline_allowed': bool(gate and gate.get('allowed')),
            'offline_reason': (gate or {}).get('reason', ''), 'online_note': ONLINE_PAID + '.',
            'options': [{'id': m, 'label': MODE_LABEL[m], 'allowed': m != 'offline' or bool(gate and gate.get('allowed'))} for m in MODES],
            'pack': pack_status(st)}


def health_info() -> dict:
    """Phần thêm vào GET /health (nhẹ: không quét máy, không gọi mạng)."""
    st = load()
    return {'video_mode': (st or {}).get('mode') or '', 'video_pack': pack_status(st)}


def set_mode(mode, source: str = 'app') -> dict:
    import videoai
    mode = str(mode or '')
    if mode not in MODES:
        raise ValueError('Cách xử lý video không hợp lệ (online | offline | later)')
    gate = videoai.offline_gate()
    if mode == 'offline' and not gate['allowed']:
        raise videoai.Refused('TIER', gate['reason'])
    st = load() or {'video_pack': 'install' if pack_installed() else 'skip'}
    st.update(mode=mode, source=source, chosen_at=now_iso(), tier=((gate.get('tier') or {}).get('tier') or st.get('tier') or ''),
              fallback=None)
    if mode == 'offline' and not st.get('offline_model'):
        st['offline_model'] = videoai.recommended_model(hwscan.load())['id']
    save(st)
    return status(gate)


# ---------------- Smart App Control (Windows 11) ----------------
def sac_state(reader=None) -> dict:
    """{state: 0|1|2|None, label}. reader() → số đọc từ sổ đăng ký (kiểm thử). Máy không phải Windows → state None."""
    if reader is None:
        if not common.IS_WIN:
            return {'state': None, 'label': 'không áp dụng'}

        def reader():
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, SAC_KEY) as k:
                return winreg.QueryValueEx(k, SAC_VALUE)[0]
    try:
        v = int(reader())
    except (OSError, ValueError, TypeError):
        return {'state': None, 'label': 'không đọc được (Windows 10 hoặc máy không có Smart App Control)'}
    return {'state': v, 'label': SAC_LABEL.get(v, f'giá trị lạ {v}')}


def sac_explain(sac: dict) -> str:
    on = 'đang bật' if sac.get('state') == 1 else 'đang ở chế độ đánh giá (có thể tự bật)' if sac.get('state') == 2 else ''
    return ('Windows 11 ' + (on + ' ' if on else 'có thể đang bật ') + 'Smart App Control (Kiểm soát ứng dụng thông minh): '
            'tính năng này chặn các tệp thư viện chưa ký số của torch (.dll/.pyd) nên Video AI offline không chạy được trên máy này. '
            'Đã chuyển sang Video AI ONLINE. Muốn dùng offline: Bảo mật Windows › Kiểm soát ứng dụng và trình duyệt › '
            'Smart App Control → Tắt (Microsoft ghi: tắt rồi muốn bật lại phải cài lại Windows), rồi chạy lại bộ cài với --chon-video.')


def looks_blocked(err: str) -> bool:
    """Thông báo lỗi nạp DLL kiểu bị chính sách kiểm soát ứng dụng chặn (WinError 4551 / 'Application Control policy')."""
    return bool(re.search(r'Application Control|WinError 4551|blocked this file|chính sách', err or '', re.I))


# ---------------- quét nhanh + lựa chọn (bước B8) ----------------
def probe(save_scan: bool = True) -> dict:
    """Quét nhanh (không đo thử – chưa có ffmpeg): đúng hàm hwscan.scan của bước B7. BDS_HW_TIER giả hạng (kiểm thử, không lưu)."""
    info = hwscan.scan(bench=False)
    fake = os.environ.get('BDS_HW_TIER', '')
    if fake in hwscan.TIERS:
        info.update(tier=fake, tier_label=hwscan.TIER_LABEL[fake], recommendations=hwscan.recommend(info, fake),
                    reasons=[f'(kiểm thử: giả hạng {hwscan.TIER_LABEL[fake]} bằng BDS_HW_TIER)'], fake_tier=True)
    elif save_scan:
        hwscan.save(info)
    return info


def gpu_line(scan: dict) -> str:
    out = []
    for g in scan.get('gpus') or []:
        if g.get('unified'):
            out.append(f"{g.get('name')} – bộ nhớ chung {hwscan.vn(g.get('vram_gb') or 0)} GB")
        elif g.get('vendor') == 'nvidia':
            out.append(f"{g.get('name')} – {hwscan.vn(g.get('vram_gb') or 0)} GB VRAM")
        else:
            out.append(str(g.get('name')))
    if not any(g.get('vendor') in ('nvidia', 'apple') for g in scan.get('gpus') or []):
        out.append('không có card NVIDIA rời')
    return ' · '.join(out)


def scan_lines(scan: dict) -> list:
    cpu = scan.get('cpu') or {}
    lines = [f"Kết quả quét máy: hạng {scan.get('tier_label') or '?'}",
             f"  · Chip/CPU: {cpu.get('model') or '?'} ({cpu.get('cores') or '?'} nhân)",
             f"  · RAM: {hwscan.vn(scan.get('ram_gb') or 0)} GB",
             f"  · Card đồ hoạ: {gpu_line(scan)}",
             f"  · Ổ trống: {hwscan.vn(scan.get('free_disk_gb') or 0)} GB"]
    for r in scan.get('reasons') or []:
        lines.append(f'  · Lý do xếp hạng: {r}')
    return lines


def offline_need_text() -> str:
    T = hwscan.THRESHOLDS
    return (f"cần máy hạng Mạnh: card NVIDIA VRAM ≥ {T['manh_vram_gb']} GB + RAM ≥ {T['manh_vram_ram_gb']} GB, "
            f"hoặc Mac chip Apple Pro/Max/Ultra bộ nhớ chung ≥ {T['manh_apple_ram_gb']} GB; ổ trống ≥ {T['video_ai_disk_gb']} GB")


def gb(n) -> str:
    return hwscan.vn(round(n / 2**30, 2)) + ' GB'


def runtime_size_text(os_family: str) -> str:
    import videoai
    R = videoai.RUNTIME_DOWNLOAD
    if os_family == 'windows':
        return (f"torch bản cho card NVIDIA (CUDA) tải từ download.pytorch.org – dung lượng thật hiện khi tải (thường vài GB) "
                f"+ thư viện còn lại ~{round(R['windows_without_torch'] / 2**20)} MB (đo trên PyPI {fmt_date(R['checked'])})")
    if os_family == 'mac':
        return f"tải ~{round(R['mac'] / 2**20)} MB (đo trên PyPI {fmt_date(R['checked'])}; giải nén ra chiếm ổ nhiều hơn)"
    return 'tải từ PyPI (dung lượng hiện khi tải)'


def fmt_date(iso: str) -> str:
    y, m, d = (iso or '0-0-0').split('-')
    return f'{int(d)}/{int(m)}/{y}'


def online_lines() -> list:
    import videoai
    out = [ONLINE_PAID + ':']
    for p in videoai.ONLINE_PROVIDERS:
        out.append(f"  · {p['name']} – {p['cost']}")
    out.append('  App không ghi sẵn giá: Chủ nhập bảng giá theo trang giá chính thức; app báo chi phí trước mỗi lần tạo.')
    return out


# Chữ menu (chủ 17/11 tối): "Online" = KHÔNG cài gì lên máy, mọi video làm bằng AI trả phí trên mạng; dựng video bản đồ/quy hoạch
# chỉ có khi chọn dựng TRÊN MÁY. Câu hỏi đầu của bộ cài (trước Python) đã có lựa chọn "Chỉ dùng AI trên mạng – không cài gì";
# B8 (sau khi quét máy) chỉ còn các cách dựng trên máy + đường lui [1] cho máy yếu. Bản web (wizard) dùng đúng các câu này.
TOOLS_SIZE = '~150–300 MB'
CHOICE_TEXT = {
    '4': f'[4] Dựng video trên máy – video bản đồ/quy hoạch miễn phí; cài công cụ dựng ({TOOLS_SIZE}). Video AI vẫn làm trên mạng (tính phí theo nhà cung cấp).',
    '2': '[2] Dựng + AI ngay trên máy (chỉ máy Mạnh) – như [4], thêm thư viện AI; AI chạy miễn phí nhưng nặng máy, tải nhiều:',
    '1': '[1] Thôi – chỉ làm video bằng AI trên mạng, không cài thêm gì lên máy (AI tính phí theo nhà cung cấp; không làm được '
         'video bản đồ/quy hoạch trên máy này).',
}
CHOICE_LABEL = {'4': 'Dựng video trên máy', '2': 'Dựng + AI ngay trên máy',
                '1': 'Chỉ làm video bằng AI trên mạng – không cài thêm gì', '3': 'Để sau – không cài thêm gì'}


def plan_choice(scan: dict, sac=None) -> dict:
    """HÀM THUẦN: kết quả quét → các lựa chọn của bước B8 (chỉ chạy khi khách đã chọn "Có – dựng video trên máy này" ở câu đầu).
    → {tier, offline_allowed, offline_reason, model, options, default}. options: [{key, mode, pack, text:[dòng]}]:
      4 Dựng video trên máy (online + gói) · 2 Dựng + AI ngay trên máy (offline + gói, chỉ máy Mạnh)
      · 1 Thôi – chỉ AI trên mạng (online, KHÔNG cài thêm: bộ cài dừng ngay, không .venv, không ffmpeg).
    Mặc định (Enter / hết giờ): máy Cơ bản → [1] (máy yếu dựng sẽ giật); hạng khác hoặc chưa quét được → [4]."""
    import videoai
    tier = scan.get('tier') if scan.get('tier') in hwscan.TIERS else ''
    gate = videoai.offline_gate(scan) if tier else {'allowed': False, 'reason': 'Chưa quét được máy.'}
    os_family = (scan.get('os') or {}).get('family') or ('windows' if common.IS_WIN else 'mac' if common.IS_MAC else 'linux')
    weak = tier == 'co_ban'
    m = videoai.recommended_model(scan) if gate['allowed'] else None
    t4 = [CHOICE_TEXT['4']]
    if weak:
        t4.append(f'      ⚠ {WEAK_WARNING}')
    opts = [{'key': '4', 'mode': 'online', 'pack': True, 'text': t4}]
    if gate['allowed']:
        need = round(m['size_bytes'] / 2**30 + videoai.DISK_RESERVE_GB, 1)
        txt = [CHOICE_TEXT['2'],
               f'      - Thư viện chạy mô hình (torch + diffusers…): {runtime_size_text(os_family)}',
               f"      - Mô hình gợi ý cho máy này: {m['title']} – {gb(m['size_bytes'])} "
               f"(đo trên Hugging Face {fmt_date(m['size_checked'])}; giấy phép {m['license']})",
               f"      - Cần trống ≥ {hwscan.vn(need)} GB (mô hình + {videoai.DISK_RESERVE_GB:g} GB dự phòng); "
               f"đang trống {hwscan.vn(scan.get('free_disk_gb') or 0)} GB",
               '      - Mô hình tải ngay hoặc để sau (trong app: Video AI › AI trên máy › Tải mô hình).']
        if sac and sac.get('state') in (1, 2):
            txt.append(f"      ⚠ Smart App Control {sac['label']}: có thể chặn thư viện torch – nếu bị chặn, bộ cài tự chuyển AI sang làm trên mạng.")
        opts.append({'key': '2', 'mode': 'offline', 'pack': True, 'text': txt})
    opts.append({'key': '1', 'mode': 'online', 'pack': False, 'text': [CHOICE_TEXT['1']]})
    if gate['allowed']:
        reason = ''
    elif tier and tier != 'manh':
        reason = f"máy hạng {scan.get('tier_label') or hwscan.TIER_LABEL[tier]}; AI ngay trên máy {offline_need_text()}."
    else:                                          # hạng Mạnh nhưng thiếu ổ trống / chưa quét được
        reason = gate['reason'].rstrip('.') + '.'
    default = '1' if weak else '4'
    return {'tier': tier, 'tier_label': scan.get('tier_label') or '', 'os_family': os_family, 'weak': weak,
            'pack_default': default == '4', 'offline_allowed': gate['allowed'], 'offline_reason': reason,
            'model': m['id'] if m else '', 'model_size': m['size_bytes'] if m else 0, 'options': opts, 'default': default}


# ---------------- hỏi có hẹn giờ ----------------
def ask(prompt: str, valid, default: str, timeout: int, interactive: bool, out=None) -> tuple:
    """→ (trả lời, tự_chọn). Không tương tác (CI / không có bàn phím) hoặc hết giờ → mặc định."""
    out = out or sys.stdout
    if not interactive or timeout <= 0:
        out.write(f'{prompt}{default} (tự chọn)\n'); out.flush()
        return default, True
    out.write(prompt); out.flush()
    end = time.monotonic() + timeout
    while True:
        line = _read_line(end)
        if line is None:
            out.write(f'\n   … hết {timeout} giây – tự chọn [{default}]\n'); out.flush()
            return default, True
        v = line.strip().lower()
        if v == '':
            return default, False
        if v in valid:
            return v, False
        out.write(f'   Chỉ gõ {" / ".join(valid)} rồi Enter: '); out.flush()


def _read_line(end: float):
    """Đọc một dòng từ bàn phím, trả None khi hết giờ. Windows: msvcrt (không có select cho cửa sổ lệnh)."""
    if common.IS_WIN:
        import msvcrt
        buf = ''
        while time.monotonic() < end:
            if msvcrt.kbhit():
                ch = msvcrt.getwche()
                if ch in ('\r', '\n'):
                    sys.stdout.write('\n')
                    return buf
                if ch == '\b':
                    buf = buf[:-1]
                else:
                    buf += ch
                end = max(end, time.monotonic() + 30)     # đang gõ dở → không cắt ngang
            else:
                time.sleep(0.05)
        return None
    import select
    r, _, _ = select.select([sys.stdin], [], [], max(0.0, end - time.monotonic()))
    if not r:
        return None
    line = sys.stdin.readline()
    return line if line else None


def _interactive(ci: bool) -> bool:
    if ci:
        return False
    try:
        return sys.stdin is not None and sys.stdin.isatty()
    except (AttributeError, ValueError):
        return False


def _timeout() -> int:
    try:
        return max(0, int(os.environ.get('BDS_VIDEO_TIMEOUT') or DEFAULT_TIMEOUT))
    except ValueError:
        return DEFAULT_TIMEOUT


def _env_pack(flag: str):
    v = (flag or os.environ.get('BDS_VIDEO_PACK') or '').strip().lower()
    return True if v in ('1', 'yes', 'true', 'co') else False if v in ('0', 'no', 'false', 'khong') else None


def write_out(path_: str, **kv):
    if not path_:
        return
    lines = [f"{k.upper()}={str(v if v is not None else '').replace(chr(10), ' ').replace(chr(13), ' ')}" for k, v in kv.items()]
    Path(path_).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def say(s=''):
    print('   ' + s if s else '', flush=True)


def cmd_choose(a: dict) -> int:
    """Bước B8: quét nhanh → in kết quả + lựa chọn → hỏi (có hẹn giờ) → lưu → TỆP cho bộ cài."""
    dry, ci = a['dry'], a['ci']
    prev = load()
    pack_flag = _env_pack(a.get('pack'))
    env_mode = (os.environ.get('BDS_VIDEO_MODE') or '').strip().lower()
    if env_mode and env_mode not in MODES:
        say(f'⚠ BDS_VIDEO_MODE="{env_mode}" không hợp lệ (online | offline | later) – bỏ qua'); env_mode = ''
    try:
        scan = probe(save_scan=not dry)
    except Exception as e:          # quét lỗi → cài như cũ (có Bộ công cụ dựng video), Video AI online
        say(f'⚠ Chưa quét nhanh được máy ({e}) – mặc định [4] Dựng video trên máy.')
        scan = {}
    sac = sac_state() if common.IS_WIN else None
    pc = plan_choice(scan, sac)
    if scan:
        for ln in scan_lines(scan):
            say(ln)
    say()
    for ln in online_lines():
        say(ln)
    if not pc['offline_allowed']:
        say(f"Không có lựa chọn [2] Dựng + AI ngay trên máy: {pc['offline_reason']}")
    say()
    by_key = {o['key']: o for o in pc['options']}
    hidden_later = {'key': '3', 'mode': 'later', 'pack': False, 'text': []}   # chỉ qua BDS_VIDEO_MODE=later (kiểm thử/cài hàng loạt)
    # chạy lại bộ cài: giữ lựa chọn DỰNG TRÊN MÁY cũ, không hỏi (nhanh). Lựa chọn cũ "không cài gói" → hỏi lại (khách vừa chọn Có ở câu đầu).
    keep = prev is not None and not a.get('ask') and not env_mode and prev.get('video_pack') == 'install'
    download = 'later'
    if keep:
        mode = prev['mode']
        pack = True
        key = '2' if mode == 'offline' else '4'
        if prev.get('migrated') and not prev['migrated'].get('shown'):
            say('Đã sửa lựa chọn cũ: ' + prev['migrated']['reason'] + '.')
        download = prev.get('offline_download') or 'later'
        source = prev.get('source') or 'installer'
        say(f"Giữ lựa chọn lần trước: [{key}] {CHOICE_LABEL[key]} (đổi: chạy bộ cài với --chon-video, hoặc trong app Video AI).")
        auto = False
    else:
        for o in pc['options']:
            for ln in o['text']:
                say(ln)
        if env_mode:
            if env_mode == 'later':
                by_key['3'] = hidden_later
            key = {'online': '1', 'later': '3', 'offline': '2'}[env_mode]
            source, auto = 'env', True
            if key not in by_key:                         # offline nhưng máy không đủ hạng → dựng trên máy, AI trên mạng
                say(f'⚠ BDS_VIDEO_MODE={env_mode} không dùng được trên máy này – chọn [4] Dựng video trên máy.')
                key = '4'
            say(f'Chọn sẵn qua BDS_VIDEO_MODE: [{key}]')
        elif dry:
            key, auto, source = pc['default'], True, 'installer'
            say(f'(chạy thử – không hỏi) sẽ mặc định [{key}] sau {_timeout()} giây nếu không ai trả lời')
        else:
            t = _timeout()
            keys = [o['key'] for o in pc['options']]
            key, auto = ask(f'Gõ {" / ".join(keys)} rồi Enter (Enter hoặc chờ {t} giây = [{pc["default"]}]): ',
                            keys, pc['default'], t, _interactive(ci))
            source = 'installer'
        o = by_key[key]
        mode, pack = o['mode'], o['pack']
        if mode == 'offline':
            env_dl = (os.environ.get('BDS_VIDEO_DOWNLOAD') or '').strip().lower()
            size = gb(pc['model_size'])
            if env_dl in ('now', 'later'):
                download = env_dl
            elif not dry:
                say(f'Tải mô hình gợi ý ({size}) ngay trong lúc cài?  [1] Để sau – tải trong app khi cần (mặc định)   '
                    f'[2] Tải ngay {size} (xác nhận dung lượng)')
                k, _ = ask(f'Gõ 1 hoặc 2 rồi Enter (chờ {_timeout()} giây = [1]): ', ['1', '2'], '1', _timeout(), _interactive(ci))
                download = 'now' if k == '2' else 'later'
    if pack_flag is not None:                             # --video / --no-video / BDS_VIDEO_PACK thắng lựa chọn
        pack = pack_flag
        if pack and key in ('1', '3'):
            key, mode = '4', 'online'
        elif not pack:
            key, mode = '1', 'online'
    if mode == 'offline' and not pc['offline_allowed'] and scan:
        say(f"⚠ Lựa chọn [2] Dựng + AI ngay trên máy không còn dùng được: {pc['offline_reason']} – chuyển [4] Dựng video trên máy.")
        mode, key = 'online', '4'
    state = {'mode': mode, 'video_pack': 'install' if pack else 'skip', 'tier': pc['tier'], 'source': source,
             'chosen_at': prev['chosen_at'] if keep and prev.get('chosen_at') else now_iso(),
             'offline_model': pc['model'] if mode == 'offline' else '', 'offline_download': download if mode == 'offline' else '',
             'fallback': prev.get('fallback') if keep else None, 'sac': sac, 'runtime': (prev or {}).get('runtime') if keep else None}
    if keep and prev.get('migrated'):
        state['migrated'] = dict(prev['migrated'], shown=True)
    if not dry:
        save(state)
    tail = []
    if mode == 'offline':
        tail.append('tải mô hình ' + ('ngay' if download == 'now' else 'sau'))
    if pack and pc['weak']:
        tail.append(WEAK_WARNING)
    msg = (f"Hạng {pc['tier_label'] or '?'} · [{key}] {CHOICE_LABEL[key]}" + (' (tự chọn)' if not keep and auto and source != 'env' else '')
           + (' · ' + ' · '.join(tail) if tail else ''))
    status_ = 'dry' if dry else ('warn' if not scan else 'ok')
    # STOP=1: [1]/[3] – bộ cài DỪNG sau B8, không tạo .venv, không ffmpeg (chỉ AI trên mạng)
    write_out(a.get('out'), status=status_, msg=msg, mode=mode, pack='install' if pack else 'skip', tier=pc['tier'],
              download=download if mode == 'offline' else '', choice=key, stop='0' if pack else '1')
    return 0


# ---------------- cài Video AI offline (bước B9) ----------------
def fallback_online(state: dict, reason: str, dry=False) -> dict:
    state = dict(state, mode='online', fallback={'from': 'offline', 'reason': reason, 'at': now_iso()})
    if not dry:
        save(state)
    return state


def cmd_offline(a: dict, setup=None, verify=None, sac_fn=None, downloader=None) -> int:
    """Bước B9 (Python của .venv): chỉ khi đã chọn Offline. setup/verify/sac_fn/downloader thay được khi kiểm thử."""
    import videoai
    dry, out = a['dry'], a.get('out')
    st = load(dry=False)
    if dry:
        env_mode = (os.environ.get('BDS_VIDEO_MODE') or '').strip().lower()
        if env_mode != 'offline' and (st or {}).get('mode') != 'offline':
            write_out(out, status='dry', msg='Không cần – chưa chọn Video AI offline'); return 0
        write_out(out, status='dry', msg='Sẽ cài thư viện chạy mô hình (torch + diffusers…) vào .venv rồi nạp thử; '
                  'Windows bật Smart App Control chặn → chuyển Online'); return 0
    if not st or st.get('mode') != 'offline':
        write_out(out, status='skipped', msg='Không cần (đã chọn ' + MODE_LABEL[(st or {}).get('mode') or 'online'] + ')'); return 0
    gate = videoai.offline_gate()
    if not gate['allowed']:
        reason = 'Máy không còn đủ điều kiện Video AI offline: ' + gate['reason']
        fallback_online(st, reason)
        write_out(out, status='warn', msg='Lỗi B9: ' + reason + ' – đã chuyển Video AI Online', mode='online'); return 0
    sac = (sac_fn or sac_state)()
    if sac.get('state') in (1, 2):
        say(f"Smart App Control {sac['label']} – sẽ nạp thử thư viện sau khi cài để biết có bị chặn không.")
    verify = verify or videoai.verify_runtime
    rt = videoai.runtime_status(force=True)
    chk = verify() if rt['ready'] else {'ok': False, 'error': 'chưa cài'}
    note = ''
    # Đã cài mà nạp bị CHẶN (Smart App Control / chính sách) → cài lại cũng vô ích, không tải lại nhiều GB
    blocked_now = rt['ready'] and not chk['ok'] and common.IS_WIN and (sac.get('state') in (1, 2) or looks_blocked(chk.get('error', '')))
    if chk['ok']:
        say(f"Đã có thư viện chạy mô hình (torch {chk.get('torch')}, diffusers {chk.get('diffusers')}).")
    elif blocked_now:
        pass
    else:
        say('Cài thư viện chạy mô hình (torch + diffusers…) vào .venv – tải lớn, có thể 5–30 phút tuỳ mạng. Tiến độ pip:')
        t0 = time.monotonic()
        last = [0.0]

        def log(line):
            keep = re.match(r'\s*(Downloading|Collecting|Installing|Successfully|ERROR|Looking in)', line) or 'GB)' in line or 'MB)' in line
            if keep or time.monotonic() - last[0] > 30:
                say('  ' + line[:160] if keep else f'  … vẫn đang cài ({int(time.monotonic() - t0) // 60} phút)')
                last[0] = time.monotonic()
        r = (setup or videoai.run_setup)(log=log)
        if not r['ok']:
            reason = 'Chưa cài được thư viện chạy mô hình (pip lỗi – xem install_videoai.log). Kiểm tra mạng rồi chạy lại bộ cài với --chon-video.'
            _write_log(r.get('log', ''))
            fallback_online(st, reason)
            write_out(out, status='warn', msg='Lỗi B9: ' + reason + ' – tạm dùng Video AI Online', mode='online'); return 0
        if r.get('torch_source') == 'pypi-cpu':
            note = ' · ⚠ torch bản chỉ CPU (kho CUDA lỗi) – tạo cảnh rất chậm'
        chk = verify()
    if not chk['ok']:
        blocked = common.IS_WIN and (sac.get('state') in (1, 2) or looks_blocked(chk.get('error', '')))
        reason = sac_explain(sac) if blocked else ('Thư viện chạy mô hình đã cài nhưng không nạp được: ' + chk.get('error', '')[-200:])
        _write_log(chk.get('error', ''))
        st['runtime'] = {'ok': False, 'error': chk.get('error', '')[-400:], 'sac': sac}
        fallback_online(st, reason)
        for ln in _wrap(reason):
            say('⚠ ' + ln)
        write_out(out, status='warn', msg='Lỗi B9: ' + ('Smart App Control chặn thư viện Video AI offline' if blocked else 'thư viện Video AI offline không nạp được')
                  + ' – đã chuyển Video AI Online', mode='online'); return 0
    dev = 'card NVIDIA (CUDA)' if chk.get('cuda') else 'chip Apple (MPS)' if chk.get('mps') else 'CPU – rất chậm'
    st['runtime'] = {'ok': True, 'torch': chk.get('torch'), 'diffusers': chk.get('diffusers'), 'device': dev, 'sac': sac}
    save(st)
    msg = f"Video AI offline sẵn sàng: torch {chk.get('torch')} chạy trên {dev}{note}"
    status_ = 'ok' if (chk.get('cuda') or chk.get('mps')) and not note else 'warn'
    mid = st.get('offline_model') or videoai.recommended_model(hwscan.load())['id']
    if videoai.installed(mid):
        msg += f' · mô hình {mid} đã có'
    elif st.get('offline_download') == 'now':
        dl = (downloader or download_model)(mid, a)
        msg += ' · ' + dl['msg']
        if not dl['ok']:
            status_ = 'warn'
    else:
        msg += ' · mô hình tải sau trong app (Video AI › AI trên máy)'
    write_out(out, status=status_, msg=msg, mode='offline'); return 0


def download_model(mid: str, a: dict) -> dict:
    """Tải mô hình qua ĐÚNG đường của app (videoai.plan + start_download, xác nhận dung lượng THẬT)."""
    import videoai
    m = videoai.model(mid)
    try:
        pl = videoai.plan(mid)
    except Exception as e:
        return {'ok': False, 'msg': f'chưa đo được dung lượng mô hình ({e}) – tải sau trong app'}
    if pl['total_bytes'] != m.get('size_bytes'):           # khác số đã báo ở B8 → hỏi lại đúng số mới
        say(f"Hugging Face báo {m['title']} nay là {gb(pl['total_bytes'])} (đã báo {gb(m.get('size_bytes') or 0)}).")
        k, _ = ask(f"Tải {gb(pl['total_bytes'])}? [1] Để sau  [2] Tải ngay (chờ {_timeout()} giây = [1]): ", ['1', '2'], '1',
                   _timeout(), _interactive(a['ci']))
        if k != '2':
            return {'ok': True, 'msg': 'mô hình để tải sau trong app'}
    if not pl['enough_disk']:
        return {'ok': False, 'msg': f"ổ còn {hwscan.vn(pl['free_disk_gb'])} GB, cần ≥ {hwscan.vn(pl['need_gb'])} GB – dọn ổ rồi tải trong app"}
    try:
        videoai.start_download(mid, pl['total_bytes'], plan_fn=lambda *_a, **_k: pl)
    except videoai.Refused as e:
        return {'ok': False, 'msg': 'chưa tải được mô hình: ' + e.message}
    say(f"Đang tải {m['title']} ({gb(pl['total_bytes'])}) – tải dở thì app/bộ cài tải tiếp, không mất phần đã tải.")
    last = -1
    while True:
        s = videoai.DOWNLOAD.status()
        pct = int((s.get('received') or 0) * 100 / max(1, s.get('total') or 1))
        if pct // 5 != last // 5:
            say(f"  … {gb(s.get('received') or 0)} / {gb(s.get('total') or 0)} ({pct}%)"); last = pct
        if s.get('state') != 'running':
            break
        time.sleep(2)
    if s.get('state') == 'done':
        return {'ok': True, 'msg': f"đã tải mô hình {m['title']}"}
    return {'ok': False, 'msg': 'tải mô hình chưa xong (' + str(s.get('error') or '')[:120] + ') – tải tiếp trong app'}


def _write_log(text: str):
    try:
        (common.data_dir() / 'install_videoai.log').write_text(text or '', encoding='utf-8')
    except OSError:
        pass


def _wrap(s: str, n=110) -> list:
    out, cur = [], ''
    for w in s.split(' '):
        if len(cur) + len(w) + 1 > n:
            out.append(cur); cur = w
        else:
            cur = (cur + ' ' + w).strip()
    return out + ([cur] if cur else [])


def main(argv=None) -> int:
    try:
        return _main(argv)
    except KeyboardInterrupt:            # Ctrl+C lúc hỏi → bộ cài báo dừng giữa chừng, chạy lại làm tiếp
        print('\n   Đã dừng.', flush=True)
        return 130


def _main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = argv[0] if argv else 'show'
    a = {'dry': '--dry' in argv, 'ci': '--ci' in argv or bool(os.environ.get('CI')), 'ask': '--ask' in argv, 'out': '', 'pack': ''}
    for k in ('out', 'pack'):
        if '--' + k in argv and argv.index('--' + k) + 1 < len(argv):
            a[k] = argv[argv.index('--' + k) + 1]
    if cmd == 'choose':
        return cmd_choose(a)
    if cmd == 'offline':
        return cmd_offline(a)
    if cmd == 'show':
        print(json.dumps(load() or {}, ensure_ascii=False, indent=1))
        return 0
    print('Dùng: videomode.py choose|offline|show [--out TỆP] [--ci] [--dry] [--ask] [--pack yes|no]')
    return 2


if __name__ == '__main__':
    common.console_utf8()
    sys.exit(main())
