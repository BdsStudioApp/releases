"""Ghép nối app ↔ máy dựng bằng MÃ 6 SỐ (M1, 17/11/2026) – thay cho "tự tin địa chỉ app đầu tiên gọi tới" (TOFU).

Vì sao: trước đây máy dựng tự tin (ghim) địa chỉ https://<nhãn>.bdsstudio.app ĐẦU TIÊN gọi tới khi danh sách còn trống – kể cả qua CORS
trên GET /health. Kẻ xấu lấy 1 app miễn phí cùng hậu tố, gửi link cho khách mới cài là chiếm chỗ "app tin cậy" + biểu tượng màn hình nền.

Quy tắc mới (chỉ nguồn ĐÃ GHÉP mới được tin và là nơi biểu tượng "BDS Studio" mở):
  1) App (https, không phải trang dùng chung – common.shared_host) gọi POST /pair/start → máy dựng tạo yêu cầu: mã 6 số + hạn 5 phút,
     trả mã cho app hiện lên, đồng thời IN mã ra cửa sổ máy dựng.
  2) Người dùng mở TRANG CỦA MÁY DỰNG http://127.0.0.1:<cổng>/ghep (app có nút mở) – trang liệt kê địa chỉ app đang xin + mã.
     Đúng địa chỉ của mình và đúng mã app đang hiện → bấm "Cho phép" (1 lần).
  3) Nút đó là form POST /pair/confirm từ chính trang 127.0.0.1 (Origin phải là nguồn tại máy + vé của yêu cầu chỉ có trong trang
     – trang khác không đọc được, không nhúng được: frame-ancestors 'none'). → common.add_user_origin(how='paired', primary=True).
  Ghép lại (đổi tên miền, máy mới…): làm lại đúng các bước trên từ app mới; trang /ghep còn liệt kê địa chỉ đã ghép để GỠ.
  Dòng lệnh vẫn dùng được: python app/launcher.py --nguon-app <địa chỉ>.
"""
import hmac
import html
import secrets
import threading
import time
from urllib.parse import parse_qs, quote

import common

TTL_S = 300
MAX_PENDING = 5
_LOCK = threading.Lock()
_PENDING = {}                     # id → {origin, code, token, exp, state}
_PAGE_TOKEN = secrets.token_urlsafe(24)   # vé của trang /ghep (gỡ địa chỉ) – đổi mỗi lần máy dựng khởi động

PAGE_HEADERS = {
    'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
    # 'same-origin', KHÔNG 'no-referrer': với no-referrer trình duyệt gửi "Origin: null" cho form POST (Fetch › serializing a request
    # origin) → /pair/confirm luôn ORIGIN_DENIED, khách không bao giờ ghép được. same-origin vẫn không lộ địa chỉ trang ra nơi khác.
    'Referrer-Policy': 'same-origin',
}


def local_origins(port=None):
    p = int(port or common.PORT)
    return ('http://127.0.0.1:%d' % p, 'http://localhost:%d' % p)


def eligible(origin) -> bool:
    """Nguồn được XIN ghép: https chuẩn (không đường dẫn/tài khoản), không phải trang dùng chung, chưa là nguồn cố định."""
    return (isinstance(origin, str) and bool(origin) and common.normalize_origin(origin) == origin
            and not common.shared_host(origin) and origin not in common.ALLOWED_ORIGINS)


def _purge(now=None):
    now = now or time.time()
    for k in [k for k, v in _PENDING.items() if v['exp'] < now - 60]:
        _PENDING.pop(k, None)


def start(origin) -> dict:
    """Tạo yêu cầu ghép cho `origin` (Origin của app gọi tới). Đã tin → {trusted: True}."""
    if common.is_allowed_origin(origin):
        return {'ok': True, 'trusted': True}
    if not eligible(origin):
        raise ValueError('Địa chỉ này không ghép được với máy dựng (chỉ app https riêng của anh/chị, không phải trang dùng chung).')
    now = time.time()
    with _LOCK:
        _purge(now)
        for k in [k for k, v in _PENDING.items() if v['origin'] == origin]:
            _PENDING.pop(k, None)                       # yêu cầu mới của cùng địa chỉ thay yêu cầu cũ
        live = sorted((v['exp'], k) for k, v in _PENDING.items() if v['state'] == 'pending')
        while len(live) >= MAX_PENDING:
            _PENDING.pop(live.pop(0)[1], None)
        pid = secrets.token_urlsafe(12)
        code = '%06d' % secrets.randbelow(10 ** 6)
        _PENDING[pid] = {'origin': origin, 'code': code, 'token': secrets.token_urlsafe(24), 'exp': now + TTL_S, 'state': 'pending'}
    url = local_origins()[0] + '/ghep?id=' + quote(pid)
    try:
        print('[Ghép nối] %s xin dùng máy dựng – mã %s %s. Mở %s để xác nhận (hết hạn sau %d phút).'
              % (origin, code[:3], code[3:], url, TTL_S // 60), flush=True)
    except Exception:  # noqa: BLE001 – không có cửa sổ (pythonw) thì thôi
        pass
    return {'ok': True, 'trusted': False, 'id': pid, 'code': code, 'expires_in': TTL_S, 'confirm_url': url}


def status(origin, pid='') -> dict:
    """Cho app (chỉ về CHÍNH địa chỉ đó): đã được tin chưa + trạng thái yêu cầu ghép `pid` của nó."""
    out = {'ok': True, 'trusted': common.is_allowed_origin(origin), 'pairing': True}
    if pid:
        with _LOCK:
            e = _PENDING.get(pid)
            st = 'unknown' if not e or e['origin'] != origin else ('expired' if e['state'] == 'pending' and e['exp'] < time.time() else e['state'])
        out['state'] = st
    return out


def _take(pid, token):
    e = _PENDING.get(pid or '')
    if not e or not token or not hmac.compare_digest(str(token), e['token']):
        raise ValueError('Yêu cầu ghép không còn hoặc không hợp lệ – bấm "Ghép nối" lại trong app.')
    if e['state'] != 'pending' or e['exp'] < time.time():
        raise ValueError('Yêu cầu ghép đã hết hạn hoặc đã xử lý – bấm "Ghép nối" lại trong app.')
    return e


def confirm(pid, token) -> str:
    with _LOCK:
        e = _take(pid, token)
        o = common.add_user_origin(e['origin'], how='paired', primary=True)
        e['state'] = 'confirmed'
    try:
        print('[Ghép nối] Đã cho phép %s dùng máy dựng.' % o, flush=True)
    except Exception:  # noqa: BLE001
        pass
    return o


def deny(pid, token) -> str:
    with _LOCK:
        e = _take(pid, token)
        e['state'] = 'denied'
        return e['origin']


def remove(origin, token) -> bool:
    if not token or not hmac.compare_digest(str(token), _PAGE_TOKEN):
        raise ValueError('Trang đã cũ – tải lại trang rồi thử lại.')
    return common.remove_user_origin(origin)


# ---------------- trang của máy dựng (http://127.0.0.1:<cổng>/ghep) ----------------
_CSS = ('body{font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;max-width:640px;margin:32px auto;padding:0 16px;color:#1d2433;background:#fff}'
        'h1{font-size:22px}.card{border:1px solid #d8dde6;border-radius:12px;padding:16px;margin:12px 0}.o{font-weight:700;word-break:break-all}'
        '.code{font:700 32px/1.2 ui-monospace,Menlo,Consolas,monospace;letter-spacing:4px;margin:8px 0}.muted{color:#5b6475;font-size:14px}'
        'button{font:inherit;border-radius:8px;padding:10px 16px;border:1px solid #1f6feb;background:#1f6feb;color:#fff;cursor:pointer;margin:4px 8px 4px 0}'
        'button.alt{background:#fff;color:#1d2433;border-color:#c4cad6}.ok{color:#116329}.err{color:#b42318}'
        '@media (prefers-color-scheme:dark){body{background:#12151c;color:#e6e9ef}.card{border-color:#2c3340}.muted{color:#a3acbb}button.alt{background:#1b2029;color:#e6e9ef;border-color:#3a4252}}')


def _form(action, fields, label, icon, alt=False):
    hid = ''.join('<input type="hidden" name="%s" value="%s">' % (html.escape(k), html.escape(v)) for k, v in fields.items())
    return ('<form method="post" action="%s" style="display:inline">%s<button type="submit"%s>%s %s</button></form>'
            % (action, hid, ' class="alt"' if alt else '', icon, html.escape(label)))


def page(q=None, msg='', ok=True) -> str:
    q = q or {}
    now = time.time()
    with _LOCK:
        _purge(now)
        pend = [(k, dict(v)) for k, v in _PENDING.items() if v['state'] == 'pending' and v['exp'] >= now]
    focus = q.get('id', '')
    pend.sort(key=lambda kv: (kv[0] != focus, -kv[1]['exp']))
    parts = ['<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
             '<title>Ghép nối máy dựng</title><style>', _CSS, '</style></head><body><h1>🔗 Ghép nối máy dựng BDS Studio</h1>']
    if msg:
        parts.append('<p class="%s" data-testid="pair-msg">%s</p>' % ('ok' if ok else 'err', html.escape(msg)))
    if pend:
        parts.append('<p>Chỉ bấm <b>Cho phép</b> khi địa chỉ dưới đây <b>đúng là app của anh/chị</b> và mã <b>giống hệt</b> mã đang hiện trong app.</p>')
        for pid, e in pend:
            parts.append('<div class="card" data-testid="pair-request"><div class="muted">Địa chỉ app xin dùng máy dựng</div>'
                         '<div class="o">%s</div><div class="muted">Mã ghép nối</div><div class="code">%s %s</div>'
                         % (html.escape(e['origin']), e['code'][:3], e['code'][3:]))
            parts.append(_form('/pair/confirm', {'id': pid, 'token': e['token']}, 'Cho phép – đúng app của tôi', '✅'))
            parts.append(_form('/pair/deny', {'id': pid, 'token': e['token']}, 'Từ chối', '✖', alt=True))
            parts.append('<div class="muted">Hết hạn sau %d phút.</div></div>' % max(1, int((e['exp'] - now) // 60) + 1))
    else:
        parts.append('<p class="muted">Không có yêu cầu ghép nối nào đang chờ. Trong app: Cài đặt › Máy của tôi › <b>Ghép nối máy dựng</b>.</p>')
    ents = common.origin_entries()
    parts.append('<h2 style="font-size:18px">Địa chỉ app đã được tin</h2>')
    if ents:
        for i, e in enumerate(ents):
            parts.append('<div class="card"><div class="o">%s%s</div><div class="muted">%s</div>'
                         % (html.escape(e['origin']), ' (biểu tượng BDS Studio mở địa chỉ này)' if i == 0 else '', html.escape(e['how'])))
            parts.append(_form('/pair/remove', {'origin': e['origin'], 'token': _PAGE_TOKEN}, 'Gỡ', '🗑', alt=True))
            parts.append('</div>')
    else:
        parts.append('<p class="muted">Chưa có.</p>')
    parts.append('<p class="muted">Gỡ nhầm hoặc đổi sang địa chỉ app mới: mở app mới › Cài đặt › Máy của tôi › Ghép nối máy dựng, rồi cho phép ở đây.</p></body></html>')
    return ''.join(parts)


def handle(h, method, p, q):
    """Định tuyến /ghep và /pair/* (server.py gọi TRƯỚC kiểm Origin chung). → (status, body, ctype?, headers?)"""
    o = h.origin()
    if p == '/ghep' and method == 'GET':
        h._no_cors = True
        return 200, page(q), 'text/html; charset=utf-8', PAGE_HEADERS
    if p == '/pair/status' and method == 'GET':
        if eligible(o) or common.is_allowed_origin(o):
            h._pair_cors = o
        return 200, status(o, q.get('id', ''))
    if p == '/pair/start' and method == 'POST':
        h.body(4096)
        if eligible(o):
            h._pair_cors = o
        try:
            return 200, start(o)
        except ValueError as e:
            return 403, {'ok': False, 'error': {'code': 'ORIGIN_DENIED', 'message': str(e)}}
    if p in ('/pair/confirm', '/pair/deny', '/pair/remove') and method == 'POST':
        h._no_cors = True
        if o not in local_origins():          # chỉ form của CHÍNH trang 127.0.0.1 (trang khác không giả được Origin)
            return 403, {'ok': False, 'error': {'code': 'ORIGIN_DENIED', 'message': 'Chỉ xác nhận được trên trang của máy dựng.'}}
        f = {k: v[0] for k, v in parse_qs(h.body(8192).decode('utf-8', 'replace')).items()}
        try:
            if p == '/pair/confirm':
                msg, good = 'Đã cho phép ' + confirm(f.get('id'), f.get('token')) + ' – quay lại app, app tự nhận trong vài giây.', True
            elif p == '/pair/deny':
                msg, good = 'Đã từ chối ' + deny(f.get('id'), f.get('token')) + '.', True
            else:
                msg, good = ('Đã gỡ ' + str(f.get('origin')) + '.', True) if remove(f.get('origin'), f.get('token')) else ('Không có địa chỉ này.', False)
        except ValueError as e:
            msg, good = str(e), False
        return 200 if good else 400, page({}, msg, good), 'text/html; charset=utf-8', PAGE_HEADERS
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
