"""Hàng chờ "Gửi máy tính dựng" (17/11 – làm video từ ĐIỆN THOẠI).

Điện thoại không gọi tới máy dựng (127.0.0.1:8765) được → điện thoại gửi việc lên máy chủ app của khách (Apps Script, bảng `jobs`
type `video_remote`). Máy dựng ĐÃ LIÊN KẾT tự hỏi máy chủ:

  engine.remote_poll      mỗi 60 giây (máy chủ trả next_poll_s: 60 khi có người xem/có việc, 240 khi rảnh – luôn < 5 phút để điện thoại
                          không báo nhầm "máy tính đang tắt"); lỗi mạng/máy chủ → lùi dần 60 → 120 → 240 → 480 → 900 giây
  → nhận việc nguyên tử (máy chủ khoá) → dàn cảnh đã duyệt → cfg.json (videopack.build_cfg: tra OSM) → dựng MP4 (JobManager, một việc
    một lúc như mọi job khác) → engine.remote_progress (nhịp tim ≤ 2 phút/lần, chống treo) → engine.remote_drive_start (phiên Drive
    resumable) → tải lên (videopack.Uploads, cùng đường "Lưu Drive") → engine.remote_update done {file_id} | error {error}.

Liên kết: Chủ mở app TRÊN MÁY TÍNH này → Video → "Liên kết máy dựng với tài khoản" → app xin vé `engine.token` (quyền hạn chế, 90 ngày,
thu hồi ở Cài đặt › Bảo mật › Thiết bị) rồi gửi vào POST /remote/link. Vé lưu ở data_dir()/remote.json (chmod 600), không lưu khoá AI nào.
Vé bị thu hồi (AUTH_INVALID) → tự dừng hỏi, trạng thái "revoked".

  POST /remote/link   {server: {url, token}, name?}   ·   POST /remote/unlink   ·   GET /remote/status
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import common

POLL_S = 60
POLL_MIN_S, POLL_MAX_S = 20, 290            # máy chủ đề nghị trong khoảng này (≤ 290 giây: dưới ngưỡng "đang tắt" 5 phút)
BACKOFF = (60, 120, 240, 480, 900)
HEARTBEAT_S = 120
RENDER_TIMEOUT_S = 3 * 3600
UPLOAD_TIMEOUT_S = 2 * 3600
AUTH_CODES = ('AUTH_INVALID', 'AUTH_REQUIRED')


class RemoteError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _txt(s, n=300):
    return re.sub(r'\s+', ' ', str(s or '')).strip()[:n]


class Client:
    """Gọi máy chủ app bằng vé máy dựng. Hợp đồng §2: POST text/plain JSON {action, token, device_id, payload}."""

    def __init__(self, url, token, timeout=60, opener=None):
        url = str(url or '')
        if not (url.startswith('https://') or url.startswith('http://127.0.0.1')):
            raise ValueError('Địa chỉ máy chủ phải là https://')
        if not token:
            raise ValueError('Thiếu vé máy dựng (engine.token)')
        self.url, self.token, self.timeout = url, str(token), timeout
        self.opener = opener or urllib.request.urlopen

    def call(self, action, payload=None):
        body = json.dumps({'action': action, 'token': self.token, 'device_id': 'engine', 'payload': payload or {}}).encode('utf-8')
        req = urllib.request.Request(self.url, data=body, method='POST', headers={'Content-Type': 'text/plain;charset=utf-8'})
        try:
            with self.opener(req, timeout=self.timeout) as r:
                d = json.loads(r.read().decode('utf-8'))
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise RemoteError('NETWORK', 'Chưa gọi được máy chủ: ' + _txt(e, 160))
        if not isinstance(d, dict) or not d.get('ok'):
            e = (d or {}).get('error') or {} if isinstance(d, dict) else {}
            raise RemoteError(str(e.get('code') or 'SERVER'), str(e.get('message') or e.get('code') or 'Máy chủ báo lỗi'))
        return d.get('data') or {}


def default_build(outline):
    import videopack
    return videopack.build_cfg(outline)['cfg']


class RemoteRunner:
    def __init__(self, app=None, client_factory=Client, clock=time.time, render=None, upload=None, build=None, path=None):
        self.app = app
        self.client_factory = client_factory
        self.clock = clock
        self.render = render or self._render
        self.upload = upload or self._upload
        self.build = build or default_build
        self.path = Path(path) if path else common.data_dir() / 'remote.json'
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.thread = None
        self.stopped = False
        self.errors = 0
        self.idle = 0
        self.st = {'state': 'off', 'last_poll': 0, 'last_ok': 0, 'next_in_s': 0, 'current': None, 'last_job': None, 'last_error': '', 'done': 0}

    # ---------- cấu hình (vé) ----------
    def load(self):
        try:
            d = json.loads(self.path.read_text(encoding='utf-8'))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self, d):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(d, ensure_ascii=False), encoding='utf-8')
        try:
            os.chmod(tmp, 0o600)                  # vé chỉ người dùng máy đọc được
        except OSError:
            pass
        os.replace(tmp, self.path)

    def linked(self):
        c = self.load()
        return bool(c.get('url') and c.get('token') and not c.get('revoked'))

    def link(self, body):
        if not isinstance(body, dict):
            raise ValueError('Cần đối tượng JSON')
        srv = body.get('server') or {}
        client = self.client_factory(srv.get('url'), srv.get('token'))      # kiểm https + có vé
        name = _txt(body.get('name') or common.OS_NAME, 80)
        self._save({'url': client.url, 'token': client.token, 'name': name, 'linked_at': common.now_ms()})
        self.errors = 0
        self.idle = 0
        self.st.update(state='linked', last_error='')
        self.start()
        self.wake.set()                            # hỏi ngay lần đầu
        return self.status()

    def unlink(self):
        try:
            self.path.unlink()
        except OSError:
            pass
        self.st.update(state='off', current=None)
        self.wake.set()
        return self.status()

    def status(self):
        c = self.load()
        with self.lock:
            s = dict(self.st)
        s.update(linked=self.linked(), name=c.get('name', ''), linked_at=c.get('linked_at', 0), revoked=bool(c.get('revoked')),
                 server_host=re.sub(r'^https?://([^/]+).*$', r'\1', c.get('url', '')) if c.get('url') else '')
        return s

    def _client(self):
        c = self.load()
        if not (c.get('url') and c.get('token')) or c.get('revoked'):
            return None
        return self.client_factory(c['url'], c['token'])

    # ---------- vòng hỏi việc ----------
    def start(self):
        if self.thread and self.thread.is_alive():
            return
        if os.environ.get('BDS_REMOTE_NO_THREAD'):
            return
        self.stopped = False
        self.thread = threading.Thread(target=self._loop, daemon=True, name='bds-remote')
        self.thread.start()

    def start_if_linked(self):
        if self.linked():
            self.st['state'] = 'linked'
            self.start()

    def stop(self):
        self.stopped = True
        self.wake.set()

    def _loop(self):
        while not self.stopped:
            delay = self.poll_once()
            if delay is None:
                return                             # chưa liên kết / vé bị thu hồi
            self.st['next_in_s'] = delay
            self.wake.wait(delay)
            self.wake.clear()

    def _busy(self):
        try:
            return bool(self.app and self.app.jobs.busy())
        except Exception:  # noqa: BLE001
            return False

    def backoff(self):
        return BACKOFF[min(self.errors, len(BACKOFF)) - 1] if self.errors else POLL_S

    def poll_once(self):
        """Một lần hỏi việc. → số giây chờ tới lần sau | None (dừng hẳn)."""
        client = self._client()
        if client is None:
            self.st['state'] = 'off'
            return None
        self.st['last_poll'] = common.now_ms()
        busy = self._busy()
        try:
            d = client.call('engine.remote_poll', {'busy': busy, 'version': common.VERSION, 'name': self.load().get('name', '')})
        except RemoteError as e:
            if e.code in AUTH_CODES:               # Chủ thu hồi ở Cài đặt › Thiết bị (hoặc vé hết hạn) → dừng, không hỏi tiếp
                c = self.load(); c['revoked'] = True; self._save(c)
                self.st.update(state='revoked', last_error='Vé máy dựng đã bị thu hồi hoặc hết hạn – liên kết lại trong app.')
                return None
            self.errors += 1
            self.st.update(state='error', last_error=_txt(e))
            return self.backoff()
        self.errors = 0
        self.st.update(state='linked', last_ok=common.now_ms(), last_error='')
        job = d.get('job')
        if job:
            self.idle = 0
            self.process(client, job)
            return 5                               # còn việc khác? hỏi lại sớm
        self.idle += 1
        try:
            nxt = int(d.get('next_poll_s') or POLL_S)
        except (TypeError, ValueError):
            nxt = POLL_S
        return max(POLL_MIN_S, min(POLL_MAX_S, nxt))

    # ---------- làm 1 việc ----------
    def process(self, client, job):
        jid = str(job.get('id') or '')
        title = _txt(job.get('title') or 'Video từ điện thoại', 120)
        self.st['current'] = {'id': jid, 'title': title, 'stage': 'cfg', 'progress': 0}
        last_beat = [0.0]

        def beat(progress, stage, force=False):
            self.st['current'] = {'id': jid, 'title': title, 'stage': stage, 'progress': round(progress, 3)}
            now = self.clock()
            if force or now - last_beat[0] >= HEARTBEAT_S:
                last_beat[0] = now
                try:
                    client.call('engine.remote_progress', {'id': jid, 'progress': round(progress, 3), 'stage': stage})
                except RemoteError as e:
                    if e.code == 'CONFLICT':
                        raise                       # máy chủ đã chuyển việc cho máy khác / đã huỷ
        try:
            payload = job.get('payload') or {}
            kind = job.get('kind')
            if kind == 'cfg':
                cfg = payload.get('cfg')
            else:
                beat(0.02, 'cfg', force=True)
                cfg = self.build(payload.get('outline') or {})
            if not isinstance(cfg, dict) or not cfg.get('scenes'):
                raise ValueError('Dàn cảnh trống – soạn và duyệt lại trên điện thoại.')
            if not common.which('ffmpeg') and self.render == self._render:
                raise ValueError('Máy tính chưa cài Bộ công cụ dựng video (ffmpeg) – mở BDS Studio trên máy tính › Video › "Cài ngay".')
            spec = {'type': 'video_map', 'cfg': cfg, 'mode': 'mp4', 'title': 'Từ điện thoại · ' + title, 'voice': bool(job.get('voice')),
                    'name': common.safe_name(title, 'video_dien_thoai')}
            path = self.render(spec, lambda p: beat(0.05 + 0.75 * max(0.0, min(1.0, p)), 'render'))
            p = Path(path)
            if not p.is_file():
                raise ValueError('Dựng xong nhưng không thấy tệp MP4')
            beat(0.82, 'upload', force=True)
            s = client.call('engine.remote_drive_start', {'id': jid, 'name': p.name, 'mime': 'video/mp4', 'size': p.stat().st_size})
            fid = self.upload(p, s.get('upload_url'), lambda f: beat(0.82 + 0.17 * max(0.0, min(1.0, f)), 'upload')) or s.get('file_id')
            if not fid:
                raise ValueError('Google Drive không trả mã tệp')
            client.call('engine.remote_update', {'id': jid, 'state': 'done', 'file_id': fid})
            self.st['done'] += 1
            self.st['last_job'] = {'id': jid, 'title': title, 'state': 'done', 'at': common.now_ms()}
        except Exception as e:  # noqa: BLE001 – mọi lỗi đều báo về điện thoại
            msg = _txt(str(e), 300) or 'Máy dựng gặp lỗi'
            self.st['last_job'] = {'id': jid, 'title': title, 'state': 'error', 'error': msg, 'at': common.now_ms()}
            if not (isinstance(e, RemoteError) and e.code == 'CONFLICT'):
                try:
                    client.call('engine.remote_update', {'id': jid, 'state': 'error', 'error': msg})
                except RemoteError:
                    pass                            # máy chủ không nhận → việc treo, máy chủ tự xếp lại sau 30 phút
        finally:
            self.st['current'] = None

    # ---------- mặc định: dựng bằng JobManager + tải lên bằng videopack.Uploads ----------
    def _render(self, spec, progress):
        jm = self.app.jobs
        jid = jm.submit(spec)
        end = self.clock() + RENDER_TIMEOUT_S
        while True:
            j = jm.get(jid) or {}
            st = j.get('state')
            if st == 'done':
                mp4 = (j.get('outputs') or {}).get('mp4')
                if not mp4:
                    raise ValueError('Dựng xong nhưng không có MP4')
                return mp4
            if st == 'error':
                raise ValueError(_txt(j.get('error') or 'Dựng lỗi', 300))
            if self.clock() > end:
                raise ValueError('Dựng quá 3 giờ – dừng')
            progress(float(j.get('progress') or 0))
            time.sleep(2)

    def _upload(self, path, upload_url, progress):
        import videopack
        it = videopack.UPLOADS.start(path, upload_url)
        end = self.clock() + UPLOAD_TIMEOUT_S
        while True:
            s = videopack.UPLOADS.status(it['id']) or {}
            if s.get('state') == 'done':
                return s.get('file_id')
            if s.get('state') == 'error':
                raise ValueError('Tải lên Drive lỗi: ' + _txt(s.get('error'), 200))
            if self.clock() > end:
                raise ValueError('Tải lên Drive quá 2 giờ – dừng')
            progress((s.get('sent') or 0) / max(1, s.get('total') or 1))
            time.sleep(2)


def handle(app, method, p, q, hd):
    r = app.remote
    if method == 'GET' and p == '/remote/status':
        return 200, dict(r.status(), ok=True)
    if method == 'POST' and p == '/remote/link':
        return 200, dict(r.link(hd.json_body()), ok=True)
    if method == 'POST' and p == '/remote/unlink':
        return 200, dict(r.unlink(), ok=True)
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
