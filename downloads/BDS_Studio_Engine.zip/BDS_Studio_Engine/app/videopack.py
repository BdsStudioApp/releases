"""Gói Video (thợ D, bản 1.0.4) – phần máy dựng cho "Soạn kịch bản trong app":

  POST /video/outline_cfg   {outline}  dàn cảnh ĐÃ DUYỆT → cfg.json (dùng lại overnight.outline_to_cfg)
                            + tra toạ độ từng địa điểm trên OpenStreetMap (Nominatim) + khoảng cách
  GET  /video/road          cài đặt khoảng cách đường đi (không trả khoá)
  POST /video/road          {provider: off|geoapify|osrm, key?, osrm_url?}
  GET/POST /video/map_source[/test]  nguồn bản đồ có khoá của khách (bản thương mại: nền + tìm địa chỉ – mapsource.py)
  GET  /video/file_info?job=&key=mp4   kích thước + loại tệp kết quả (để máy chủ mở phiên Drive)
  POST /video/drive_upload  {job, key, upload_url}  gửi tệp lên Drive theo từng phần (phiên resumable do máy chủ mở)
  GET  /video/drive_upload/<id>        tiến độ {state, sent, total, file_id, error}

TOẠ ĐỘ: chỉ lấy từ Nominatim (dữ liệu © OpenStreetMap contributors, ODbL). Theo chính sách sử dụng Nominatim
(operations.osmfoundation.org/policies/nominatim): tối đa 1 yêu cầu/giây (ở đây ≥ 1,1 giây, khoá dùng chung), có User-Agent
nêu tên ứng dụng (không thông tin cá nhân), lưu đệm kết quả (90 ngày; không thấy: 3 ngày), không tra hàng loạt (tối đa 12 địa
điểm/lần). Không thấy địa điểm hoặc nằm ngoài vùng bản đồ có sẵn → cảnh thành THẺ SỐ LIỆU, không đoán vị trí.

KHOẢNG CÁCH: render_map chỉ tính đường chim bay (math.dist). Đường đi (tuỳ chọn, mặc định tắt):
  - Geoapify Routing API: gói Free cho phép dùng thương mại khi ghi nguồn ("Powered by Geoapify" + © OpenStreetMap),
    3.000 lượt/ngày, cần khoá miễn phí (geoapify.com/pricing – đối chiếu 16/11/2026 qua trang giá chính thức).
  - Máy chủ OSRM tự dựng (phần mềm BSD-2, dữ liệu OSM ODbL) – nhập địa chỉ riêng.
  KHÔNG dùng: máy chủ thử OSRM công khai (router.project-osrm.org – chính sách cấm dùng sản phẩm), openrouteservice gói
  miễn phí (không cho thương mại), GraphHopper gói miễn phí (chỉ phi thương mại), Google Routes (trả phí, cấm vẽ lên bản đồ khác).
  Không cấu hình / lỗi → ghi rõ "đường chim bay".
"""
import json
import math
import os
import re
import threading
import time
import uuid
import http.client
import urllib.parse
import urllib.request
from pathlib import Path

import common
import mapsource
import overnight
import secrets_store

# Máy chủ tìm địa chỉ công cộng của OpenStreetMap: CHỈ bản của chủ app. Bản thương mại (tools/sale_build.mjs cắt khối dưới)
# không có địa chỉ này → luôn tìm địa chỉ bằng nhà cung cấp có khoá của khách (mapsource.py, Cài đặt › Kết nối › Bản đồ).
NOMINATIM = ''
USER_AGENT = f'BDSStudio-Engine/{common.VERSION} (video map tool; +{common.APP_ORIGIN})'
MIN_INTERVAL_S = 1.1
HIT_TTL_S = 90 * 86400
MISS_TTL_S = 3 * 86400
MAX_PLACES = 12
VN_BOX = (8.0, 24.0, 102.0, 110.0)          # lat_min, lat_max, lon_min, lon_max
BANNED_ROUTERS = ('router.project-osrm.org', 'routing.openstreetmap.de', 'valhalla1.openstreetmap.de', 'map.project-osrm.org')
GEOAPIFY_URL = 'https://api.geoapify.com/v1/routing'
KEY_NAME = 'GEOAPIFY_KEY'
UPLOAD_PREFIXES = ['https://www.googleapis.com/upload/drive/v3/files?']
CHUNK = 8 * 2**20                           # bội số 256 KiB (yêu cầu của Drive resumable)
_sleep = time.sleep
UPLOAD_MIME = {'.mp4': 'video/mp4', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png'}
KICKER = overnight.KIND_KICKER


def _txt(s, n=200):
    return re.sub(r'\s+', ' ', str(s or '')).strip()[:n]


def _norm(q):
    return re.sub(r'\s+', ' ', str(q or '').strip().lower())


def _http_get(url, headers=None, timeout=15):
    req = urllib.request.Request(url, headers=dict({'User-Agent': USER_AGENT, 'Accept': 'application/json'}, **(headers or {})))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def _load_json(p, d):
    try:
        v = json.loads(Path(p).read_text(encoding='utf-8'))
        return v if isinstance(v, type(d)) else d
    except (OSError, ValueError):
        return d


def _save_json(p, v):
    try:
        p = Path(p); tmp = p.with_suffix('.tmp')
        tmp.write_text(json.dumps(v, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, p)
    except OSError:
        pass


# ───────────────────────── Nominatim ─────────────────────────
_RATE_LOCK = threading.Lock()
_LAST = [0.0]


class Geocoder:
    def __init__(self, path=None, fetch=None, clock=time.time, sleep=time.sleep):
        self.path = Path(path) if path else common.data_dir() / 'geocode_cache.json'
        self.fetch = fetch or _http_get
        self.clock, self.sleep = clock, sleep
        self.lock = threading.Lock()
        self.cache = _load_json(self.path, {})
        self.requests = 0

    def _wait(self):
        with _RATE_LOCK:
            gap = MIN_INTERVAL_S - (self.clock() - _LAST[0])
            if gap > 0:
                self.sleep(gap)
            _LAST[0] = self.clock()

    def lookup(self, query):
        """Tên địa điểm → {query, name, lat, lon, osm_url, display_name, source} hoặc {query, found: False, reason}."""
        q = _txt(query, 160)
        key = _norm(q)
        if not key:
            return {'query': q, 'found': False, 'reason': 'Tên trống'}
        now = self.clock()
        with self.lock:
            c = self.cache.get(key)
        if c and now - c.get('at', 0) < (HIT_TTL_S if c.get('found') else MISS_TTL_S):
            return dict(c['res'], source='cache')
        if not NOMINATIM:          # bản thương mại: không có máy chủ công cộng – default_geocoder() dùng nhà cung cấp có khoá
            return {'query': q, 'found': False, 'reason': 'Chưa có nguồn tìm địa chỉ – thêm khoá bản đồ ở Cài đặt › Kết nối', 'source': 'error'}
        params = urllib.parse.urlencode({'q': q, 'format': 'jsonv2', 'limit': 3, 'countrycodes': 'vn', 'accept-language': 'vi'})
        self._wait()
        self.requests += 1
        try:
            rows = self.fetch(NOMINATIM + '?' + params)
        except Exception as e:     # mạng lỗi: không lưu đệm, báo rõ
            return {'query': q, 'found': False, 'reason': 'Không gọi được OpenStreetMap: ' + _txt(e, 120), 'source': 'error'}
        res = None
        for r in rows if isinstance(rows, list) else []:
            try:
                lat, lon = float(r['lat']), float(r['lon'])
            except (KeyError, TypeError, ValueError):
                continue
            if VN_BOX[0] <= lat <= VN_BOX[1] and VN_BOX[2] <= lon <= VN_BOX[3]:
                ot, oi = str(r.get('osm_type') or ''), str(r.get('osm_id') or '')
                res = {'query': q, 'found': True, 'name': _txt(r.get('name') or q.split(',')[0], 60), 'lat': round(lat, 6), 'lon': round(lon, 6),
                       'display_name': _txt(r.get('display_name'), 200),
                       'osm_url': f'https://www.openstreetmap.org/{ot}/{oi}' if ot in ('node', 'way', 'relation') and oi.isdigit() else ''}
                break
        if res is None:
            res = {'query': q, 'found': False, 'reason': 'OpenStreetMap không có địa điểm này (trong Việt Nam)'}
        with self.lock:
            self.cache[key] = {'at': now, 'found': res['found'], 'res': res}
            if len(self.cache) > 3000:
                for k in sorted(self.cache, key=lambda k: self.cache[k].get('at', 0))[:500]:
                    self.cache.pop(k, None)
            _save_json(self.path, self.cache)
        return dict(res, source='nominatim')


def default_geocoder():
    """Bản thương mại (hoặc không có máy chủ công cộng): nhà cung cấp có khoá của khách – thiếu khoá → mapsource.MapKeyMissing.
    Bản của chủ app: Nominatim như cũ."""
    if mapsource.sale_mode() or not NOMINATIM:
        return mapsource.ProviderGeocoder()
    return Geocoder()


# ───────────────────────── khoảng cách ─────────────────────────
def straight_km(a, b):
    """Đường chim bay (haversine), a/b = [lat, lon]."""
    R = 6371.0088
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def fmt_km(km):
    return (f'{km:.1f}'.replace('.', ',') if km < 10 else f'{km:.0f}')


def distance_label(straight, road=None):
    if road and road.get('km'):
        return f'≈ {fmt_km(road["km"])} km đường đi'
    return f'≈ {fmt_km(straight)} km đường chim bay'


def _settings_path():
    return common.data_dir() / 'video_pack.json'


def road_settings():
    s = _load_json(_settings_path(), {}).get('road') or {}
    prov = s.get('provider') if s.get('provider') in ('off', 'geoapify', 'osrm') else 'off'
    return {'provider': prov, 'osrm_url': s.get('osrm_url') or '', 'key_set': bool(secrets_store.get_secret(KEY_NAME)),
            'sources': {'geoapify': 'Geoapify (gói Free cho phép thương mại, ghi nguồn; 3.000 lượt/ngày; cần khoá miễn phí)',
                        'osrm': 'Máy chủ OSRM tự dựng (BSD-2 + dữ liệu OSM ODbL)', 'off': 'Tắt – chỉ đường chim bay'}}


def _check_osrm_url(u):
    u = str(u or '').strip().rstrip('/')
    if not u:
        return ''
    p = urllib.parse.urlparse(u)
    if p.scheme not in ('http', 'https') or not p.hostname:
        raise ValueError('Địa chỉ OSRM phải bắt đầu bằng http:// hoặc https://')
    if p.hostname.lower() in BANNED_ROUTERS:
        raise ValueError('Không dùng máy chủ thử OSRM công khai (chính sách của họ cấm dùng cho sản phẩm). Nhập máy chủ OSRM của anh hoặc chọn Geoapify.')
    return u


def save_road_settings(d):
    prov = d.get('provider')
    if prov not in ('off', 'geoapify', 'osrm'):
        raise ValueError('provider phải là off, geoapify hoặc osrm')
    cur = _load_json(_settings_path(), {})
    road = dict(cur.get('road') or {}, provider=prov)
    if 'osrm_url' in d:
        road['osrm_url'] = _check_osrm_url(d.get('osrm_url'))
    if prov == 'osrm' and not road.get('osrm_url'):
        raise ValueError('Chưa nhập địa chỉ máy chủ OSRM')
    if isinstance(d.get('key'), str) and d['key'].strip():
        if len(d['key']) > 200:
            raise ValueError('Khoá không hợp lệ')
        secrets_store.set_secret(KEY_NAME, d['key'].strip())
    if prov == 'geoapify' and not secrets_store.get_secret(KEY_NAME):
        raise ValueError('Chưa nhập khoá Geoapify')
    cur['road'] = road
    _save_json(_settings_path(), cur)
    return road_settings()


class Router:
    def __init__(self, settings=None, fetch=None, path=None):
        self.s = settings or road_settings()
        self.fetch = fetch or _http_get
        self.path = Path(path) if path else common.data_dir() / 'road_cache.json'
        self.cache = _load_json(self.path, {})

    @property
    def enabled(self):
        return self.s.get('provider') in ('geoapify', 'osrm')

    def source_name(self):
        return {'geoapify': 'Geoapify', 'osrm': 'OSRM'}.get(self.s.get('provider'), '')

    def distance(self, a, b):
        """→ {km, source} hoặc None (tắt/lỗi → dùng đường chim bay)."""
        prov = self.s.get('provider')
        if prov not in ('geoapify', 'osrm'):
            return None
        key = f'{prov}:{a[0]:.5f},{a[1]:.5f}>{b[0]:.5f},{b[1]:.5f}'
        if key in self.cache:
            return dict(self.cache[key], cached=True)
        try:
            if prov == 'geoapify':
                k = secrets_store.get_secret(KEY_NAME)
                if not k:
                    return None
                url = GEOAPIFY_URL + '?' + urllib.parse.urlencode({'waypoints': f'{a[0]},{a[1]}|{b[0]},{b[1]}', 'mode': 'drive', 'apiKey': k})
                d = self.fetch(url)
                m = ((d.get('features') or [{}])[0].get('properties') or {}).get('distance')
            else:
                base = _check_osrm_url(self.s.get('osrm_url'))
                d = self.fetch(f'{base}/route/v1/driving/{a[1]},{a[0]};{b[1]},{b[0]}?overview=false')
                m = ((d.get('routes') or [{}])[0]).get('distance') if d.get('code', 'Ok') == 'Ok' else None
        except Exception:
            return None
        if not isinstance(m, (int, float)) or m <= 0:
            return None
        r = {'km': round(m / 1000, 2), 'source': self.source_name()}
        self.cache[key] = r
        _save_json(self.path, self.cache)
        return r


# ───────────────────────── dàn cảnh → cfg ─────────────────────────
def _host(u):
    m = re.match(r'^https?://(?:www\.)?([^/:?#]+)', str(u or ''))
    return m.group(1) if m else ''


def _inside_template(lat, lon, tpl, margin_m=2000):
    o, ext = tpl.get('origin'), tpl.get('extent_m')
    if not o or not ext:
        return True
    x = (lon - o[1]) * 111320 * math.cos(math.radians(o[0])); y = (lat - o[0]) * 110570
    return ext[0] + margin_m <= x <= ext[1] - margin_m and ext[2] + margin_m <= y <= ext[3] - margin_m


def _lines(sc):
    out = []
    for l in sc.get('narration') or []:
        if isinstance(l, dict):
            t, s = _txt(l.get('text'), 160), _txt(l.get('say'), 260)
            if t:
                out.append({'text': t, 'say': s} if s and s != t else t)
        elif _txt(l):
            out.append(_txt(l, 160))
    return out


def _plain(sub):
    return (sub['text'] if isinstance(sub, dict) else sub).replace('**', '')


def _words(subs):
    return sum(len(str(s.get('say') or s['text'] if isinstance(s, dict) else s).split()) for s in subs)


def _fig_text(f):
    return _txt(f.get('value'), 40) + (f' ({_txt(f.get("month"), 12)})' if f.get('month') else '')


def _card(title, figs):
    figs = [f for f in figs if f.get('source_url') and _txt(f.get('value'))]
    if not figs:
        return None
    card = {'title': _txt(title, 40)}
    big = next((f for f in figs if re.match(r'^\s*[~≈]?\d', str(f.get('value')))), None)
    if big:
        m = re.match(r'^\s*([~≈]?\d[\d.,]*)\s*(.*)$', str(big['value']))
        note = (_txt(big.get('label'), 30) + ' · ' if big.get('label') else '') + 'Nguồn: ' + (_host(big['source_url']) or 'đã ghi') + \
            (f' ({_txt(big.get("month"), 12)})' if big.get('month') else '')
        card['big'] = {'value': m.group(1), 'unit': _txt(m.group(2), 24), 'note': note}
    rows = [[_txt(f.get('label'), 24) or 'Số liệu', _fig_text(f)] for f in figs if f is not big][:4]
    if rows:
        card['rows'] = rows
    return card


def build_cfg(outline, geocoder=None, router=None, template=None, tiles=None):
    """Dàn cảnh đã duyệt (web/packs/bds/_lib/videoscript.js toEngineOutline) → {cfg, places, distances, warnings}.
    Bản thương mại: tìm địa chỉ + lớp nền bằng nhà cung cấp có khoá của khách (mapsource), chân hình ghi nguồn nhà cung cấp."""
    if not isinstance(outline, dict) or not isinstance(outline.get('scenes'), list) or not outline['scenes']:
        raise ValueError('Dàn cảnh trống')
    sale = mapsource.sale_mode() or not NOMINATIM
    tpl = template if template is not None else overnight._template()
    geocoder = geocoder or default_geocoder()
    router = router or Router()
    scenes = [s for s in outline['scenes'] if isinstance(s, dict)][:overnight.MAX_SCENES + 1]
    warnings, places = [], {}
    # 1) tra toạ độ (tuần tự, ≥ 1,1 giây/lần; trùng tên tra 1 lần; tối đa 12 địa điểm)
    order = []
    for sc in scenes:
        if sc.get('kind') == 'map':
            for q in sc.get('places') or []:
                q = _txt(q, 160)
                if q and _norm(q) not in [_norm(x) for x in order]:
                    order.append(q)
    if len(order) > MAX_PLACES:
        warnings.append(f'Chỉ tra {MAX_PLACES} địa điểm đầu (giới hạn tra mỗi lần); {len(order) - MAX_PLACES} địa điểm còn lại bỏ qua.')
    for q in order[:MAX_PLACES]:
        r = geocoder.lookup(q)
        if r.get('found') and not _inside_template(r['lat'], r['lon'], tpl):
            r = dict(r, found=False, outside=True, reason='Nằm ngoài vùng bản đồ có sẵn (Hà Nội) – chưa vẽ được')
        places[_norm(q)] = r
        if not r.get('found'):
            warnings.append(f'"{q}": {r.get("reason") or "không thấy trên OpenStreetMap"} → cảnh dùng thẻ số liệu, không đoán vị trí.')
    # 2) đầu vào dạng overnight (facts có nguồn, items có toạ độ thật)
    inp = {'title': _txt(outline.get('title'), 90), 'sources': [s for s in outline.get('sources') or [] if isinstance(s, dict)], 'scenes': []}
    for i, sc in enumerate(scenes):
        kind = sc.get('kind') if sc.get('kind') in KICKER else 'stat'
        figs = [f for f in sc.get('figures') or [] if isinstance(f, dict)]
        d = {'kind': kind, 'title': _txt(sc.get('title'), 80), 'say': ' '.join(_plain(x) for x in _lines(sc)),
             'facts': [{'text': _fig_text(f), 'source': f.get('source_url') or ''} for f in figs if f.get('source_url')]}
        if kind == 'map':
            items = [{'name': _txt(p['name'], 40), 'll': [p['lat'], p['lon']]}
                     for p in (places.get(_norm(q)) for q in sc.get('places') or []) if p and p.get('found')]
            if items:
                d['items'] = items
        inp['scenes'].append(d)
    cfg = overnight.outline_to_cfg(inp)
    # 3) hoàn thiện: phụ đề theo từng câu, thẻ số liệu có nhãn + nguồn, checklist đọc từng câu, khoảng cách ghi rõ loại
    distances, hosts, months = [], [], []
    items = {it['id']: it for it in cfg.get('items', [])}
    for i, (sc, src) in enumerate(zip(cfg['scenes'], scenes)):
        subs = _lines(src) or sc.get('subs') or []
        sc['subs'] = subs
        figs = [f for f in src.get('figures') or [] if isinstance(f, dict) and f.get('source_url')]
        for f in figs:
            h = _host(f['source_url'])
            if h and h not in hosts:
                hosts.append(h)
            if f.get('month') and f['month'] not in months:
                months.append(_txt(f['month'], 12))
        kind = src.get('kind')
        if kind == 'checklist':
            idx = [k for k, s in enumerate(subs) if re.match(r'^\s*(Một|Hai|Ba|1|2|3)\s*[:.)]', _plain(s), re.I)]
            lst = [re.sub(r'^\s*(Một|Hai|Ba|1|2|3)\s*[:.)]\s*', '', _plain(subs[k]), flags=re.I) for k in idx][:3]
            card = {'title': _txt(src.get('title'), 40) or 'Cần nhớ', 'list': lst or [_plain(s) for s in subs[1:4]] or ['Kiểm văn bản gốc']}
            if idx and idx == list(range(idx[0], idx[0] + len(idx))):
                card['list_from_sub'] = idx[0]
            sc['card'] = card
            sc.pop('fade_out', None)
        elif 'card' in sc or (kind not in ('hook', 'map')):
            c = _card(src.get('title'), figs)
            if c:
                sc['card'] = c
            else:
                sc.pop('card', None)
        for m in sc.get('measure') or []:
            a, b = items.get(m[0]), items.get(m[1])
            if a and b:
                st = straight_km(a['ll'], b['ll'])
                road = router.distance(a['ll'], b['ll']) if router.enabled else None
                lab = distance_label(st, road)
                if len(m) > 2:
                    m[2] = lab
                else:
                    m.append(lab)
                distances.append({'scene': i, 'from': a['name'], 'to': b['name'], 'straight_km': round(st, 2),
                                  'road_km': road['km'] if road else None, 'road_source': road['source'] if road else '', 'label': lab})
                if router.enabled and not road:
                    warnings.append(f'Cảnh {i + 1}: chưa lấy được quãng đường đi ({router.source_name()}) → ghi "đường chim bay".')
        need = _words(subs) / 3.0 + 0.8
        sc['dur'] = round(max(sc.get('dur', 3.0), need, 3.0), 1)
    # 4) toàn cục: thương hiệu, chân hình đủ nguồn (ODbL bắt buộc ghi OpenStreetMap), bìa
    if outline.get('channel'):
        cfg.setdefault('brand', {})['channel'] = _txt(outline['channel'], 60)
    elif isinstance(cfg.get('brand'), dict) and _txt(cfg['brand'].get('channel'), 60) in overnight.PLACEHOLDER_CHANNELS:
        # QA 18/11: app không gửi tên kênh (khách chưa điền Hồ sơ) → KHÔNG in chữ mẫu của dự án mẫu
        # ("Tên của bạn | Thương hiệu của bạn" ở bản bán) lên video của khách. Kênh thật trong mẫu (bản của chủ) giữ nguyên.
        cfg['brand'].pop('channel', None)
    road_used = any(d['road_km'] for d in distances)
    figs_txt = 'Số liệu: ' + (', '.join(hosts[:3]) or 'xem caption') + (f' ({months[0]})' if months else '') + '.' + \
        (f' Quãng đường: {router.source_name()} / OSM.' if road_used else '')
    basemap = None
    if sale:                   # nhà cung cấp có khoá: ghi nguồn theo điều khoản (Geoapify Free: "Powered by Geoapify" + OpenMapTiles + OSM)
        mp = getattr(geocoder, 'p', None) or mapsource.provider()
        foot = 'Bản đồ: ' + mp['attribution'] + '. ' + figs_txt + ' Vị trí: ' + mp['attribution_short'] + '.'
        try:
            basemap = mapsource.add_basemap(cfg, tiles)
        except mapsource.MapSourceError as e:   # thiếu nền ảnh không chặn video: vẫn còn nền sơ đồ có sẵn trong máy dựng
            warnings.append('Chưa tải được nền bản đồ: ' + str(e) + ' → video dùng nền sơ đồ có sẵn.')
    else:
        foot = 'Bản đồ: © OpenStreetMap contributors, OpenMapTiles. ' + figs_txt + ' Vị trí theo OpenStreetMap.'
    cfg['footer'] = foot
    cfg['sfx'] = True
    cfg['make_cover'] = True
    cfg['cover'] = {'scene': 1, 'text': _txt(outline.get('title'), 60)}
    cfg['title'] = _txt(outline.get('title'), 90) or cfg.get('title')
    found = [p for p in places.values() if p.get('found')]
    return {'cfg': cfg, 'places': list(places.values()), 'distances': distances, 'warnings': warnings,
            'stats': {'places': len(places), 'found': len(found), 'nominatim_requests': 0 if sale else geocoder.requests,
                      'geocode_requests': geocoder.requests, 'geocode_source': getattr(geocoder, 'source', 'nominatim'),
                      'basemap_tiles': (basemap or {}).get('tiles', 0), 'map_scenes': sum(1 for s in cfg['scenes'] if 'camera' in s)}}


# ───────────────────────── tải lên Drive (phiên resumable) ─────────────────────────
class Uploads:
    def __init__(self):
        self.items = {}
        self.lock = threading.Lock()

    @staticmethod
    def check_url(u):
        u = str(u or '')
        if not any(u.startswith(p) for p in UPLOAD_PREFIXES):
            raise ValueError('Địa chỉ tải lên không phải phiên Google Drive')
        return u

    def start(self, path, upload_url, conn_factory=None):
        upload_url = self.check_url(upload_url)
        p = Path(path)
        if not p.is_file():
            raise ValueError('Không thấy tệp kết quả')
        uid = uuid.uuid4().hex[:12]
        it = {'id': uid, 'state': 'running', 'sent': 0, 'total': p.stat().st_size, 'file_id': None, 'error': None, 'name': p.name}
        with self.lock:
            self.items[uid] = it
            if len(self.items) > 50:
                for k in list(self.items)[:-50]:
                    self.items.pop(k, None)
        threading.Thread(target=self._run, args=(it, p, upload_url, conn_factory), daemon=True, name='bds-drive-up').start()
        return dict(it)

    def status(self, uid):
        it = self.items.get(uid)
        return dict(it) if it else None

    @staticmethod
    def _conn(url):
        u = urllib.parse.urlparse(url)
        port = u.port or (443 if u.scheme == 'https' else 80)
        proxy = (os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')) if u.scheme == 'https' else None
        if proxy:                                   # máy dùng proxy HTTP: mở đường hầm CONNECT rồi TLS tới Google
            pp = urllib.parse.urlparse(proxy)
            c = http.client.HTTPSConnection(pp.hostname, pp.port or 80, timeout=120)
            c.set_tunnel(u.hostname, port)
            return c
        cls = http.client.HTTPSConnection if u.scheme == 'https' else http.client.HTTPConnection
        return cls(u.hostname, port, timeout=120)

    def _put(self, url, headers, body, conn_factory):
        u = urllib.parse.urlparse(url)
        c = (conn_factory or self._conn)(url)
        try:
            c.request('PUT', u.path + ('?' + u.query if u.query else ''), body=body, headers=headers)
            r = c.getresponse()
            return r.status, {k.lower(): v for k, v in r.getheaders()}, r.read()
        finally:
            c.close()

    def _run(self, it, path, url, conn_factory):
        total = it['total']
        off, tries = 0, 0
        try:
            with open(path, 'rb') as f:
                while True:
                    f.seek(off)
                    data = f.read(CHUNK)
                    end = off + len(data) - 1
                    hdr = {'Content-Length': str(len(data)), 'Content-Range': f'bytes {off}-{end}/{total}' if data else f'bytes */{total}'}
                    try:
                        st, h, body = self._put(url, hdr, data, conn_factory)
                    except (OSError, http.client.HTTPException) as e:
                        st, h, body = 0, {}, str(e).encode()
                    if st in (200, 201):
                        d = json.loads(body.decode('utf-8') or '{}')
                        it.update(state='done', sent=total, file_id=d.get('id'))
                        return
                    if st == 308:                      # chưa đủ: Range cho biết Google đã nhận tới đâu
                        m = re.match(r'bytes=0-(\d+)', h.get('range', ''))
                        off = int(m.group(1)) + 1 if m else 0
                        it['sent'] = off; tries = 0
                        continue
                    if st in (0, 500, 502, 503, 504) and tries < 5:
                        tries += 1; _sleep(min(30, 2 ** tries))
                        st2, h2, _ = (0, {}, b'')
                        try:                            # hỏi Google đã nhận bao nhiêu rồi gửi tiếp
                            st2, h2, _ = self._put(url, {'Content-Length': '0', 'Content-Range': f'bytes */{total}'}, b'', conn_factory)
                        except (OSError, http.client.HTTPException):
                            pass
                        if st2 == 308:
                            m = re.match(r'bytes=0-(\d+)', h2.get('range', ''))
                            off = int(m.group(1)) + 1 if m else 0
                        continue
                    msg = 'Phiên tải lên đã hết hạn – bấm lưu lại' if st in (404, 410) else f'Google Drive trả lỗi {st}'
                    raise RuntimeError(msg)
        except Exception as e:
            it.update(state='error', error=_txt(e, 300))


UPLOADS = Uploads()


def output_path(app, job_id, key):
    j = app.jobs.get(str(job_id or ''))
    if not j:
        raise KeyError('Không có job này')
    p = (j.get('outputs') or {}).get(str(key or ''))
    if not p:
        raise KeyError('Job chưa có tệp ' + str(key))
    p = Path(p)
    if p.suffix.lower() not in UPLOAD_MIME:
        raise ValueError('Chỉ gửi được MP4/JPG/PNG')
    return p


# ───────────────────────── định tuyến ─────────────────────────
def handle(app, method, p, q, hd):
    if p == '/video/map_source' or p.startswith('/video/map_source/'):   # Cài đặt › Kết nối › Bản đồ (mapsource.py)
        try:
            return mapsource.handle(method, p, hd)
        except mapsource.MapSourceError as e:
            return e.status, e.payload()
    if method == 'GET':
        if p == '/video/road':
            return 200, dict(road_settings(), ok=True)
        if p == '/video/file_info':
            f = output_path(app, q.get('job'), q.get('key'))
            return 200, {'ok': True, 'name': f.name, 'size': f.stat().st_size, 'mime': UPLOAD_MIME[f.suffix.lower()]}
        if p.startswith('/video/drive_upload/'):
            st = UPLOADS.status(p.rsplit('/', 1)[-1])
            if not st:
                return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có lượt tải lên này'}}
            return 200, dict(st, ok=True)
        return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
    if p == '/video/outline_cfg':
        d = hd.json_body()
        try:
            return 200, dict(build_cfg(d.get('outline') or d), ok=True)
        except mapsource.MapSourceError as e:      # bản thương mại chưa có khoá bản đồ → chặn rõ ràng + lối tới thẻ Kết nối
            return e.status, e.payload()
    if p == '/video/road':
        return 200, dict(save_road_settings(hd.json_body()), ok=True)
    if p == '/video/drive_upload':
        d = hd.json_body()
        f = output_path(app, d.get('job'), d.get('key'))
        return 200, dict(UPLOADS.start(f, d.get('upload_url')), ok=True)
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
