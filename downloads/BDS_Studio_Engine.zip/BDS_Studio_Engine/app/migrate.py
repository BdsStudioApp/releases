"""Chuyển máy: đóng gói cấu hình engine (KHÔNG có bí mật) + các dự án → zip.

Có mật khẩu và cài được `pyzipper` → zip mã hoá AES-256. Không thì zip thường (vẫn không có bí mật).
Khoá Vbee nằm trong keychain máy cũ, không bao giờ vào gói – trên máy mới nhập lại trong app.
"""
import io
import json
import re
import zipfile
from pathlib import Path

import common
import secrets_store

FORMAT = 'bds-studio-migrate/1'
NAME_RE = re.compile(r'^[\w\-\.]{1,80}$', re.UNICODE)
SKIP_DIRS = {'out', 'voice', '__pycache__'}
MAX_FILE = 50 * 2**20


def _pyzipper():
    try:
        import pyzipper
        return pyzipper
    except Exception:
        return None


def export_zip(password: str = None) -> tuple:
    """-> (bytes, info)"""
    cfg = common.load_config()
    projects = []
    files = {}
    for d in sorted(common.projects_dir().iterdir()) if common.projects_dir().is_dir() else []:
        if not d.is_dir() or not NAME_RE.match(d.name):
            continue
        projects.append(d.name)
        for f in d.rglob('*'):
            rel = f.relative_to(d)
            if f.is_file() and not (set(rel.parts[:-1]) & SKIP_DIRS) and f.stat().st_size <= MAX_FILE:
                files[f'projects/{d.name}/{rel.as_posix()}'] = f.read_bytes()
    secret_values = [v for v in (secrets_store.get_secret(k) for k in secrets_store.ALLOWED_KEYS) if v]
    manifest = {'format': FORMAT, 'version': common.VERSION, 'created': common.now_ms(), 'os': common.OS_NAME,
                'projects': projects, 'has_secrets': False,
                'note': 'Không chứa khoá dịch vụ. Trên máy mới, nhập lại khoá Vbee trong app.'}
    files['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=1).encode()
    files['config.json'] = json.dumps(cfg, ensure_ascii=False, indent=1).encode()
    # chốt an toàn: không tệp nào được chứa giá trị bí mật
    for name, b in files.items():
        for v in secret_values:
            if len(v) >= 6 and v.encode() in b:
                raise RuntimeError(f'Tệp {name} có chứa khoá bí mật – dừng đóng gói.')
    buf = io.BytesIO()
    pz = _pyzipper() if password else None
    if pz:
        with pz.AESZipFile(buf, 'w', compression=pz.ZIP_DEFLATED, encryption=pz.WZ_AES) as z:
            z.setpassword(password.encode())
            for n, b in files.items():
                z.writestr(n, b)
        enc = 'aes'
    else:
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for n, b in files.items():
                z.writestr(n, b)
        enc = 'none'
    data = buf.getvalue()
    out = common.migrate_dir() / f'bds_studio_chuyen_may_{__import__("datetime").date.today().isoformat()}.zip'
    out.write_bytes(data)
    return data, {'encryption': enc, 'projects': projects, 'saved_to': str(out),
                  'password_ignored': bool(password) and not pz}


def import_zip(data: bytes, password: str = None, overwrite: bool = False) -> dict:
    buf = io.BytesIO(data)
    pz = _pyzipper()
    try:
        z = pz.AESZipFile(buf) if pz else zipfile.ZipFile(buf)
    except zipfile.BadZipFile:
        raise ValueError('Tệp không phải gói chuyển máy (.zip).')
    with z:
        if password:
            z.setpassword(password.encode())
        try:
            manifest = json.loads(z.read('manifest.json'))
        except KeyError:
            raise ValueError('Thiếu manifest.json – không phải gói của BDS Studio.')
        except RuntimeError:
            raise ValueError('Gói có mật khẩu: nhập đúng mật khẩu.')
        if manifest.get('format') != FORMAT:
            raise ValueError('Gói không đúng định dạng.')
        imported, skipped = [], []
        try:
            cfg = json.loads(z.read('config.json'))
            common.save_config({k: v for k, v in cfg.items() if k in common.DEFAULT_CONFIG})
        except KeyError:
            pass
        root = common.projects_dir().resolve()
        for info in z.infolist():
            n = info.filename
            if not n.startswith('projects/') or n.endswith('/'):
                continue
            parts = n.split('/')
            if len(parts) < 3 or not NAME_RE.match(parts[1]) or any(p in ('', '.', '..') for p in parts[1:]):
                continue
            dest = (root / Path(*parts[1:])).resolve()
            if not common._inside(dest, root):
                continue                                   # chống zip-slip
            if (root / parts[1]).exists() and parts[1] not in imported and not overwrite:
                if parts[1] not in skipped:
                    skipped.append(parts[1])
                continue
            if info.file_size > MAX_FILE:
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(info))
            if parts[1] not in imported:
                imported.append(parts[1])
    return {'imported': imported, 'skipped_existing': skipped, 'config': True,
            'note': 'Nhập lại khoá Vbee trong app (khoá không đi theo gói).'}
