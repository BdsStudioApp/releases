"""Tự cập nhật máy dựng BDS Studio – CHỈ từ bản phát hành có ký số (POST /update/auto) – và khôi phục bản trước (POST /update/rollback).
16/11: bỏ hẳn đường nhận zip thủ công (POST /update) – khách không tự cập nhật bằng file.

Quy trình cài (Updater.apply – chỉ gọi nội bộ sau khi đã kiểm chữ ký; mọi bước kiểm tra xong mới đụng tới file thật):
  1. kiểm tra zip: phải có app/server.py + app/common.py (VERSION), không đường dẫn tuyệt đối / '..' / liên kết tượng trưng,
     giới hạn số file và dung lượng giải nén; phiên bản mới ≥ bản đang chạy (hạ cấp phải xác nhận allow_downgrade=1)
  2. giải nén vào <engine>/.update_tmp/<id>/
  3. chuyển các mục cấp gốc của bản hiện tại (app/, web/, engine/ …) sang <engine>/.backup/<phiên bản cũ>/, đưa bản mới vào
     – KHÔNG đụng .venv, .backup, mọi mục bắt đầu bằng dấu chấm, và dữ liệu người dùng (~/BDS Studio, ~/.bds_studio, cache)
  4. requirements.txt đổi → pip install -r requirements.txt (lỗi → tự trả lại bản cũ)
  5. trả lời web, rồi tự khởi động lại (os.execv) với --no-browser --after-update

Cập nhật tự động (POST /update/auto, theo dõi GET /update → "auto"):
  tải /release.json + /release.json.sig (CHỈ đúng host này, https, không theo chuyển hướng sang host khác,
  giới hạn kích thước) → kiểm chữ ký ed25519 bằng khoá công khai gắn sẵn (release_check.PUBKEY) → parts.engine mới hơn bản đang chạy?
  → tải zip của ĐÚNG hệ điều hành máy này (/downloads/BDS_Studio_Video_Windows.zip | _Mac.zip; bản phát hành cũ chỉ có
    /downloads/BDS_Studio_Engine.zip thì dùng zip đó) → kiểm sha256 + kích thước theo release.json → bản trong zip phải đúng parts.engine
  → apply() ở trên (sao lưu bản cũ vào .backup/ để khôi phục) → khởi động lại.
  Thiếu chữ ký / sai chữ ký / sai khoá / tệp bị sửa → dừng, không cài. Đang dựng: nút bấm → BUSY; app gọi nền (silent) → chờ dựng xong.
"""
import hashlib
import urllib.error
import urllib.request
from urllib.parse import urljoin, urlparse
import io
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from pathlib import Path, PurePosixPath

import common
import release_check

MAX_UPDATE = 300 * 2**20          # thân yêu cầu tối đa (file zip)
MAX_UNPACKED = 1024 * 2**20       # tổng dung lượng giải nén tối đa
MAX_FILES = 20000
KEEP_BACKUPS = 3
IGNORE_TOP = {'__MACOSX', '__pycache__'}
VERSION_RE = re.compile(r'''^VERSION\s*=\s*['"]([^'"]+)['"]''', re.M)


class UpdateError(Exception):
    def __init__(self, code, message, status=400, **extra):
        super().__init__(message)
        self.code, self.message, self.status, self.extra = code, message, status, extra


def cmp_version(a, b):
    """So sánh '1.0.10' với '1.0.9' theo từng số; thiếu phần coi là 0. Trả -1/0/1."""
    def parts(v):
        out = []
        for x in str(v or '0').split('.'):
            m = re.match(r'\d+', x)
            out.append(int(m.group()) if m else 0)
        return out
    pa, pb = parts(a), parts(b)
    n = max(len(pa), len(pb))
    pa += [0] * (n - len(pa)); pb += [0] * (n - len(pb))
    return (pa > pb) - (pa < pb)


def restart_argv(argv=None):
    """Lệnh chạy lại chính máy dựng: cùng Python (.venv), đường dẫn tuyệt đối, không mở thêm trình duyệt."""
    argv = list(sys.argv if argv is None else argv)
    script = os.path.abspath(argv[0]) if argv else str(common.APP_DIR / 'server.py')
    rest = [a for a in argv[1:] if a not in ('--no-browser', '--after-update')]
    return [sys.executable, script] + rest + ['--no-browser', '--after-update']


def default_restart():
    argv = restart_argv()
    for s in (sys.stdout, sys.stderr):
        try:
            s.flush()
        except Exception:
            pass
    os.execv(argv[0], argv)


def default_pip(root: Path):
    try:
        p = subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', str(root / 'requirements.txt')],
                           capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=900,
                           env=common.child_env())
        return p.returncode == 0, (p.stdout + p.stderr)[-2000:]
    except (OSError, subprocess.SubprocessError) as e:
        return False, str(e)


def read_version(common_py_text):
    m = VERSION_RE.search(common_py_text or '')
    return m.group(1) if m else None


def _safe_parts(name):
    """Tên trong zip → danh sách phần đường dẫn an toàn, hoặc None nếu nguy hiểm (zip-slip)."""
    n = name.replace('\\', '/')
    if n.startswith('/') or re.match(r'^[A-Za-z]:', n) or '\x00' in n:
        return None
    parts = [p for p in PurePosixPath(n).parts if p not in ('', '.')]
    if any(p == '..' or ':' in p for p in parts):
        return None
    return parts


class Updater:
    def __init__(self, root: Path = None, pip=None, restart=None, restart_delay=1.0):
        self.root = Path(root or common.ENGINE_ROOT)
        self.pip = pip or default_pip
        self.restart = restart or default_restart
        self.restart_delay = restart_delay
        self.lock = threading.Lock()
        self.auto = AutoUpdate(self)          # POST /update/auto (nguồn cố định: AUTO_BASE)

    # ---------- thông tin ----------
    @property
    def backup_dir(self):
        return self.root / '.backup'

    def current_version(self):
        try:
            return read_version((self.root / 'app' / 'common.py').read_text(encoding='utf-8')) or common.VERSION
        except OSError:
            return common.VERSION

    def backups(self):
        out = []
        if self.backup_dir.is_dir():
            for d in self.backup_dir.iterdir():
                meta = self._meta(d)
                if meta:
                    out.append({'version': meta.get('version', d.name), 'at': meta.get('at', 0), 'dir': d.name})
        return sorted(out, key=lambda b: -b['at'])

    def status(self):
        auto = getattr(self, 'auto', None)
        return {'ok': True, 'version': self.current_version(), 'backups': [{'version': b['version'], 'at': b['at']} for b in self.backups()],
                'busy': self.lock.locked() or bool(auto and auto.running()), 'auto': auto.status() if auto else None}

    @staticmethod
    def _meta(d: Path):
        try:
            m = json.loads((d / '.meta.json').read_text(encoding='utf-8'))
            return m if isinstance(m, dict) and isinstance(m.get('items'), list) else None
        except (OSError, ValueError):
            return None

    # ---------- kiểm tra zip ----------
    def inspect(self, data: bytes):
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
            infos = z.infolist()
        except (zipfile.BadZipFile, ValueError, OSError):
            raise UpdateError('BAD_ZIP', 'Tệp không phải zip máy dựng hợp lệ.')
        if len(infos) > MAX_FILES:
            raise UpdateError('BAD_ZIP', 'Zip có quá nhiều tệp.')
        total = 0
        entries = []
        for i in infos:
            parts = _safe_parts(i.filename)
            if parts is None:
                raise UpdateError('BAD_ZIP', f'Zip chứa đường dẫn nguy hiểm: {i.filename[:120]}')
            mode = (i.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK:
                raise UpdateError('BAD_ZIP', f'Zip chứa liên kết tượng trưng: {i.filename[:120]}')
            total += i.file_size
            if total > MAX_UNPACKED:
                raise UpdateError('BAD_ZIP', 'Zip giải nén ra quá lớn.')
            if parts:
                entries.append((parts, i))
        # thư mục gốc của gói: '' hoặc 1 cấp (BDS_Studio_Engine/) hoặc 2 cấp – bố cục 17/11: BDS_Studio_Engine/_he_thong/
        # (ngoài cùng chỉ có nút "Cai dat voi 1 click" + Doc truoc.txt – không thuộc máy dựng nên không chép vào thư mục máy dựng)
        prefix = None
        for parts, i in entries:
            if not i.is_dir() and parts[-2:] == ['app', 'server.py'] and len(parts) <= 4 and parts[0] not in IGNORE_TOP:
                prefix = parts[:-2]
                break
        if prefix is None:
            raise UpdateError('BAD_ZIP', 'Zip không có app/server.py – không phải gói máy dựng BDS Studio.')
        files = []
        for parts, i in entries:
            if parts[:len(prefix)] != prefix or len(parts) == len(prefix):
                continue
            rel = parts[len(prefix):]
            if rel[0] in IGNORE_TOP or rel[0].startswith('.') or rel[-1] == '.DS_Store' or '__pycache__' in rel:
                continue                                    # không bao giờ ghi vào .venv/.backup/…
            files.append((rel, i))
        try:
            ver = read_version(z.read(next(i for rel, i in files if rel == ['app', 'common.py'])).decode('utf-8', 'replace'))
        except StopIteration:
            ver = None
        if not ver:
            raise UpdateError('BAD_ZIP', 'Zip thiếu app/common.py (VERSION).')
        return z, files, ver

    def _protected(self):
        out = []
        for fn in (common.data_dir, common.home_dir, common.cache_dir):
            try:
                out.append(fn().resolve())
            except OSError:
                pass
        return out

    def _top_items(self, names):
        prot = self._protected()
        keep = []
        for n in sorted(names):
            p = (self.root / n)
            if any(common._inside(x, p) for x in prot):
                continue                                    # thư mục chứa dữ liệu người dùng → không thay
            keep.append(n)
        return keep

    # ---------- cập nhật ----------
    def apply(self, data: bytes, allow_downgrade=False, busy=False, expect_version=None):
        if busy:
            raise UpdateError('BUSY', 'Máy đang dựng video – chờ xong rồi cập nhật.', 409)
        if not self.lock.acquire(blocking=False):
            raise UpdateError('BUSY', 'Đang cập nhật máy dựng.', 409)
        try:
            z, files, new_ver = self.inspect(data)
            if expect_version and cmp_version(new_ver, expect_version) != 0:
                raise UpdateError('VERSION_MISMATCH', f'Gói máy dựng là bản {new_ver}, khác bản đã ký {expect_version} – dừng, không cài.', 502)
            cur = self.current_version()
            if cmp_version(new_ver, cur) < 0 and not allow_downgrade:
                raise UpdateError('DOWNGRADE', f'Tệp là bản {new_ver}, cũ hơn bản đang chạy {cur}. Xác nhận nếu muốn hạ cấp.', 409,
                                  current=cur, incoming=new_ver)
            tmp_base = self.root / '.update_tmp'
            tmp = tmp_base / uuid.uuid4().hex[:10]
            tmp.mkdir(parents=True)
            try:
                for rel, info in files:
                    dest = tmp.joinpath(*rel)
                    if not common._inside(dest, tmp):
                        raise UpdateError('BAD_ZIP', 'Zip chứa đường dẫn nguy hiểm.')
                    if info.is_dir():
                        dest.mkdir(parents=True, exist_ok=True); continue
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(info) as src, open(dest, 'wb') as out:
                        shutil.copyfileobj(src, out, 1 << 20)
                    mode = (info.external_attr >> 16) & 0o777
                    if os.name != 'nt' and mode & 0o111:
                        os.chmod(dest, 0o755)
                old_req = self._read(self.root / 'requirements.txt')
                items = self._top_items(p.name for p in tmp.iterdir())
                backup = self._swap_in(tmp, items, cur, new_ver)
                pip = 'skipped'
                if self._read(self.root / 'requirements.txt') != old_req:
                    ok, log = self.pip(self.root)
                    if not ok:
                        self._restore(backup, drop_current=True)
                        raise UpdateError('PIP_FAILED', 'Cài thư viện cho bản mới chưa được (kiểm tra mạng) – đã giữ nguyên bản cũ.', 500,
                                          log=str(log)[-800:])
                    pip = 'ok'
                self._prune()
                return {'ok': True, 'from': cur, 'to': new_ver, 'backup': cur, 'pip': pip, 'restarting': True, 'items': items}
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
                try:
                    tmp_base.rmdir()
                except OSError:
                    pass
        finally:
            self.lock.release()

    def _swap_in(self, src: Path, items, cur_ver, new_ver, backup_name=None):
        """Chuyển items hiện có sang .backup/<cur_ver>/, đưa items từ src vào gốc. Lỗi giữa chừng → trả lại như cũ."""
        self.backup_dir.mkdir(exist_ok=True)
        bk = self.backup_dir / common.safe_name(backup_name or cur_ver, 'ban_cu').replace('_', '.')
        if bk.exists():
            shutil.rmtree(bk)
        bk.mkdir()
        moved, placed = [], []
        try:
            for n in items:
                cur = self.root / n
                if cur.exists() or cur.is_symlink():
                    os.replace(cur, bk / n); moved.append(n)
                os.replace(src / n, cur); placed.append(n)
        except OSError:
            for n in placed:
                shutil.rmtree(self.root / n, ignore_errors=True) if (self.root / n).is_dir() else (self.root / n).unlink(missing_ok=True)
            for n in moved:
                os.replace(bk / n, self.root / n)
            shutil.rmtree(bk, ignore_errors=True)
            raise
        (bk / '.meta.json').write_text(json.dumps({'version': cur_ver, 'at': common.now_ms(), 'items': items, 'existed': moved, 'replaced_by': new_ver},
                                                  ensure_ascii=False), encoding='utf-8')
        return bk

    def _restore(self, bk: Path, drop_current=False):
        """Đưa các mục trong bk về gốc (bản đang có của các mục đó bị bỏ nếu drop_current)."""
        meta = self._meta(bk) or {'items': []}
        existed = set(meta.get('existed', meta['items']))
        for n in meta['items']:
            cur = self.root / n
            if drop_current and n not in existed and cur.exists():      # mục chỉ bản mới có → bỏ
                shutil.rmtree(cur) if cur.is_dir() and not cur.is_symlink() else cur.unlink()
            if (bk / n).exists():
                if cur.exists() and drop_current:
                    shutil.rmtree(cur) if cur.is_dir() and not cur.is_symlink() else cur.unlink()
                os.replace(bk / n, cur)
        shutil.rmtree(bk, ignore_errors=True)

    def rollback(self, busy=False):
        if busy:
            raise UpdateError('BUSY', 'Máy đang dựng video – chờ xong rồi khôi phục.', 409)
        if not self.lock.acquire(blocking=False):
            raise UpdateError('BUSY', 'Đang cập nhật máy dựng.', 409)
        try:
            bks = self.backups()
            if not bks:
                raise UpdateError('NO_BACKUP', 'Chưa có bản sao lưu nào để khôi phục.', 404)
            target = self.backup_dir / bks[0]['dir']
            meta = self._meta(target)
            cur = self.current_version()
            items = [n for n in meta['items'] if (target / n).exists()]
            old_req = self._read(self.root / 'requirements.txt')
            # tách bản sao lưu đích ra chỗ tạm để tên thư mục sao lưu mới (= bản hiện tại) không đè lên nó
            stage = self.backup_dir / ('.dang_khoi_phuc_' + uuid.uuid4().hex[:6])
            os.replace(target, stage)
            try:
                self._swap_in(stage, items, cur, meta.get('version'))
            except OSError:
                os.replace(stage, target)
                raise
            shutil.rmtree(stage, ignore_errors=True)
            pip = 'skipped'
            if self._read(self.root / 'requirements.txt') != old_req:
                ok, _ = self.pip(self.root)
                pip = 'ok' if ok else 'failed'
            return {'ok': True, 'from': cur, 'to': meta.get('version'), 'pip': pip, 'restarting': True}
        finally:
            self.lock.release()

    def _prune(self):
        for b in self.backups()[KEEP_BACKUPS:]:
            shutil.rmtree(self.backup_dir / b['dir'], ignore_errors=True)

    @staticmethod
    def _read(p: Path):
        try:
            return p.read_bytes()
        except OSError:
            return None

    def schedule_restart(self):
        def go():
            time.sleep(self.restart_delay)
            self.restart()
        threading.Thread(target=go, daemon=True).start()


# ======================================================================
# CẬP NHẬT TỰ ĐỘNG – chỉ bản phát hành CÓ KÝ SỐ từ trang app chính thức
# ======================================================================
# S (16/11 de-hardcode): nguồn tải bản phát hành ĐÃ KÝ của máy cài này. Mặc định = bản của anh (common.RELEASE_ORIGIN, owner).
# Bản Cá nhân/Công ty đặt biến môi trường BDS_RELEASE_ORIGIN = kho phát hành công khai của anh. Cách kiểm chữ ký KHÔNG đổi (release_check).
AUTO_BASE = common.RELEASE_ORIGIN
AUTO_HOSTS = (urlparse(AUTO_BASE).hostname or '',)
AUTO_MANIFEST = '/release.json'
AUTO_SIG = '/release.json.sig'
# Zip máy dựng trong release.json → files[] (17/11: tải riêng từng hệ điều hành; zip chung cũ vẫn nhận – bản phát hành cũ chỉ có zip đó).
LEGACY_ZIP_PATH = 'downloads/BDS_Studio_Engine.zip'
OS_ZIP_PATHS = {'windows': 'downloads/BDS_Studio_Video_Windows.zip', 'mac': 'downloads/BDS_Studio_Video_Mac.zip'}
ZIP_PATH = LEGACY_ZIP_PATH                        # tên cũ (tương thích)
AUTO_ZIP = '/' + LEGACY_ZIP_PATH


def own_os() -> str:
    """Hệ điều hành của máy dựng này theo tên zip bộ cài: 'windows' | 'mac' (Linux/khác dùng bản Mac – cùng họ Unix, có tệp .command)."""
    return 'windows' if common.IS_WIN else 'mac'


def zip_candidates(os_name=None):
    """Thứ tự tìm zip trong release.json: zip của đúng hệ điều hành → zip chung cũ."""
    return [OS_ZIP_PATHS.get(os_name or own_os(), OS_ZIP_PATHS['mac']), LEGACY_ZIP_PATH]


def pick_zip(manifest, os_name=None):
    """→ (đường dẫn, mục files[]) của zip máy dựng nên tải cho máy này, hoặc (None, None)."""
    for p in zip_candidates(os_name):
        ent = release_check.file_entry(manifest, p)
        if ent:
            return p, ent
    return None, None
MAX_MANIFEST = 2 * 2**20
MAX_SIG = 4096
DEFER_POLL_S = 15                                 # app gọi nền khi đang dựng → kiểm lại mỗi 15 giây
DEFER_MAX_S = 6 * 3600                            # chờ tối đa 6 giờ rồi bỏ (lần mở app sau gọi lại)


def check_source(url, hosts=AUTO_HOSTS, require_https=True):
    """Chỉ nhận đúng host được phép (và https). Sai → UpdateError BAD_SOURCE."""
    u = urlparse(str(url or ''))
    host = (u.hostname or '').lower()
    if (require_https and u.scheme != 'https') or u.scheme not in ('https', 'http') or host not in hosts or u.username or u.password:
        raise UpdateError('BAD_SOURCE', f'Chỉ tải bản cập nhật từ {AUTO_BASE} – từ chối nguồn {host or url!s:.80}.', 400)
    return url


class AutoUpdate:
    """Tải + kiểm chữ ký + kiểm sha256 + cài trong luồng nền.
    state: idle|waiting|checking|downloading|verifying|installing|restarting|latest|error."""

    def __init__(self, up: 'Updater', base=AUTO_BASE, hosts=AUTO_HOSTS, require_https=True, max_bytes=None, timeout=60, pubkey=None, os_name=None,
                 defer_poll=DEFER_POLL_S, defer_max=DEFER_MAX_S):
        self.up = up
        self.base = base.rstrip('/')
        self.hosts = tuple(h.lower() for h in hosts)
        self.require_https = require_https
        self.max_bytes = max_bytes or MAX_UPDATE
        self.timeout = timeout
        self.pubkey = pubkey                      # None = khoá chính thức (release_check.PUBKEY); test truyền khoá thử
        self.os_name = os_name                    # None = hệ điều hành của máy này (own_os); test truyền 'windows'/'mac'
        self.defer_poll, self.defer_max = defer_poll, defer_max
        self._lock = threading.Lock()
        self.state = {'state': 'idle'}
        self.thread = None

    def status(self):
        with self._lock:
            return dict(self.state)

    def _set(self, **kw):
        with self._lock:
            self.state = dict(kw, at=common.now_ms())

    def running(self):
        return self.thread is not None and self.thread.is_alive()

    # ---------- tải an toàn ----------
    def _opener(self):
        outer = self

        class Redirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                check_source(urljoin(req.full_url, newurl), outer.hosts, outer.require_https)   # chuyển hướng sang host khác → chặn
                return super().redirect_request(req, fp, code, msg, headers, newurl)

        return urllib.request.build_opener(Redirect)

    def fetch(self, path, limit, progress=None, missing_ok=False):
        url = check_source(self.base + path, self.hosts, self.require_https)
        rq = urllib.request.Request(url, headers={'User-Agent': 'BDSStudioEngine/' + common.VERSION, 'Cache-Control': 'no-cache'})
        try:
            with self._opener().open(rq, timeout=self.timeout) as r:
                check_source(r.geturl(), self.hosts, self.require_https)
                total = int(r.headers.get('Content-Length') or 0)
                if total > limit:
                    raise UpdateError('TOO_LARGE', 'Tệp cập nhật quá lớn.', 400)
                buf = bytearray()
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    buf += chunk
                    if len(buf) > limit:
                        raise UpdateError('TOO_LARGE', 'Tệp cập nhật quá lớn.', 400)
                    if progress:
                        progress(len(buf), total)
                return bytes(buf)
        except UpdateError:
            raise
        except urllib.error.HTTPError as e:
            if missing_ok and e.code == 404:
                return b''
            raise UpdateError('DOWNLOAD_FAILED', f'Không tải được bản cập nhật (HTTP {e.code}).', 502)
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise UpdateError('DOWNLOAD_FAILED', f'Không tải được bản cập nhật – kiểm tra mạng ({str(e)[:80]}).', 502)

    def signed_release(self):
        """Tải + kiểm chữ ký release.json → manifest (dict). Thiếu/sai chữ ký → UpdateError (NO_SIG/BAD_SIG/…)."""
        manifest = self.fetch(AUTO_MANIFEST, MAX_MANIFEST)
        sig = self.fetch(AUTO_SIG, MAX_SIG, missing_ok=True)
        try:
            return release_check.check_release(manifest, sig, pub_b64=self.pubkey)
        except release_check.ReleaseError as e:
            raise UpdateError(e.code, e.message, 502)

    # ---------- chạy ----------
    def start(self, busy=lambda: False, wait=False, defer=False):
        """defer=True (app gọi nền): đang dựng → trạng thái 'waiting', tự cài khi dựng xong; defer=False (bấm nút): đang dựng → BUSY."""
        if self.running() or self.up.lock.locked():
            if defer:
                return self.status()              # đang chạy/đang chờ rồi → không chạy thêm
            raise UpdateError('BUSY', 'Đang cập nhật máy dựng.', 409)
        if busy() and not defer:
            raise UpdateError('BUSY', 'Máy đang dựng video – chờ xong rồi cập nhật.', 409)
        self._set(state='waiting' if busy() else 'checking')
        self.thread = threading.Thread(target=self._run_when_free if defer else self.run, args=(busy,), daemon=True)
        self.thread.start()
        if wait:
            self.thread.join()
        return self.status()

    def _run_when_free(self, busy):
        end = time.time() + self.defer_max
        while busy():
            if time.time() > end:
                self._set(state='idle')
                return
            time.sleep(self.defer_poll)
        self._set(state='checking')
        self.run(busy)

    def run(self, busy=lambda: False):
        try:
            cur = self.up.current_version()
            m = self.signed_release()
            latest = str((m.get('parts') or {}).get('engine') or '')
            if not latest:
                raise UpdateError('BAD_MANIFEST', 'Bản phát hành đã ký không ghi phiên bản máy dựng.', 502)
            if cmp_version(latest, cur) <= 0:
                self._set(state='latest', version=cur, latest=latest, build_id=m.get('build_id'))
                return
            zip_path, ent = pick_zip(m, self.os_name)
            if not ent:
                raise UpdateError('NOT_IN_MANIFEST', 'Bản phát hành đã ký không có gói máy dựng.', 502)
            self._set(state='downloading', received=0, total=0, version=cur, latest=latest)
            data = self.fetch('/' + zip_path, self.max_bytes,
                              lambda n, t: self._set(state='downloading', received=n, total=t, version=cur, latest=latest))
            self._set(state='verifying', version=cur, latest=latest)
            try:
                release_check.check_release_files(m, {zip_path: data})
            except release_check.ReleaseError as e:
                raise UpdateError(e.code, e.message, 502)
            self._set(state='installing', version=cur, latest=latest)
            res = self.up.apply(data, busy=busy(), expect_version=latest)
            self._set(state='restarting', version=cur, latest=latest, build_id=m.get('build_id'),
                      **{'from': res['from'], 'to': res['to'], 'pip': res['pip']})
            self.up.schedule_restart()
        except UpdateError as e:
            self._set(state='error', code=e.code, message=e.message)
        except Exception as e:      # không để luồng nền chết im lặng
            self._set(state='error', code='INTERNAL', message=f'Lỗi cập nhật tự động: {e}')
