"""Nhân viên AI chạy trên máy dựng (Mac/Windows) – CONTRACT §9 `/staff/run`, `/staff/status`.

KHÔNG dùng Claude (chủ app dùng gói Pro – Claude chỉ qua nút handoff trên app). Nhà cung cấp: gemini | ollama.

Hai cách chạy:
  1) Trực tiếp (app đang mở trên máy này):  POST /staff/run {"tasks": [{id, staff_id, prompt, provider, json}]}
     → máy dựng chạy lần lượt (Ollama nhường RAM cho dựng video), app đọc GET /staff/status rồi tự ghi kết quả.
  2) Qua đêm (app đóng):  POST /staff/run {"pull": true, "server": {"url", "token"}, "remember": true}
     → máy dựng dùng vé riêng `engine.token` (§9, quyền hạn chế: ai.run, jobs, ideas) để: sync.pull jobs →
       chạy việc `staff_task` đang chờ (where = mac) → tự chạy tiếp chuỗi (input.chain: Kiểm duyệt → dựng nháp) →
       sync.push kết quả. `remember` lưu vé + bật hẹn giờ: tới giờ phòng (mặc định 21:00) tự chạy; Mac tắt thì chạy bù lúc bật.
Gemini chỉ đi qua máy chủ app (`ai.run` với vé), không giữ khoá Gemini trên máy. Không có vé → dùng Ollama trên máy.
"""
import datetime
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

import common

STAFF_PROVIDERS = ('gemini', 'ollama')
MAX_TASKS = 20
MAX_PROMPT = 60000
PRIVATE_KEYS = ('phone', 'zalo', 'email', 'objects', 'events', 'reminders', 'quotes')
PHONE = re.compile(r'(\+?84|0)(\s?[.-]?\d){8,10}\b')
EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')


def redact(s):
    return PHONE.sub('[sđt ẩn]', EMAIL.sub('[email ẩn]', str(s or '')))


def safe_provider(p):
    return p if p in STAFF_PROVIDERS else 'gemini'


def run_key(start='21:00', now=None):
    """Lượt chạy: sau giờ bắt đầu hôm nay → hôm nay; trước đó → hôm qua (giống staff.js runKey)."""
    d = datetime.datetime.fromtimestamp((now or time.time()))
    try:
        hh, mm = (int(x) for x in str(start).split(':')[:2])
    except ValueError:
        hh, mm = 21, 0
    s = d.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if d < s:
        s -= datetime.timedelta(days=1)
    return s.strftime('%Y-%m-%d')


def extract_json(text):
    s = re.sub(r'^\s*```(?:json)?\s*|\s*```\s*$', '', str(text or ''))
    try:
        return json.loads(s)
    except ValueError:
        m = re.search(r'[\[{][\s\S]*[\]}]', s)
        if m:
            try:
                return json.loads(m.group(0))
            except ValueError:
                return None
    return None


def _parse(v):
    if isinstance(v, dict):
        return v
    try:
        d = json.loads(v or '{}')
        return d if isinstance(d, dict) else {}
    except (TypeError, ValueError):
        return {}


class ServerClient:
    """Gọi máy chủ app (GAS) bằng vé máy dựng. Hợp đồng §2: POST text/plain JSON {action, token, device_id, payload}."""

    def __init__(self, url, token, timeout=60):
        if not re.match(r'^https://', str(url or '')) and not str(url or '').startswith('http://127.0.0.1'):
            raise ValueError('Địa chỉ máy chủ phải là https://')
        if not token:
            raise ValueError('Thiếu vé máy dựng (engine.token)')
        self.url, self.token, self.timeout = url, token, timeout

    def call(self, action, payload=None):
        body = json.dumps({'action': action, 'token': self.token, 'device_id': 'engine', 'payload': payload or {}}).encode('utf-8')
        req = urllib.request.Request(self.url, data=body, method='POST', headers={'Content-Type': 'text/plain;charset=utf-8'})
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            d = json.loads(r.read().decode('utf-8'))
        if not d.get('ok'):
            e = d.get('error') or {}
            raise RuntimeError(e.get('message') or e.get('code') or 'Máy chủ báo lỗi')
        return d.get('data')


class StaffRunner:
    def __init__(self, jobs=None, ollama_fn=None):
        self.jobs = jobs                      # JobManager – để Ollama không chạy chồng lúc dựng video
        self.lock = threading.Lock()
        self.ollama_fn = ollama_fn or self._ollama
        self.st = {'state': 'idle', 'run_id': None, 'mode': None, 'total': 0, 'done': 0, 'results': [], 'log': '',
                   'started': None, 'finished': None, 'error': None}
        self.ollama_wait_s = float(os.environ.get('BDS_STAFF_OLLAMA_WAIT', '1800'))
        self._sched = None
        self.get_bridge = None                # → overnight.Bridge (server.py gắn): job video_map → nháp 480p qua đêm

    def _bridge(self):
        try:
            return self.get_bridge() if self.get_bridge else None
        except Exception as e:                # máy dựng thiếu thư viện dựng → phòng vẫn chạy
            self._log('⚠ Chưa nối được hàng đợi dựng: ' + str(e))
            return None

    def _bridge_sync(self, client):
        b = self._bridge()
        if b is None or client is None:
            return None
        try:
            return b.sync(client, log=self._log)
        except Exception as e:
            self._log('✗ Nháp qua đêm: ' + str(e))
            return None

    # ---------- cấu hình (vé nhớ cho chạy qua đêm) ----------
    @staticmethod
    def cfg_path() -> Path:
        return common.data_dir() / 'staff.json'

    def load_cfg(self):
        try:
            return json.loads(self.cfg_path().read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return {}

    def save_cfg(self, patch):
        c = self.load_cfg(); c.update(patch)
        p = self.cfg_path()
        p.write_text(json.dumps(c, ensure_ascii=False), encoding='utf-8')
        try:
            os.chmod(p, 0o600)                 # vé chỉ người dùng máy đọc được
        except OSError:
            pass
        return c

    def public_cfg(self):
        c = self.load_cfg()
        return {'auto': bool(c.get('auto')), 'start': c.get('start', '21:00'), 'last_run': c.get('last_run', ''),
                'server_set': bool(c.get('url') and c.get('token'))}

    # ---------- trạng thái ----------
    def status(self):
        with self.lock:
            s = json.loads(json.dumps(self.st, ensure_ascii=False))
        s['log'] = s['log'][-6000:]
        s['config'] = self.public_cfg()
        s['providers'] = list(STAFF_PROVIDERS)
        return s

    def _log(self, line):
        with self.lock:
            self.st['log'] += line.rstrip() + '\n'

    # ---------- bắt đầu ----------
    def start(self, body):
        if not isinstance(body, dict):
            raise ValueError('Cần đối tượng JSON')
        server = body.get('server') or {}
        client = None
        if server.get('url') or server.get('token'):
            client = ServerClient(server.get('url'), server.get('token'))
        elif body.get('pull') or any(safe_provider(t.get('provider')) == 'gemini' for t in body.get('tasks') or [] if isinstance(t, dict)):
            c = self.load_cfg()
            if c.get('url') and c.get('token'):
                client = ServerClient(c['url'], c['token'])
        if body.get('remember') and client:
            self.save_cfg({'url': client.url, 'token': client.token, 'auto': True, 'start': str(body.get('start') or '21:00')[:5]})
        if body.get('forget'):
            self.save_cfg({'url': '', 'token': '', 'auto': False})
            return {'ok': True, 'state': self.st['state'], 'forgot': True}
        if body.get('pull'):
            if not client:
                raise ValueError('Chưa có vé máy dựng (engine.token) – chờ máy chủ cập nhật; app sẽ chạy việc khi mở.')
            tasks = None
        else:
            tasks = self._validate(body.get('tasks'))
        with self.lock:
            if self.st['state'] == 'running':
                raise FileExistsError('Nhân viên đang chạy một lượt khác – chờ xong rồi chạy lại.')
            rid = uuid.uuid4().hex[:10]
            self.st = {'state': 'running', 'run_id': rid, 'mode': 'pull' if tasks is None else 'direct', 'total': len(tasks or []), 'done': 0,
                       'results': [], 'log': '', 'started': common.now_ms(), 'finished': None, 'error': None}
        t = threading.Thread(target=self._run, args=(rid, tasks, client), daemon=True, name='bds-staff')
        t.start()
        if body.get('wait'):
            t.join(float(body.get('wait')))
        return {'ok': True, 'run_id': rid, 'state': self.st['state']}

    def _validate(self, tasks):
        if not isinstance(tasks, list) or not tasks:
            raise ValueError('Cần danh sách việc (tasks)')
        if len(tasks) > MAX_TASKS:
            raise ValueError(f'Tối đa {MAX_TASKS} việc một lượt')
        out = []
        for t in tasks:
            if not isinstance(t, dict) or not str(t.get('prompt') or '').strip():
                raise ValueError('Việc thiếu lời nhắn (prompt)')
            if any(k in t for k in PRIVATE_KEYS):
                raise ValueError('Không gửi dữ liệu khách cho nhân viên AI')
            if len(t['prompt']) > MAX_PROMPT:
                raise ValueError('Lời nhắn quá dài')
            out.append({'id': str(t.get('id') or uuid.uuid4().hex[:8])[:64], 'staff_id': str(t.get('staff_id') or '')[:32],
                        'prompt': redact(t['prompt']), 'provider': safe_provider(t.get('provider')), 'json': bool(t.get('json'))})
        return out

    # ---------- gọi AI ----------
    def _ollama(self, prompt, json_mode):
        cfg = common.load_config()
        payload = {'model': cfg.get('ollama_model') or 'qwen2.5:3b', 'prompt': prompt, 'stream': False, 'keep_alive': '5m'}
        if json_mode:
            payload['format'] = 'json'
        req = urllib.request.Request(common.OLLAMA_URL + '/api/generate', method='POST', data=json.dumps(payload).encode(),
                                     headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=float(cfg.get('ollama_timeout_s', 120))) as r:
            d = json.loads(r.read())
        return {'text': d.get('response', ''), 'provider': 'ollama', 'tokens_in': d.get('prompt_eval_count', 0),
                'tokens_out': d.get('eval_count', 0), 'cost_usd': 0}

    def _ollama_guarded(self, prompt, json_mode):
        if self.jobs is None:
            return self.ollama_fn(prompt, json_mode)
        end = time.time() + self.ollama_wait_s
        while not self.jobs.ollama_enter():           # đang dựng video → chờ (máy 8 GB RAM)
            if time.time() > end:
                raise RuntimeError('Máy đang dựng video quá lâu – để lượt sau.')
            time.sleep(2)
        try:
            return self.ollama_fn(prompt, json_mode)
        finally:
            self.jobs.ollama_exit()

    def ask(self, task, client):
        prov = safe_provider(task.get('provider'))
        order = [prov] + [p for p in STAFF_PROVIDERS if p != prov]
        errs = []
        for p in order:
            try:
                if p == 'gemini':
                    if not client:
                        errs.append('Gemini: chưa có vé máy dựng'); continue
                    d = client.call('ai.run', {'task': 'staff', 'provider': 'gemini', 'prompt': task['prompt'], 'json': task.get('json', False)}) or {}
                    r = {'text': d.get('text', ''), 'provider': 'gemini', 'tokens_in': d.get('tokens_in', 0), 'tokens_out': d.get('tokens_out', 0),
                         'cost_usd': float(d.get('cost_usd') or 0)}
                else:
                    r = self._ollama_guarded(task['prompt'], task.get('json', False))
                if not str(r.get('text') or '').strip():
                    raise RuntimeError('trả lời trống')
                if p != prov:
                    r['fallback_from'] = prov
                return dict(r, ok=True)
            except Exception as e:                   # thử nhà cung cấp còn lại
                errs.append(f'{p}: {e}')
        return {'ok': False, 'error': '; '.join(errs) or 'AI không trả lời', 'provider': prov, 'cost_usd': 0}

    # ---------- vòng chạy ----------
    def _run(self, rid, tasks, client):
        try:
            if tasks is None:
                self._pull_run(client)
            else:
                for t in tasks:
                    self._log(f'▶ {t["staff_id"] or "việc"} {t["id"]} ({t["provider"]})')
                    r = dict(self.ask(t, client), id=t['id'], staff_id=t['staff_id'], finished_at=common.now_ms())
                    self._log(('✓ ' if r['ok'] else '✗ ') + t['id'] + ('' if r['ok'] else ' – ' + r['error']))
                    with self.lock:
                        self.st['results'].append(r); self.st['done'] += 1
            with self.lock:
                self.st['state'] = 'done'
        except Exception as e:
            with self.lock:
                self.st['state'] = 'error'; self.st['error'] = str(e)
            self._log('✗ ' + str(e))
        finally:
            with self.lock:
                self.st['finished'] = common.now_ms()

    # ---------- qua đêm: kéo việc từ máy chủ, chạy chuỗi, đẩy kết quả ----------
    def _pull_run(self, client):
        data = client.call('sync.pull', {'since': 0, 'tables': ['jobs']}) or {}
        rows = ((data.get('changes') or {}).get('jobs')) or []
        todo = [r for r in rows if r.get('type') == 'staff_task' and r.get('status') == 'queued' and not int(r.get('deleted') or 0)
                and _parse(r.get('input')).get('where', 'mac') == 'mac' and not _parse(r.get('output')).get('text')]
        with self.lock:
            self.st['total'] = len(todo)
        self._log(f'Kéo về {len(todo)} việc chờ chạy.')
        spent = 0.0
        while todo:
            row = todo.pop(0)
            cap = float(_parse(row.get('input')).get('budget_usd_day') or 0)
            if cap > 0 and spent >= cap:          # vượt ngân sách ngày → dừng, để app chuyển Bán tự động + báo
                with self.lock:
                    self.st['paused_budget'] = True
                self._log(f'⏸ Vượt ngân sách ngày ({spent:.2f}/{cap:.2f} USD) – dừng, các việc còn lại chờ anh duyệt.')
                break
            ops, follow = self.run_row(row, client)
            spent += sum(float(_parse(o['row'].get('output')).get('cost_usd') or 0) for o in ops if o['row'].get('id') == row.get('id'))
            if ops:
                client.call('sync.push', {'ops': ops})
            todo.extend(follow)
            with self.lock:
                self.st['done'] += 1; self.st['total'] = max(self.st['total'], self.st['done'] + len(todo))
        self.save_cfg({'last_run': run_key(self.load_cfg().get('start', '21:00'))})
        self._bridge_sync(client)            # job video_map (ý tưởng 21h + nháp của phòng) → hàng đợi dựng nháp 480p

    def run_row(self, row, client):
        """Chạy một việc staff_task; trả (ops để sync.push, các việc tiếp theo cần chạy ngay)."""
        inp, out = _parse(row.get('input')), _parse(row.get('output'))
        now = common.now_ms()
        r = self.ask({'prompt': redact(inp.get('prompt', '')), 'provider': inp.get('provider'), 'json': inp.get('json')}, client)
        out.update({'provider': r.get('provider'), 'cost_usd': r.get('cost_usd', 0), 'tokens_in': r.get('tokens_in'),
                    'tokens_out': r.get('tokens_out'), 'finished_at': now, 'by': 'engine'})
        with self.lock:
            self.st['results'].append({'id': row.get('id'), 'ok': r['ok'], 'staff_id': inp.get('staff_id'), 'error': r.get('error')})
        ops, follow = [], []
        if not r['ok']:
            out['error'] = r['error']
            ops.append(self._op(row, 'error', inp, out, now))
            self._log(f'✗ {row.get("title")}: {r["error"]}')
            return ops, follow
        text = str(r['text']).strip()
        out['text'] = text
        staff_id = inp.get('staff_id')
        final = text
        status = 'done'
        if staff_id == 'reviewer':
            j = extract_json(text) or {}
            passed = j.get('pass') is True
            out['pass'] = passed
            out['issues'] = j.get('issues') if isinstance(j.get('issues'), list) else []
            final = str(j.get('fixed_text') or '').strip() or inp.get('source_text', '')
            if not passed:
                status = 'waiting_approval'
        out['final_text'] = final
        if inp.get('mode') == 'semi':
            status = 'waiting_approval'
        ops.append(self._op(row, status, inp, out, now))
        self._log(f'✓ {row.get("title")} → {status}')
        chain = inp.get('chain') or []
        if status == 'done' and chain:
            nxt, rest = chain[0], chain[1:]
            title = re.sub(r'^[^:]+:\s*', '', str(row.get('title') or ''))
            if nxt.get('staff_id') == 'render':
                ops.append({'table': 'jobs', 'op': 'upsert', 'row': {
                    'id': self.new_id(), 'type': 'video_map', 'title': 'Nháp: ' + title, 'status': 'waiting_approval', 'cost_estimate': 0,
                    'input': json.dumps({'idea_id': inp.get('idea_id'), 'title': title, 'script': final, 'from_staff': True,
                                         'staff_task_id': row.get('id'), 'draft': '480p', 'mode': 'stills', 'created_at': now}, ensure_ascii=False),
                    'output': '', 'updated_at': now, 'deleted': 0}})
            else:
                child = {'id': self.new_id(), 'type': 'staff_task', 'title': f'{nxt.get("name") or nxt.get("staff_id")}: {title}'[:140],
                         'status': 'queued', 'cost_estimate': 0, 'updated_at': now, 'deleted': 0, 'output': '{}',
                         'input': json.dumps({'room_id': inp.get('room_id'), 'staff_id': nxt.get('staff_id'), 'step': nxt.get('staff_id'),
                                              'idea_id': inp.get('idea_id'), 'prompt': str(nxt.get('prefix') or '') + '\n' + redact(final),
                                              'json': bool(nxt.get('json')), 'provider': safe_provider(nxt.get('provider')),
                                              'mode': nxt.get('mode') or 'auto', 'where': 'mac', 'parent_id': row.get('id'),
                                              'source_text': final, 'created_at': now, 'chain': rest,
                                              'budget_usd_day': inp.get('budget_usd_day', 0)}, ensure_ascii=False)}
                ops.append({'table': 'jobs', 'op': 'upsert', 'row': child})
                follow.append(child)
        return ops, follow

    @staticmethod
    def new_id():
        return format(int(time.time() * 1000), 'x') + uuid.uuid4().hex[:6]

    @staticmethod
    def _op(row, status, inp, out, now):
        r = dict(row, status=status, input=json.dumps(inp, ensure_ascii=False), output=json.dumps(out, ensure_ascii=False), updated_at=now)
        return {'table': 'jobs', 'op': 'upsert', 'row': r}

    # ---------- hẹn giờ qua đêm ----------
    def tick(self, now=None):
        """Gọi mỗi phút: tới giờ phòng mà chưa chạy lượt này → chạy (Mac bật muộn thì chạy bù)."""
        c = self.load_cfg()
        if not (c.get('auto') and c.get('url') and c.get('token')) or self.st['state'] == 'running':
            return False
        if c.get('last_run') == run_key(c.get('start', '21:00'), now):
            b = self._bridge()               # ngoài lượt phòng: 21h–7h mỗi 10 phút kéo job nháp mới + gửi nháp đã xong
            if b is not None and b.due(now):
                try:
                    self._bridge_sync(ServerClient(c['url'], c['token']))
                except ValueError:
                    pass
            return False
        self.save_cfg({'last_run': run_key(c.get('start', '21:00'), now)})   # đánh dấu trước: lỗi cũng không chạy lặp mỗi phút
        try:
            self.start({'pull': True})
        except Exception as e:
            self._log('✗ Hẹn giờ: ' + str(e))
            return False
        return True

    def start_scheduler(self, every_s=60):
        if self._sched or os.environ.get('BDS_STAFF_NO_SCHED'):
            return

        def loop():
            time.sleep(15)
            while True:
                try:
                    self.tick()
                except Exception:
                    pass
                time.sleep(every_s)
        self._sched = threading.Thread(target=loop, daemon=True, name='bds-staff-sched')
        self._sched.start()
