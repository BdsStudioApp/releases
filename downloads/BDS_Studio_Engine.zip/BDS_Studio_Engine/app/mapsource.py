"""Nguồn bản đồ CÓ KHOÁ CỦA KHÁCH (bản thương mại) – nền bản đồ (tile) + tìm địa chỉ (geocoding) cho video bản đồ.

Vì sao: máy chủ tile và máy chủ tìm địa chỉ công cộng của OpenStreetMap (OSMF) chỉ cho dùng nhẹ; chính sách sử dụng tile cấm
app phân phối cho nhiều người dùng chúng khi chưa xin phép, chính sách Nominatim cấm dùng nặng/hệ thống
(operations.osmfoundation.org/policies/tiles/ , /policies/nominatim/). Bản thương mại vì vậy KHÔNG gọi hai máy chủ đó: mỗi khách
tự lấy khoá MIỄN PHÍ của một nhà cung cấp bản đồ, dán ở Cài đặt › Kết nối › "Bản đồ (nền + tìm địa chỉ)". Người bán không trả gì.
Bản của chủ app giữ nguyên hành vi cũ (videopack.Geocoder – khối chỉ-bản-riêng), chọn theo phiên bản: common.RELEASE_CHANNEL
('sale' ở bản bán – tools/sale_build.mjs đặt), không xoá mã.

Nhà cung cấp mặc định: Geoapify (đối chiếu 17/11/2026 qua trích đoạn trang chính thức geoapify.com – máy làm việc không mở thẳng được):
  - gói Free 3.000 credit/ngày, không cần thẻ; 1 tile = 0,25 credit, 1 lượt tìm địa chỉ = 1 credit; tối đa 5 yêu cầu/giây;
  - "You can use the Free plan for commercial websites, apps, and business projects, including in production, as long as you stay
    within its usage and feature limits and provide the required Geoapify and data-source attribution";
  - "you can cache, store, and redistribute the generated map tiles" → lưu đệm tile trên máy dựng và dựng vào video được;
  - ghi nguồn: "Powered by Geoapify" (bắt buộc ở gói Free) + © OpenMapTiles + © OpenStreetMap contributors.
Không dùng: MapTiler / Stadia gói miễn phí (chỉ phi thương mại), Thunderforest Hobby (để thử), Esri (cấm lưu kết quả tìm địa chỉ
"non-stored", cấm tải tile hàng loạt) – xem docs/DOI_CHIEU_GIA_DIEU_KHOAN.md mục 12.

Khoá lưu như khoá Vbee: keychain của máy dựng (secrets_store, tên GEOAPIFY_KEY – dùng chung với khoảng cách đường đi), không lên
máy chủ, không bao giờ trả lại qua API. Lỗi/URL ghi ra luôn che khoá.

API (videopack.handle chuyển tới):
  GET  /video/map_source            {provider, providers, key_set, required, attribution, last_check, usage}
  POST /video/map_source            {provider?, key?}  lưu (khoá rỗng = giữ khoá cũ; forget: true = xoá khoá)
  POST /video/map_source/test       {provider?, key?}  lưu (nếu có) rồi gọi THẬT 1 tile nhỏ + 1 lượt tìm địa chỉ
"""
import hashlib
import io
import json
import math
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date
from pathlib import Path

import common
import secrets_store

FIX_HASH = '#/settings/connection/map'
DAY_S = 86400
PROVIDERS = {
    'geoapify': {
        'id': 'geoapify', 'name': 'Geoapify', 'recommended': True,
        'tile_url': 'https://maps.geoapify.com/v1/tile/{style}/{z}/{x}/{y}.png?apiKey={key}',
        'style': 'dark-matter', 'tile_px': 256, 'zmin': 10, 'zmax': 16,
        'geocode_url': 'https://api.geoapify.com/v1/geocode/search',
        'attribution': 'Powered by Geoapify · © OpenMapTiles · © OpenStreetMap contributors',
        'attribution_short': 'Geoapify / OpenStreetMap',
        'min_interval_s': 0.25,                 # gói Free: tối đa 5 yêu cầu/giây → 4/giây cho chắc
        'daily_credits': 3000, 'tile_credit': 0.25, 'geocode_credit': 1.0,
        'cache_tiles': True,                    # điều khoản: được lưu đệm/lưu trữ/phân phối lại tile đã sinh
        'tile_ttl_s': 30 * DAY_S,               # làm mới định kỳ cho dữ liệu mới (không phải giới hạn điều khoản)
        'geocode_ttl_s': 30 * DAY_S, 'geocode_miss_ttl_s': 3 * DAY_S,
        'key_secret': 'GEOAPIFY_KEY', 'key_re': r'^[A-Za-z0-9_-]{16,80}$',
        'signup_url': 'https://myprojects.geoapify.com/', 'pricing_url': 'https://www.geoapify.com/pricing/',
        'sat': {'saturation': 1.0, 'brightness': 0.9},
    },
}
DEFAULT_PROVIDER = 'geoapify'
MAX_TILES = 160              # trần tile cho 1 video (≈ 40 credit Geoapify) – giữ xa hạn mức ngày
VN_BOX = (8.0, 24.0, 102.0, 110.0)
USER_AGENT = f'BDSStudio-Engine/{common.VERSION} (video map tool)'


class MapSourceError(Exception):
    code = 'MAP_SOURCE_ERROR'
    status = 502

    def payload(self):
        return {'ok': False, 'error': {'code': self.code, 'message': str(self), 'fix': FIX_HASH}}


class MapKeyMissing(MapSourceError):
    code = 'MAP_KEY_REQUIRED'
    status = 409


class MapQuotaExceeded(MapSourceError):
    code = 'MAP_QUOTA'
    status = 429


def sale_mode():
    """Bản thương mại (tools/sale_build.mjs đặt common.RELEASE_CHANNEL = 'sale'): bắt buộc nguồn bản đồ có khoá của khách."""
    return getattr(common, 'RELEASE_CHANNEL', '') == 'sale'


def _settings_path():
    return common.data_dir() / 'map_source.json'


def _load(p, d):
    try:
        v = json.loads(Path(p).read_text(encoding='utf-8'))
        return v if isinstance(v, type(d)) else d
    except (OSError, ValueError):
        return d


def _save(p, v):
    try:
        p = Path(p); tmp = p.with_suffix('.tmp')
        tmp.write_text(json.dumps(v, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, p)
    except OSError:
        pass


def provider(pid=None):
    pid = pid or _load(_settings_path(), {}).get('provider') or DEFAULT_PROVIDER
    return PROVIDERS.get(pid) or PROVIDERS[DEFAULT_PROVIDER]


def get_key(prov=None):
    return secrets_store.get_secret((prov or provider())['key_secret'])


def mask(text, key=None):
    """Che khoá trong URL/lỗi (apiKey=…, token=…, và chính giá trị khoá)."""
    s = re.sub(r'((?:apiKey|api_key|key|token|access_token)=)[^&\s]+', r'\1***', str(text or ''), flags=re.I)
    if key:
        s = s.replace(key, '***')
    return s[:300]


def public_provider(p):
    return {k: p[k] for k in ('id', 'name', 'recommended', 'attribution', 'signup_url', 'pricing_url', 'daily_credits')}


def settings():
    s = _load(_settings_path(), {})
    p = provider(s.get('provider'))
    return {'provider': p['id'], 'providers': [public_provider(x) for x in PROVIDERS.values()], 'key_set': bool(get_key(p)),
            'required': sale_mode(), 'attribution': p['attribution'], 'last_check': s.get('last_check') or None, 'usage': usage(p)}


def save_settings(d):
    d = d or {}
    cur = _load(_settings_path(), {})
    pid = d.get('provider') or cur.get('provider') or DEFAULT_PROVIDER
    if pid not in PROVIDERS:
        raise ValueError('Nhà cung cấp bản đồ không hợp lệ')
    p = PROVIDERS[pid]
    if d.get('forget') is True:
        secrets_store.set_secret(p['key_secret'], '')
        cur.pop('last_check', None)
    key = d.get('key')
    if isinstance(key, str) and key.strip():
        key = key.strip()
        if not re.match(p['key_re'], key):
            raise ValueError('Khoá ' + p['name'] + ' không đúng dạng – chép lại nguyên chuỗi API key (không có dấu cách).')
        secrets_store.set_secret(p['key_secret'], key)
        cur.pop('last_check', None)
    if pid != cur.get('provider'):
        cur.pop('last_check', None)
    cur['provider'] = pid
    _save(_settings_path(), cur)
    return settings()


def require_key(prov=None):
    """→ (provider, key) hoặc MapKeyMissing (thông báo rõ + lối tới thẻ Kết nối)."""
    p = prov or provider()
    k = get_key(p)
    if not k:
        raise MapKeyMissing('Video bản đồ cần khoá bản đồ miễn phí của anh/chị (' + p['name'] + '). Mở Cài đặt › Kết nối › '
                            '"Bản đồ (nền + tìm địa chỉ)", dán khoá rồi bấm Lưu và kiểm tra.')
    return p, k


# ───────────────────────── URL ─────────────────────────
def tile_url(p, z, x, y, key):
    return p['tile_url'].format(style=p['style'], z=int(z), x=int(x), y=int(y), key=urllib.parse.quote(key, safe=''))


def geocode_url(p, query, key, limit=3):
    if p['id'] == 'geoapify':
        return p['geocode_url'] + '?' + urllib.parse.urlencode({'text': query, 'filter': 'countrycode:vn', 'lang': 'vi', 'limit': int(limit),
                                                                 'format': 'json', 'apiKey': key})
    raise ValueError('Nhà cung cấp chưa hỗ trợ tìm địa chỉ')


# ───────────────────────── nhịp gọi + hạn mức ngày ─────────────────────────
_RATE_LOCK = threading.Lock()
_LAST = [0.0]
_USAGE_LOCK = threading.Lock()


def _usage_path():
    return common.data_dir() / 'map_usage.json'


def usage(p=None, today=None):
    p = p or provider()
    u = _load(_usage_path(), {})
    day = today or date.today().isoformat()
    used = float((u.get(p['id']) or {}).get(day) or 0)
    return {'day': day, 'credits': round(used, 2), 'limit': p['daily_credits']}


def spend(p, credits, today=None):
    """Cộng credit đã dùng hôm nay (đếm trên máy này). Vượt hạn mức miễn phí → dừng TRƯỚC khi gọi (không tự phát sinh phí)."""
    day = today or date.today().isoformat()
    with _USAGE_LOCK:
        u = _load(_usage_path(), {})
        row = {k: v for k, v in (u.get(p['id']) or {}).items() if k == day}
        used = float(row.get(day) or 0)
        if used + credits > p['daily_credits']:
            raise MapQuotaExceeded(f'Hôm nay đã dùng gần hết hạn mức miễn phí của {p["name"]} ({int(used)}/{p["daily_credits"]} credit). '
                                   'Chờ sang ngày mới (hạn mức tính theo ngày) rồi dựng tiếp.')
        row[day] = round(used + credits, 4)
        u[p['id']] = row
        _save(_usage_path(), u)


def _wait(p, clock=time.time, sleep=time.sleep):
    with _RATE_LOCK:
        gap = min(p['min_interval_s'], p['min_interval_s'] - (clock() - _LAST[0]))   # đồng hồ lùi → chờ tối đa 1 nhịp
        if gap > 0:
            sleep(gap)
        _LAST[0] = clock()


def _http(url, accept='application/json', timeout=20):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Accept': accept})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _http_error_text(e, p, key):
    if isinstance(e, urllib.error.HTTPError):
        if e.code in (401, 403):
            return f'{p["name"]} từ chối khoá (lỗi {e.code}) – kiểm lại khoá đã chép đủ, dự án còn bật.'
        if e.code == 429:
            return f'{p["name"]} báo hết hạn mức hoặc gọi quá nhanh (lỗi 429) – chờ rồi thử lại.'
        return f'{p["name"]} trả lỗi {e.code}.'
    return 'Không gọi được ' + p['name'] + ': ' + mask(e, key)


# ───────────────────────── tile ─────────────────────────
def deg2tile(lat, lon, z):
    n = 2 ** z
    x = int((lon + 180) / 360 * n)
    y = int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def tile2ll(x, y, z):
    n = 2 ** z
    lon = x / n * 360 - 180
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lat, lon


def tiles_for(bbox, z):
    s, w, n, e = bbox
    x0, y0 = deg2tile(n, w, z); x1, y1 = deg2tile(s, e, z)
    return [(z, x, y) for x in range(min(x0, x1), max(x0, x1) + 1) for y in range(min(y0, y1), max(y0, y1) + 1)]


def pick_zoom(bbox, p, m_per_px=8.0, max_tiles=MAX_TILES):
    """Mức zoom gần độ nét nền render_map (base_m_per_px), không vượt trần tile cho 1 video."""
    lat = (bbox[0] + bbox[2]) / 2
    z = p['zmin']
    for zz in range(p['zmin'], p['zmax'] + 1):
        z = zz
        if 156543.03 * math.cos(math.radians(lat)) / 2 ** zz <= m_per_px * 1.15:
            break
    while z > p['zmin'] and len(tiles_for(bbox, z)) > max_tiles:
        z -= 1
    return z


def tile_cache_root(p):
    return common.sub_cache('map_tiles') / p['id'] / p['style']


class Tiles:
    def __init__(self, prov=None, key=None, fetch=None, clock=time.time, sleep=time.sleep, today=None):
        self.p, self.key = (prov, key) if prov and key else require_key(prov)
        self.fetch = fetch or (lambda u: _http(u, accept='image/png,image/*'))
        self.clock, self.sleep, self.today = clock, sleep, today
        self.requests = 0

    def path(self, z, x, y):
        return tile_cache_root(self.p) / str(z) / str(x) / f'{y}.png'

    def get(self, z, x, y):
        f = self.path(z, x, y)
        if self.p['cache_tiles'] and f.is_file() and time.time() - f.stat().st_mtime < self.p['tile_ttl_s']:
            return f.read_bytes()
        spend(self.p, self.p['tile_credit'], self.today)
        _wait(self.p, self.clock, self.sleep)
        self.requests += 1
        try:
            data = self.fetch(tile_url(self.p, z, x, y, self.key))
        except Exception as e:
            raise MapSourceError(_http_error_text(e, self.p, self.key))
        if not isinstance(data, (bytes, bytearray)) or not data[:8].startswith(b'\x89PNG') and not data[:3] == b'\xff\xd8\xff':
            raise MapSourceError(self.p['name'] + ' không trả ảnh nền bản đồ (kiểm lại khoá).')
        if self.p['cache_tiles']:
            try:
                f.parent.mkdir(parents=True, exist_ok=True)
                tmp = f.with_suffix('.part'); tmp.write_bytes(data); os.replace(tmp, f)
            except OSError:
                pass
        return bytes(data)

    def stitch(self, bbox, m_per_px=8.0, out=None, max_tiles=MAX_TILES):
        """Ghép tile phủ bbox [s, w, n, e] → ảnh JPG làm lớp nền (cfg.satellite) của render_map."""
        from PIL import Image
        z = pick_zoom(bbox, self.p, m_per_px, max_tiles)
        ts = tiles_for(bbox, z)
        if len(ts) > max_tiles:
            raise MapSourceError(f'Vùng bản đồ quá rộng ({len(ts)} ô nền) – thu hẹp địa điểm trong video.')
        xs, ys = [t[1] for t in ts], [t[2] for t in ts]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        px = self.p['tile_px']
        im = Image.new('RGB', ((x1 - x0 + 1) * px, (y1 - y0 + 1) * px), (14, 24, 40))
        for _, x, y in ts:
            im.paste(Image.open(io.BytesIO(self.get(z, x, y))).convert('RGB').resize((px, px)), ((x - x0) * px, (y - y0) * px))
        north, west = tile2ll(x0, y0, z); south, east = tile2ll(x1 + 1, y1 + 1, z)
        name = hashlib.sha1(f'{self.p["id"]}|{self.p["style"]}|{z}|{x0},{y0},{x1},{y1}'.encode()).hexdigest()[:12]
        out = Path(out or (common.sub_cache('scenes') / f'nen_{self.p["id"]}_{name}.jpg'))
        im.save(out, quality=88)
        return {'file': str(out), 'bbox_ll': [round(south, 6), round(west, 6), round(north, 6), round(east, 6)], 'zoom': z,
                'tiles': len(ts), 'fetched': self.requests}


def places_bbox(lls, margin_km=3.0, min_span_km=6.0):
    """Khung [s, w, n, e] quanh các toạ độ [lat, lon] (+ lề), tối thiểu min_span_km mỗi chiều."""
    lats, lons = [a[0] for a in lls], [a[1] for a in lls]
    lat_c = (min(lats) + max(lats)) / 2
    ky, kx = 110.57, 111.32 * math.cos(math.radians(lat_c))
    span_y = max((max(lats) - min(lats)) * ky + 2 * margin_km, min_span_km)
    span_x = max((max(lons) - min(lons)) * kx + 2 * margin_km, min_span_km)
    lon_c = (min(lons) + max(lons)) / 2
    return [lat_c - span_y / 2 / ky, lon_c - span_x / 2 / kx, lat_c + span_y / 2 / ky, lon_c + span_x / 2 / kx]


# ───────────────────────── tìm địa chỉ ─────────────────────────
def _txt(s, n=200):
    return re.sub(r'\s+', ' ', str(s or '')).strip()[:n]


class ProviderGeocoder:
    """Cùng giao diện videopack.Geocoder (lookup, requests) – gọi nhà cung cấp bằng khoá của khách, lưu đệm theo điều khoản."""
    def __init__(self, prov=None, key=None, path=None, fetch=None, clock=time.time, sleep=time.sleep, today=None):
        self.p, self.key = (prov, key) if prov and key else require_key(prov)
        self.path = Path(path) if path else common.data_dir() / f'geocode_{self.p["id"]}.json'
        self.fetch = fetch or (lambda u: json.loads(_http(u).decode('utf-8')))
        self.clock, self.sleep, self.today = clock, sleep, today
        self.lock = threading.Lock()
        self.cache = _load(self.path, {})
        self.requests = 0
        self.source = self.p['id']

    def lookup(self, query):
        q = _txt(query, 160)
        k = re.sub(r'\s+', ' ', q.lower())
        if not k:
            return {'query': q, 'found': False, 'reason': 'Tên trống'}
        now = self.clock()
        with self.lock:
            c = self.cache.get(k)
        if c and now - c.get('at', 0) < (self.p['geocode_ttl_s'] if c.get('found') else self.p['geocode_miss_ttl_s']):
            return dict(c['res'], source='cache')
        spend(self.p, self.p['geocode_credit'], self.today)
        _wait(self.p, self.clock, self.sleep)
        self.requests += 1
        try:
            d = self.fetch(geocode_url(self.p, q, self.key))
        except Exception as e:
            return {'query': q, 'found': False, 'reason': _http_error_text(e, self.p, self.key), 'source': 'error'}
        res = None
        for r in (d.get('results') if isinstance(d, dict) else None) or []:
            try:
                lat, lon = float(r['lat']), float(r['lon'])
            except (KeyError, TypeError, ValueError):
                continue
            if VN_BOX[0] <= lat <= VN_BOX[1] and VN_BOX[2] <= lon <= VN_BOX[3]:
                res = {'query': q, 'found': True, 'name': _txt(r.get('name') or q.split(',')[0], 60), 'lat': round(lat, 6), 'lon': round(lon, 6),
                       'display_name': _txt(r.get('formatted'), 200), 'osm_url': ''}
                break
        if res is None:
            res = {'query': q, 'found': False, 'reason': self.p['name'] + ' không thấy địa điểm này (trong Việt Nam)'}
        with self.lock:
            self.cache[k] = {'at': now, 'found': res['found'], 'res': res}
            if len(self.cache) > 3000:
                for kk in sorted(self.cache, key=lambda x: self.cache[x].get('at', 0))[:500]:
                    self.cache.pop(kk, None)
            _save(self.path, self.cache)
        return dict(res, source=self.p['id'])


# ───────────────────────── kiểm tra thật ─────────────────────────
def check(prov=None, key=None, fetch_tile=None, fetch_json=None):
    """Gọi THẬT 1 tile nhỏ (z=1) + 1 lượt tìm "Hà Nội" (≈ 1,25 credit). → {ok, tile_ok, geocode_ok, message, at}"""
    p = prov or provider()
    key = key or get_key(p)
    if not key:
        return {'ok': False, 'tile_ok': False, 'geocode_ok': False, 'message': 'Chưa có khoá ' + p['name'] + ' – dán khoá rồi bấm Lưu và kiểm tra.'}
    out = {'tile_ok': False, 'geocode_ok': False}
    msgs = []
    try:
        data = (fetch_tile or (lambda u: _http(u, accept='image/png,image/*')))(tile_url(p, 1, 1, 0, key))
        out['tile_ok'] = isinstance(data, (bytes, bytearray)) and (bytes(data[:8]).startswith(b'\x89PNG') or bytes(data[:3]) == b'\xff\xd8\xff')
        if not out['tile_ok']:
            msgs.append('Nền bản đồ: không nhận được ảnh')
    except Exception as e:
        msgs.append('Nền bản đồ: ' + _http_error_text(e, p, key))
    try:
        d = (fetch_json or (lambda u: json.loads(_http(u).decode('utf-8'))))(geocode_url(p, 'Hà Nội', key, limit=1))
        out['geocode_ok'] = bool(isinstance(d, dict) and (d.get('results') or []))
        if not out['geocode_ok']:
            msgs.append('Tìm địa chỉ: không có kết quả')
    except Exception as e:
        msgs.append('Tìm địa chỉ: ' + _http_error_text(e, p, key))
    try:
        spend(p, p['tile_credit'] + p['geocode_credit'])
    except MapQuotaExceeded:
        pass
    out['ok'] = out['tile_ok'] and out['geocode_ok']
    out['message'] = (f'{p["name"]}: nền bản đồ và tìm địa chỉ đều chạy.' if out['ok'] else ' · '.join(msgs))
    out['at'] = common.now_ms()
    cur = _load(_settings_path(), {})
    cur['provider'] = p['id']; cur['last_check'] = {k: out[k] for k in ('ok', 'tile_ok', 'geocode_ok', 'message', 'at')}
    _save(_settings_path(), cur)
    return out


def add_basemap(cfg, tiles=None):
    """Bản bán: thêm lớp nền từ nhà cung cấp (cfg.satellite) phủ các địa điểm có toạ độ. → thông tin lớp nền hoặc None."""
    lls = [it['ll'] for it in cfg.get('items') or [] if isinstance(it, dict) and isinstance(it.get('ll'), list) and len(it['ll']) == 2]
    if not lls:
        return None
    t = tiles or Tiles()
    sat = t.stitch(places_bbox(lls), m_per_px=float(cfg.get('base_m_per_px') or 8.0))
    cfg['satellite'] = dict({'file': sat['file'], 'bbox_ll': sat['bbox_ll'], 'water': True}, **t.p.get('sat', {}))
    return sat


def handle(method, p, hd):
    """GET/POST /video/map_source[/test] → (status, body)."""
    if method == 'GET' and p == '/video/map_source':
        return 200, dict(settings(), ok=True)
    if method == 'POST' and p in ('/video/map_source', '/video/map_source/test'):
        d = hd.json_body() or {}
        s = save_settings(d)
        if p.endswith('/test'):
            r = check()
            return 200, dict(settings(), ok=True, check=r)
        return 200, dict(s, ok=True)
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
