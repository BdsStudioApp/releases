"""Hàng đợi dựng video: chạy MỘT job một lúc (máy 8 GB RAM), không chạy cùng lúc với Ollama.

Trạng thái job (khớp bảng `jobs` trong CONTRACT): queued → running → done | error.
"""
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import uuid
from pathlib import Path

import common
import flow
import secrets_store

MAP_MODES = ('check', 'stills', 'cover', 'mp4', 'gif')
EST_SECONDS = {'check': 20, 'stills': 30, 'cover': 20, 'mp4': 240, 'gif': 280, 'video_flow': 90}
MEDIA_EXT = flow.VIDEO_EXT + flow.IMAGE_EXT + ('.mp3', '.wav', '.m4a', '.aac')
PATH_KEYS = ('geo', 'names', 'src', 'music', 'voice', 'satellite', 'image', 'photo', 'file', 'logo')


class JobManager:
    def __init__(self):
        self.jobs = {}
        self.order = []
        self.cv = threading.Condition()
        self.ollama_active = 0
        self.current = None
        self._load_history()
        self.worker = threading.Thread(target=self._loop, daemon=True, name='bds-render')
        self.worker.start()

    # ---------- lịch sử ----------
    def _hist(self) -> Path:
        return common.data_dir() / 'jobs.json'

    def _load_history(self):
        try:
            for j in json.loads(self._hist().read_text(encoding='utf-8')):
                if j.get('state') in ('queued', 'running'):
                    j['state'] = 'error'; j['error'] = 'Máy dựng đã tắt giữa chừng – bấm dựng lại.'
                self.jobs[j['id']] = j; self.order.append(j['id'])
        except (OSError, ValueError, KeyError):
            pass

    def _save_history(self):
        try:
            keep = [self.public(self.jobs[i], log_tail=4000) for i in self.order[-60:]]
            for k in keep:
                k['_spec'] = self.jobs[k['id']].get('_spec_summary')
            tmp = self._hist().with_suffix('.tmp')
            tmp.write_text(json.dumps(keep, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, self._hist())
        except OSError:
            pass

    # ---------- công khai ----------
    def public(self, j, log_tail=20000):
        return {'id': j['id'], 'type': j['type'], 'title': j.get('title', ''), 'mode': j.get('mode'),
                'state': j['state'], 'progress': round(j.get('progress', 0), 3), 'log': j.get('log', '')[-log_tail:],
                'outputs': {k: os.path.basename(v) for k, v in (j.get('outputs') or {}).items()},
                'warnings': j.get('warnings', []), 'error': j.get('error'),
                'created': j.get('created'), 'started': j.get('started'), 'finished': j.get('finished')}

    def list(self):
        return [self.public(self.jobs[i], log_tail=600) for i in reversed(self.order[-50:])]

    def busy(self) -> bool:
        return any(self.jobs[i]['state'] in ('queued', 'running') for i in self.order)

    def eta(self) -> int:
        tot = 0.0
        for i in self.order:
            j = self.jobs[i]
            est = EST_SECONDS.get(j.get('mode') or j['type'], 120)
            if j['state'] == 'running':
                el = time.time() - (j.get('started') or time.time()) / 1000
                p = j.get('progress', 0)
                tot += max(5.0, el / p * (1 - p)) if p > 0.05 else max(5.0, est - el)
            elif j['state'] == 'queued':
                tot += est
        return int(tot)

    def submit(self, spec: dict) -> str:
        t = spec.get('type')
        if t == 'video_map':
            cfg = spec.get('cfg')
            if isinstance(cfg, str):
                cfg = json.loads(cfg)
            if not isinstance(cfg, dict) or not cfg.get('scenes'):
                raise ValueError('cfg.json thiếu "scenes"')
            mode = spec.get('mode', 'check')
            if mode not in MAP_MODES:
                raise ValueError('mode phải là một trong ' + ', '.join(MAP_MODES))
            spec = dict(spec, cfg=cfg, mode=mode)
        elif t == 'video_flow':
            clips = spec.get('clips') or []
            if not clips:
                raise ValueError('Chưa có clip nào')
            norm = []
            for c in clips:
                c = dict(c) if isinstance(c, dict) else {'path': str(c)}
                p = Path(c.get('path', '')).expanduser()
                if not p.is_file() or p.suffix.lower() not in flow.VIDEO_EXT + flow.IMAGE_EXT:
                    raise ValueError(f'Không thấy clip: {p.name or "(trống)"}')
                c['path'] = str(p.resolve()); norm.append(c)
            spec = dict(spec, clips=norm, mode='video_flow')
            if spec.get('music'):
                m = Path(spec['music']).expanduser()
                spec['music'] = str(m.resolve()) if m.is_file() and m.suffix.lower() in MEDIA_EXT else None
        else:
            raise ValueError('type phải là video_map hoặc video_flow')
        jid = datetime.datetime.now().strftime('%m%d%H%M%S') + uuid.uuid4().hex[:4]
        title = spec.get('title') or spec.get('name') or (spec.get('cfg') or {}).get('title') or t
        j = {'id': jid, 'type': t, 'mode': spec.get('mode'), 'title': str(title)[:120], 'state': 'queued', 'progress': 0.0,
             'log': '', 'outputs': {}, 'created': common.now_ms(), '_spec': spec,
             '_spec_summary': {'type': t, 'mode': spec.get('mode'), 'name': spec.get('name')}}
        with self.cv:
            self.jobs[jid] = j; self.order.append(jid); self.cv.notify_all()
        self._save_history()
        return jid

    def get(self, jid):
        return self.jobs.get(jid)

    # ---------- Ollama: không chạy chồng với dựng video ----------
    def ollama_enter(self) -> bool:
        with self.cv:
            if self.busy():
                return False
            self.ollama_active += 1
            return True

    def ollama_exit(self):
        with self.cv:
            self.ollama_active = max(0, self.ollama_active - 1); self.cv.notify_all()

    # ---------- vòng chạy ----------
    def _next(self):
        for i in self.order:
            if self.jobs[i]['state'] == 'queued':
                return self.jobs[i]
        return None

    def _loop(self):
        while True:
            with self.cv:
                while True:
                    j = self._next()
                    if j and self.ollama_active == 0:
                        break
                    self.cv.wait(1.0)
                j['state'] = 'running'; j['started'] = common.now_ms(); self.current = j
            try:
                unload_ollama()
                self._run(j)
                j['state'] = 'done'; j['progress'] = 1.0
            except Exception as e:
                j['state'] = 'error'; j['error'] = str(e)
                j['log'] += f'\n✗ {e}\n'
                if os.environ.get('BDS_DEBUG'):
                    j['log'] += traceback.format_exc()
            finally:
                j['finished'] = common.now_ms(); self.current = None
                j.pop('_spec', None)
                try:
                    common.prune_cache()
                    prune_previews()
                except Exception:
                    pass
                self._save_history()
                with self.cv:
                    self.cv.notify_all()

    def _run(self, j):
        log = lambda s: j.__setitem__('log', j['log'] + s)
        prog = lambda p: j.__setitem__('progress', max(j.get('progress', 0), min(0.99, p)))
        spec = j['_spec']
        if j['type'] == 'video_map':
            run_video_map(j, spec, log, prog)
        else:
            run_video_flow(j, spec, log, prog)


# ---------------- video_map (render_map.py của skill bds-quyhoach-video) ----------------
def _resolve_paths(obj, bases):
    """Đổi đường dẫn tương đối trong cfg (vd "../../data/hn_region_geo.txt") thành tuyệt đối nếu tìm thấy."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str) and k in PATH_KEYS and v and not re.match(r'^[a-z]+://', v):
                p = Path(v).expanduser()
                if not p.is_absolute():
                    for b in bases:
                        c = (b / v).resolve()
                        if c.is_file():
                            obj[k] = str(c); break
                    else:
                        c = (common.DATA_FILES_DIR / p.name)
                        if c.is_file():
                            obj[k] = str(c)
            else:
                _resolve_paths(v, bases)
    elif isinstance(obj, list):
        for v in obj:
            _resolve_paths(v, bases)
    return obj


def run_proc(cmd, cwd, log, prog=None, env=None, total_scenes=None):
    log('$ ' + ' '.join(Path(c).name if os.sep in str(c) else str(c) for c in cmd[1:]) + '\n')
    p = subprocess.Popen([str(c) for c in cmd], cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding='utf-8', errors='replace', bufsize=1, env=env or common.child_env())
    warnings = []
    for line in p.stdout:
        log(line)
        if line.startswith('⚠'):
            warnings.append(line[1:].strip())
        m = re.match(r'scene (\d+)/(\d+)', line)
        if m and prog:
            prog(0.15 + 0.75 * int(m.group(1)) / int(m.group(2)))
    if p.wait() != 0:
        raise RuntimeError('Bước dựng lỗi, xem nhật ký.')
    return warnings


def unique(path: Path) -> Path:
    if not path.exists():
        return path
    for k in range(2, 999):
        c = path.with_name(f'{path.stem}-{k}{path.suffix}')
        if not c.exists():
            return c
    return path


def preview_dir(jid) -> Path:
    p = common.sub_cache('previews') / jid; p.mkdir(parents=True, exist_ok=True); return p


def prune_previews():
    keep = int(common.load_config().get('keep_previews', 20))
    root = common.sub_cache('previews')
    ds = sorted((d for d in root.iterdir() if d.is_dir()), key=lambda d: d.stat().st_mtime, reverse=True)
    for d in ds[keep:]:
        shutil.rmtree(d, ignore_errors=True)


def run_video_map(j, spec, log, prog):
    cfg = json.loads(json.dumps(spec['cfg']))
    mode = spec['mode']
    name = common.safe_name(spec.get('name') or cfg.get('slug') or j['title'], 'video_map')
    work = common.sub_cache('work') / name
    work.mkdir(parents=True, exist_ok=True)
    srcdir = Path(spec['project_dir']) if spec.get('project_dir') else common.TEMPLATE_PROJECT
    _resolve_paths(cfg, [work, srcdir, common.TEMPLATE_PROJECT, common.ENGINE_ROOT])
    cfg.setdefault('workers', common.render_workers())
    (work / 'cfg.json').write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding='utf-8')
    out_dir = work / 'out'
    shutil.rmtree(out_dir, ignore_errors=True); out_dir.mkdir()
    rel_mp4 = Path('out') / f'{name}.mp4'
    cfg_name = 'cfg.json'
    prog(0.05)
    if spec.get('voice') and mode in ('mp4', 'gif'):
        if secrets_store.vbee_configured():
            run_proc([sys.executable, common.VBEE_TTS, 'cfg.json', 'cfg_voiced.json'], work, log,
                     env=common.child_env(secrets_store.vbee_env()))
            cfg_name = 'cfg_voiced.json'
        else:
            log('⚠ Chưa cài khoá Vbee: dựng không giọng (vẫn có phụ đề).\n')
    prog(0.12)
    args = [sys.executable, common.RENDER_MAP, cfg_name, rel_mp4] + ([mode] if mode in ('check', 'stills', 'cover') else [])
    j['warnings'] = run_proc(args, work, log, prog)
    outs = {}
    stem = out_dir / name
    date = datetime.date.today().isoformat()
    if mode == 'stills':
        pd = preview_dir(j['id'])
        for f in sorted((out_dir / f'{name}_scenes').glob('*')):
            if f.suffix in ('.jpg', '.png'):
                shutil.copy2(f, pd / f.name); outs[f.stem] = str(pd / f.name)
    elif mode == 'cover':
        pd = preview_dir(j['id']); c = Path(str(stem) + '_cover.jpg')
        if c.is_file():
            shutil.copy2(c, pd / c.name); outs['cover'] = str(pd / c.name)
    elif mode in ('mp4', 'gif'):
        vd = common.video_dir()
        target = unique(vd / f'{date}_{name}.mp4')
        if mode == 'gif':
            g = cfg.get('gif', {})
            gif = unique(vd / f'{date}_{name}.gif')
            cmd = [sys.executable, common.GIFTOOL, rel_mp4, gif, '--width', str(g.get('width', 600)), '--fps', str(g.get('fps', 12))]
            if g.get('crop', '0:236:1080:1300'):
                cmd += ['--crop', g.get('crop', '0:236:1080:1300')]
            run_proc(cmd, work, log); outs['gif'] = str(gif)
        mp4 = work / rel_mp4
        if mp4.is_file() and (mode == 'mp4' or cfg.get('gif', {}).get('keep_mp4')):
            shutil.move(str(mp4), target); outs['mp4'] = str(target)
            for suf, key in (('.srt', 'srt'), ('_cover.jpg', 'cover'), ('_meta.json', 'meta')):
                f = Path(str(stem) + suf)
                if f.is_file():
                    t = target.with_name(target.stem + suf); shutil.move(str(f), t); outs[key] = str(t)
    j['outputs'] = outs
    # dọn file tạm: giữ cfg + cache giọng đọc (voice/cache) để lần sau đỡ tốn ký tự Vbee
    shutil.rmtree(out_dir, ignore_errors=True)
    vdir = work / 'voice'
    if vdir.is_dir():
        for f in vdir.glob('scene_*.wav'):
            f.unlink(missing_ok=True)
    log('\n✓ Xong.\n')


# ---------------- video_flow ----------------
def run_video_flow(j, spec, log, prog):
    work = common.sub_cache('work') / ('flow_' + j['id'])
    env_secrets = secrets_store.vbee_env() if secrets_store.vbee_configured() else None
    try:
        res = flow.compose(work, spec, log, prog, tts=spec.get('_tts'), env_secrets=env_secrets)
        vd = common.video_dir()
        date = datetime.date.today().isoformat()
        target = unique(vd / f'{date}_{Path(res["mp4"]).name}')
        shutil.move(res['mp4'], target)
        outs = {'mp4': str(target)}
        for key in ('srt', 'meta'):
            t = target.with_name(target.stem + Path(res[key]).name[len(Path(res['mp4']).stem):])
            shutil.move(res[key], t); outs[key] = str(t)
        if spec.get('keep_work'):
            outs['joined'] = res['joined']
        j['outputs'] = outs
        j['warnings'] = [ln[1:].strip() for ln in j['log'].splitlines() if ln.startswith('⚠')]
        # clip tải lên chỉ là file tạm → xoá sau khi dựng xong
        up = common.sub_cache('uploads').resolve()
        for c in spec.get('clips', []):
            p = Path(c['path'])
            if common._inside(p, up):
                p.unlink(missing_ok=True)
    finally:
        if not spec.get('keep_work'):
            shutil.rmtree(work, ignore_errors=True)


# ---------------- Ollama ----------------
def unload_ollama():
    """Trước khi dựng: nhả mô hình Ollama khỏi RAM (nếu đang nạp)."""
    try:
        with urllib.request.urlopen(common.OLLAMA_URL + '/api/ps', timeout=1) as r:
            models = [m.get('name') for m in json.loads(r.read()).get('models', [])]
        for m in models:
            req = urllib.request.Request(common.OLLAMA_URL + '/api/generate', method='POST',
                                         data=json.dumps({'model': m, 'keep_alive': 0}).encode(),
                                         headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass
