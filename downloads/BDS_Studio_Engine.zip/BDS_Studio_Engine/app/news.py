"""BDS Studio – tải tin RSS/Atom cho "Nguồn ý tưởng" (dự phòng khi máy chủ GAS chưa có `news.fetch`).

  GET /news?feeds=<url1>,<url2>&since=<ms>&limit=<n>   → {ok, items:[{title, link, published, source, summary}], errors:[{feed, message}]}
  (không truyền feeds → dùng DEFAULT_FEEDS)

An toàn: chỉ http/https · chặn địa chỉ nội bộ (127.x, 10.x, 192.168.x…) kể cả khi bị chuyển hướng · timeout · giới hạn kích thước
· XML đọc bằng defusedxml nếu có, không thì chặn DOCTYPE/ENTITY trước khi đưa cho xml.etree (chống XXE / "billion laughs").
L2 (17/11, SSRF): kiểm địa chỉ IP SAU khi phân giải DNS NGAY LÚC KẾT NỐI (kết nối thẳng tới IP đã kiểm – chống "DNS rebinding" đổi IP
giữa lúc kiểm và lúc tải), chặn mọi IP không công khai (riêng, loopback, link-local, CGNAT 100.64/10, ::ffff:127.0.0.1…), chỉ cổng
80/443, tổng dung lượng 1 lần gọi có giới hạn (MAX_TOTAL_BYTES). Route GET /news chỉ nhận từ app đã tin (server.py).
"""
import http.client
import html
import ipaddress
import os
import re
import socket
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlparse

try:  # pragma: no cover - tuỳ máy có cài hay không
    from defusedxml import ElementTree as SAFE_ET
except Exception:  # noqa: BLE001
    SAFE_ET = None

# Sửa danh sách ở đây (giữ giống DEFAULT_FEEDS trong web/packs/bds/_lib/ideas.js)
DEFAULT_FEEDS = [
    ('VnExpress – Bất động sản', 'https://vnexpress.net/rss/bat-dong-san.rss'),
    ('VnExpress – Thời sự', 'https://vnexpress.net/rss/thoi-su.rss'),
    ('Tuổi Trẻ – Nhà đất', 'https://tuoitre.vn/rss/nha-dat.rss'),
    ('Thanh Niên – Kinh tế', 'https://thanhnien.vn/rss/kinh-te.rss'),
    ('CafeF – Bất động sản', 'https://cafef.vn/bat-dong-san.rss'),
    ('Báo Chính phủ – Chính sách mới', 'https://baochinhphu.vn/chinh-sach-moi.rss'),
    ('Hà Nội Mới – Đô thị', 'https://hanoimoi.vn/rss/do-thi.rss'),
]
TIMEOUT_S = 8
MAX_BYTES = 2 * 2**20
MAX_TOTAL_BYTES = 8 * 2**20      # cả lô feeds của 1 lần gọi
ALLOWED_PORTS = (80, 443)
MAX_FEEDS = 20
MAX_ITEMS_PER_FEED = 60
CACHE_S = 600
USER_AGENT = 'BDSStudio-News/1.0 (+rss reader)'
ATOM = '{http://www.w3.org/2005/Atom}'
CACHE = {}
_LOCK = threading.Lock()


class NewsError(ValueError):
    pass


def allow_local():
    return os.environ.get('BDS_NEWS_ALLOW_LOCAL') == '1'


def ip_blocked(ip) -> bool:
    """IP không công khai (không được tải tin): riêng, loopback, link-local, CGNAT, dành riêng, multicast, IPv4 nhúng trong IPv6."""
    if isinstance(ip, str):
        ip = ipaddress.ip_address(ip.split('%')[0])
    if ip.version == 6:
        inner = ip.ipv4_mapped or ip.sixtofour or (ip.teredo[1] if ip.teredo else None)
        if inner is not None and ip_blocked(inner):
            return True
    return (not ip.is_global or ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
            or ip.is_multicast or ip.is_unspecified)


def public_ip(host, port):
    """Phân giải host → IP công khai đầu tiên; bất kỳ IP nào không công khai → NewsError (không thử IP khác)."""
    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except (socket.gaierror, UnicodeError):
        raise NewsError('Không tìm thấy máy chủ ' + str(host))
    ips = []
    for info in infos:
        try:
            ip = ipaddress.ip_address(str(info[4][0]).split('%')[0])
        except ValueError:
            raise NewsError('Địa chỉ máy chủ không hợp lệ')
        if ip_blocked(ip):
            raise NewsError('Không tải tin từ địa chỉ nội bộ')
        ips.append(str(ip))
    if not ips:
        raise NewsError('Không tìm thấy máy chủ ' + str(host))
    return ips[0]


def check_url(url, local_ok=None):
    """Chỉ http/https, có tên máy, cổng 80/443, không trỏ vào mạng nội bộ (trừ khi BDS_NEWS_ALLOW_LOCAL=1 – dùng cho kiểm thử)."""
    local_ok = allow_local() if local_ok is None else local_ok
    u = urlparse(str(url or '').strip())
    if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password:
        raise NewsError('Chỉ nhận link RSS http/https')
    if local_ok:
        return u
    try:
        port = u.port or (443 if u.scheme == 'https' else 80)
    except ValueError:
        raise NewsError('Cổng không hợp lệ')
    if port not in ALLOWED_PORTS:
        raise NewsError('Chỉ nhận link RSS cổng 80/443')
    public_ip(u.hostname, port)
    return u


def _guarded_sock(conn):
    """Mở socket tới IP ĐÃ KIỂM (không phân giải lại) – chống DNS rebinding giữa lúc kiểm và lúc kết nối. Qua proxy: kiểm đích tunnel."""
    if allow_local():
        return socket.create_connection((conn.host, conn.port), conn.timeout, conn.source_address)
    tunnel = getattr(conn, '_tunnel_host', None)
    if tunnel:                                         # HTTPS qua proxy hệ thống: proxy phân giải – kiểm đích trước
        public_ip(tunnel, getattr(conn, '_tunnel_port', None) or 443)
        return socket.create_connection((conn.host, conn.port), conn.timeout, conn.source_address)
    if conn.port not in ALLOWED_PORTS:
        raise NewsError('Chỉ nhận link RSS cổng 80/443')
    return socket.create_connection((public_ip(conn.host, conn.port), conn.port), conn.timeout, conn.source_address)


class _GuardedHTTPConnection(http.client.HTTPConnection):
    def connect(self):
        self.sock = _guarded_sock(self)
        if getattr(self, '_tunnel_host', None):
            self._tunnel()


class _GuardedHTTPSConnection(http.client.HTTPSConnection):
    def connect(self):
        sock = _guarded_sock(self)
        server_hostname = self.host
        if getattr(self, '_tunnel_host', None):
            self.sock = sock
            self._tunnel()
            server_hostname = self._tunnel_host
            sock = self.sock
        self.sock = self._context.wrap_socket(sock, server_hostname=server_hostname)


class _GuardedHTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_GuardedHTTPConnection, req)


class _GuardedHTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        kw = {'context': self._context}
        if getattr(self, '_check_hostname', None) is not None:      # Python < 3.12
            kw['check_hostname'] = self._check_hostname
        return self.do_open(_GuardedHTTPSConnection, req, **kw)


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_bytes(url, timeout=TIMEOUT_S, max_bytes=MAX_BYTES, opener=None):
    check_url(url)
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT,
                                               'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5'})
    op = opener or urllib.request.build_opener(_SafeRedirect(), _GuardedHTTPHandler(), _GuardedHTTPSHandler())
    with op.open(req, timeout=timeout) as r:
        n = r.headers.get('Content-Length')
        if n and n.isdigit() and int(n) > max_bytes:
            raise NewsError('Tin RSS quá lớn')
        data = r.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise NewsError('Tin RSS quá lớn')
    return data


_DTD = re.compile(rb'<!\s*(DOCTYPE|ENTITY)', re.I)


def safe_fromstring(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    if _DTD.search(data):
        raise NewsError('RSS có DOCTYPE/ENTITY – bị chặn vì an toàn')
    if SAFE_ET is not None:
        return SAFE_ET.fromstring(data, forbid_dtd=True, forbid_entities=True, forbid_external=True)
    return ET.fromstring(data)


_TAG = re.compile(r'<[^>]+>')


def _text(el):
    return ''.join(el.itertext()).strip() if el is not None else ''


def _clean(s, n):
    s = html.unescape(_TAG.sub(' ', s or ''))
    return re.sub(r'\s+', ' ', s).strip()[:n]


def _ms(s):
    s = (s or '').strip()
    if not s:
        return 0
    try:
        d = parsedate_to_datetime(s)
    except (TypeError, ValueError, IndexError):
        try:
            d = datetime.fromisoformat(s.replace('Z', '+00:00'))
        except ValueError:
            return 0
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return int(d.timestamp() * 1000)


def _ok_link(u):
    return u if re.match(r'^https?://\S+$', u or '', re.I) else ''


def parse_feed(data, source=''):
    """RSS 2.0 / Atom → [{title, link, published(ms), source, summary}]"""
    root = safe_fromstring(data)
    items = []
    if root.tag == ATOM + 'feed':
        name = source or _text(root.find(ATOM + 'title'))
        for e in root.findall(ATOM + 'entry')[:MAX_ITEMS_PER_FEED]:
            link = ''
            for l in e.findall(ATOM + 'link'):
                if l.get('rel', 'alternate') == 'alternate' and l.get('href'):
                    link = l.get('href'); break
            items.append({'title': _clean(_text(e.find(ATOM + 'title')), 300), 'link': _ok_link(link.strip()),
                          'published': _ms(_text(e.find(ATOM + 'published')) or _text(e.find(ATOM + 'updated'))),
                          'source': name, 'summary': _clean(_text(e.find(ATOM + 'summary')) or _text(e.find(ATOM + 'content')), 400)})
    else:
        ch = root.find('channel')
        name = source or (_text(ch.find('title')) if ch is not None else '')
        for it in root.iter('item'):
            if len(items) >= MAX_ITEMS_PER_FEED:
                break
            link = _text(it.find('link')) or _text(it.find('guid'))
            items.append({'title': _clean(_text(it.find('title')), 300), 'link': _ok_link(link),
                          'published': _ms(_text(it.find('pubDate')) or _text(it.find('{http://purl.org/dc/elements/1.1/}date'))),
                          'source': name, 'summary': _clean(_text(it.find('description')), 400)})
    return [i for i in items if i['title'] and i['link']]


def fetch_feed(url, name='', timeout=TIMEOUT_S, max_bytes=MAX_BYTES, use_cache=True):
    now = time.time()
    with _LOCK:
        hit = CACHE.get(url)
    if use_cache and hit and now - hit[0] < CACHE_S:
        return hit[1]
    items = parse_feed(fetch_bytes(url, timeout=timeout, max_bytes=max_bytes), name)
    with _LOCK:
        CACHE[url] = (now, items)
    return items


def fetch_all(feeds, since=0, limit=200, timeout=TIMEOUT_S):
    names = dict((u, n) for n, u in DEFAULT_FEEDS)
    feeds = [f for f in dict.fromkeys(feeds)][:MAX_FEEDS]
    errors, items = [], []
    budget = {'left': MAX_TOTAL_BYTES}
    blk = threading.Lock()

    def one(u):
        try:
            with blk:
                cap = min(MAX_BYTES, budget['left'])
                if cap <= 0:
                    raise NewsError('Tổng dung lượng tin vượt giới hạn – bớt nguồn RSS')
                budget['left'] -= cap
            return u, fetch_feed(u, names.get(u, ''), timeout=timeout, max_bytes=cap), None
        except (NewsError, ET.ParseError) as e:
            return u, [], str(e) or 'RSS lỗi định dạng'
        except Exception as e:  # noqa: BLE001 – mạng/HTTP/định dạng: báo lỗi từng nguồn, không làm hỏng cả lô
            msg = getattr(e, 'reason', None) or e
            return u, [], f'Không tải được ({msg})'

    with ThreadPoolExecutor(max_workers=min(6, max(1, len(feeds)))) as ex:
        for u, its, er in ex.map(one, feeds):
            if er:
                errors.append({'feed': u, 'message': er})
            items.extend(its)
    seen, out = set(), []
    for i in sorted(items, key=lambda x: -x['published']):
        if i['link'] in seen or (since and i['published'] and i['published'] < since):
            continue
        seen.add(i['link']); out.append(i)
    return {'ok': True, 'items': out[:limit], 'errors': errors, 'fetched_at': int(time.time() * 1000)}


def handle(q):
    """q: tham số query đã tách ({feeds, since, limit}) → JSON trả về cho GET /news."""
    raw = str(q.get('feeds') or '').strip()
    feeds = [f.strip() for f in re.split(r'[\s,]+', raw) if f.strip()] if raw else [u for _, u in DEFAULT_FEEDS]
    if len(feeds) > MAX_FEEDS:
        raise NewsError(f'Tối đa {MAX_FEEDS} nguồn RSS mỗi lần')
    for f in feeds:
        u = urlparse(f)
        if u.scheme not in ('http', 'https') or not u.hostname:
            raise NewsError('Chỉ nhận link RSS http/https: ' + f[:80])
    try:
        since = int(q.get('since') or 0)
        limit = max(1, min(500, int(q.get('limit') or 200)))
    except ValueError:
        raise NewsError('since/limit phải là số')
    return fetch_all(feeds, since=since, limit=limit)
