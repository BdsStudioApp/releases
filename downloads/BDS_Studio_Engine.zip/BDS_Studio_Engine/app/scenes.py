"""Dựng & Sửa theo TỪNG CẢNH (bản 1.0 – §9 CONTRACT: /scenes/*).

Ý tưởng: cfg.json (bộ dựng render_map.py) được tách thành các "khúc" độc lập, mỗi khúc dựng ra 1 file mp4
nằm trong bộ nhớ đệm theo HASH NỘI DUNG; ghép bằng ffmpeg concat (-c copy, không nén lại).
  - thân cảnh i       khoá = cảnh i + bối cảnh cần thiết (mục đang hiện, camera cảnh trước, tiêu đề kế thừa…)
  - chuyển cảnh i-1→i vài khung hoà trộn (crossfade 0,25 s) – khoá = (thân i-1, thân i)
  - đuôi vòng lặp     0,5 s cuối hoà về khung đầu (loop_end) – khoá = (thân cuối, thân đầu)
Thời gian hoạt ảnh (tàu chạy, nhịp chấm, nét đứt) tính RIÊNG từng cảnh (bắt đầu từ 0) → đổi độ dài cảnh trước
không làm cảnh sau phải dựng lại; chỗ nối được che bằng chuyển cảnh.
Sửa chữ cảnh 3 → chỉ dựng lại thân cảnh 3 + 2 đoạn chuyển cảnh ngắn (≈8 khung) hai bên.

Xem trước nhanh: render_map.py vẽ cố định 1080×1920 (bố cục tính theo pixel, KHÔNG có tham số độ phân giải) →
ở chế độ xem trước ta hạ fps vẽ xuống 15 (ít khung = nhanh gấp đôi) rồi ffmpeg thu nhỏ còn 480×854 ngay khi nén
(preset ultrafast). Bản nét: 30 fps, 1080×1920, crf 18 – giống hệt cách render_map dựng.

Giọng Vbee: mỗi câu 1 tệp trong bộ nhớ đệm, tên = hash(giọng|tốc độ|câu) (cùng công thức vbee_tts.py) →
chỉ câu bị sửa mới gọi Vbee lại.

Không chèn nhãn "AI" lên video (ảnh/clip minh hoạ chỉ ghi "ẢNH/VIDEO MINH HOẠ"). Khi dựng giữ khoá RAM chung với
JobManager → Ollama không chạy cùng lúc (Mac 8 GB).
"""
import copy
import datetime
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common  # noqa: E402

RENDER_VERSION = 'scenes-1'
PROFILES = {
    'preview': {'fps': 15, 'short': 480, 'crf': 30, 'preset': 'ultrafast'},
    'final': {'fps': 30, 'short': 1080, 'crf': 18, 'preset': None},       # preset theo cấu hình (x264_preset)
}
THUMB_W = 360
# khoá cfg chỉ ảnh hưởng tiếng / xuất tệp – không vào khoá hình
AUDIO_KEYS = {'music', 'music_volume', 'sfx', 'sfx_volume', 'voice', 'audio', 'voice_offset', 'fit_to_audio', 'vbee',
              'make_cover', 'cover', 'gif', 'workers', 'keep_scenes', 'slug', 'title', 'name', 'studio'}
SCENE_AUDIO_KEYS = {'voice_pad', '_voice_len', 'studio', 'id', 'note', 'source'}
PATH_KEYS = ('geo', 'names', 'src', 'music', 'voice', 'satellite', 'image', 'photo', 'file', 'logo')
READ_CPS = 3.3
SAFE = {'9:16': dict(W=1080, H=1920, top=288, bottom=1250, right=150),
        '16:9': dict(W=1920, H=1080, top=40, bottom=1040, right=40)}
LUFS_TARGET = -14.0
DUR_MIN, DUR_MAX = 15.0, 90.0


# ───────────────────────── tiện ích ─────────────────────────
def _h(obj) -> str:
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:24]


def cfg_hash(cfg) -> str:
    return _h(cfg)


_ENGINE_SIG = None


def engine_sig() -> str:
    global _ENGINE_SIG
    if _ENGINE_SIG is None:
        try:
            _ENGINE_SIG = hashlib.sha256(Path(common.RENDER_MAP).read_bytes()).hexdigest()[:12] + RENDER_VERSION
        except OSError:
            _ENGINE_SIG = RENDER_VERSION
    return _ENGINE_SIG


def _file_sig(v):
    try:
        st = os.stat(v)
        return f'file:{os.path.basename(v)}:{st.st_size}:{int(st.st_mtime)}'
    except OSError:
        return v


def _sig_paths(obj):
    """Đường dẫn tệp → chữ ký (tên, cỡ, giờ sửa): đổi máy/thư mục không làm hỏng bộ nhớ đệm; đổi tệp thì dựng lại."""
    if isinstance(obj, dict):
        return {k: (os.path.basename(v) if k == 'voice' and isinstance(v, str)          # tệp giọng đặt tên theo hash nội dung
                    else _file_sig(v) if isinstance(v, str) and k in PATH_KEYS and os.path.isfile(v) else _sig_paths(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sig_paths(v) for v in obj]
    return obj


def plain(s):
    return (s.get('text', '') if isinstance(s, dict) else str(s or '')).replace('**', '')


def frame_size(fmt, prof):
    short = PROFILES[prof]['short']
    long_ = int(round(short * 16 / 9 / 2) * 2)
    return (short, long_) if fmt != '16:9' else (long_, short)


def scene_dur(sc):
    if sc.get('dur') is not None:
        return float(sc['dur'])
    return round(max(4.0, sum(len(plain(s).split()) for s in sc.get('subs', [])) / READ_CPS + 0.8), 2)


def ffbin(name):
    return common.which(name) or name


def ffrun(args, what, timeout=1800):
    p = subprocess.run([ffbin('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y'] + [str(a) for a in args],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', env=common.child_env(), timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(f'ffmpeg lỗi khi {what}: {p.stderr.strip()[-400:]}')
    return p


def probe(path):
    out = subprocess.run([ffbin('ffprobe'), '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height',
                          '-of', 'json', str(path)], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    d = json.loads(out.stdout or '{}')
    v = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    return {'duration': float((d.get('format') or {}).get('duration') or 0), 'width': v.get('width'), 'height': v.get('height'),
            'audio': any(s.get('codec_type') == 'audio' for s in d.get('streams', []))}


def measure_lufs(path):
    """Độ to tích hợp (LUFS, EBU R128) bằng ffmpeg ebur128; None nếu không có tiếng."""
    try:
        if not probe(path)['audio']:
            return None
    except Exception:
        return None
    p = subprocess.run([ffbin('ffmpeg'), '-hide_banner', '-nostats', '-i', str(path), '-vn', '-af', 'ebur128=framelog=quiet', '-f', 'null', '-'],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=600, env=common.child_env())
    m = re.findall(r'I:\s+(-?[\d.]+|-inf)\s+LUFS', p.stderr)
    if not m or m[-1] == '-inf':
        return None
    return float(m[-1])


# ───────────────────────── dự án ─────────────────────────
NAME_RE = re.compile(r'^[\w\-\.]{1,80}$', re.UNICODE)


def project_dir(name) -> Path:
    if not NAME_RE.match(name or '') or name.startswith('.'):
        raise ValueError('Tên dự án không hợp lệ')
    d = common.projects_dir() / name
    if name == '_mau_moi' and not (d / 'cfg.json').is_file() and (common.TEMPLATE_PROJECT / 'cfg.json').is_file():
        d.mkdir(parents=True, exist_ok=True); shutil.copy(common.TEMPLATE_PROJECT / 'cfg.json', d / 'cfg.json')
    return d


def load_cfg(name):
    f = project_dir(name) / 'cfg.json'
    if not f.is_file():
        raise KeyError('Không có dự án ' + name)
    return json.loads(f.read_text(encoding='utf-8'))


def validate_cfg(cfg):
    if not isinstance(cfg, dict):
        raise ValueError('cfg phải là đối tượng JSON')
    scs = cfg.get('scenes')
    if not isinstance(scs, list) or not scs:
        raise ValueError('cfg.json thiếu "scenes"')
    if len(scs) > 60:
        raise ValueError('Tối đa 60 cảnh')
    ids = set()
    for it in cfg.get('items', []) or []:
        if not isinstance(it, dict) or not it.get('id'):
            raise ValueError('Mỗi mục (items) cần "id"')
        ids.add(it['id'])
    for i, sc in enumerate(scs, 1):
        if not isinstance(sc, dict):
            raise ValueError(f'Cảnh {i} không hợp lệ')
        if sc.get('dur') is not None and not (0.5 <= float(sc['dur']) <= 60):
            raise ValueError(f'Cảnh {i}: độ dài phải 0,5–60 giây')
        for k in ('show', 'pop', 'draw', 'hide', 'focus'):
            for r in sc.get(k, []) or []:
                if r not in ids:
                    raise ValueError(f'Cảnh {i}: không có mục "{r}"')
    return cfg


def save_cfg(name, cfg):
    validate_cfg(cfg)
    d = project_dir(name); d.mkdir(parents=True, exist_ok=True)
    tmp = d / 'cfg.json.tmp'
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding='utf-8'); os.replace(tmp, d / 'cfg.json')
    return cfg


def work_dir(name) -> Path:
    p = common.sub_cache('scenes') / 'work' / common.safe_name(name, 'du_an'); p.mkdir(parents=True, exist_ok=True); return p


def clip_cache() -> Path:
    return common.sub_cache('scenes') / 'clips'


def thumb_cache() -> Path:
    return common.sub_cache('scenes') / 'thumbs'


def voice_cache() -> Path:
    return common.sub_cache('voice_lines')


def state_path(name) -> Path:
    return common.data_dir() / 'scenes_state' / (common.safe_name(name, 'du_an') + '.json')


def load_state(name) -> dict:
    try:
        return json.loads(state_path(name).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def save_state(name, patch) -> dict:
    st = load_state(name); st.update(patch)
    p = state_path(name); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.tmp'); tmp.write_text(json.dumps(st, ensure_ascii=False), encoding='utf-8'); os.replace(tmp, p)
    return st


def effective_cfg(cfg, pdir=None):
    """Bản sao cfg: đường dẫn tương đối → tuyệt đối, phụ đề {text, say} chuẩn hoá, mỗi cảnh có dur."""
    import jobs
    eff = copy.deepcopy(cfg)
    bases = [b for b in (pdir, common.TEMPLATE_PROJECT, common.ENGINE_ROOT) if b]
    jobs._resolve_paths(eff, [Path(b) for b in bases])
    for sc in eff['scenes']:
        if sc.get('dur') is None and not sc.get('voice'):
            sc['dur'] = scene_dur(sc)
    return eff


# ───────────────────────── tách cảnh + khoá ─────────────────────────
def scene_kind(sc, items):
    m = sc.get('media') or {}
    if m.get('flow') or m.get('character'):
        return 'nhan_vat'
    if m:
        return 'anh'
    pn = sc.get('panel') or {}
    if pn.get('type') == 'compare':
        return 'so_sanh'
    if pn:
        return 'bang_tin'
    cd = sc.get('card') or {}
    if cd.get('list'):
        return 'danh_sach'
    if cd:
        return 'the_so_lieu'
    if sc.get('spotlight'):
        return 'khoanh_phuong'
    if any((items.get(i) or {}).get('train') or (items.get(i) or {}).get('stations') for i in sc.get('draw', []) + sc.get('show', [])):
        return 'metro'
    if sc.get('hook'):
        return 'mo_dau'
    return 'ban_do'


KIND_LABEL = {'nhan_vat': 'Nhân vật', 'anh': 'Ảnh/clip', 'so_sanh': 'So sánh', 'bang_tin': 'Bảng tin', 'danh_sach': 'Danh sách',
              'the_so_lieu': 'Thẻ số liệu', 'khoanh_phuong': 'Khoanh phường', 'metro': 'Metro', 'mo_dau': 'Mở đầu', 'ban_do': 'Bản đồ vị trí'}


def plan(cfg, prof='final'):
    """Kế hoạch dựng thuần JSON (không vẽ): mỗi cảnh → dur, số khung, khoá thân, chuyển cảnh, đuôi."""
    fps = PROFILES[prof]['fps'] if prof in PROFILES else 30
    items = {it['id']: it for it in cfg.get('items', []) if isinstance(it, dict) and it.get('id')}
    g = {k: v for k, v in cfg.items() if k not in ('scenes', 'items') and k not in AUDIO_KEYS}
    water = [it for it in items.values() if it.get('water')]
    gsig = {'g': _sig_paths(g), 'water': _sig_paths(water), 'names': sorted(str(it.get('name', '')).lower() for it in items.values()),
            'mapless': not items and not cfg.get('geo')}
    if 'extent_m' not in cfg:
        gsig['all_items'] = _sig_paths(list(items.values()))
    scenes = cfg['scenes']; nsc = len(scenes)
    vis, prev_spec, title, prev_card = [], None, None, None
    out = []; t0 = 0.0
    xf_s = float(cfg.get('crossfade', 0.25)); loop_end = cfg.get('loop_end', True)
    for i, sc in enumerate(scenes):
        for r in sc.get('show', []) + sc.get('pop', []) + sc.get('draw', []):
            if r not in vis:
                vis.append(r)
        for r in sc.get('hide', []):
            if r in vis:
                vis.remove(r)
        spec = sc.get('camera') or prev_spec or {'center': [0, 0], 'km': 10}
        has_card = bool(sc.get('card'))
        title_eff = sc.get('title') or title
        refs = set(vis) | set(spec.get('fit', [])) | set((prev_spec or {}).get('fit', [])) | set(sc.get('focus', []))
        refs |= {x for m in sc.get('measure', []) for x in m[:2]} | ({sc['spotlight']} if sc.get('spotlight') else set())
        dur = scene_dur(sc)
        n = int(round(dur * fps))
        xf = 0 if (i == 0 or sc.get('cut')) else int(fps * xf_s)
        loop = int(fps * 0.5) if (i == nsc - 1 and loop_end) else 0
        if n - xf - loop < 1:
            xf = 0; loop = 0
        sc_sig = {k: v for k, v in sc.items() if k not in SCENE_AUDIO_KEYS}
        ctx = {'vis': list(vis), 'cam': spec, 'cam_prev': prev_spec or spec, 'title': title_eff, 'prev_card': prev_card if prev_card is not None else has_card,
               'first': i == 0, 'last': i == nsc - 1, 'loop_end': loop_end, 'n': n, 'xf': xf, 'loop': loop}
        body = _h({'v': engine_sig(), 'gl': gsig, 'items': _sig_paths({r: items.get(r) for r in sorted(refs)}),
                   'sc': _sig_paths(sc_sig), 'ctx': ctx, 'prof': prof, 'fps': fps})
        out.append({'index': i, 'dur': dur, 't0': round(t0, 3), 'n': n, 'xf': xf, 'loop': loop, 'body': body,
                    'kind': scene_kind(sc, items), 'content': _h(_sig_paths(sc_sig))})
        prev_spec, title, prev_card = spec, title_eff, has_card
        t0 += dur
    for i, P in enumerate(out):
        P['trans'] = _h({'t': 'trans', 'a': out[i - 1]['body'], 'b': P['body'], 'xf': P['xf']}) if P['xf'] else None
        P['tail'] = _h({'t': 'tail', 'a': P['body'], 'b': out[0]['body'], 'loop': P['loop']}) if P['loop'] else None
    return out


def units_of(pl):
    """Thứ tự khúc để ghép: [chuyển cảnh i] thân i … đuôi."""
    seq = []
    for P in pl:
        if P['trans']:
            seq.append({'kind': 'trans', 'i': P['index'], 'key': P['trans']})
        seq.append({'kind': 'body', 'i': P['index'], 'key': P['body']})
        if P['tail']:
            seq.append({'kind': 'tail', 'i': P['index'], 'key': P['tail']})
    return seq


def split(cfg, eff=None):
    """Danh sách cảnh cho giao diện (eff = cfg hiệu lực để tính khoá bộ nhớ đệm giống lúc dựng)."""
    items = {it['id']: it for it in cfg.get('items', []) if isinstance(it, dict) and it.get('id')}
    eff = eff or cfg
    pl = plan(eff, 'preview'); plf = plan(eff, 'final')
    out = []
    for P, PF, sc in zip(pl, plf, cfg['scenes']):
        title = sc.get('title') or {}
        subs = [{'text': s.get('text', '') if isinstance(s, dict) else str(s), 'say': (s.get('say') if isinstance(s, dict) else '') or ''}
                for s in sc.get('subs', [])]
        m = sc.get('media') or {}
        st = (sc.get('studio') or {})
        out.append({'index': P['index'], 'id': sc.get('id') or f's{P["index"] + 1}', 'kind': P['kind'], 'kind_label': KIND_LABEL[P['kind']],
                    'title': title.get('text', '') if isinstance(title, dict) else str(title), 'kicker': title.get('kicker', '') if isinstance(title, dict) else '',
                    'hook': (sc.get('hook') or {}).get('text', ''), 'subs': subs, 'dur': P['dur'], 't0': P['t0'],
                    'key': P['body'], 'content': P['content'],
                    'cached': (clip_cache() / f'{P["body"]}.mp4').is_file(),
                    'thumb': (thumb_cache() / f'{_thumb_key(PF["body"])}.jpg').is_file() and f'/scenes/thumb/{_thumb_key(PF["body"])}.jpg' or None,
                    'thumb_key': _thumb_key(PF['body']),
                    'labels': [{'id': r, 'name': items[r].get('name', r), 'label_offset': items[r].get('label_offset', [60, -40]),
                                'label_side': items[r].get('label_side', 'right')}
                               for r in _visible(cfg, P['index']) if r in items and items[r].get('name') and items[r].get('marker') is not False],
                    'media': {'src': os.path.basename(str(m.get('src', ''))), 'ai': bool(m.get('ai')), 'flow': m.get('flow')} if m else None,
                    'approved': bool(st.get('approved'))})
    return out


def _visible(cfg, idx):
    vis = []
    for sc in cfg['scenes'][:idx + 1]:
        for r in sc.get('show', []) + sc.get('pop', []) + sc.get('draw', []):
            if r not in vis:
                vis.append(r)
        for r in sc.get('hide', []):
            if r in vis:
                vis.remove(r)
    return vis


def _thumb_key(body_key):
    return _h({'thumb': body_key, 'w': THUMB_W})


# ───────────────────────── giọng đọc từng câu (cache theo hash câu) ─────────────────────────
def line_key(text, voice, speed):
    return hashlib.sha1(f'{voice}|{speed}|{text}'.encode()).hexdigest()[:16]      # = vbee_tts.voice_line


def real_tts(voice, speed):
    """Hàm đọc thật qua Vbee (khoá trong keychain, không ghi ra đĩa)."""
    import secrets_store
    if not secrets_store.vbee_configured():
        return None
    sys.path.insert(0, str(common.SCRIPTS_DIR))
    import vbee_tts
    env = secrets_store.vbee_env()
    hdr = {'Content-Type': 'application/json', 'App-Id': env['VBEE_APP_ID'], 'Authorization': 'Bearer ' + env.get('VBEE_TOKEN', '')}
    cdir = str(voice_cache()); os.makedirs(cdir, exist_ok=True)
    return lambda text: vbee_tts.voice_line(text, voice, speed, hdr, cdir)


def _pcm(path, sr=44100):
    raw = subprocess.run([ffbin('ffmpeg'), '-v', 'error', '-i', str(path), '-f', 's16le', '-ac', '1', '-ar', str(sr), '-'],
                         capture_output=True, check=True, env=common.child_env()).stdout
    import array
    a = array.array('h', raw)
    thr = 600; i0, i1 = 0, len(a)
    while i0 < i1 and abs(a[i0]) < thr:
        i0 += 1
    while i1 > i0 and abs(a[i1 - 1]) < thr:
        i1 -= 1
    return a[max(0, i0 - int(0.03 * sr)):min(len(a), i1 + int(0.08 * sr))]


def voice_scenes(eff, tts, log=print, voice=None, speed=None, lead=0.35, gap=0.25, tail=0.45):
    """Gắn giọng cho từng cảnh: chỉ gọi tts(câu) cho câu chưa có trong bộ nhớ đệm. Trả {'new': n, 'cached': m}."""
    import array
    import wave
    cfgd = common.load_config()
    vb = eff.get('vbee') or {}
    voice = voice or vb.get('voice') or cfgd['vbee_voice']; speed = speed or vb.get('speed') or cfgd['vbee_speed']
    cdir = voice_cache(); cdir.mkdir(parents=True, exist_ok=True)
    vout = common.sub_cache('scenes') / 'voice'; vout.mkdir(parents=True, exist_ok=True)
    new = cached = 0; SR = 44100
    for si, sc in enumerate(eff['scenes']):
        says = [(s.get('say') if isinstance(s, dict) else None) or plain(s) for s in sc.get('subs', [])]
        says = [s for s in says if s.strip()]
        if not says:
            continue
        files = []
        for t in says:
            f = cdir / (line_key(t, voice, speed) + '.mp3')
            if f.is_file() and f.stat().st_size > 200:
                cached += 1; os.utime(f, None)
            else:
                got = tts(t)
                if got and Path(got).resolve() != f.resolve():
                    shutil.copy2(got, f)
                new += 1
            files.append(f)
        sk = _h({'v': voice, 's': speed, 'lines': says, 'lead': lead, 'gap': gap})
        wav = vout / f'{sk}.wav'; times_f = vout / f'{sk}.json'
        if not (wav.is_file() and times_f.is_file()):
            buf = array.array('h', [0] * int(lead * SR)); times = []
            for k, f in enumerate(files):
                c = _pcm(f, SR); t0 = len(buf) / SR; buf.extend(c); times.append([round(t0, 3), round(len(buf) / SR, 3)])
                if k < len(files) - 1:
                    buf.extend([0] * int(gap * SR))
            for k in range(len(times) - 1):
                times[k][1] = times[k + 1][0]
            total = len(buf) / SR
            times[-1][1] = round(total + tail, 3)
            with wave.open(str(wav), 'wb') as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(buf.tobytes())
            times_f.write_text(json.dumps({'times': times, 'len': total}), encoding='utf-8')
        info = json.loads(times_f.read_text(encoding='utf-8'))
        os.utime(wav, None)
        md = sc.get('min_dur', 4.5 if (sc.get('panel') or sc.get('media')) else 3.0)
        sc['voice'] = str(wav); sc['voice_pad'] = tail; sc['sub_times'] = info['times']
        sc['dur'] = round(max(md, info['len'] + tail), 2)
        if len(sc['sub_times']) != len(sc.get('subs', [])):
            sc.pop('sub_times', None)
    log(f'giọng: {new} câu mới, {cached} câu dùng lại\n')
    return {'new': new, 'cached': cached}


# ───────────────────────── dựng ─────────────────────────
def _run_worker(spec, cwd, log, prog=None):
    sp = Path(cwd) / f'worker_{os.getpid()}_{int(time.time() * 1000)}.json'
    sp.write_text(json.dumps(spec, ensure_ascii=False), encoding='utf-8')
    p = subprocess.Popen([sys.executable, os.path.abspath(__file__), '--worker', str(sp)], cwd=str(cwd), stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1, env=common.child_env())
    res = None; tail = []
    for line in p.stdout:
        if line.startswith('RESULT '):
            res = json.loads(line[7:])
        else:
            tail.append(line); tail = tail[-40:]
            if line.startswith('unit ') and prog:
                m = re.match(r'unit (\d+)/(\d+)', line)
                if m:
                    prog(int(m.group(1)) / int(m.group(2)))
            if not line.startswith('unit '):
                log(line)
    rc = p.wait()
    sp.unlink(missing_ok=True)
    if rc != 0 or res is None:
        raise RuntimeError('Bước dựng lỗi: ' + ''.join(tail)[-600:])
    return res


def build(name, prof='preview', log=print, prog=lambda p: None, voice=False, tts=None, workers=None, cfg=None, out=None):
    """Dựng cả video theo từng cảnh. Trả {'mp4', 'rendered': [chỉ số thân cảnh đã dựng], 'cached': [...], 'duration', ...}."""
    if prof not in PROFILES:
        raise ValueError('prof phải là preview hoặc final')
    pdir = project_dir(name)
    cfg = cfg if cfg is not None else load_cfg(name)
    validate_cfg(cfg)
    ch = cfg_hash(cfg)
    eff = effective_cfg(cfg, pdir)
    prog(0.02)
    voice_info = None
    if voice:
        fn = tts or real_tts((eff.get('vbee') or {}).get('voice') or common.load_config()['vbee_voice'],
                             (eff.get('vbee') or {}).get('speed') or common.load_config()['vbee_speed'])
        if fn is None:
            log('⚠ Chưa cài khoá Vbee: dựng không giọng (vẫn có phụ đề).\n')
        else:
            voice_info = voice_scenes(eff, fn, log)
    for sc in eff['scenes']:
        if sc.get('dur') is None:
            sc['dur'] = scene_dur(sc)
    gv = eff.get('voice') or eff.get('audio')
    if gv and eff.get('fit_to_audio') and os.path.isfile(gv) and not any(sc.get('sub_times') for sc in eff['scenes']):
        k = (probe(gv)['duration'] + 0.8) / sum(sc['dur'] for sc in eff['scenes'])      # như render_map.prepare_audio
        for sc in eff['scenes']:
            sc['dur'] = round(sc['dur'] * k, 3)
    pl = plan(eff, prof)
    seq = units_of(pl)
    cc = clip_cache(); cc.mkdir(parents=True, exist_ok=True)
    todo = []
    seen = set()
    for u in seq:
        f = cc / f'{u["key"]}.mp4'
        if f.is_file() and f.stat().st_size > 0:
            os.utime(f, None)
        elif u['key'] not in seen:
            todo.append(dict(u, out=str(f))); seen.add(u['key'])
    rendered = sorted({u['i'] for u in todo if u['kind'] == 'body'})
    cached = [P['index'] for P in pl if P['index'] not in rendered]
    log(f'{len(pl)} cảnh · dựng {len(todo)} khúc ({len(rendered)} thân cảnh), dùng lại {len(seq) - len(todo)} khúc\n')
    work = work_dir(name)
    fmt = eff.get('format', '9:16')
    w, hh = frame_size(fmt, prof)
    P_ = PROFILES[prof]
    preset = P_['preset'] or common.load_config().get('x264_preset', 'veryfast')
    stamp = datetime.datetime.now().strftime('%H%M%S')
    silent = work / f'{prof}_silent.mp4'
    final_out = Path(out) if out else work / f'{prof}.mp4'
    need_mix = bool(eff.get('sfx', True) or eff.get('music') or any(sc.get('voice') for sc in eff['scenes']) or eff.get('voice'))
    finishing = prof == 'final'
    stem = work / f'{common.safe_name(name, "video")}_{stamp}'
    spec = {'cfg': eff, 'base': str(pdir if pdir.is_dir() else common.TEMPLATE_PROJECT), 'fps': P_['fps'], 'size': [w, hh], 'crf': P_['crf'],
            'preset': preset, 'units': [{k: u[k] for k in ('kind', 'i', 'out')} for u in todo], 'plan': pl,
            'workers': int(workers or eff.get('workers') or common.render_workers()),
            'concat': [str(cc / f'{u["key"]}.mp4') for u in seq], 'silent': str(silent),
            'mix': str(final_out) if need_mix else None,
            'srt': str(stem) + '.srt' if finishing else None, 'cover': str(stem) + '_cover.jpg' if finishing and eff.get('make_cover', True) else None,
            'meta': str(stem) + '_meta.json' if finishing else None, 'full_base': bool(todo) or (finishing and eff.get('make_cover', True))}
    prog(0.08)
    t_start = time.time()
    if todo or need_mix or finishing:
        res = _run_worker(spec, work, log, lambda p: prog(0.08 + 0.82 * p))
    else:
        res = {}
    if not need_mix:
        if not res.get('concat_done'):
            _concat(spec['concat'], silent)
        shutil.move(str(silent), str(final_out))
    lufs = measure_lufs(final_out)
    if prof == 'final' and lufs is not None and abs(lufs - LUFS_TARGET) > 1.0:
        tmp = final_out.with_name(final_out.stem + '_ln.mp4')
        ffrun(['-i', final_out, '-c:v', 'copy', '-af', f'loudnorm=I={LUFS_TARGET}:TP=-1.5:LRA=11', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100',
               '-movflags', '+faststart', tmp], 'chuẩn hoá âm lượng')
        os.replace(tmp, final_out); lufs = measure_lufs(final_out)
        log(f'✓ chuẩn hoá âm lượng về {lufs} LUFS\n')
    info = probe(final_out)
    prog(1.0)
    result = {'mp4': str(final_out), 'rendered': rendered, 'cached': cached, 'units_rendered': len(todo), 'units_total': len(seq),
              'duration': round(info['duration'], 3), 'expected': round(sum(P['n'] for P in pl) / P_['fps'], 3), 'width': info['width'],
              'height': info['height'], 'lufs': lufs, 'cfg_hash': ch, 'voice': voice_info, 'seconds': round(time.time() - t_start, 1),
              'prof': prof}
    for k in ('srt', 'cover', 'meta'):
        if spec.get(k) and os.path.isfile(spec[k]):
            result[k] = spec[k]
    save_state(name, {prof: {k: result[k] for k in ('mp4', 'duration', 'lufs', 'cfg_hash', 'width', 'height')}})
    log(f'✓ {prof}: {info["duration"]:.1f}s {info["width"]}×{info["height"]}' + (f' · {lufs:.1f} LUFS' if lufs is not None else '') + '\n')
    return result


def _concat(files, out):
    lst = Path(out).with_suffix('.txt')
    lst.write_text(''.join("file '" + str(f).replace("'", "'\\''") + "'\n" for f in files), encoding='utf-8')
    ffrun(['-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', '-movflags', '+faststart', out], 'ghép cảnh')
    lst.unlink(missing_ok=True)


def thumbs(name, log=print, prog=lambda p: None, cfg=None):
    """Ảnh khung đại diện (cuối mỗi cảnh) + toạ độ các chữ (để kéo nhãn & kiểm tra vùng an toàn)."""
    pdir = project_dir(name)
    cfg = cfg if cfg is not None else load_cfg(name)
    validate_cfg(cfg)
    eff = effective_cfg(cfg, pdir)
    for sc in eff['scenes']:
        if sc.get('dur') is None:
            sc['dur'] = scene_dur(sc)
    pl = plan(eff, 'final')
    tc = thumb_cache(); tc.mkdir(parents=True, exist_ok=True)
    todo = []
    for P in pl:
        k = _thumb_key(P['body'])
        if not ((tc / f'{k}.jpg').is_file() and (tc / f'{k}.json').is_file()):
            todo.append({'i': P['index'], 'jpg': str(tc / f'{k}.jpg'), 'json': str(tc / f'{k}.json')})
    if todo:
        spec = {'cfg': eff, 'base': str(pdir if pdir.is_dir() else common.TEMPLATE_PROJECT), 'fps': 30, 'thumbs': todo, 'plan': pl,
                'full_base': True, 'units': []}
        _run_worker(spec, work_dir(name), log, prog)
    layouts = []
    for P in pl:
        k = _thumb_key(P['body'])
        try:
            lay = json.loads((tc / f'{k}.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            lay = {'boxes': [], 'labels': []}
        lay.update({'index': P['index'], 'thumb': f'/scenes/thumb/{k}.jpg', 'thumb_key': k})
        layouts.append(lay)
    return {'layouts': layouts, 'rendered': [t['i'] for t in todo], 'cfg_hash': cfg_hash(cfg)}


# ───────────────────────── kiểm tra trước khi xuất ─────────────────────────
TYPOS = {
    'xây xựng': 'xây dựng', 'sát nhập': 'sáp nhập', 'giành cho': 'dành cho', 'chuẩn đoán': 'chẩn đoán', 'lãi xuất': 'lãi suất',
    'sử lý': 'xử lý', 'trao chuốt': 'trau chuốt', 'xuất xắc': 'xuất sắc', 'sơ xuất': 'sơ suất', 'xổ đỏ': 'sổ đỏ', 'xổ hồng': 'sổ hồng',
    'triết khấu': 'chiết khấu', 'chiếc khấu': 'chiết khấu', 'suất xứ': 'xuất xứ', 'tiện tích': 'tiện ích', 'quy hoạc': 'quy hoạch',
    'bất động xản': 'bất động sản', 'diện tít': 'diện tích', 'chủ đầu từ': 'chủ đầu tư', 'vành đay': 'vành đai', 'kiến chúc': 'kiến trúc',
    'dành giật': 'giành giật', 'đường xá': 'đường sá', 'nhà sản xuất': None, 'chung cư mi ni': 'chung cư mini', 'tham khỏa': 'tham khảo',
    'ngân sác': 'ngân sách', 'cở sở': 'cơ sở', 'thủ tụt': 'thủ tục', 'phê duyêt': 'phê duyệt', 'hoàn thiên': 'hoàn thiện',
}
FORBIDDEN = ['x2', 'x3', 'gấp đôi', 'đón sóng', 'cơ hội vàng', 'mua ngay', 'chốt ngay', 'cam kết lợi nhuận', 'lợi nhuận cam kết',
             'chắc chắn tăng', 'tăng giá chắc', 'đầu tư sinh lời', 'sinh lời cao', 'lãi thấp nhất', 'vay ngay', 'nên vay',
             'ai-generated', 'ai generated', 'made with ai', 'nội dung ai', 'video ai', 'ảnh ai', 'tạo bằng ai', 'ảnh tạo bởi ai']
_W = r'[^\W_]'
NUM_RE = re.compile(r'\d[\d.,]*\s*(%|tỷ|tỉ|triệu|nghìn|ngàn|km|m²|m2|ha|đồng|usd|căn|tầng|phút|giờ|làn|ga)(?![^\W_])', re.I)
AI_RE = re.compile(r'(?<![^\W_])AI(?![^\W_])')
SAFE_KINDS = {'title', 'subtitle', 'card', 'panel', 'hook', 'label', 'measure', 'spotlight', 'media'}


def scene_texts(cfg):
    """[(chỉ số cảnh, nơi, chữ hiện trên hình)]"""
    out = []
    items = {it['id']: it for it in cfg.get('items', []) if isinstance(it, dict) and it.get('id')}
    for i, sc in enumerate(cfg['scenes']):
        t = sc.get('title') or {}
        if isinstance(t, dict):
            out += [(i, 'tiêu đề', t.get('text', '')), (i, 'dòng nhỏ', t.get('kicker', ''))]
        out += [(i, 'phụ đề', plain(s)) for s in sc.get('subs', [])]
        if sc.get('hook'):
            out += [(i, 'mở đầu', sc['hook'].get('text', '')), (i, 'mở đầu', sc['hook'].get('sub', ''))]
        cd = sc.get('card') or {}
        out += [(i, 'thẻ', cd.get('title', ''))] + [(i, 'thẻ', ' '.join(map(str, r))) for r in cd.get('rows', [])]
        out += [(i, 'thẻ', plain(x)) for x in cd.get('list', [])]
        if cd.get('big'):
            out.append((i, 'thẻ', f"{cd['big'].get('value', '')} {cd['big'].get('unit', '')} {cd['big'].get('note', '')}"))
        pn = sc.get('panel') or {}
        out += [(i, 'bảng', pn.get('title', ''))] + [(i, 'bảng', ' '.join(map(str, r))) for r in pn.get('rows', []) + pn.get('items', []) + pn.get('steps', [])]
        if pn.get('text'):
            out.append((i, 'bảng', pn['text']))
        for r in _visible(cfg, i):
            if r in items and items[r].get('name'):
                out.append((i, 'nhãn', items[r]['name']))
    return [(i, w, s) for i, w, s in out if s and str(s).strip()]


def has_source(cfg, sc):
    if sc.get('source') or (sc.get('panel') or {}).get('note') or (sc.get('card') or {}).get('source'):
        return True
    ft = str(cfg.get('footer', ''))
    m = re.search(r'(Số liệu|Nguồn)\s*:\s*([^.]*)', ft, re.I)
    return bool(m and m.group(2).strip() and '(ghi nguồn)' not in m.group(2) and len(m.group(2).strip()) >= 3)


def _box_overlap(a, b, tol=2):
    return a[0] + tol < b[2] and b[0] + tol < a[2] and a[1] + tol < b[3] and b[1] + tol < a[3]


def precheck(cfg, layouts=None, lufs=None, duration=None, final=False):
    """Bảng kiểm tra ✓/✗. Mỗi dòng {id, label, status: ok|warn|error, detail}. blocking = có dòng error."""
    rows = []

    def row(id_, label, status, detail=''):
        rows.append({'id': id_, 'label': label, 'status': status, 'detail': detail})
    fmt = cfg.get('format', '9:16'); S = SAFE.get(fmt, SAFE['9:16'])
    # 1. chữ ra ngoài vùng an toàn / đè nhau (theo toạ độ thật của chữ trong khung đại diện)
    if layouts is None:
        row('safe', 'Chữ trong vùng an toàn TikTok', 'warn', 'Chưa có khung đại diện – bấm "Kiểm tra" khi máy dựng bật.')
        row('overlap', 'Chữ không đè nhau', 'warn', 'Chưa có khung đại diện.')
    else:
        out_, ov = [], []
        for lay in layouts:
            n = lay.get('index', 0) + 1
            bx = [b for b in lay.get('boxes', []) if b.get('kind') in SAFE_KINDS]
            for b in bx:
                x0, y0, x1, y1 = b['box']
                if x0 < 0 or x1 > S['W'] - S['right'] or y0 < S['top'] or y1 > S['bottom']:
                    out_.append(f'Cảnh {n}: {b["kind"]} "{b.get("text", "")[:30]}" ({int(x0)},{int(y0)})–({int(x1)},{int(y1)})')
            for a_i in range(len(bx)):
                for b_i in range(a_i + 1, len(bx)):
                    a, b = bx[a_i], bx[b_i]
                    if a.get('probe') or b.get('probe'):
                        continue
                    if a.get('group') != b.get('group') and _box_overlap(a['box'], b['box']):
                        ov.append(f'Cảnh {n}: "{a.get("text", "")[:24]}" đè "{b.get("text", "")[:24]}"')
        row('safe', 'Chữ trong vùng an toàn TikTok', 'error' if out_ else 'ok',
            '; '.join(out_[:6]) if out_ else f'Mọi chữ trong {S["W"] - S["right"]}×({S["top"]}..{S["bottom"]}) px')
        row('overlap', 'Chữ không đè nhau', 'error' if ov else 'ok', '; '.join(ov[:6]) if ov else 'Không có chữ chồng lên nhau')
    # 2. âm lượng
    if lufs is None:
        row('lufs', f'Âm lượng {LUFS_TARGET:g} LUFS', 'warn', 'Chưa đo (chưa có bản xem trước có tiếng). Bản nét tự chuẩn hoá về −14 LUFS.')
    else:
        dv = abs(lufs - LUFS_TARGET)
        row('lufs', f'Âm lượng {LUFS_TARGET:g} LUFS', 'ok' if dv <= 1.5 else ('warn' if dv <= 3 or not final else 'error'),
            f'Đo được {lufs:.1f} LUFS'.replace('.', ',') + ('' if dv <= 1.5 else ' – bản nét sẽ tự chuẩn hoá về −14'))
    # 3. độ dài
    total = duration if duration is not None else sum(scene_dur(sc) for sc in cfg['scenes'])
    row('duration', f'Độ dài {DUR_MIN:g}–{DUR_MAX:g} giây', 'ok' if DUR_MIN <= total <= DUR_MAX else 'error',
        f'{total:.1f} giây'.replace('.', ',') + ('' if DUR_MIN <= total <= DUR_MAX else (' – ngắn quá, thêm cảnh' if total < DUR_MIN else ' – dài quá, bớt cảnh')))
    # 4. chính tả + từ cấm
    texts = scene_texts(cfg); typo, bad = [], []
    for i, where, s in texts:
        low = s.lower()
        for w, r in TYPOS.items():
            if r and re.search(r'(?<![^\W_])' + re.escape(w) + r'(?![^\W_])', low):
                typo.append(f'Cảnh {i + 1} ({where}): "{w}" → "{r}"')
        if re.search(r'(?<![^\W_])(\w+)\s+\1(?![^\W_])', low):
            typo.append(f'Cảnh {i + 1} ({where}): lặp từ "{re.search(r"(?<![^\W_])(\w+)\s+\1(?![^\W_])", low).group(0)}"')
        if re.search(r'\s[,.!?;:]', s) or '  ' in s:
            typo.append(f'Cảnh {i + 1} ({where}): khoảng trắng thừa')
        if AI_RE.search(s):
            bad.append(f'Cảnh {i + 1} ({where}): chữ "AI" trên hình')
        for w in FORBIDDEN:
            if re.search(r'(?<![^\W_])' + re.escape(w) + r'(?![^\W_])', low):
                bad.append(f'Cảnh {i + 1} ({where}): "{w}"')
    row('spell', 'Chính tả cơ bản', 'warn' if typo else 'ok', '; '.join(typo[:6]) if typo else 'Không thấy lỗi hay gặp')
    row('forbidden', 'Không có nhãn "AI" / từ cấm', 'error' if bad else 'ok', '; '.join(bad[:6]) if bad else 'Đạt')
    # 5. số liệu cần nguồn
    miss = sorted({i + 1 for i, _, s in texts if NUM_RE.search(s) and not has_source(cfg, cfg['scenes'][i])})
    row('source', 'Số liệu có nguồn', 'error' if miss else 'ok',
        ('Cảnh ' + ', '.join(map(str, miss)) + ' có số liệu nhưng chưa ghi nguồn (footer "Số liệu: …" hoặc "source" của cảnh)') if miss else 'Đạt')
    # 6. ảnh minh hoạ / nhân vật
    il, fl = [], []
    for i, sc in enumerate(cfg['scenes']):
        m = sc.get('media') or {}
        if not m:
            continue
        src = str(m.get('src', '')).lower()
        if (m.get('illustrative') or m.get('render3d') or m.get('flow') or re.search(r'3d|phoi.?canh|render', src)) and not m.get('ai'):
            il.append(f'Cảnh {i + 1}')
        if not m.get('ai') and not m.get('credit') and not m.get('own'):
            il.append(f'Cảnh {i + 1} (ảnh thật cần ghi nguồn/"own")')
        fw = m.get('flow') or {}
        if final and fw and fw.get('stage') != 'final':
            fl.append(f'Cảnh {i + 1}')
    row('illustrative', 'Ảnh 3D/phối cảnh ghi "Ảnh minh hoạ"', 'error' if il else 'ok', '; '.join(il) if il else 'Đạt')
    if any((sc.get('media') or {}).get('flow') for sc in cfg['scenes']):
        row('flow', 'Cảnh nhân vật đã duyệt bản nét', 'error' if fl else 'ok',
            ('Còn bản nháp: ' + ', '.join(fl)) if fl else ('Đạt' if final else 'Xem trước dùng bản nháp – bản nét cần clip Veo Quality đã duyệt'))
    # 7. cảnh "AI cao cấp": phải có clip gắn vào; dịch vụ trả phí riêng phải được duyệt trước
    PAID = ('kling', 'runway', 'hailuo', 'veo_api')
    noclip, unpaid = [], []
    for i, sc in enumerate(cfg['scenes']):
        st = sc.get('studio') or {}
        if st.get('engine') != 'ai':
            continue
        if not (sc.get('media') or {}).get('src'):
            noclip.append(f'Cảnh {i + 1}')
        if st.get('provider') in PAID and not st.get('paid_approved'):
            unpaid.append(f'Cảnh {i + 1} ({st["provider"]})')
    if any((sc.get('studio') or {}).get('engine') == 'ai' for sc in cfg['scenes']):
        row('ai_clip', 'Cảnh AI cao cấp đã gắn clip', ('error' if final else 'warn') if noclip else 'ok',
            ('Chưa có clip: ' + ', '.join(noclip) + (' – xem trước tạm dùng hình dựng trên máy' if not final else '')) if noclip else 'Đạt')
        row('ai_paid', 'Dịch vụ AI trả phí đã duyệt', 'error' if unpaid else 'ok',
            ('Chưa bấm "Duyệt" chi phí: ' + ', '.join(unpaid)) if unpaid else 'Đạt')
    # 8. giấy phép bản đồ
    if cfg.get('geo') and 'openstreetmap' not in str(cfg.get('footer', '')).lower():
        row('osm', 'Ghi công © OpenStreetMap', 'error', 'Footer thiếu "© OpenStreetMap contributors" (giấy phép ODbL)')
    return {'rows': rows, 'blocking': any(r['status'] == 'error' for r in rows),
            'errors': sum(r['status'] == 'error' for r in rows), 'warnings': sum(r['status'] == 'warn' for r in rows)}


def check(name, log=print, prog=lambda p: None, cfg=None):
    cfg = cfg if cfg is not None else load_cfg(name)
    th = thumbs(name, log, lambda p: prog(0.9 * p), cfg=cfg)
    st = load_state(name); ch = cfg_hash(cfg)
    pv = st.get('preview') or {}
    lufs = pv.get('lufs') if pv.get('cfg_hash') == ch else None
    dur = pv.get('duration') if pv.get('cfg_hash') == ch else None
    res = precheck(cfg, th['layouts'], lufs, dur)
    res.update({'cfg_hash': ch, 'at': common.now_ms(), 'layouts': th['layouts']})
    save_state(name, {'check': {k: res[k] for k in ('rows', 'blocking', 'errors', 'warnings', 'cfg_hash', 'at')}})
    prog(1.0)
    return res


def final_allowed(name, cfg=None):
    """(được xuất?, lý do) – chặn "Xuất bản nét" khi chưa kiểm tra bản hiện tại hoặc còn lỗi đỏ."""
    cfg = cfg if cfg is not None else load_cfg(name)
    c = load_state(name).get('check') or {}
    if c.get('cfg_hash') != cfg_hash(cfg):
        return False, 'CHECK_REQUIRED', 'Bấm "Kiểm tra" cho bản đang sửa trước khi xuất bản nét.'
    if c.get('blocking'):
        return False, 'CHECK_FAILED', f'Còn {c.get("errors", 1)} lỗi đỏ trong bảng kiểm tra – sửa xong rồi xuất.'
    return True, '', ''


def export_final(name, log=print, prog=lambda p: None, voice=True, tts=None, workers=None):
    ok, code, msg = final_allowed(name)
    if not ok:
        raise ValueError(msg)
    cfg = load_cfg(name)
    lay = thumbs(name, log, cfg=cfg)['layouts']
    pre = precheck(cfg, lay, None, None, final=True)
    if pre['blocking']:
        raise ValueError('Bản nét bị chặn: ' + '; '.join(r['label'] + ' – ' + r['detail'] for r in pre['rows'] if r['status'] == 'error'))
    date = datetime.date.today().isoformat()
    target = common.video_dir() / f'{date}_{common.safe_name(name, "video")}.mp4'
    k = 2
    while target.exists():
        target = common.video_dir() / f'{date}_{common.safe_name(name, "video")}-{k}.mp4'; k += 1
    res = build(name, 'final', log, prog, voice=voice, tts=tts, workers=workers, cfg=cfg, out=target)
    for key, suf in (('srt', '.srt'), ('cover', '_cover.jpg'), ('meta', '_meta.json')):
        if res.get(key):
            t = target.with_name(target.stem + suf); shutil.move(res[key], t); res[key] = str(t)
    return res


# ───────────────────────── chỉnh sửa cfg ─────────────────────────
def patch_scene(cfg, index, scene=None, items=None):
    cfg = copy.deepcopy(cfg)
    if not (0 <= index < len(cfg['scenes'])):
        raise ValueError('Không có cảnh này')
    if scene is not None:
        if not isinstance(scene, dict):
            raise ValueError('scene phải là đối tượng')
        cfg['scenes'][index] = scene
    if items:
        by = {it['id']: it for it in cfg.get('items', [])}
        for iid, p in items.items():
            if iid not in by or not isinstance(p, dict):
                raise ValueError(f'Không có mục "{iid}"')
            for k in ('label_offset', 'label_side', 'name', 'always_label', 'hide_label', 'll', 'color', 'tag'):
                if k in p:
                    if k == 'label_offset':
                        v = p[k]
                        if not (isinstance(v, list) and len(v) == 2):
                            raise ValueError('label_offset = [dx, dy]')
                        p[k] = [max(-900, min(900, round(float(v[0])))), max(-900, min(900, round(float(v[1]))))]
                    if k == 'label_side' and p[k] not in ('left', 'right'):
                        raise ValueError('label_side = left | right')
                    by[iid][k] = p[k]
    return validate_cfg(cfg)


def insert_scene(cfg, at, scene, items=None):
    cfg = copy.deepcopy(cfg)
    ids = {it['id'] for it in cfg.get('items', [])}
    for it in items or []:
        if not isinstance(it, dict) or not it.get('id'):
            raise ValueError('Mục mẫu cần id')
        if it['id'] in ids:
            continue                 # mục trùng id: dùng mục đã có
        cfg.setdefault('items', []).append(it); ids.add(it['id'])
    at = len(cfg['scenes']) if at is None else max(0, min(int(at), len(cfg['scenes'])))
    cfg['scenes'].insert(at, scene)
    return validate_cfg(cfg)


def move_scene(cfg, frm, to):
    cfg = copy.deepcopy(cfg)
    n = len(cfg['scenes'])
    if not (0 <= frm < n and 0 <= to < n):
        raise ValueError('Vị trí cảnh không hợp lệ')
    cfg['scenes'].insert(to, cfg['scenes'].pop(frm))
    return validate_cfg(cfg)


def delete_scene(cfg, index):
    cfg = copy.deepcopy(cfg)
    if len(cfg['scenes']) <= 1:
        raise ValueError('Cần ít nhất 1 cảnh')
    cfg['scenes'].pop(index)
    return validate_cfg(cfg)


# ───────────────────────── kho bản đồ tải sẵn (tile) ─────────────────────────
REGIONS = [
    {'id': 'hn_noi_do', 'name': 'Hà Nội nội đô', 'bbox': [20.98, 105.78, 21.07, 105.88]},
    {'id': 'gia_lam', 'name': 'Gia Lâm', 'bbox': [20.96, 105.90, 21.03, 105.98]},
    {'id': 'dong_anh', 'name': 'Đông Anh / Cổ Loa', 'bbox': [21.08, 105.78, 21.17, 105.90]},
    {'id': 'tay_ho_tay', 'name': 'Tây Hồ – Bắc Từ Liêm', 'bbox': [21.05, 105.77, 21.09, 105.82]},
    {'id': 'long_bien', 'name': 'Long Biên', 'bbox': [21.02, 105.86, 21.07, 105.93]},
    {'id': 'ha_dong', 'name': 'Hà Đông / Thanh Xuân', 'bbox': [20.94, 105.75, 21.00, 105.83]},
]
# Tải trước hàng loạt từ máy chủ tile công cộng của OpenStreetMap VI PHẠM chính sách OSM (operations.osmfoundation.org/policies/tiles:
# cấm tải trước/bulk download) → mặc định KHÔNG có nguồn. Chỉ tải khi anh tự cấu hình nguồn tile có giấy phép
# (POST /scenes/maps/settings {url, licensed:true}). Video bản đồ vẫn dùng dữ liệu OSM vector có sẵn (engine/data) – không ảnh hưởng.
TILE_DEFAULT = {'url': '', 'zmin': 12, 'zmax': 16, 'avg_kb': 25, 'licensed': False}
TILE_UA = 'BDS-Studio-Engine/1.0 (offline map cache)'
TILE_BLOCKED_HOSTS = re.compile(r'(^|\.)tile\.openstreetmap\.(org|fr|de)$|(^|\.)openstreetmap\.org$', re.I)
TILE_HELP = {
    'why': 'Máy chủ tile công cộng của OpenStreetMap không cho tải trước hàng loạt (chính sách sử dụng tile của OSM). '
           'Video bản đồ vẫn dựng bình thường bằng dữ liệu OSM có sẵn trong máy dựng – kho này chỉ thêm ảnh nền khi mất mạng.',
    'how': 'Muốn tải sẵn ảnh nền: đăng ký một nguồn tile có giấy phép, dán đường dẫn dạng https://…/{z}/{x}/{y}.png?key=… '
           'rồi đánh dấu "Tôi có quyền dùng nguồn này".',
    'providers': [
        {'name': 'Geoapify', 'url': 'https://www.geoapify.com/pricing/', 'note': 'gói Free 3.000 credit/ngày (1 tile = 0,25 credit), cho dùng thương mại khi ghi nguồn, cho lưu đệm tile; không cần thẻ'},
        {'name': 'MapTiler Cloud', 'url': 'https://www.maptiler.com/cloud/pricing/', 'note': 'gói miễn phí chỉ phi thương mại – kiểm điều khoản gói (video bán hàng/quảng cáo cần gói trả phí)'},
        {'name': 'Stadia Maps', 'url': 'https://stadiamaps.com/pricing/', 'note': 'gói miễn phí chỉ phi thương mại – kiểm điều khoản gói (video bán hàng/quảng cáo cần gói trả phí)'},
    ],
}


def tile_host(url):
    m = re.match(r'^https?://([^/:?#]+)', str(url or ''))
    return m.group(1).lower() if m else ''


def tile_settings():
    p = common.data_dir() / 'map_store.json'
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        d = {}
    cur = dict(TILE_DEFAULT, **{k: v for k, v in d.items() if k in TILE_DEFAULT})
    if TILE_BLOCKED_HOSTS.search(tile_host(cur['url'])):      # tệp cấu hình cũ (bản trước) trỏ OSM → bỏ
        cur['url'] = ''; cur['licensed'] = False
    return cur


def tile_allowed(ts=None):
    ts = ts or tile_settings()
    return bool(ts.get('url')) and bool(ts.get('licensed'))


def save_tile_settings(patch):
    cur = tile_settings()
    patch = patch or {}
    if 'url' in patch:
        v = patch.get('url')
        v = v.strip() if isinstance(v, str) else ''
        if not v:
            cur['url'] = ''; cur['licensed'] = False
        else:
            if not re.match(r'^https://[^\s]+\{z\}.*\{x\}.*\{y\}', v):
                raise ValueError('Đường dẫn nguồn tile phải dạng https://…/{z}/{x}/{y}.png')
            if TILE_BLOCKED_HOSTS.search(tile_host(v)):
                raise ValueError('Không dùng máy chủ tile công cộng của OpenStreetMap để tải trước (chính sách OSM cấm tải hàng loạt). '
                                 'Dùng nguồn có giấy phép như Geoapify (gói Free cho thương mại khi ghi nguồn) – kiểm điều khoản gói.')
            if v != cur['url']:
                cur['licensed'] = False                      # đổi nguồn → phải xác nhận lại quyền dùng
            cur['url'] = v
    for k, v in patch.items():
        if k in ('zmin', 'zmax') and isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 18:
            cur[k] = v
    if 'licensed' in patch:
        cur['licensed'] = bool(patch.get('licensed') is True and cur['url'])
    p = common.data_dir() / 'map_store.json'
    p.write_text(json.dumps(cur, ensure_ascii=False), encoding='utf-8')
    return cur


def public_tile_settings(ts=None):
    ts = ts or tile_settings()
    u = ts.get('url') or ''
    return {'source_set': bool(u), 'licensed': bool(ts.get('licensed')), 'allowed': tile_allowed(ts),
            'source': tile_host(u), 'url_masked': re.sub(r'([?&](?:key|api_key|access_token|token)=)[^&]+', r'\1***', u),
            'zoom': [ts['zmin'], ts['zmax']]}


def deg2tile(lat, lon, z):
    n = 2 ** z
    x = int((lon + 180) / 360 * n)
    y = int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def region_tiles(region, zmin, zmax):
    s, w, n, e = region['bbox']
    for z in range(zmin, zmax + 1):
        x0, y0 = deg2tile(n, w, z); x1, y1 = deg2tile(s, e, z)
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                yield z, x, y


def tile_root():
    return common.sub_cache('tiles')


def tile_path(z, x, y, src=None):
    src = src or hashlib.sha1((tile_settings()['url'] or 'none').encode()).hexdigest()[:8]
    return tile_root() / src / str(z) / str(x) / f'{y}.png'


class TileStore:
    def __init__(self, fetch=None):
        self.fetch = fetch or self._http
        self.status = {}          # region → {state, done, total, error}
        self.lock = threading.Lock()

    @staticmethod
    def _http(url):
        req = urllib.request.Request(url, headers={'User-Agent': TILE_UA})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read()

    def region(self, rid):
        r = next((x for x in REGIONS if x['id'] == rid), None)
        if not r:
            raise KeyError('Không có vùng ' + str(rid))
        return r

    def summary(self):
        ts = tile_settings()
        out = []; total_bytes = 0
        for r in REGIONS:
            have = 0; size = 0; n = 0
            for z, x, y in region_tiles(r, ts['zmin'], ts['zmax']):
                n += 1; f = tile_path(z, x, y)
                if f.is_file():
                    have += 1; size += f.stat().st_size
            total_bytes += size
            out.append(dict(r, tiles_total=n, tiles_have=have, bytes=size, est_bytes=n * ts['avg_kb'] * 1024,
                            status=self.status.get(r['id'], {}).get('state', 'done' if have == n else ('partial' if have else 'none')),
                            progress=self.status.get(r['id'])))
        cache_gb = common.load_config()['map_cache_gb']
        used = common.dir_size(common.cache_dir())
        pub = public_tile_settings(ts)
        return dict(pub, regions=out, tiles_bytes=total_bytes, cache_bytes=used, limit_bytes=int(cache_gb * 2**30),
                    source=pub['source'] or 'chưa cấu hình', help=TILE_HELP)

    def prefetch(self, rid, background=True, delay=0.05):
        r = self.region(rid); ts = tile_settings()
        if not tile_allowed(ts):
            raise PermissionError(TILE_HELP['why'] + ' ' + TILE_HELP['how'])
        if TILE_BLOCKED_HOSTS.search(tile_host(ts['url'])):
            raise PermissionError('Không tải trước từ máy chủ tile công cộng của OpenStreetMap.')
        tiles = [t for t in region_tiles(r, ts['zmin'], ts['zmax']) if not tile_path(*t).is_file()]
        est = len(tiles) * ts['avg_kb'] * 1024
        limit = int(common.load_config()['map_cache_gb'] * 2**30)
        if common.dir_size(common.cache_dir()) + est > limit:
            raise ValueError(f'Vượt giới hạn bộ nhớ đệm ({limit / 2**30:.1f} GB) – tăng "map_cache_gb" hoặc xoá vùng khác.')
        with self.lock:
            if self.status.get(rid, {}).get('state') == 'running':
                return self.status[rid]
            self.status[rid] = {'state': 'running', 'done': 0, 'total': len(tiles), 'error': None}

        def go():
            st = self.status[rid]
            try:
                for z, x, y in tiles:
                    f = tile_path(z, x, y); f.parent.mkdir(parents=True, exist_ok=True)
                    data = self.fetch(ts['url'].format(z=z, x=x, y=y))
                    tmp = f.with_suffix('.part'); tmp.write_bytes(data); os.replace(tmp, f)
                    st['done'] += 1
                    if delay:
                        time.sleep(delay)
                st['state'] = 'done'
            except Exception as e:      # mất mạng giữa chừng → giữ phần đã tải
                st['state'] = 'error'; st['error'] = str(e)[:200]
        if background:
            threading.Thread(target=go, daemon=True, name='bds-tiles').start()
        else:
            go()
        return self.status[rid]

    def delete(self, rid):
        r = self.region(rid); ts = tile_settings(); n = 0
        for t in region_tiles(r, ts['zmin'], ts['zmax']):
            f = tile_path(*t)
            if f.is_file():
                f.unlink(); n += 1
        self.status.pop(rid, None)
        return {'removed': n}

    def stitch(self, rid, z=None, out=None):
        """Ghép tile thành 1 ảnh nền (cfg.satellite = {file, bbox_ll}) dùng được khi mất mạng."""
        from PIL import Image
        r = self.region(rid); ts = tile_settings(); z = z or min(ts['zmax'], 15)
        s, w, n, e = r['bbox']
        x0, y0 = deg2tile(n, w, z); x1, y1 = deg2tile(s, e, z)
        im = Image.new('RGB', ((x1 - x0 + 1) * 256, (y1 - y0 + 1) * 256), (14, 24, 40)); miss = 0
        for x in range(x0, x1 + 1):
            for y in range(y0, y1 + 1):
                f = tile_path(z, x, y)
                if f.is_file():
                    try:
                        im.paste(Image.open(f).convert('RGB'), ((x - x0) * 256, (y - y0) * 256))
                    except OSError:
                        miss += 1
                else:
                    miss += 1

        def t2ll(x, y):
            nn = 2 ** z; lon = x / nn * 360 - 180
            lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / nn))))
            return lat, lon
        north, west = t2ll(x0, y0); south, east = t2ll(x1 + 1, y1 + 1)
        out = Path(out or (common.sub_cache('scenes') / f'nen_{rid}_z{z}.jpg'))
        im.save(out, quality=88)
        return {'file': str(out), 'bbox_ll': [round(south, 6), round(west, 6), round(north, 6), round(east, 6)], 'missing': miss}


# ───────────────────────── thư viện clip nhân vật (dùng lại cho căn cùng loại/dự án) ─────────────────────────
def clip_lib_path():
    return common.data_dir() / 'clip_library.json'


def clip_lib():
    try:
        return [c for c in json.loads(clip_lib_path().read_text(encoding='utf-8')) if os.path.isfile(c.get('path', ''))]
    except (OSError, ValueError):
        return []


def clip_add(c):
    p = Path(str(c.get('path', ''))).expanduser()
    if not p.is_file():
        raise ValueError('Không thấy tệp clip')
    keep = common.home_dir() / 'Thu vien clip'; keep.mkdir(parents=True, exist_ok=True)
    if not common._inside(p, keep):
        dst = keep / p.name
        if dst.exists():
            dst = keep / f'{int(time.time())}_{p.name}'
        shutil.copy2(p, dst); p = dst
    row = {'id': hashlib.sha1(str(p).encode()).hexdigest()[:10], 'path': str(p), 'name': p.name,
           'project': str(c.get('project', ''))[:80], 'unit_type': str(c.get('unit_type', ''))[:40], 'room': str(c.get('room', ''))[:40],
           'stage': 'final' if c.get('stage') == 'final' else 'draft', 'model': c.get('model', 'fast'), 'character': str(c.get('character', ''))[:60],
           'created': common.now_ms()}
    lib = [x for x in clip_lib() if x['path'] != row['path']] + [row]
    clip_lib_path().write_text(json.dumps(lib, ensure_ascii=False), encoding='utf-8')
    return row


def clip_find(project='', unit_type='', room='', stage=''):
    def score(c):
        return (2 if project and c['project'] == project else 0) + (2 if unit_type and c['unit_type'] == unit_type else 0) + \
            (1 if room and c['room'] == room else 0) + (1 if c['stage'] == 'final' else 0)
    lib = [c for c in clip_lib() if (not stage or c['stage'] == stage) and (not room or c['room'] == room or not c['room'])]
    lib = [c for c in lib if score(c) >= (2 if (project or unit_type) else 0)]
    return sorted(lib, key=lambda c: (-score(c), -c['created']))


# ───────────────────────── HTTP (/scenes/*) – gọi từ server.py ─────────────────────────
_LOCK = threading.Lock()


def services(app):
    """Hàng đợi thông minh + kho bản đồ gắn vào App của server (tạo 1 lần)."""
    with _LOCK:
        if getattr(app, '_scenes_q', None) is None:
            import queue_smart
            app._scenes_tiles = TileStore()
            app._scenes_q = queue_smart.SmartQueue(app.jobs, run_item)
            app._scenes_q.start()
    return app._scenes_q, app._scenes_tiles


def overnight_bridge(app):
    """Cầu nối job video_map → nháp 480p qua đêm (overnight.py), dùng chung hàng đợi thông minh."""
    services(app)
    with _LOCK:
        if getattr(app, '_overnight', None) is None:
            import overnight
            app._overnight = overnight.Bridge(lambda: app._scenes_q)
    return app._overnight


def run_item(item, log, prog, workers):
    k = item['kind']; name = item['project']
    if k == 'preview':
        r = build(name, 'preview', log, prog, voice=item.get('voice', False), workers=workers)
        return {'outputs': {'mp4': r['mp4']}, 'result': {x: r[x] for x in ('rendered', 'cached', 'duration', 'lufs', 'width', 'height', 'seconds', 'units_rendered', 'units_total')}}
    if k == 'final':
        r = export_final(name, log, prog, voice=item.get('voice', True), workers=workers)
        return {'outputs': {x: r[x] for x in ('mp4', 'srt', 'cover', 'meta') if r.get(x)},
                'result': {x: r[x] for x in ('rendered', 'cached', 'duration', 'lufs', 'width', 'height', 'seconds')}}
    if k == 'thumbs':
        r = thumbs(name, log, prog)
        return {'outputs': {}, 'result': {'rendered': r['rendered']}}
    if k == 'check':
        r = check(name, log, prog)
        return {'outputs': {}, 'result': {x: r[x] for x in ('rows', 'blocking', 'errors', 'warnings', 'cfg_hash')}}
    raise ValueError('Loại việc không hợp lệ')


def project_view(name):
    cfg = load_cfg(name)
    st = load_state(name); ch = cfg_hash(cfg)
    c = st.get('check') or {}
    return {'ok': True, 'name': name, 'cfg': cfg, 'cfg_hash': ch, 'scenes': split(cfg, effective_cfg(cfg, project_dir(name))),
            'duration': round(sum(scene_dur(sc) for sc in cfg['scenes']), 2),
            'check': c if c.get('cfg_hash') == ch else None, 'check_stale': bool(c) and c.get('cfg_hash') != ch,
            'preview': (st.get('preview') or {}) if (st.get('preview') or {}).get('cfg_hash') == ch else None,
            'final_allowed': final_allowed(name, cfg)[0]}


def list_projects():
    project_dir('_mau_moi')
    return [d.name for d in sorted(common.projects_dir().iterdir()) if (d / 'cfg.json').is_file()]


def handle(app, method, p, q, hd):
    """Trả (status, body[, ctype, headers]) hoặc None (đã tự gửi tệp). Lỗi ValueError/KeyError → server trả BAD_INPUT."""
    Q, T = services(app)
    if method == 'GET':
        if p == '/scenes/projects':
            return 200, {'ok': True, 'projects': list_projects()}
        if p == '/scenes/project':
            return 200, project_view(q.get('name', ''))
        if p == '/scenes/queue':
            return 200, dict(Q.snapshot(), ok=True)
        if p == '/scenes/maps':
            return 200, dict(T.summary(), ok=True)
        if p == '/scenes/overnight':
            return 200, {'ok': True, 'rows': overnight_bridge(app).results(include_pushed=q.get('all') == '1')}
        if p == '/scenes/clips':
            return 200, {'ok': True, 'clips': clip_find(q.get('project', ''), q.get('unit_type', ''), q.get('room', ''), q.get('stage', ''))}
        if p.startswith('/scenes/thumb/'):
            k = p.rsplit('/', 1)[-1]
            if not re.match(r'^[0-9a-f]{24}\.jpg$', k) or not (thumb_cache() / k).is_file():
                return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Chưa có ảnh khung'}}
            return hd.send_file(thumb_cache() / k)
        if p.startswith('/scenes/file/'):
            parts = p.split('/')
            it = Q.get(parts[3]) if len(parts) == 5 else None
            f = (it or {}).get('outputs', {}).get(parts[4]) if it else None
            if not f or not os.path.isfile(f):
                return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không thấy tệp (có thể đã bị dọn)'}}
            return hd.send_file(Path(f), {'Content-Disposition': f'inline; filename="{Path(f).name.encode("ascii", "ignore").decode() or "video.mp4"}"'})
        return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}
    d = hd.json_body()
    name = d.get('name', '')
    if p == '/scenes/ping':
        Q.activity.ping(); return 200, {'ok': True, 'mode': Q.mode()[0]}
    if p == '/scenes/project':
        if d.get('create'):
            dd = project_dir(name)
            if (dd / 'cfg.json').exists():
                raise FileExistsError('Dự án đã có')
            dd.mkdir(parents=True, exist_ok=True); shutil.copy(common.TEMPLATE_PROJECT / 'cfg.json', dd / 'cfg.json')
        else:
            save_cfg(name, d.get('cfg'))
        return 200, project_view(name)
    if p == '/scenes/scene':
        save_cfg(name, patch_scene(load_cfg(name), int(d.get('index', -1)), d.get('scene'), d.get('items')))
        return 200, project_view(name)
    if p == '/scenes/insert':
        save_cfg(name, insert_scene(load_cfg(name), d.get('at'), d.get('scene'), d.get('items')))
        return 200, project_view(name)
    if p == '/scenes/move':
        save_cfg(name, move_scene(load_cfg(name), int(d.get('from', -1)), int(d.get('to', -1))))
        return 200, project_view(name)
    if p == '/scenes/delete':
        save_cfg(name, delete_scene(load_cfg(name), int(d.get('index', -1))))
        return 200, project_view(name)
    if p in ('/scenes/preview', '/scenes/check', '/scenes/thumbs', '/scenes/final'):
        kind = p.rsplit('/', 1)[-1]
        load_cfg(name)
        if kind == 'final':
            ok, code, msg = final_allowed(name)
            if not ok:
                return 409, {'ok': False, 'error': {'code': code, 'message': msg}}
        it = Q.submit(kind, name, voice=bool(d.get('voice', kind == 'final')), now=kind != 'final' or bool(d.get('now')),
                      approved=bool(d.get('approved', kind != 'final')), title=d.get('title'))
        return 200, {'ok': True, 'id': it['id'], 'item': Q.public(it)}
    if p == '/scenes/overnight':              # app đang mở trên máy này giao job nháp qua đêm
        rows = d.get('jobs')
        if not isinstance(rows, list) or len(rows) > 50:
            raise ValueError('Cần danh sách jobs (tối đa 50)')
        return 200, {'ok': True, 'rows': overnight_bridge(app).handle_rows(rows)}
    if p == '/scenes/overnight/ack':
        overnight_bridge(app).ack([str(i) for i in (d.get('ids') or [])][:200]); return 200, {'ok': True}
    if p == '/scenes/queue/order':
        return 200, dict(Q.reorder(d.get('ids') or []), ok=True)
    if p == '/scenes/queue/approve':
        Q.approve(d.get('id'), bool(d.get('approved', True))); return 200, dict(Q.snapshot(), ok=True)
    if p == '/scenes/queue/remove':
        Q.remove(d.get('id')); return 200, dict(Q.snapshot(), ok=True)
    if p == '/scenes/queue/run_now':
        Q.run_now(d.get('id')); return 200, dict(Q.snapshot(), ok=True)
    if p == '/scenes/maps/prefetch':
        try:
            return 200, {'ok': True, 'status': T.prefetch(d.get('region'))}
        except PermissionError as e:
            return 409, {'ok': False, 'error': {'code': 'TILE_SOURCE_REQUIRED', 'message': str(e)}}
    if p == '/scenes/maps/delete':
        return 200, dict(T.delete(d.get('region')), ok=True)
    if p == '/scenes/maps/settings':
        return 200, {'ok': True, 'settings': public_tile_settings(save_tile_settings(d))}
    if p == '/scenes/maps/use':
        sat = T.stitch(d.get('region'))
        cfg = load_cfg(name); cfg['satellite'] = {'file': sat['file'], 'bbox_ll': sat['bbox_ll'], 'saturation': 0.85, 'brightness': 0.55}
        save_cfg(name, cfg)
        return 200, dict(project_view(name), satellite=sat)
    if p == '/scenes/clips':
        return 200, {'ok': True, 'clip': clip_add(d)}
    return 404, {'ok': False, 'error': {'code': 'NOT_FOUND', 'message': 'Không có đường dẫn này'}}


# ───────────────────────── tiến trình con: vẽ khung bằng render_map ─────────────────────────
class _NoBase:
    """Nền giả cho bước chỉ trộn tiếng (không cần vẽ bản đồ → khỏi mất ~10 s dựng nền)."""
    def __init__(self, *a, **k):
        pass

    def view(self, *a, **k):
        raise RuntimeError('no base')


_CTX = {}


def _encoder(path):
    R = _CTX['R']; W, H = R.W, R.H; w, h = _CTX['size']; fps = _CTX['fps']; spec = _CTX['spec']
    vf = [] if (w, h) == (W, H) else ['-vf', f'scale={w}:{h}:flags=bicubic']
    return subprocess.Popen([ffbin('ffmpeg'), '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(fps),
                             '-i', '-'] + vf + ['-c:v', 'libx264', '-preset', spec.get('preset', 'veryfast'), '-crf', str(spec.get('crf', 18)),
                             '-pix_fmt', 'yuv420p', '-r', str(fps), path + '.part.mp4'], stdin=subprocess.PIPE)


def _render_unit(u):
    """1 khúc (thân / chuyển cảnh / đuôi) → mp4. Chạy trong tiến trình con (fork) – dùng _CTX."""
    from PIL import Image
    R, V, plan_ = _CTX['R'], _CTX['V'], _CTX['plan']
    i = u['i']; P = plan_[i]; n = P['n']; xf = P['xf']; loop = P['loop']
    pr = _encoder(u['out'])
    if u['kind'] == 'body':
        for k in range(xf):                       # nạp nhớ vị trí nhãn như khi dựng liền mạch
            V.frame(k, i)
        for k in range(xf, n - loop):
            pr.stdin.write(V.frame(k, i).tobytes())
    elif u['kind'] == 'trans':
        prev = V.frame(plan_[i - 1]['n'] - 1, i - 1)
        for k in range(xf):
            pr.stdin.write(Image.blend(prev, V.frame(k, i), R.ease((k + 1) / (xf + 1))).tobytes())
    else:
        first = V.frame(0, 0)
        for k in range(n - loop, n):
            pr.stdin.write(Image.blend(V.frame(k, i), first, R.ease((k - (n - loop) + 1) / loop)).tobytes())
    pr.stdin.close()
    if pr.wait() != 0:
        raise RuntimeError(f'ffmpeg lỗi ở cảnh {i + 1}')
    os.replace(u['out'] + '.part.mp4', u['out'])
    return u['out']


def _worker(spec_path):
    spec = json.loads(Path(spec_path).read_text(encoding='utf-8'))
    sys.path.insert(0, str(common.SCRIPTS_DIR))
    import render_map as R
    from PIL import Image, ImageDraw
    cfg = spec['cfg']; base = spec['base']; fps = int(spec['fps'])
    R.FPS = fps
    R.L = R.LAYOUTS[cfg.get('format', '9:16')]; R.W, R.H = R.L['W'], R.L['H']
    W, H = R.W, R.H
    R.normalize_subs(cfg)          # dur đã được tiến trình cha tính sẵn (kể cả cảnh có giọng) → không gọi prepare_audio
    if not spec.get('full_base'):
        R.Base = _NoBase
    V = R.Video(cfg, base); V.build(); R._V = V
    result = {}
    plan_ = spec.get('plan') or []
    # thời gian hoạt ảnh riêng từng cảnh
    t0s = [P['t0'] for P in V.plan]
    srt_abs = list(V.srt)
    for P in V.plan:
        s = P['t0']; P['t0'] = 0.0; P['subs'] = [(a - s, b - s, t) for a, b, t in P['subs']]
    nfr = [p['n'] for p in plan_] if plan_ else [int(round(P['sc']['dur'] * fps)) for P in V.plan]
    units = spec.get('units') or []
    w, h = spec.get('size') or [W, H]

    _CTX.update(R=R, V=V, plan=plan_, size=(w, h), fps=fps, spec=spec)
    if units:
        procs = max(1, min(int(spec.get('workers') or 1), len(units)))
        import multiprocessing as mp
        if procs > 1 and 'fork' in mp.get_all_start_methods():
            with mp.get_context('fork').Pool(procs) as pool:
                for k, _ in enumerate(pool.imap_unordered(_render_unit, units), 1):
                    print(f'unit {k}/{len(units)}', flush=True)
        else:
            for k, u in enumerate(units, 1):
                _render_unit(u); print(f'unit {k}/{len(units)}', flush=True)
    # ảnh khung đại diện + toạ độ chữ
    for t in spec.get('thumbs') or []:
        i = t['i']; n = nfr[i] if i < len(nfr) else int(round(V.plan[i]['sc']['dur'] * fps))
        boxes, labels = _capture_layout(R, V, i, max(0, n - 1 - int(fps * 0.4)))
        im = boxes.pop('_image')
        im.resize((THUMB_W, int(THUMB_W * H / W))).save(t['jpg'], quality=82)
        Path(t['json']).write_text(json.dumps({'W': W, 'H': H, 'boxes': boxes['list'], 'labels': labels}, ensure_ascii=False), encoding='utf-8')
    # ghép + tiếng + phụ đề + bìa
    if spec.get('concat') and (spec.get('mix') or units):
        _concat(spec['concat'], spec['silent']); result['concat_done'] = True
    if spec.get('mix'):
        for P, s in zip(V.plan, t0s):
            P['t0'] = s
        V.srt = srt_abs
        R.mix_audio(cfg, base, V, spec['silent'], spec['mix'])
    if spec.get('srt'):
        with open(spec['srt'], 'w', encoding='utf-8') as f:
            for k, (a, b, s) in enumerate(srt_abs, 1):
                f.write(f'{k}\n{R.fmt(a)} --> {R.fmt(b)}\n{s}\n\n')
    if spec.get('cover'):
        V.cover(spec['cover'])
    if spec.get('meta'):
        json.dump({'duration': round(sum(t['n'] for t in plan_) / fps, 2) if plan_ else round(V.total, 2),
                   'has_ai': any((sc.get('media') or {}).get('ai') for sc in cfg['scenes']),
                   'credits': sorted({sc['media']['credit'] for sc in cfg['scenes'] if (sc.get('media') or {}).get('credit')}),
                   'reminder': 'Khi đăng, tự bật nhãn nội dung AI trên mạng xã hội.'}, open(spec['meta'], 'w', encoding='utf-8'), ensure_ascii=False)
    print('RESULT ' + json.dumps(result), flush=True)


def _capture_layout(R, V, i, k):
    """Vẽ khung k của cảnh i, ghi lại hộp bao của mọi chữ (theo nhóm: tiêu đề, phụ đề, thẻ, nhãn…)."""
    from PIL import ImageDraw
    rec = {'list': []}; cur = {'kind': None, 'group': 0}; labels = []
    orig_text = ImageDraw.ImageDraw.text
    gid = [0]

    def text(self, xy, txt, fill=None, font=None, anchor=None, *a, **kw):
        if cur['kind'] and txt and str(txt).strip():
            al = fill[3] if isinstance(fill, tuple) and len(fill) == 4 else 255
            if al >= 40:
                try:
                    bb = self.textbbox(xy, txt, font=font, anchor=anchor, stroke_width=kw.get('stroke_width', 0))
                    rec['list'].append({'kind': cur['kind'], 'group': cur['group'], 'text': str(txt), 'box': [round(v, 1) for v in bb],
                                        'probe': bool(cur.get('probe'))})
                except Exception:
                    pass
        return orig_text(self, xy, txt, fill, font, anchor, *a, **kw)

    def wrap(meth, kind):
        f = getattr(V, meth)

        def g(*a, **kw):
            prev = dict(cur); gid[0] += 1; cur.update(kind=kind, group=gid[0])
            try:
                return f(*a, **kw)
            finally:
                cur.update(prev)
        setattr(V, meth, g)
    for meth, kind in (('title_box', 'title'), ('card', 'card'), ('subtitle', 'subtitle'), ('hook', 'hook'), ('panel', 'panel'),
                       ('draw_label', 'label'), ('measure', 'measure'), ('spotlight', 'spotlight'), ('media_labels', 'media'),
                       ('chrome', 'chrome'), ('place_names', 'names'), ('big_labels', 'names'), ('path_extras', 'extras')):
        if hasattr(V, meth):
            wrap(meth, kind)
    pl_orig = V.plan_label

    def plan_label(d, it, x, y, alpha, focused, placed):
        s = pl_orig(d, it, x, y, alpha, focused, placed)
        if s:
            labels.append({'id': it['id'], 'name': it.get('name', ''), 'x': round(x, 1), 'y': round(y, 1), 'side': s['side'],
                           'box': [round(s['bx0'], 1), round(s['ly'] - s['h1'] / 2 - s['ch'], 1), round(s['bx0'] + s['bw'], 1), round(s['ly'] + s['h1'] / 2, 1)],
                           'label_offset': it.get('label_offset', [60, -40])})
        return s
    V.plan_label = plan_label
    ImageDraw.ImageDraw.text = text
    try:
        im = V.frame(k, i)
        # mọi câu phụ đề của cảnh (không chỉ câu đang hiện) – câu dài 3 dòng cũng phải nằm trong vùng an toàn
        P = V.plan[i]
        scratch = R.Image.new('RGB', (R.W, R.H)); sd = ImageDraw.Draw(scratch, 'RGBA')
        cur['probe'] = True
        for a0, b0, s in P['subs']:
            V.subtitle(sd, s, 1.0, 1.0)
        cur['probe'] = False
    finally:
        ImageDraw.ImageDraw.text = orig_text
        V.plan_label = pl_orig
        for meth in ('title_box', 'card', 'subtitle', 'hook', 'panel', 'draw_label', 'measure', 'spotlight', 'media_labels', 'chrome', 'place_names', 'big_labels', 'path_extras'):
            V.__dict__.pop(meth, None)
    # gộp: mỗi nhóm 1 hộp (phụ đề nhiều dòng = 1 khối)
    groups = {}
    for b in rec['list']:
        g = groups.setdefault(b['group'], {'kind': b['kind'], 'group': b['group'], 'text': '', 'box': list(b['box']), 'probe': b['probe']})
        g['text'] = (g['text'] + ' ' + b['text']).strip()[:120]
        g['box'] = [min(g['box'][0], b['box'][0]), min(g['box'][1], b['box'][1]), max(g['box'][2], b['box'][2]), max(g['box'][3], b['box'][3])]
    rec['list'] = list(groups.values())
    rec['_image'] = im
    return rec, labels


if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    if len(sys.argv) >= 3 and sys.argv[1] == '--worker':
        _worker(sys.argv[2])
