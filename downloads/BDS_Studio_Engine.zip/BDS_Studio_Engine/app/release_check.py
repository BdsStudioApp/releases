"""Kiểm bản phát hành có ký số (giống BDSVerify trong web/shared/bds_verify.js, cùng khoá công khai).

release.json      = {version, build_id, parts:{web,gas,engine}, files:[{path, sha256, size}], signed, key_id?}
release.json.sig  = base64 chữ ký ed25519 trên ĐÚNG các byte của release.json
Khoá công khai chính thức: PUBKEY dưới đây = tools/release_pubkey.txt (SPKI DER base64; test kiểm hai nơi giống nhau).
Đổi khoá: phát hành 1 bản (ký bằng KHOÁ CŨ) có PUBKEY mới ở đây + web/shared/bds_verify.js + tools/release_pubkey.txt – xem docs/PHAT_HANH.md.
"""
import base64
import binascii
import hashlib
import json
import re

import ed25519_verify

PUBKEY = 'MCowBQYDK2VwAyEA08ZyQbCvDOkxv4iLixzoX+GsCugVDUIEqkmpfOeFKto='
_SPKI_PREFIX = bytes.fromhex('302a300506032b6570032100')


class ReleaseError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code, self.message = code, message


def raw_key(pub_b64=None):
    k = base64.b64decode(str(pub_b64 or PUBKEY).strip(), validate=True)
    if len(k) == 32:
        return k
    if len(k) == 44 and k[:12] == _SPKI_PREFIX:
        return k[12:]
    raise ValueError('khoá công khai không phải ed25519')


def key_id(pub_b64=None):
    return hashlib.sha256(base64.b64decode(str(pub_b64 or PUBKEY).strip())).hexdigest()[:16]


def verify(manifest_bytes, sig_b64, pub_b64=None):
    """True khi sig_b64 là chữ ký hợp lệ của manifest_bytes (bytes hoặc str UTF-8)."""
    try:
        if isinstance(manifest_bytes, str):
            manifest_bytes = manifest_bytes.encode('utf-8')
        if isinstance(sig_b64, bytes):
            sig_b64 = sig_b64.decode('ascii')
        sig = base64.b64decode(str(sig_b64 or '').strip(), validate=True)
        return ed25519_verify.verify(raw_key(pub_b64), manifest_bytes, sig)
    except (ValueError, binascii.Error, UnicodeError):
        return False


def file_entry(manifest, path):
    for f in (manifest or {}).get('files') or []:
        if isinstance(f, dict) and f.get('path') == path:
            return f
    return None


def _required_channel():
    """Kênh bản phát hành máy dựng này nhận (common.RELEASE_CHANNEL – bản bán 'sale'); '' = không ràng buộc."""
    try:
        import common
        return str(getattr(common, 'RELEASE_CHANNEL', '') or '')
    except Exception:  # noqa: BLE001 – chạy rời (kiểm thử) không có common
        return ''


def check_release(manifest_bytes, sig, files=None, pub_b64=None, channel=None):
    """Kiểm chữ ký rồi sha256 + kích thước từng tệp trong files {đường_dẫn: bytes}. Đúng → manifest (dict); sai → ReleaseError.
    channel: kênh bắt buộc (None = common.RELEASE_CHANNEL) – release.json phải ghi đúng kênh này trong phần đã ký."""
    sig_txt = sig.decode('ascii', 'replace') if isinstance(sig, (bytes, bytearray)) else str(sig or '')
    sig_txt = sig_txt.strip()
    if not sig_txt or sig_txt.startswith('<'):          # rỗng, hoặc trang HTML thay cho tệp thiếu → coi như chưa ký
        raise ReleaseError('NO_SIG', 'Bản phát hành chưa có chữ ký số – máy dựng không tự cài.')
    if not verify(manifest_bytes, sig_txt, pub_b64):
        raise ReleaseError('BAD_SIG', 'Chữ ký số của bản phát hành không đúng – dừng, không cài.')
    try:
        manifest = json.loads(manifest_bytes.decode('utf-8') if isinstance(manifest_bytes, (bytes, bytearray)) else manifest_bytes)
    except ValueError:
        raise ReleaseError('BAD_MANIFEST', 'Danh sách tệp phát hành (release.json) bị hỏng.')
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), list) or not isinstance(manifest.get('parts'), dict):
        raise ReleaseError('BAD_MANIFEST', 'Danh sách tệp phát hành (release.json) thiếu thông tin.')
    want = _required_channel() if channel is None else str(channel or '')
    if want and manifest.get('channel') != want:
        raise ReleaseError('WRONG_CHANNEL', 'Bản phát hành không thuộc kênh của máy dựng này – dừng, không cài.')
    return check_release_files(manifest, files)


def check_release_files(manifest, files):
    """Kiểm sha256 + kích thước từng tệp {đường_dẫn: bytes} theo manifest ĐÃ KIỂM CHỮ KÝ. Đúng → manifest; sai → ReleaseError."""
    for path, data in (files or {}).items():
        ent = file_entry(manifest, path)
        if not ent:
            raise ReleaseError('NOT_IN_MANIFEST', f'Tệp {path} không có trong bản phát hành đã ký.')
        if isinstance(ent.get('size'), int) and ent['size'] != len(data):
            raise ReleaseError('SIZE_MISMATCH', f'Tệp {path} khác kích thước bản đã ký – dừng, không cài.')
        want = str(ent.get('sha256') or '').lower()
        if not re.fullmatch(r'[0-9a-f]{64}', want) or hashlib.sha256(data).hexdigest() != want:
            raise ReleaseError('SHA_MISMATCH', f'Tệp {path} không khớp mã sha256 của bản đã ký – dừng, không cài.')
    return manifest
