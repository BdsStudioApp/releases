"""Đường dẫn, cấu hình và thông tin máy dùng chung cho máy dựng BDS Studio.

Không ghi cứng đường dẫn: mọi thư mục người dùng tính bằng pathlib theo hệ điều hành,
đổi được bằng biến môi trường (để kiểm tra tự động):
  BDS_DATA_DIR    cấu hình, lịch sử job, ffmpeg tự tải, bí mật dự phòng   (mặc định ~/.bds_studio)
  BDS_HOME_DIR    thư mục người dùng nhìn thấy (mặc định ~/BDS Studio): Video/, Du an/, Chuyen may/
  BDS_CACHE_DIR   bộ nhớ đệm + file tạm (Mac ~/Library/Caches/BDS Studio, Win %LOCALAPPDATA%\\BDS Studio\\Cache)
"""
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = '1.0.5'
ENGINE_ROOT = Path(__file__).resolve().parent.parent          # .../engine
APP_DIR = ENGINE_ROOT / 'app'
SCRIPTS_DIR = ENGINE_ROOT / 'engine'
RENDER_MAP = SCRIPTS_DIR / 'render_map.py'
VBEE_TTS = SCRIPTS_DIR / 'vbee_tts.py'
GIFTOOL = ENGINE_ROOT / 'tools' / 'make_gif.py'
FONTS_DIR = ENGINE_ROOT / 'fonts'
DATA_FILES_DIR = ENGINE_ROOT / 'data'
TEMPLATE_PROJECT = ENGINE_ROOT / 'projects' / '_mau_moi'
OS_NAME = platform.system()            # 'Darwin' | 'Windows' | 'Linux'
IS_MAC = OS_NAME == 'Darwin'
IS_WIN = OS_NAME == 'Windows'
OLLAMA_URL = os.environ.get('BDS_OLLAMA_URL', 'http://127.0.0.1:11434')
PORT = int(os.environ.get('BDS_PORT', '8765'))
# S (16/11 de-hardcode "Bản cho người khác"): nguồn web app + kho phát hành của máy cài này.
# Mặc định = BẢN CỦA ANH (owner) để không đổi hành vi; bản Cá nhân/Công ty đặt qua biến môi trường BDS_APP_ORIGIN / BDS_RELEASE_ORIGIN.
APP_ORIGIN = os.environ.get('BDS_APP_ORIGIN', '').rstrip('/')
RELEASE_ORIGIN = os.environ.get('BDS_RELEASE_ORIGIN', 'https://raw.githubusercontent.com/BdsStudioApp/releases/main').rstrip('/')
# H1 (17/11): kênh phát hành máy dựng nhận (release.json › "channel", nằm TRONG phần đã ký). Trống = không ràng buộc (bản của anh).
# Bản bán: tools/sale_build.mjs đặt 'sale' → máy dựng của khách từ chối bản của anh / bản không ghi kênh (release_check.check_release).
RELEASE_CHANNEL = 'sale'
ALLOWED_ORIGINS = tuple(o for o in (APP_ORIGIN, 'http://127.0.0.1:%d' % PORT) if o)
# Biểu tượng "BDS Studio" (launcher.py) mở app ở đâu. Trống = http://127.0.0.1:<cổng> (bản của anh / chạy tại máy).
# Bản bán: tools/sale_build.mjs đặt = nguồn web app dùng chung (dữ liệu khách nằm ở đó – mở 127.0.0.1 là nguồn KHÁC,
# khách thấy app trống/Trợ lý cài đặt và tưởng mất dữ liệu). Chỉ dùng khi nằm trong ALLOWED_ORIGINS (máy dựng nhận yêu cầu).
LAUNCH_ORIGIN = os.environ.get('BDS_LAUNCH_ORIGIN', '').rstrip('/')
# 17/11 – APP RIÊNG TỪNG KHÁCH (docs/APP_RIENG_TUNG_KHACH.md): mỗi khách một địa chỉ app riêng (https://<slug>.bdsstudio.app hoặc
# tên miền riêng, vd https://app.tenkhach.com). Bản máy dựng ĐÃ KÝ giống hệt cho mọi khách nên không ghi cứng địa chỉ đó; thay vào đó
# máy dựng giữ DANH SÁCH NGUỒN APP TIN CẬY của chính máy này (<data_dir>/app_origins.json), so khớp CHÍNH XÁC từng nguồn:
#   - M1 (17/11): KHÔNG còn tự ghim địa chỉ đầu tiên gọi tới (TOFU – app của khách khác cùng hậu tố chiếm được chỗ). Chỉ địa chỉ ĐÃ GHÉP
#     NỐI mới được tin: app xin ghép (POST /pair/start) → người dùng thấy địa chỉ + mã 6 số trên trang CỦA MÁY DỰNG
#     (http://127.0.0.1:<cổng>/ghep) và bấm Cho phép 1 lần (pairing.py). Địa chỉ vừa ghép = nơi biểu tượng "BDS Studio" mở.
#   - người dùng thêm/bớt: Cài đặt › Máy của tôi (GET/POST /install/origins, chỉ nhận từ nguồn ĐÃ tin) hoặc
#     python app/launcher.py --nguon-app <địa chỉ>. Tên miền riêng của khách (B) thêm theo cách này.
# APP_ORIGIN_SUFFIX: bản bán = '.bdsstudio.app' (tools/sale_build.mjs đặt từ sale.config.json › APP_DOMAIN); bản của chủ = '' (tắt tự ghim).
APP_ORIGIN_SUFFIX = os.environ.get('BDS_APP_ORIGIN_SUFFIX', '.bdsstudio.app').strip().lower()
if APP_ORIGIN_SUFFIX and not APP_ORIGIN_SUFFIX.startswith('.'):
    APP_ORIGIN_SUFFIX = '.' + APP_ORIGIN_SUFFIX
RESERVED_APP_LABELS = frozenset((
    'app', 'www', 'trang', 'api', 'mail', 'hotro', 'cai', 'admin', 'status', 'demo', 'thu', 'test', 'dev', 'staging', 'docs', 'blog',
    'shop', 'ban', 'banhang', 'dangky', 'dang-ky', 'dangnhap', 'dang-nhap', 'login', 'auth', 'sso', 'cdn', 'assets', 'static', 'img',
    'media', 'files', 'smtp', 'imap', 'pop', 'mx', 'ftp', 'ns1', 'ns2', 'webmail', 'email', 'support', 'help', 'billing', 'pay',
    'thanhtoan', 'thanh-toan', 'release', 'releases', 'update', 'capnhat', 'cap-nhat', 'license', 'banquyen', 'ban-quyen', 'bdsstudio',
    'bds', 'root', 'owner', 'seller', 'portal', 'console', 'dashboard', 'quantri', 'quan-tri', 'cloudflare', 'pages', 'git', 'github',
    'internal', 'noreply', 'no-reply'))
# Nơi AI CŨNG đăng được trang (dùng chung) – không bao giờ là nguồn app tin cậy, kể cả người dùng tự thêm.
SHARED_HOSTS = frozenset(('script.google.com', 'script.googleusercontent.com', 'docs.google.com', 'sites.google.com', 'drive.google.com',
                          'github.com', 'gist.github.com', 'raw.githubusercontent.com', 'pages.dev', 'workers.dev', 'bdsstudio.app'))
SHARED_SUFFIXES = ('.googleusercontent.com', '.github.io', '.githubusercontent.com', '.netlify.app', '.vercel.app', '.glitch.me',
                   '.repl.co', '.web.app', '.firebaseapp.com', '.ngrok.io', '.ngrok-free.app', '.trycloudflare.com')
MAX_USER_ORIGINS = 10
APP_ORIGINS_FILE = 'app_origins.json'
_ORIGINS_LOCK = threading.RLock()
_ORIGINS_CACHE = {'key': None, 'list': ()}
_HOST_RE = re.compile(r'^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$')
_LABEL_RE = re.compile(r'^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$')

DEFAULT_CONFIG = {
    'map_cache_gb': 1.5,          # giới hạn bộ nhớ đệm (bản đồ, giọng đọc, file tạm) – xoá cũ nhất khi vượt
    'keep_previews': 20,          # số bản xem trước giữ lại
    'ollama_model': 'qwen2.5:3b',
    'ollama_timeout_s': 120,
    'render_workers': 0,          # 0 = tự chọn theo RAM (8 GB → 2 tiến trình)
    'x264_preset': 'veryfast',
    'vbee_voice': 'hn_male_manhdung_news_48k-fhg',
    'vbee_speed': 1.1,
}


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def data_dir() -> Path:
    p = Path(os.environ.get('BDS_DATA_DIR') or (Path.home() / '.bds_studio')).expanduser()
    if _inside(p, ENGINE_ROOT):        # bí mật/cấu hình không bao giờ nằm trong thư mục engine
        p = Path.home() / '.bds_studio'
    p.mkdir(parents=True, exist_ok=True)
    return p


def home_dir() -> Path:
    p = Path(os.environ.get('BDS_HOME_DIR') or (Path.home() / 'BDS Studio')).expanduser()
    p.mkdir(parents=True, exist_ok=True)
    return p


def video_dir() -> Path:
    p = home_dir() / 'Video'; p.mkdir(parents=True, exist_ok=True); return p


def projects_dir() -> Path:
    p = home_dir() / 'Du an'
    p.mkdir(parents=True, exist_ok=True)
    return p


def migrate_dir() -> Path:
    p = home_dir() / 'Chuyen may'; p.mkdir(parents=True, exist_ok=True); return p


def cache_dir() -> Path:
    env = os.environ.get('BDS_CACHE_DIR')
    if env:
        p = Path(env).expanduser()
    elif IS_MAC:
        p = Path.home() / 'Library' / 'Caches' / 'BDS Studio'
    elif IS_WIN:
        p = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local')) / 'BDS Studio' / 'Cache'
    else:
        p = Path(os.environ.get('XDG_CACHE_HOME') or (Path.home() / '.cache')) / 'bds_studio'
    p.mkdir(parents=True, exist_ok=True)
    return p


def sub_cache(name: str) -> Path:
    p = cache_dir() / name; p.mkdir(parents=True, exist_ok=True); return p


def bin_dir() -> Path:
    p = data_dir() / 'bin'; p.mkdir(parents=True, exist_ok=True); return p


def web_dir():
    """web/ cạnh engine (bản đóng gói: engine/web, bản phát triển: ../web)."""
    for c in (ENGINE_ROOT / 'web', ENGINE_ROOT.parent / 'web'):
        if (c / 'index.html').is_file():
            return c
    return None


# ---------------- cấu hình ----------------
_cfg_lock = threading.Lock()


def config_path() -> Path:
    return data_dir() / 'config.json'


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        cfg.update(json.loads(config_path().read_text(encoding='utf-8')))
    except (OSError, ValueError):
        pass
    return cfg


def save_config(patch: dict) -> dict:
    with _cfg_lock:
        cfg = load_config()
        for k, v in patch.items():
            if k in DEFAULT_CONFIG and type(v) in (int, float, str, bool):
                cfg[k] = v
        config_path().write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding='utf-8')
        return cfg


# ---------------- công cụ ngoài ----------------
EXTRA_BIN = ['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin']


def child_path() -> str:
    parts = [str(bin_dir())] + os.environ.get('PATH', '').split(os.pathsep)
    if not IS_WIN:
        parts += EXTRA_BIN
    seen, out = set(), []
    for p in parts:
        if p and p not in seen:
            seen.add(p); out.append(p)
    return os.pathsep.join(out)


def which(name: str):
    return shutil.which(name, path=child_path())


def console_utf8() -> None:
    """Ép sys.stdout/stderr sang UTF-8 (lỗi ký tự → '?') – cửa sổ lệnh Windows mặc định cp1252/cp437 làm print chữ Việt
    văng UnicodeEncodeError (gặp thật trên máy Windows của GitHub 17/11). pythonw: stdout là None → bỏ qua."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:  # noqa: BLE001
            pass


def windows_powershell_env(env=None) -> dict:
    """Môi trường cho tiến trình con powershell.exe (Windows PowerShell 5.1): bỏ PSModulePath kế thừa từ PowerShell 7
    (mở máy dựng từ Windows Terminal/pwsh) – nếu để, 5.1 nạp nhầm module của bản 7 → Get-CimInstance/Get-FileHash… "không tìm thấy"."""
    env = dict(os.environ if env is None else env)
    for k in [k for k in env if k.upper() == 'PSMODULEPATH']:
        env.pop(k)
    return env


def child_env(extra=None) -> dict:
    env = os.environ.copy()
    env['PATH'] = child_path()
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUTF8'] = '1'
    env['BDS_FONT_DIR'] = str(FONTS_DIR) + os.sep
    # không để lọt bí mật vào tiến trình con trừ khi được truyền rõ
    env.pop('VBEE_TOKEN', None); env.pop('VBEE_APP_ID', None)
    if extra:
        env.update(extra)
    return env


def tool_version(name: str):
    exe = which(name)
    if not exe:
        return None
    try:
        out = subprocess.run([exe, '-version'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=10).stdout
        m = re.search(r'version\s+(\S+)', out)
        return {'path': exe, 'version': m.group(1) if m else '?'}
    except (OSError, subprocess.SubprocessError):
        return None


# ---------------- thông tin máy ----------------
def ram_gb() -> float:
    try:
        if IS_MAC:
            b = int(subprocess.run(['sysctl', '-n', 'hw.memsize'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=5).stdout.strip())
            return round(b / 2**30, 1)
        if IS_WIN:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', ctypes.c_ulonglong), ('ullAvailPhys', ctypes.c_ulonglong),
                            ('ullTotalPageFile', ctypes.c_ulonglong), ('ullAvailPageFile', ctypes.c_ulonglong),
                            ('ullTotalVirtual', ctypes.c_ulonglong), ('ullAvailVirtual', ctypes.c_ulonglong),
                            ('sullAvailExtendedVirtual', ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys / 2**30, 1)
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    return round(int(line.split()[1]) / 2**20, 1)
    except Exception:
        pass
    return 0.0


def free_disk_gb(path: Path = None) -> float:
    try:
        return round(shutil.disk_usage(str(path or home_dir())).free / 2**30, 1)
    except OSError:
        return 0.0


def render_workers() -> int:
    n = int(load_config().get('render_workers') or 0)
    if n > 0:
        return n
    cpu = os.cpu_count() or 2
    ram = ram_gb() or 8
    return max(1, min(cpu, 2 if ram <= 8.5 else 4))


def dir_size(p: Path) -> int:
    total = 0
    for root, _, files in os.walk(p):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def prune_cache(limit_gb: float = None, root: Path = None) -> dict:
    """Giữ bộ nhớ đệm dưới giới hạn: xoá file cũ nhất (theo lần dùng/sửa cuối)."""
    root = root or cache_dir()
    limit = int(float(limit_gb if limit_gb is not None else load_config()['map_cache_gb']) * 2**30)
    files = []
    for r, _, fs in os.walk(root):
        for f in fs:
            fp = os.path.join(r, f)
            try:
                st = os.stat(fp)
                files.append((max(st.st_mtime, st.st_atime), st.st_size, fp))
            except OSError:
                pass
    total = sum(s for _, s, _ in files)
    removed = 0
    for _, size, fp in sorted(files):
        if total <= limit:
            break
        try:
            os.remove(fp); total -= size; removed += 1
        except OSError:
            pass
    # dọn thư mục rỗng
    for r, ds, fs in sorted(os.walk(root), key=lambda x: -len(x[0])):
        if r != str(root) and not ds and not fs:
            try:
                os.rmdir(r)
            except OSError:
                pass
    return {'removed': removed, 'size_gb': round(total / 2**30, 3), 'limit_gb': round(limit / 2**30, 3)}


def safe_name(s: str, default='video') -> str:
    import unicodedata
    s = unicodedata.normalize('NFD', str(s or '')).replace('đ', 'd').replace('Đ', 'D')
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    s = re.sub(r'[^A-Za-z0-9]+', '_', s).strip('_').lower()[:60]
    return s or default


def now_ms() -> int:
    return int(time.time() * 1000)


# ---------------- nguồn app tin cậy (app riêng từng khách) ----------------
def normalize_origin(value) -> str:
    """'tenkhach.bdsstudio.app' | 'https://App.TenKhach.com/' → 'https://app.tenkhach.com'. Chỉ https, không đường dẫn/truy vấn/tài khoản.
    Không hợp lệ → ''."""
    from urllib.parse import urlsplit
    s = str(value or '').strip()
    if not s or len(s) > 300:
        return ''
    if '://' not in s:
        s = 'https://' + s
    try:
        u = urlsplit(s)
        port = u.port
    except ValueError:
        return ''
    if u.scheme != 'https' or u.username or u.password or u.query or u.fragment or u.path not in ('', '/'):
        return ''
    host = (u.hostname or '').lower()
    if not _HOST_RE.match(host):
        return ''
    return 'https://' + host + (':%d' % port if port and port != 443 else '')


def shared_host(origin: str) -> bool:
    host = origin.split('://', 1)[-1].split(':', 1)[0]
    return host in SHARED_HOSTS or host.endswith(SHARED_SUFFIXES)


def suffix_eligible(origin) -> bool:
    """Nguồn được TỰ GHIM (khi chưa có nguồn nào): đúng https://<nhãn><APP_ORIGIN_SUFFIX>, 1 nhãn hợp lệ, không dành riêng."""
    if not APP_ORIGIN_SUFFIX or not isinstance(origin, str) or normalize_origin(origin) != origin:
        return False
    host = origin[len('https://'):]
    if ':' in host or not host.endswith(APP_ORIGIN_SUFFIX):
        return False
    label = host[:-len(APP_ORIGIN_SUFFIX)]
    return bool(_LABEL_RE.match(label)) and '--' not in label and label not in RESERVED_APP_LABELS


def app_origins_path() -> Path:
    return data_dir() / APP_ORIGINS_FILE


def origin_entries() -> list:
    """[{origin, how: pinned|user|cli, at}] – mục hỏng/không hợp lệ bị bỏ qua."""
    try:
        d = json.loads(app_origins_path().read_text(encoding='utf-8'))
        items = d.get('origins') if isinstance(d, dict) else None
    except (OSError, ValueError):
        items = None
    out, seen = [], set()
    for x in items or []:
        o = x.get('origin') if isinstance(x, dict) else None
        if isinstance(o, str) and normalize_origin(o) == o and not shared_host(o) and o not in seen:
            seen.add(o)
            out.append({'origin': o, 'how': str(x.get('how') or 'user')[:10], 'at': str(x.get('at') or '')[:25]})
    return out[:MAX_USER_ORIGINS]


def user_origins() -> tuple:
    """Nguồn app tin cậy của máy này (đã ghim/người dùng thêm), theo thứ tự – nguồn đầu = nơi biểu tượng mở app. Có bộ nhớ đệm theo mtime."""
    p = app_origins_path()
    try:
        st = p.stat()
        key = (str(p), st.st_mtime_ns, st.st_size)
    except OSError:
        return ()
    if _ORIGINS_CACHE['key'] != key:
        _ORIGINS_CACHE['list'] = tuple(e['origin'] for e in origin_entries())
        _ORIGINS_CACHE['key'] = key
    return _ORIGINS_CACHE['list']


def _save_origins(entries: list) -> None:
    p = app_origins_path(); tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps({'origins': entries}, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, p)
    _ORIGINS_CACHE['key'] = None


def add_user_origin(value, how: str = 'user', primary: bool = False) -> str:
    """Thêm 1 nguồn app (người dùng / dòng lệnh / tự ghim). → nguồn đã chuẩn hoá. Sai → ValueError (câu tiếng Việt)."""
    o = normalize_origin(value)
    if not o:
        raise ValueError('Địa chỉ app không hợp lệ – nhập dạng https://tenkhach.bdsstudio.app hoặc https://app.tenmiencuaban.com')
    if shared_host(o):
        raise ValueError('Không nhận ' + o + ': đây là trang dùng chung mà ai cũng đăng được nội dung – không an toàn cho máy dựng.')
    with _ORIGINS_LOCK:
        cur = [e for e in origin_entries() if e['origin'] != o]
        if len(cur) >= MAX_USER_ORIGINS:
            raise ValueError('Đã có %d địa chỉ app – bỏ bớt trước khi thêm.' % MAX_USER_ORIGINS)
        e = {'origin': o, 'how': how, 'at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        old = [x for x in origin_entries() if x['origin'] == o]
        if old and not primary:
            return o
        _save_origins([e] + cur if primary else cur + [e])
    return o


def remove_user_origin(value) -> bool:
    o = normalize_origin(value) or str(value or '')
    with _ORIGINS_LOCK:
        cur = origin_entries()
        keep = [e for e in cur if e['origin'] != o]
        if len(keep) == len(cur):
            return False
        _save_origins(keep)
    return True


def is_allowed_origin(origin) -> bool:
    """Máy dựng nhận yêu cầu (CORS, POST) từ nguồn này? Khớp CHÍNH XÁC: nguồn cố định (ALLOWED_ORIGINS) hoặc nguồn tin cậy đã lưu."""
    return bool(origin) and isinstance(origin, str) and (origin in ALLOWED_ORIGINS or origin in user_origins())


def accept_origin(origin) -> bool:
    """Máy dựng nhận yêu cầu từ nguồn này? M1 (17/11): CHỈ nguồn cố định hoặc nguồn ĐÃ GHÉP NỐI / người dùng thêm (is_allowed_origin).
    Không còn tự ghim nguồn đầu tiên (kể cả đúng dạng https://<nhãn><hậu tố>) – ghép nối bằng mã 6 số: pairing.py."""
    return is_allowed_origin(origin)


def app_origins_info() -> dict:
    ents = origin_entries()
    return {'ok': True, 'origins': ents, 'primary': ents[0]['origin'] if ents else '', 'fixed': list(ALLOWED_ORIGINS),
            'suffix': APP_ORIGIN_SUFFIX, 'auto_pin': False, 'pairing': True, 'pair_url': 'http://127.0.0.1:%d/ghep' % PORT,
            'max': MAX_USER_ORIGINS}
