"""video_flow: ghép clip tải từ Flow/Veo thành video dọc 1080×1920 30fps có giọng + phụ đề cháy chữ.

compose(job_dir, spec, log, progress, tts=None) -> {'mp4': path, 'srt': path, 'meta': path, ...}

spec = {
  "clips": ["/đường/dẫn/canh1.mp4", {"path": ".../3d.png", "illustrative": true, "dur": 4}, ...],
  "script": {"lines": [{"text": "Phòng khách **32 m²**", "say": "...", "start": 0.5, "end": 4.0} | {"text", "clip": 0}]},
  "voice": true, "music": "/đường/dẫn/nhac.mp3", "music_volume": 0.15, "clip_audio": 0.0,
  "illustrative": false,      # true → chữ "Ảnh minh hoạ" trên toàn bộ video (ảnh 3D/phối cảnh)
  "brand": "Tên của bạn | Thương hiệu của bạn", "title": "…"
}
Không bao giờ chèn chữ nhãn "AI" lên hình (người dùng tự bật nhãn nội dung AI của mạng xã hội khi đăng).
"""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

import common

W, H, FPS = 1080, 1920, 30
# vùng an toàn TikTok/Reels (giống render_map.py): chữ trong 1080 × (288..1250), chừa cột biểu tượng bên phải 150 px
SAFE_TOP, SAFE_BOTTOM, SAFE_RIGHT = 288, 1250, 150
SUB_CX = 0.465 * W
SUB_MAXW = 0.80 * W
SUB_SIZE = 54
ACCENT = (255, 138, 61)
ILLUSTRATIVE_LABEL = 'Ảnh minh hoạ'
VIDEO_EXT = ('.mp4', '.mov', '.m4v', '.webm', '.mkv')
IMAGE_EXT = ('.jpg', '.jpeg', '.png', '.webp')
WORDS_PER_SEC = 3.3


def font_path(weight='ExtraBold') -> str:
    for name in (f'BeVietnamPro-{weight}.ttf', f'BeVietnamPro-{weight}.otf', f'Inter-{weight}.otf', 'Inter-Bold.otf'):
        p = common.FONTS_DIR / name
        if p.is_file():
            return str(p)
    raise FileNotFoundError('Thiếu phông chữ trong engine/fonts')


def _font(weight, size):
    return ImageFont.truetype(font_path(weight), size)


def ffprobe_json(path):
    exe = common.which('ffprobe') or 'ffprobe'
    out = subprocess.run([exe, '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height',
                          '-of', 'json', str(path)], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    if out.returncode != 0:
        raise RuntimeError(f'Không đọc được tệp {Path(path).name}: {out.stderr.strip()[:200]}')
    return json.loads(out.stdout or '{}')


def probe(path):
    d = ffprobe_json(path)
    dur = float((d.get('format') or {}).get('duration') or 0)
    kinds = {s.get('codec_type') for s in d.get('streams', [])}
    return dur, 'audio' in kinds, 'video' in kinds


def ff(args, log, what):
    exe = common.which('ffmpeg') or 'ffmpeg'
    cmd = [exe, '-hide_banner', '-loglevel', 'error', '-y'] + [str(a) for a in args]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', env=common.child_env())
    if p.returncode != 0:
        log(f'✗ ffmpeg ({what}): {p.stderr.strip()[-600:]}\n')
        raise RuntimeError(f'ffmpeg lỗi khi {what}')


def plain(s):
    return (s or '').replace('**', '')


# ---------------- vẽ chữ (Pillow → PNG trong suốt, rồi overlay) ----------------
PUNCT = '?!.,:;…)»"'


def _tokens(text):
    """'Rộng **32 m²**, trần cao' -> [(từ, nhấn)]; dấu câu dính vào từ trước (như render_map.tokens)."""
    out = []
    for i, part in enumerate((text or '').split('**')):
        ws = part.split()
        if ws and out and i > 0 and not part[:1].isspace() and ws[0][:1] in PUNCT:
            m = re.match('[' + re.escape(PUNCT) + ']+', ws[0]).group(0)
            out[-1] = (out[-1][0] + m, out[-1][1]); ws[0] = ws[0][len(m):]
            if not ws[0]:
                ws = ws[1:]
        for w in ws:
            out.append((w, i % 2 == 1))
    return out


def _wrap(d, toks, f, maxw):
    lines, cur = [], []
    for t in toks:
        if cur and d.textlength(' '.join(w for w, _ in cur + [t]), font=f) > maxw:
            lines.append(cur); cur = [t]
        else:
            cur.append(t)
    if cur:
        lines.append(cur)
    return lines


def render_sub_png(text, path, size=SUB_SIZE):
    """Phụ đề: tối đa 3 dòng, căn giữa trong vùng an toàn, dòng cuối kết thúc ở ~1250 px."""
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    f = _font('ExtraBold', size)
    lines = _wrap(d, _tokens(text), f, SUB_MAXW)
    while len(lines) > 3 and size > 34:
        size -= 4; f = _font('ExtraBold', size); lines = _wrap(d, _tokens(text), f, SUB_MAXW)
    lh = size + 18; sp = d.textlength(' ', font=f)
    y_last = SAFE_BOTTOM - lh / 2
    y0 = y_last - (len(lines) - 1) * lh
    widths = [d.textlength(' '.join(w for w, _ in ln), font=f) for ln in lines]
    if lines:
        bw = max(widths) + 48
        d.rounded_rectangle([SUB_CX - bw / 2, y0 - lh / 2 - 10, SUB_CX + bw / 2, y_last + lh / 2 + 10], 22, fill=(0, 0, 0, 120))
    for ln, tw, k in zip(lines, widths, range(len(lines))):
        x = SUB_CX - tw / 2; y = y0 + k * lh
        for w, emph in ln:
            d.text((x, y), w, font=f, fill=(ACCENT if emph else (255, 255, 255)) + (255,), anchor='lm',
                   stroke_width=5, stroke_fill=(0, 0, 0, 255))
            x += d.textlength(w, font=f) + sp
    im.save(path)
    return path


def render_label_png(path, brand=None, label=None, skip_brand_row=False):
    """Tên kênh (tuỳ chọn) + chữ "Ảnh minh hoạ" góc trên trái, dưới thanh "Dành cho bạn"."""
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    y = SAFE_TOP + 14
    if brand:
        f = _font('ExtraBold', 30)
        d.rounded_rectangle([40, y - 26, 40 + d.textlength(brand, font=f) + 36, y + 26], 12, fill=(0, 0, 0, 160))
        d.text((58, y), brand, font=f, fill=ACCENT + (255,), anchor='lm')
    if brand or skip_brand_row:
        y += 64
    if label:
        f = _font('Bold', 28)
        d.rounded_rectangle([40, y - 22, 40 + d.textlength(label, font=f) + 30, y + 22], 10, fill=(0, 0, 0, 170))
        d.text((55, y), label, font=f, fill=(255, 225, 120, 240), anchor='lm')
    im.save(path)
    return path


# ---------------- giọng Vbee (qua vbee_tts.py, bí mật truyền bằng biến môi trường) ----------------
def vbee_tts_lines(texts, log, env_secrets, voice=None, speed=None):
    """Mỗi câu 1 cảnh trong cfg tạm → voice/scene_XX.wav. Cache giọng nằm trong bộ nhớ đệm (giới hạn dung lượng)."""
    cfgd = common.load_config()
    base = common.sub_cache('voice_flow')
    cfg = {'vbee': {'voice': voice or cfgd['vbee_voice'], 'speed': speed or cfgd['vbee_speed']},
           'scenes': [{'subs': [t]} for t in texts]}
    (base / 'tts.json').write_text(json.dumps(cfg, ensure_ascii=False), encoding='utf-8')
    vdir = base / 'voice'
    for old in vdir.glob('scene_*.wav') if vdir.is_dir() else []:
        old.unlink()
    p = subprocess.run([sys.executable, str(common.VBEE_TTS), 'tts.json', 'tts_out.json', '--lead', '0', '--tail', '0'],
                       cwd=str(base), capture_output=True, text=True, encoding='utf-8', errors='replace', env=common.child_env(env_secrets), timeout=900)
    log(p.stdout[-1500:])
    if p.returncode != 0:
        raise RuntimeError('Vbee lỗi: ' + (p.stderr or p.stdout).strip()[-300:])
    return [str(vdir / f'scene_{i:02d}.wav') for i in range(len(texts))]


# ---------------- thời gian phụ đề ----------------
def resolve_times(lines, offsets, durs, total, voice_durs=None):
    """Trả về [(start, end)] cho từng câu.
    - có start/end → theo đó (giây trên video cuối);
    - có "clip": i → tính trong clip i (start/end tương đối, mặc định cả clip);
    - không có gì → xếp nối tiếp, độ dài theo giọng đọc hoặc số chữ."""
    out = []
    t = 0.4
    for i, ln in enumerate(lines):
        vd = voice_durs[i] if voice_durs and voice_durs[i] else None
        est = vd or max(1.2, len(plain(ln.get('say') or ln.get('text')).split()) / WORDS_PER_SEC)
        if isinstance(ln.get('clip'), int) and 0 <= ln['clip'] < len(offsets):
            c = ln['clip']; base = offsets[c]
            s = base + float(ln.get('start', 0.3))
            e = base + float(ln['end']) if ln.get('end') is not None else base + durs[c] - 0.15
        elif ln.get('start') is not None:
            s = float(ln['start'])
            e = float(ln['end']) if ln.get('end') is not None else s + est
        else:
            s = t; e = s + est
        if vd:
            e = max(e, s + vd + 0.15)
        s = max(0.0, min(s, total - 0.2)); e = max(s + 0.3, min(e, total))
        out.append((round(s, 3), round(e, 3)))
        t = e + 0.25
    return out


def srt_time(t):
    ms = int(round(t * 1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'


# ---------------- chính ----------------
def normalize_clips(clips, work: Path, log, progress, preset):
    segs, durs, illus = [], [], []
    for i, c in enumerate(clips):
        c = c if isinstance(c, dict) else {'path': c}
        src = Path(c['path'])
        ext = src.suffix.lower()
        out = work / f'seg_{i:02d}.mp4'
        vf = f'scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps={FPS},format=yuv420p'
        if ext in IMAGE_EXT:
            dur = float(c.get('dur', 4.0))
            n = int(dur * FPS)
            vfi = (f'scale={int(W*1.1)}:{int(H*1.1)}:force_original_aspect_ratio=increase,crop={int(W*1.1)}:{int(H*1.1)},'
                   f"zoompan=z='min(1+0.0009*on,1.08)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={n}:s={W}x{H}:fps={FPS},"
                   f'setsar=1,format=yuv420p')
            ff(['-loop', '1', '-t', f'{dur:.3f}', '-i', src, '-f', 'lavfi', '-t', f'{dur:.3f}', '-i',
                'anullsrc=channel_layout=stereo:sample_rate=48000', '-vf', vfi, '-map', '0:v', '-map', '1:a',
                '-c:v', 'libx264', '-preset', preset, '-crf', '20', '-r', FPS, '-c:a', 'aac', '-b:a', '160k', '-ar', '48000',
                '-ac', '2', '-shortest', out], log, f'chuẩn hoá ảnh {src.name}')
            illus.append(True if c.get('illustrative', True) else False)
        else:
            dur0, has_a, _ = probe(src)
            trim = []
            if c.get('trim_start'):
                trim += ['-ss', f"{float(c['trim_start']):.3f}"]
            if c.get('dur'):
                trim += ['-t', f"{float(c['dur']):.3f}"]
            args = trim + ['-i', src]
            if has_a:
                amap = ['-map', '0:v:0', '-map', '0:a:0']
            else:
                args += ['-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=48000']
                amap = ['-map', '0:v:0', '-map', '1:a', '-shortest']
            ff(args + ['-vf', vf, '-af', 'aresample=48000,aformat=channel_layouts=stereo'] + amap +
               ['-c:v', 'libx264', '-preset', preset, '-crf', '20', '-r', FPS, '-g', str(FPS * 2),
                '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2', out], log, f'chuẩn hoá {src.name}')
            illus.append(bool(c.get('illustrative', False)))
        d, _, _ = probe(out)
        segs.append(out); durs.append(d)
        log(f'✓ cảnh {i + 1}: {src.name} → 1080×1920 30fps, {d:.2f}s\n')
        progress(0.05 + 0.45 * (i + 1) / len(clips))
    return segs, durs, illus


def compose(job_dir, spec, log, progress, tts=None, env_secrets=None):
    work = Path(job_dir); work.mkdir(parents=True, exist_ok=True)
    clips = spec.get('clips') or []
    if not clips:
        raise ValueError('Chưa có clip nào')
    preset = common.load_config().get('x264_preset', 'veryfast')
    segs, durs, illus = normalize_clips(clips, work, log, progress, preset)

    # 1. ghép theo thứ tự (cùng thông số → copy, không nén lại)
    lst = work / 'list.txt'
    lst.write_text(''.join("file '" + str(s).replace("'", "'\\''") + "'\n" for s in segs), encoding='utf-8')
    joined = work / 'joined.mp4'
    ff(['-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', joined], log, 'ghép clip')
    total, _, _ = probe(joined)
    offsets = []; acc = 0.0
    for d in durs:
        offsets.append(acc); acc += d
    log(f'✓ ghép {len(segs)} clip: {total:.2f}s\n'); progress(0.55)

    # 2. giọng đọc
    lines = [ln if isinstance(ln, dict) else {'text': str(ln)} for ln in (spec.get('script') or {}).get('lines', [])]
    lines = [ln for ln in lines if plain(ln.get('text'))]
    voice_files, voice_durs = [], None
    if spec.get('voice') and lines:
        if tts is None and env_secrets and env_secrets.get('VBEE_APP_ID'):
            tts = lambda texts: vbee_tts_lines(texts, log, env_secrets, spec.get('vbee_voice'), spec.get('vbee_speed'))
        if tts is None:
            log('⚠ Chưa cài khoá Vbee (Video → Khoá Vbee): dựng không giọng, vẫn có phụ đề.\n')
        else:
            try:
                voice_files = tts([plain(ln.get('say') or ln.get('text')) for ln in lines])
                voice_durs = [probe(v)[0] if v and os.path.exists(v) else 0 for v in voice_files]
                log(f'✓ giọng đọc {len(voice_files)} câu\n')
            except Exception as e:      # giọng lỗi không làm hỏng cả video
                voice_files, voice_durs = [], None
                log(f'⚠ Không tạo được giọng Vbee ({e}) – dựng không giọng, vẫn có phụ đề.\n')
    progress(0.65)
    times = resolve_times(lines, offsets, durs, total, voice_durs)

    # 3. chữ: phụ đề + tên kênh/"Ảnh minh hoạ"
    inputs = ['-i', joined]; fc = []; vlabel = '[0:v]'; idx = 1
    global_illus = bool(spec.get('illustrative'))
    brand = spec.get('brand')
    if brand or global_illus:
        render_label_png(work / 'label_all.png', brand, ILLUSTRATIVE_LABEL if global_illus else None)
        inputs += ['-i', work / 'label_all.png']
        fc.append(f'{vlabel}[{idx}:v]overlay=0:0[v{idx}]'); vlabel = f'[v{idx}]'; idx += 1
    if not global_illus and any(illus):
        render_label_png(work / 'label_illus.png', None, ILLUSTRATIVE_LABEL, skip_brand_row=bool(brand))
        inputs += ['-i', work / 'label_illus.png']
        en = '+'.join(f'between(t,{offsets[k]:.3f},{offsets[k] + durs[k]:.3f})' for k, f_ in enumerate(illus) if f_)
        fc.append(f"{vlabel}[{idx}:v]overlay=0:0:enable='{en}'[v{idx}]"); vlabel = f'[v{idx}]'; idx += 1
    for k, (ln, (s, e)) in enumerate(zip(lines, times)):
        png = render_sub_png(ln.get('text'), work / f'sub_{k:02d}.png')
        inputs += ['-i', png]
        fc.append(f"{vlabel}[{idx}:v]overlay=0:0:enable='between(t,{s:.3f},{e:.3f})'[v{idx}]"); vlabel = f'[v{idx}]'; idx += 1
    fc.append(f'{vlabel}format=yuv420p[vout]')

    # 4. tiếng: tiếng gốc của clip (mặc định tắt), giọng, nhạc nền
    amix = []
    ca = float(spec.get('clip_audio', 0.0))
    fc.append(f'[0:a]volume={ca:.3f}[a0]'); amix.append('[a0]')
    for k, vf_ in enumerate(voice_files):
        if not vf_ or not os.path.exists(vf_):
            continue
        inputs += ['-i', vf_]
        ms = int(times[k][0] * 1000)
        fc.append(f'[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,adelay={ms}|{ms},volume=1.0[va{k}]')
        amix.append(f'[va{k}]'); idx += 1
    music = spec.get('music')
    if music and os.path.isfile(music):
        mv = float(spec.get('music_volume', 0.15 if voice_files else 0.5))
        inputs = inputs + ['-stream_loop', '-1', '-i', music]
        fo = max(0.0, total - 1.5)
        fc.append(f'[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,volume={mv:.3f},'
                  f'afade=t=in:d=0.6,afade=t=out:st={fo:.2f}:d=1.5[mu]')
        amix.append('[mu]'); idx += 1
    elif music:
        log('⚠ Không thấy tệp nhạc nền, bỏ qua.\n')
    fc.append(f"{''.join(amix)}amix=inputs={len(amix)}:normalize=0:duration=first,alimiter=limit=0.95[aout]")

    stem = common.safe_name(spec.get('title') or 'video_flow', 'video_flow')
    out = work / f'{stem}.mp4'
    fcs = work / 'filter.txt'; fcs.write_text(';\n'.join(fc), encoding='utf-8')
    progress(0.7)
    ff(inputs + ['-filter_complex_script', fcs, '-map', '[vout]', '-map', '[aout]', '-t', f'{total:.3f}',
                 '-c:v', 'libx264', '-preset', preset, '-crf', '20', '-r', FPS, '-pix_fmt', 'yuv420p',
                 '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', out], log, 'dựng bản cuối')
    progress(0.95)
    srt = work / f'{stem}.srt'
    srt.write_text(''.join(f'{i}\n{srt_time(s)} --> {srt_time(e)}\n{plain(ln.get("text"))}\n\n'
                           for i, (ln, (s, e)) in enumerate(zip(lines, times), 1)), encoding='utf-8')
    meta = {'duration': round(total, 2), 'width': W, 'height': H, 'fps': FPS, 'clips': len(segs),
            'subtitles': [{'text': plain(ln.get('text')), 'start': s, 'end': e} for ln, (s, e) in zip(lines, times)],
            'voice': bool(voice_files), 'illustrative': global_illus or any(illus),
            'reminder': 'Khi đăng, tự bật nhãn nội dung AI trên mạng xã hội.'}
    mp = work / f'{stem}_meta.json'; mp.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding='utf-8')
    log(f'✓ Xong: {out.name} ({total:.1f}s)\n')
    return {'mp4': str(out), 'srt': str(srt), 'meta': str(mp), 'joined': str(joined)}
