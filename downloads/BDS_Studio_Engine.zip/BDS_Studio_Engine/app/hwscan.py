"""Quét cấu hình máy + xếp hạng Cơ bản / Khá / Mạnh (quyết định 16/11 "MÁY DỰNG QUÉT CẤU HÌNH", thợ I).

  scan(bench=False)  -> dict thông tin máy (CPU, RAM, GPU, VRAM/bộ nhớ chung, ổ trống, hệ điều hành) + tier + gợi ý
  classify(info)     -> {tier, label, reasons[]}   – HÀM THUẦN (test được), ngưỡng ghi ở THRESHOLDS
  recommend(info, tier) -> [{id, title, show, reason}]  – gói/tuỳ chọn nên hiện; máy yếu không hiện lựa chọn nặng
  benchmark(seconds=10) -> đo thật: ffmpeg mã hoá 10 giây video 1080p30 (x264, preset trong cấu hình) → tốc độ so với thời gian thực

Ngưỡng (đổi ở THRESHOLDS, ghi lại trong docs/CONTRACT.md + engine/HUONG_DAN_CAI.md):
  Mạnh : Apple chip Pro/Max/Ultra + bộ nhớ chung ≥ 32 GB, HOẶC card NVIDIA ≥ 12 GB VRAM + RAM ≥ 16 GB
  Khá  : RAM ≥ 16 GB, HOẶC card NVIDIA ≥ 8 GB VRAM
  Cơ bản: còn lại (vd Mac 8 GB). Thêm: CPU < 4 nhân → Cơ bản; Mac Intel tối đa Khá;
         đo thử chậm hơn 0,5× thời gian thực → hạ về Cơ bản (đo thật, không đoán).
RAM/VRAM do máy báo hơi thấp hơn số ghi trên hộp (16 GB → 15,8) nên ngưỡng so có dung sai 0,5 GB.

Chạy tay:  python3 app/hwscan.py [--bench] [--save]   (bộ cài gọi với --save để app đọc lại qua GET /hw/scan)
"""
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common  # noqa: E402

SCHEMA = 1
TIERS = ('co_ban', 'kha', 'manh')
TIER_LABEL = {'co_ban': 'Cơ bản', 'kha': 'Khá', 'manh': 'Mạnh'}
SLACK = 0.5                         # dung sai GB (máy báo 15,8 GB cho thanh RAM 16 GB)
THRESHOLDS = {
    'kha_ram_gb': 16, 'kha_vram_gb': 8,
    'manh_apple_ram_gb': 32, 'manh_vram_gb': 12, 'manh_vram_ram_gb': 16,
    'min_cores': 4, 'bench_min_speed_x': 0.5,
    'video_ai_disk_gb': 40, 'image_ai_disk_gb': 15, 'ollama_disk_gb': 5,
}
BENCH_SECONDS = 10
_LOCK = threading.Lock()


# ---------------- đọc thông tin máy ----------------
def _run(cmd, timeout=10, env=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout, env=env)
        return p.stdout.strip() if p.returncode == 0 else ''
    except (OSError, subprocess.SubprocessError):
        return ''


def _sysctl(key):
    return _run(['sysctl', '-n', key], timeout=5)


def cpu_info() -> dict:
    model, phys, logical, perf = '', 0, os.cpu_count() or 0, 0
    arch = platform.machine().lower()
    if common.IS_MAC:
        model = _sysctl('machdep.cpu.brand_string')
        phys = int(_sysctl('hw.physicalcpu') or 0)
        logical = int(_sysctl('hw.logicalcpu') or logical)
        perf = int(_sysctl('hw.perflevel0.physicalcpu') or 0)
        if _sysctl('sysctl.proc_translated') == '1' or _sysctl('hw.optional.arm64') == '1':
            arch = 'arm64'                       # Python Intel chạy qua Rosetta trên chip Apple → vẫn là máy arm64
    elif common.IS_WIN:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as k:
                model = str(winreg.QueryValueEx(k, 'ProcessorNameString')[0]).strip()
        except OSError:
            model = platform.processor()
        arch = {'amd64': 'x86_64', 'x86_64': 'x86_64', 'arm64': 'arm64'}.get(os.environ.get('PROCESSOR_ARCHITECTURE', arch).lower(), arch)
    else:
        try:
            txt = Path('/proc/cpuinfo').read_text(encoding='utf-8', errors='replace')
            m = re.search(r'^model name\s*:\s*(.+)$', txt, re.M)
            model = m.group(1).strip() if m else ''
            cores = set()
            for block in txt.split('\n\n'):
                pid = re.search(r'^physical id\s*:\s*(\d+)', block, re.M); cid = re.search(r'^core id\s*:\s*(\d+)', block, re.M)
                if pid and cid:
                    cores.add((pid.group(1), cid.group(1)))
            phys = len(cores)
        except OSError:
            pass
    arch = {'amd64': 'x86_64', 'aarch64': 'arm64'}.get(arch, arch)
    return {'model': model or platform.processor() or '?', 'cores': phys or logical, 'threads': logical,
            'perf_cores': perf or None, 'arch': arch, 'vendor': cpu_vendor(model, arch)}


def cpu_vendor(model: str, arch: str = '') -> str:
    m = (model or '').lower()
    if m.startswith('apple') or (common.IS_MAC and arch == 'arm64'):
        return 'apple'
    if 'intel' in m:
        return 'intel'
    if 'amd' in m or 'ryzen' in m:
        return 'amd'
    if 'snapdragon' in m or 'qualcomm' in m:
        return 'qualcomm'
    return 'other'


def apple_chip(model: str) -> dict:
    """'Apple M3 Pro' → {family:'M3', variant:'pro'}; không phải chip Apple → {}"""
    m = re.match(r'apple\s+(m\d+)(?:\s+(pro|max|ultra))?', (model or '').strip().lower())
    if not m:
        return {}
    return {'family': m.group(1).upper(), 'variant': m.group(2) or 'base'}


def parse_nvidia_smi(text: str) -> list:
    """Dòng 'NVIDIA GeForce RTX 4070, 12282, 555.85' (csv,noheader,nounits) → [{name, vram_gb, driver}]"""
    out = []
    for line in (text or '').splitlines():
        parts = [p.strip() for p in line.split(',')]
        if len(parts) < 2 or not parts[0]:
            continue
        try:
            mib = float(parts[1])
        except ValueError:
            continue
        out.append({'name': parts[0], 'vendor': 'nvidia', 'vram_gb': round(mib / 1024, 1),
                    'driver': parts[2] if len(parts) > 2 else '', 'unified': False})
    return out


def gpu_info(cpu: dict, ram: float) -> list:
    gpus = []
    smi = common.which('nvidia-smi') or (r'C:\Windows\System32\nvidia-smi.exe' if common.IS_WIN and os.path.isfile(r'C:\Windows\System32\nvidia-smi.exe') else None)
    if smi:
        gpus += parse_nvidia_smi(_run([smi, '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader,nounits'], timeout=15))
    if common.IS_MAC:
        if cpu.get('vendor') == 'apple':
            cores = None
            try:
                d = json.loads(_run(['system_profiler', 'SPDisplaysDataType', '-json'], timeout=15) or '{}')
                for g in d.get('SPDisplaysDataType', []):
                    if str(g.get('sppci_cores', '')).isdigit():
                        cores = int(g['sppci_cores'])
            except ValueError:
                pass
            gpus.append({'name': (cpu.get('model') or 'Apple') + ' (GPU tích hợp)', 'vendor': 'apple', 'vram_gb': ram,
                         'unified': True, 'gpu_cores': cores})
        else:
            try:
                d = json.loads(_run(['system_profiler', 'SPDisplaysDataType', '-json'], timeout=15) or '{}')
                for g in d.get('SPDisplaysDataType', []):
                    vram = g.get('spdisplays_vram') or g.get('spdisplays_vram_shared') or ''
                    m = re.search(r'(\d+)\s*(GB|MB)', str(vram))
                    gb = (float(m.group(1)) / (1024 if m.group(2) == 'MB' else 1)) if m else None
                    gpus.append({'name': g.get('sppci_model') or '?', 'vendor': 'other', 'vram_gb': gb, 'unified': False})
            except ValueError:
                pass
    elif common.IS_WIN:
        # in ra UTF-8 (tên card có ký tự lạ) + bỏ PSModulePath của PowerShell 7 (xem common.windows_powershell_env)
        txt = _run(['powershell', '-NoProfile', '-Command',
                    '[Console]::OutputEncoding = [Text.Encoding]::UTF8; '
                    'try { CimCmdlets\\Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object { $_.Name } } '
                    'catch { Get-WmiObject Win32_VideoController | ForEach-Object { $_.Name } }'],
                   timeout=20, env=common.windows_powershell_env())
        for name in [n.strip() for n in txt.splitlines() if n.strip()]:
            if any(name.lower() == g['name'].lower() for g in gpus) or ('nvidia' in name.lower() and gpus):
                continue
            # AdapterRAM của Windows tối đa 4 GB (sai với card lớn) → không dùng để xếp hạng
            gpus.append({'name': name, 'vendor': 'amd' if re.search(r'amd|radeon', name, re.I) else
                         'intel' if 'intel' in name.lower() else 'other', 'vram_gb': None, 'unified': False})
    return gpus


def os_info() -> dict:
    if common.IS_MAC:
        ver = platform.mac_ver()[0]
        return {'family': 'mac', 'name': 'macOS', 'version': ver, 'label': f'macOS {ver}'}
    if common.IS_WIN:
        ver = platform.version()                       # '10.0.22631'
        build = int(ver.split('.')[-1]) if ver.split('.')[-1].isdigit() else 0
        name = 'Windows 11' if build >= 22000 else 'Windows ' + platform.release()
        return {'family': 'windows', 'name': name, 'version': ver, 'build': build, 'label': f'{name} (bản {build})'}
    return {'family': 'linux', 'name': platform.system(), 'version': platform.release(), 'label': f'{platform.system()} {platform.release()}'}


# ---------------- đo thử ----------------
def benchmark(seconds: int = BENCH_SECONDS, timeout: float = 90) -> dict:
    """Mã hoá `seconds` giây video 1080p30 bằng ffmpeg (đồ hoạ thử + chữ chạy) – đo thời gian thật trên máy này."""
    ff = common.which('ffmpeg')
    if not ff:
        return {'ok': False, 'reason': 'Chưa có ffmpeg – chạy lại bộ cài hoặc Tự kiểm tra → Tự sửa.'}
    preset = str(common.load_config().get('x264_preset') or 'veryfast')
    cmd = [ff, '-hide_banner', '-nostdin', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=1920x1080:rate=30',
           '-t', str(seconds), '-c:v', 'libx264', '-preset', preset, '-pix_fmt', 'yuv420p', '-f', 'null', '-']
    t0 = time.monotonic()
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout, env=common.child_env())
    except subprocess.TimeoutExpired:
        return {'ok': False, 'reason': f'Quá {int(timeout)} giây chưa dựng xong 10 giây video – máy rất chậm.',
                'seconds_video': seconds, 'wall_s': timeout, 'speed_x': round(seconds / timeout, 2)}
    except OSError as e:
        return {'ok': False, 'reason': f'Không chạy được ffmpeg: {e}'}
    wall = max(0.01, time.monotonic() - t0)
    if p.returncode != 0:
        return {'ok': False, 'reason': 'ffmpeg báo lỗi: ' + (p.stderr or '')[-200:]}
    speed = round(seconds / wall, 2)
    return {'ok': True, 'seconds_video': seconds, 'wall_s': round(wall, 2), 'speed_x': speed, 'preset': preset,
            'what': f'mã hoá {seconds} giây video 1080p30 (x264 {preset})',
            # Chỉ là phần MÃ HOÁ của 60 giây video 1080p, suy thẳng từ số đo; video bản đồ còn thêm thời gian vẽ khung hình
            # (chưa có số đo thật cho phần đó → không cộng thêm hệ số đoán).
            'encode_60s_1080p_min': round(60 / speed / 60, 1)}


# ---------------- xếp hạng (thuần) ----------------
def vn(x) -> str:
    """15.7 → '15,7' (số thập phân kiểu Việt)."""
    return f'{float(x):g}'.replace('.', ',')


def _ge(v, limit):
    return v is not None and float(v) + SLACK >= limit


def classify(info: dict) -> dict:
    """info: {cpu:{model,cores,vendor,arch}, ram_gb, gpus:[{vendor,vram_gb,unified}], bench?:{ok,speed_x}} → {tier, label, reasons}"""
    T = THRESHOLDS
    cpu = info.get('cpu') or {}
    ram = float(info.get('ram_gb') or 0)
    gpus = info.get('gpus') or []
    nv = max([float(g.get('vram_gb') or 0) for g in gpus if g.get('vendor') == 'nvidia'] or [0])
    chip = apple_chip(cpu.get('model', ''))
    reasons = []
    tier = 'co_ban'
    if chip and chip['variant'] in ('pro', 'max', 'ultra') and _ge(ram, T['manh_apple_ram_gb']):
        tier = 'manh'; reasons.append(f"Chip Apple {chip['family']} {chip['variant'].capitalize()} + bộ nhớ chung {vn(ram)} GB (đạt mức {T['manh_apple_ram_gb']} GB)")
    elif _ge(nv, T['manh_vram_gb']) and _ge(ram, T['manh_vram_ram_gb']):
        tier = 'manh'; reasons.append(f"Card NVIDIA {vn(nv)} GB VRAM (đạt mức {T['manh_vram_gb']} GB) + RAM {vn(ram)} GB")
    elif _ge(ram, T['kha_ram_gb']):
        tier = 'kha'; reasons.append(f"RAM {vn(ram)} GB (đạt mức {T['kha_ram_gb']} GB)")
    elif _ge(nv, T['kha_vram_gb']):
        tier = 'kha'; reasons.append(f"Card NVIDIA {vn(nv)} GB VRAM (đạt mức {T['kha_vram_gb']} GB)")
    else:
        reasons.append(f"RAM {vn(ram)} GB" + (f", card NVIDIA {vn(nv)} GB" if nv else ', không có card NVIDIA rời') +
                       f" – dưới mức Khá ({T['kha_ram_gb']} GB RAM hoặc card {T['kha_vram_gb']} GB)")
    if tier == 'manh' and common_is_intel_mac(info):
        tier = 'kha'; reasons.append('Mac chip Intel: không chạy Video AI trên máy → tối đa Khá')
    cores = int(cpu.get('cores') or 0)
    if cores and cores < T['min_cores'] and tier != 'co_ban':
        tier = 'co_ban'; reasons.append(f'CPU chỉ {cores} nhân (< {T["min_cores"]}) → Cơ bản')
    b = info.get('bench') or {}
    if b.get('speed_x') is not None and float(b['speed_x']) < T['bench_min_speed_x'] and tier != 'co_ban':
        tier = 'co_ban'; reasons.append(f"Đo thử chậm ({vn(b['speed_x'])}× thời gian thực, < {vn(T['bench_min_speed_x'])}×) → Cơ bản")
    return {'tier': tier, 'label': TIER_LABEL[tier], 'reasons': reasons}


def common_is_intel_mac(info: dict) -> bool:
    cpu = info.get('cpu') or {}
    return (info.get('os') or {}).get('family') == 'mac' and cpu.get('vendor') == 'intel'


def recommend(info: dict, tier: str) -> list:
    """Gói/tuỳ chọn nên hiện cho máy này. show=False → giao diện KHÔNG hiện lựa chọn đó (máy yếu không thấy lựa chọn nặng)."""
    T = THRESHOLDS
    rank = TIERS.index(tier)
    disk = float(info.get('free_disk_gb') or 0)
    ram = float(info.get('ram_gb') or 0)

    def item(id_, title, need, reason_ok, disk_need=0):
        show = rank >= TIERS.index(need)
        reason = reason_ok if show else f'Cần máy hạng {TIER_LABEL[need]} trở lên.'
        if show and disk_need and disk < disk_need:
            show = False; reason = f'Cần trống ≥ {disk_need} GB ổ đĩa (đang trống {vn(disk)} GB) – dọn bớt rồi Quét lại máy.'
        return {'id': id_, 'title': title, 'min_tier': need, 'show': show, 'reason': reason}

    out = [
        # Bộ công cụ dựng video (ffmpeg) là TUỲ CHỌN trên mọi máy – chỉ cài khi người dùng chọn (videomode.py, yêu cầu chủ 17/11)
        item('map_1080p', 'Video bản đồ 1080p + AI online (Gemini)', 'co_ban',
             'Chạy tốt trên máy này – cần Bộ công cụ dựng video (cài khi chọn).' if rank else
             'Cần Bộ công cụ dựng video (tuỳ chọn). Máy yếu: video dựng trên máy sẽ không đẹp và giật – chỉ nên dùng để làm video mẫu; '
             'nên dùng Video AI online.'),
        item('ai_offline_small', 'AI soạn trên máy – mô hình nhỏ (3–4 tỷ tham số, ~2–3 GB)', 'co_ban',
             'Chỉ việc nhẹ; không chạy cùng lúc dựng video (app tự xếp hàng).' if ram < 15 else 'Dùng cho nháp tin, tóm tắt khách.',
             T['ollama_disk_gb']),
        item('ai_offline_medium', 'AI soạn trên máy – mô hình vừa (7–8 tỷ tham số)', 'kha', 'Đủ RAM cho mô hình vừa.', T['ollama_disk_gb'] * 2),
        item('image_ai_offline', 'Tạo ảnh AI trên máy', 'kha', 'Đủ bộ nhớ cho mô hình tạo ảnh.', T['image_ai_disk_gb']),
        item('ai_offline_large', 'AI soạn trên máy – mô hình lớn (14 tỷ tham số trở lên)', 'manh', 'Máy mạnh, chạy được mô hình lớn.', T['ollama_disk_gb'] * 3),
        item('video_ai_offline', 'Gói Video AI OFFLINE (tạo cảnh video bằng AI ngay trên máy)', 'manh',
             'Máy hạng Mạnh – mở được Video AI chạy trên máy.', T['video_ai_disk_gb']),
        item('overnight_parallel', 'Dựng song song qua đêm (nhiều video cùng lúc)', 'manh', 'Đủ nhân CPU và bộ nhớ để dựng song song.'),
    ]
    return out


# ---------------- quét + lưu ----------------
def scan_path() -> Path:
    return common.data_dir() / 'hwscan.json'


def scan(bench: bool = False, busy: bool = False) -> dict:
    cpu = cpu_info()
    ram = common.ram_gb()
    info = {'schema': SCHEMA, 'at': common.now_ms(), 'engine_version': common.VERSION, 'os': os_info(), 'cpu': cpu,
            'ram_gb': ram, 'gpus': gpu_info(cpu, ram), 'free_disk_gb': common.free_disk_gb(),
            'python': platform.python_version(), 'render_workers': common.render_workers()}
    if bench:
        info['bench'] = ({'ok': False, 'skipped': True, 'reason': 'Máy đang dựng video – đo thử sau khi dựng xong.'}
                         if busy else benchmark())
    return finish(info)


def finish(info: dict) -> dict:
    c = classify(info)
    info.update(tier=c['tier'], tier_label=c['label'], reasons=c['reasons'], recommendations=recommend(info, c['tier']),
                thresholds=dict(THRESHOLDS))
    return info


def save(info: dict) -> dict:
    p = scan_path(); tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, p)
    return info


def load():
    try:
        d = json.loads(scan_path().read_text(encoding='utf-8-sig'))
        return d if isinstance(d, dict) and d.get('schema') == SCHEMA else None
    except (OSError, ValueError):
        return None


def scan_locked(bench=False, busy=False):
    """Một lần quét tại một thời điểm (đo thử chiếm CPU ~10 giây). Đang quét → None."""
    if not _LOCK.acquire(blocking=False):
        return None
    try:
        info = scan(bench=bench, busy=busy)
        old = load()
        if not bench and old and old.get('bench') and old['bench'].get('ok'):
            info['bench'] = dict(old['bench'], from_previous=True, at=old.get('at'))   # giữ kết quả đo lần trước
            info = finish(info)
        return save(info)
    finally:
        _LOCK.release()


def summary_line(info: dict) -> str:
    gpu = ', '.join(g['name'] for g in info.get('gpus') or []) or 'không rõ'
    s = (f"Máy hạng {info['tier_label']} · {info['cpu']['model']} ({info['cpu']['cores']} nhân) · RAM {vn(info['ram_gb'])} GB · "
         f"GPU: {gpu} · ổ trống {vn(info['free_disk_gb'])} GB · {info['os']['label']}")
    b = info.get('bench') or {}
    if b.get('ok'):
        s += f" · đo thử: {b['seconds_video']} giây video dựng trong {vn(b['wall_s'])} giây"
    return s


if __name__ == '__main__':
    common.console_utf8()
    res = scan(bench='--bench' in sys.argv)
    if '--save' in sys.argv:
        save(res)
    print(json.dumps(res, ensure_ascii=False) if '--json' in sys.argv else summary_line(res))
