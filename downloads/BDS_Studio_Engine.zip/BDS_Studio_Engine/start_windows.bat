@echo off
rem Mo may dung BDS Studio - trinh duyet tu mo http://127.0.0.1:8765. Dong cua so nay = tat may dung.
chcp 65001 >nul
rem tieu de cua so (thanh tac vu hien chu nay) - mo tu Start Menu > "Bat may dung BDS Studio" thi cua so mang bieu tuong cua loi tat
title May dung BDS Studio - dong cua so nay la tat may dung
setlocal
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
rem mo tu PowerShell 7 / Windows Terminal: bo PSModulePath cua ban 7 (may dung goi powershell.exe 5.1 de quet GPU)
set "PSModulePath="
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" app\server.py %*
) else (
  py -3 app\server.py %* || python app\server.py %*
)
pause
