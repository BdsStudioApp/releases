#!/usr/bin/env python3
"""Phụ thuộc của Máy dựng video theo cách làm video đã chọn – đọc deps_video.json (nguồn sự thật duy nhất).

Chỉ dùng thư viện chuẩn (chạy được bằng Python gốc của bộ cài, trước khi có .venv). Dùng chung cho bộ cài Windows, Mac và app.

  python tools/deps_video.py validate                                  kiểm cấu trúc deps_video.json
  python tools/deps_video.py check    --mode online|offline|pack [--json]          trạng thái từng mục
  python tools/deps_video.py plan     --mode M [--os windows|mac|linux] [--out TỆP] [--apply] [--dry]
        in bảng "cần cài gì · dung lượng · thời gian" TRƯỚC khi tải; TỆP nhận dòng KHOÁ=giá trị cho bộ cài
        (STATUS, MSG, MODE, NEED_FFMPEG, FFMPEG_BAD, NEED_PIP, NEED_RUNTIME, DL_BYTES, DL_TEXT, FFMPEG_EST, PIP_EST, RUNTIME_EST,
        MODEL_EST, PACK). --apply: mục ffmpeg bắt buộc → ghi video_mode.json video_pack=install (videomode.set_pack).
  python tools/deps_video.py selftest --mode M [--out TỆP] [--out-json TỆP.json] [--report install_report.json] [--rerun "câu"]
        chạy bằng Python của .venv: kiểm từng mục bắt buộc + DỰNG THỬ 3 giây có phụ đề tiếng Việt bằng đúng render_map.py
        (libx264 + aac + numpy + phông Inter) → ĐẠT/LỖI từng mục, cách sửa bằng tiếng Việt, câu chạy lại.
        Giọng đọc: chỉ thử khi có TTS miễn phí/trên máy – mã hiện tại chỉ có Vbee (trả phí) nên BỎ QUA.
Mã thoát: 0 = xong (kể cả khi có mục LỖI – đọc STATUS/ket_qua); 2 = tham số sai / tệp kê khai hỏng.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent                 # thư mục engine (hoặc _he_thong sau khi đổi bố cục)
sys.path.insert(0, str(ROOT / 'app'))
import common  # noqa: E402  (chỉ thư viện chuẩn)

MODES = ('online', 'offline', 'pack')
LEVELS = ('required', 'optional')
KINDS = ('python', 'venv', 'pip', 'pip_runtime', 'binary', 'bundled', 'cache', 'service', 'model', 'disk')
OSES = ('windows', 'mac', 'linux')
CHECK_TYPES = ('python_version', 'venv', 'pip_import', 'ffmpeg', 'fonts', 'glob', 'files', 'none', 'model', 'disk')
SELFTEST_TEXT = 'Dựng thử 3 giây – phụ đề **tiếng Việt**: Căn hộ view sông, sổ hồng riêng'   # = bộ cài Mac
RERUN = {'windows': 'Bấm đúp lại tệp cài đặt ("Cai dat voi 1 click" hoặc install_windows.bat): phần đã xong được giữ, bộ cài làm tiếp '
                    'và tự kiểm lại.',
         'mac': 'Bấm đúp lại tệp cài đặt ("Cai dat voi 1 click.command" hoặc install_mac.command): phần đã xong được giữ, bộ cài làm tiếp '
                'và tự kiểm lại.',
         'linux': 'Chạy lại: python3 tools/deps_video.py selftest --mode pack'}


def manifest_path() -> Path:
    for p in (ROOT / 'deps_video.json', ROOT / '_he_thong' / 'deps_video.json'):
        if p.is_file():
            return p
    return ROOT / 'deps_video.json'


def load(path=None) -> dict:
    return json.loads(Path(path or manifest_path()).read_text(encoding='utf-8'))


def os_family() -> str:
    return 'windows' if common.IS_WIN else 'mac' if common.IS_MAC else 'linux'


# ───────────────────────── kiểm cấu trúc tệp kê khai ─────────────────────────
def validate(m: dict) -> list:
    """→ danh sách lỗi (rỗng = hợp lệ)."""
    err = []
    if m.get('schema') != 1:
        err.append('schema phải = 1')
    if set(m.get('modes') or {}) != set(MODES):
        err.append(f'modes phải đúng {MODES}')
    for k, md in (m.get('modes') or {}).items():
        for f in ('choice', 'videomode', 'label', 'disk_free_min_gb', 'network_install', 'network_runtime'):
            if f not in md:
                err.append(f'modes.{k} thiếu {f}')
    vp = m.get('video_paths')
    if not isinstance(vp, list) or not vp:
        err.append('video_paths phải là danh sách tệp')
    else:
        for f in vp:
            if not (ROOT / f).is_file():
                err.append(f'video_paths: không thấy {f}')
    ids = set()
    for it in m.get('items') or []:
        i = it.get('id', '?')
        if i in ids:
            err.append(f'mục trùng id {i}')
        ids.add(i)
        for f in ('title', 'kind', 'modes', 'why', 'check', 'check_cmd', 'size', 'time_s', 'install'):
            if f not in it:
                err.append(f'{i}: thiếu {f}')
        if it.get('kind') not in KINDS:
            err.append(f'{i}: kind lạ {it.get("kind")}')
        for md, lv in (it.get('modes') or {}).items():
            if md not in MODES or lv not in LEVELS:
                err.append(f'{i}: modes.{md}={lv} không hợp lệ')
        if (it.get('check') or {}).get('type') not in CHECK_TYPES:
            err.append(f'{i}: check.type lạ')
        for o in OSES:
            if o not in (it.get('check_cmd') or {}):
                err.append(f'{i}: check_cmd thiếu {o}')
            ways = (it.get('install') or {}).get(o)
            if not isinstance(ways, list) or not ways:
                err.append(f'{i}: install.{o} phải là danh sách cách cài')
                continue
            for w in ways:
                if 'method' not in w or 'admin' not in w:
                    err.append(f'{i}: install.{o} mỗi cách cần method + admin')
                if o in ('windows', 'mac') and w.get('admin') is True:
                    err.append(f'{i}: install.{o} không được cần quyền quản trị')
        sz = it.get('size') or {}
        for f in ('download_bytes', 'disk_bytes', 'measured'):
            if f not in sz:
                err.append(f'{i}: size thiếu {f}')
        ts = it.get('time_s')
        if not (isinstance(ts, list) and len(ts) == 2 and 0 <= ts[0] <= ts[1]):
            err.append(f'{i}: time_s phải là [min, max]')
        if it.get('kind') in ('pip', 'pip_runtime') and not it.get('imports'):
            err.append(f'{i}: mục pip cần imports')
        if it.get('kind') == 'model' and not it.get('confirm'):
            err.append(f'{i}: mô hình phải có confirm=true (chỉ tải sau khi khách xác nhận GB)')
    for need in ('python', 'ffmpeg', 'fonts', 'pip_pillow', 'pip_numpy', 'offline_runtime', 'offline_model'):
        if need not in ids:
            err.append(f'thiếu mục bắt buộc {need}')
    return err


def items_for(m: dict, mode: str, level=None) -> list:
    out = []
    for it in m['items']:
        lv = (it.get('modes') or {}).get(mode)
        if lv and (level is None or lv == level):
            out.append(dict(it, level=lv))
    return out


# ───────────────────────── kiểm từng mục ─────────────────────────
def venv_python():
    p = ROOT / '.venv' / ('Scripts/python.exe' if common.IS_WIN else 'bin/python')
    return p if p.is_file() else None


def _run(cmd, timeout=60, **kw):
    try:
        return subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding='utf-8', errors='replace',
                              timeout=timeout, **kw)
    except (OSError, subprocess.SubprocessError) as e:
        return subprocess.CompletedProcess(cmd, 127, '', str(e))


def _py_for_imports(in_venv: bool):
    """selftest chạy TRONG .venv → sys.executable; plan chạy bằng Python gốc → Python của .venv (chưa có = thiếu)."""
    return sys.executable if in_venv else venv_python()


def check_python(c, py=None) -> dict:
    exe = py or sys.executable
    r = _run([exe, '-c', 'import sys; print("%d.%d.%d" % sys.version_info[:3])'])
    v = (r.stdout or '').strip()
    need = tuple(int(x) for x in c['min'].split('.'))
    ok = r.returncode == 0 and bool(v) and tuple(int(x) for x in v.split('.')[:2]) >= need
    return {'ok': ok, 'detail': f'Python {v or "?"} ({exe})' + ('' if ok else f' – cần ≥ {c["min"]}')}


def check_pip(c, py) -> dict:
    if not py:
        return {'ok': False, 'detail': 'chưa có .venv'}
    mods = [c['module']] + list(c.get('also') or [])
    r = _run([py, '-c', 'import ' + ', '.join(mods)], timeout=180)
    return {'ok': r.returncode == 0, 'detail': 'đã cài' if r.returncode == 0 else ('chưa cài / không nạp được: ' + (r.stderr or '').strip()[-200:])}


def ffmpeg_caps(exe: str) -> dict:
    def names(flag):
        out = _run([exe, '-hide_banner', flag], timeout=30).stdout or ''
        got = set()
        for ln in out.splitlines():
            parts = ln.split()
            if len(parts) >= 2 and re.match(r'^[A-Z.|]{2,}$', parts[0].replace('|', '.')):
                got.add(parts[1])
        return got
    return {'encoders': names('-encoders'), 'decoders': names('-decoders'), 'filters': names('-filters')}


def check_ffmpeg(c) -> dict:
    found = {b: common.which(b) for b in c['binaries']}
    miss = [b for b, p in found.items() if not p]
    if miss:
        return {'ok': False, 'present': False, 'detail': 'không thấy ' + ', '.join(miss)}
    ff = found['ffmpeg']
    r = _run([ff, '-hide_banner', '-version'], timeout=20)
    if r.returncode != 0:
        return {'ok': False, 'present': True, 'detail': f'{ff} không chạy được: {(r.stderr or "")[-160:]}'}
    ver = (re.search(r'version\s+(\S+)', r.stdout or '') or [None, '?'])[1]
    caps = ffmpeg_caps(ff)
    lack = [x for k in ('encoders', 'decoders', 'filters') for x in c.get(k, []) if x not in caps[k]]
    return {'ok': not lack, 'present': True, 'path': ff, 'version': ver,
            'detail': f'ffmpeg {ver} ({ff})' + (' – THIẾU: ' + ', '.join(lack) if lack else ''), 'lack': lack}


GLYPH_CODE = r'''
import sys, json
from PIL import Image, ImageDraw, ImageFont
def shot(font, ch):
    im = Image.new('L', (96, 96), 0); ImageDraw.Draw(im).text((8, 8), ch, font=font, fill=255); return im.tobytes()
res = {}
for f in json.loads(sys.argv[1]):
    font = ImageFont.truetype(f, 48)
    nd = shot(font, '\U0010FFFD')          # ký tự riêng không phông nào có → hình .notdef
    res[f] = ''.join(ch for ch in sys.argv[2] if shot(font, ch) == nd)
print(json.dumps(res, ensure_ascii=False))
'''


def check_fonts(c, py) -> dict:
    d = ROOT / c['dir']
    miss = [f for f in c['files'] if not (d / f).is_file()]
    if miss:
        return {'ok': False, 'detail': 'thiếu ' + ', '.join(miss)}
    if not py:
        return {'ok': True, 'detail': f'đủ {len(c["files"])} tệp (chưa kiểm dấu – chưa có Pillow)'}
    r = _run([py, '-c', GLYPH_CODE, json.dumps([str(d / f) for f in c['files']]), c['glyphs']], timeout=60)
    if r.returncode != 0:
        return {'ok': True, 'detail': f'đủ {len(c["files"])} tệp (chưa kiểm dấu: {(r.stderr or "").strip()[-120:]})'}
    bad = {Path(k).name: v for k, v in json.loads(r.stdout).items() if v}
    return {'ok': not bad, 'detail': (f'đủ {len(c["files"])} tệp, đủ dấu tiếng Việt' if not bad
                                      else 'thiếu dấu: ' + '; '.join(f'{k}: {v}' for k, v in bad.items()))}


def check_item(it, mode, py_imports, py_version=None) -> dict:
    c = it['check']; t = c['type']
    if t == 'python_version':
        return check_python(c, py_version)
    if t == 'venv':
        p = venv_python()
        return {'ok': bool(p), 'detail': str(p) if p else 'chưa có .venv'}
    if t == 'pip_import':
        return check_pip(c, py_imports)
    if t == 'ffmpeg':
        return check_ffmpeg(c)
    if t == 'fonts':
        return check_fonts(c, py_imports)
    if t == 'glob':
        hit = list(ROOT.glob(c['pattern']))
        return {'ok': bool(hit), 'detail': f'{len(hit)} tệp' if hit else 'không có'}
    if t == 'files':
        miss = [f for f in c['files'] if not (ROOT / f).is_file()]
        return {'ok': not miss, 'detail': 'đủ' if not miss else 'thiếu ' + ', '.join(miss)}
    if t == 'disk':
        need = c['min_gb'][mode]; free = common.free_disk_gb()
        return {'ok': free >= need, 'detail': f'trống {free} GB, cần ≥ {need} GB'}
    if t == 'model':
        mdir = common.data_dir() / 'videoai' / 'models'
        have = [ch['id'] for ch in it.get('choices', []) if (mdir / ch['id'] / '.complete').is_file()]
        return {'ok': bool(have), 'detail': ('đã có ' + ', '.join(have)) if have else 'chưa tải (tải sau trong app, cần xác nhận GB)'}
    return {'ok': None, 'detail': 'không kiểm tự động'}


# ───────────────────────── dung lượng + thời gian ─────────────────────────
def mb(n) -> str:
    return (f'{n / 2**30:.1f} GB' if n >= 2**30 else f'{max(1, round(n / 2**20))} MB').replace('.', ',')


def est(it, m, osf) -> dict:
    sz = it['size']; dl = int(sz.get('download_bytes') or 0)
    if it['id'] == 'offline_runtime' and osf == 'mac':
        dl = int(sz['per_os']['mac'])
    bps = m.get('speed_assumption', {}).get('bytes_per_s', 2_500_000)
    t0, t1 = it['time_s']
    lo, hi = t0 + dl / bps, t1 + int(sz.get('download_bytes_max') or dl) / bps
    return {'bytes': dl, 'text': (f'tải ~{mb(dl)}' if dl else 'không tải') + (f', ~{fmt_t(lo)}–{fmt_t(hi)}' if hi >= 1 else '')}


def fmt_t(s) -> str:
    s = int(round(s))
    if s < 90:
        return f'{max(1, s)} giây'
    if s < 5400:
        return f'{round(s / 60)} phút'
    return f'{s / 3600:.1f} giờ'.replace('.', ',')


# ───────────────────────── lệnh ─────────────────────────
def write_kv(path, **kv):
    if not path:
        return
    lines = [f"{k.upper()}={str(v if v is not None else '').replace(chr(10), ' ').replace(chr(13), ' ')}" for k, v in kv.items()]
    Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def say(s=''):
    print('   ' + s if s else '', flush=True)


def cmd_plan(m, a) -> int:
    mode, osf = a['mode'], a['os'] or os_family()
    vpy = venv_python()
    rows, kv = [], {'mode': mode, 'need_ffmpeg': 0, 'ffmpeg_required': 0, 'ffmpeg_bad': '', 'need_pip': 0, 'need_runtime': 0,
                    'ffmpeg_est': '', 'pip_est': '', 'runtime_est': '', 'model_est': '', 'pack': ''}
    total = 0
    req = items_for(m, mode)
    if not req:                                   # "Chỉ AI trên mạng": không cài gì lên máy
        say(f'Cách làm video đã chọn: {m["modes"][mode]["label"]} – không cần cài gì.')
        write_kv(a.get('out'), status='dry' if a.get('dry') else 'ok', msg='Không cài gì lên máy', mode=mode, need_ffmpeg=0,
                 ffmpeg_required=0, ffmpeg_bad='', need_pip=0, need_runtime=0, dl_bytes=0, dl_text='0 MB', ffmpeg_est='', pip_est='',
                 runtime_est='', model_est='', pack='skip', blockers='')
        return 0
    say(f'Cần cho cách làm video đã chọn ({m["modes"][mode]["choice"]} {m["modes"][mode]["label"]}):')
    for n, it in enumerate(req, 1):
        r = check_item(it, mode, vpy, a.get('python'))
        e = est(it, m, osf)
        need_dl = r['ok'] is False and it['level'] == 'required' and it['kind'] not in ('bundled', 'disk', 'service', 'cache')
        if it['id'] == 'ffmpeg':
            kv['ffmpeg_est'] = e['text']; kv['ffmpeg_required'] = int(it['level'] == 'required')
            if r['ok'] is False and it['level'] == 'required':
                kv['need_ffmpeg'] = 1
                if r.get('present'):
                    kv['ffmpeg_bad'] = r['detail']
        if it['kind'] == 'pip' and need_dl:
            kv['need_pip'] = 1; kv['pip_est'] = 'tải ~25 MB (Pillow + numpy + thư viện phụ), ~1–3 phút'
        if it['id'] == 'offline_runtime':
            kv['runtime_est'] = e['text']; kv['need_runtime'] = int(r['ok'] is False)
        if it['id'] == 'offline_model':
            ch = it.get('choices') or []
            kv['model_est'] = ' / '.join(f"{c['id']} {mb(c['bytes'])}" for c in ch)
        if need_dl and it['kind'] != 'pip':
            total += e['bytes']
        nodl = it['kind'] in ('bundled', 'disk', 'service', 'cache', 'venv')
        if r['ok']:
            mark = '✓ có sẵn'
        elif it['level'] == 'optional':
            mark = '○ tuỳ chọn' + (' – cài cùng thư viện' if it['kind'] == 'pip' and it.get('requirements_txt') else
                                   ' – không cài lúc này' if not nodl else '')
        elif r['ok'] is None:
            mark = '·'
        elif it['kind'] == 'disk':
            mark = '✗ chưa đủ'
        elif it['kind'] == 'venv':
            mark = '→ sẽ tạo'
        elif it['kind'] == 'pip':
            mark = '→ sẽ cài cùng thư viện'
        elif nodl:
            mark = '✗ thiếu (không tải được – xem cách sửa)'
        else:
            mark = '→ sẽ cài · ' + e['text']
        if it['id'] == 'offline_model' and not r['ok']:
            mark = '○ ' + kv['model_est'] + ' – CHỈ tải khi anh/chị xác nhận đúng số GB'
        show_detail = r['ok'] is False and (it['level'] == 'required' or it['kind'] == 'model')
        rows.append((n, it, r))
        say(f'  {n}/{len(req)} {it["title"]}: {mark}' + (f' ({r["detail"]})' if show_detail and it['id'] != 'offline_model' else ''))
    if kv['need_pip']:
        total += 25_000_000
        say(f"  Thư viện Python (Pillow, numpy, keyring, pyzipper): {kv['pip_est']}")
    kv['dl_bytes'] = total
    kv['dl_text'] = mb(total) if total else '0 MB'
    if mode == 'pack':
        say('  Không có mô hình AI nào tải về ở cách này (cảnh/clip Video AI tạo trên mạng, tính phí theo nhà cung cấp).')
    say(f'  Tổng sẽ tải (phần bắt buộc còn thiếu): ~{kv["dl_text"]}' + (' (gồm thư viện AI cài ở bước B9)' if kv['need_runtime'] else ''))
    ff_req = any(it['id'] == 'ffmpeg' and it['level'] == 'required' for it in req)
    if ff_req and a.get('apply') and not a.get('dry'):
        try:
            import videomode
            st = videomode.load() or {}
            if st.get('video_pack') != 'install':
                videomode.set_pack(True, source='installer')
            kv['pack'] = 'install'
        except Exception as e:  # noqa: BLE001 – không ghi được lựa chọn vẫn cài
            say(f'  ⚠ chưa ghi được lựa chọn Bộ công cụ dựng video: {e}')
    elif ff_req:
        kv['pack'] = 'install'
    missing_req = [it['title'] for _, it, r in rows if it['level'] == 'required' and r['ok'] is False
                   and it['kind'] not in ('disk', 'bundled')]
    blockers = [f"{it['title']}: {r['detail']}" for _, it, r in rows if it['level'] == 'required' and r['ok'] is False
                and it['kind'] in ('disk', 'bundled')]
    msg = ('Đủ mọi thứ cần cho cách làm video đã chọn' if not missing_req
           else f'Sẽ cài {len(missing_req)} mục (~{kv["dl_text"]}): ' + '; '.join(missing_req))
    if blockers:
        msg += ' · ⚠ ' + '; '.join(blockers)
        say('  ⚠ ' + '; '.join(blockers))
    kv['blockers'] = '; '.join(blockers)
    write_kv(a.get('out'), status='dry' if a.get('dry') else 'ok', msg=msg, **kv)
    return 0


def cmd_check(m, a) -> int:
    mode = a['mode']; vpy = venv_python() or (sys.executable if sys.prefix != sys.base_prefix else None)
    res = []
    for it in items_for(m, mode):
        r = check_item(it, mode, vpy)
        res.append({'id': it['id'], 'title': it['title'], 'level': it['level'], 'ok': r['ok'], 'detail': r['detail']})
    if a.get('json'):
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        for x in res:
            print(('ĐẠT ' if x['ok'] else 'THIẾU ' if x['ok'] is False else '·   ') + f"[{x['level']}] {x['title']} – {x['detail']}")
    return 0


FIX = {
    'python': 'Chạy lại bộ cài: bộ cài tự cài Python 3.12 cho riêng anh/chị (không cần quyền quản trị).',
    'venv': 'Chạy lại bộ cài: bộ cài tạo lại môi trường .venv.',
    'pip': 'Kiểm tra mạng rồi chạy lại bộ cài (bộ cài cài lại thư viện vào .venv).',
    'ffmpeg': 'Chạy lại bộ cài (bộ cài tải ffmpeg bản đầy đủ vào thư mục .bds_studio\\bin), hoặc trong app: Video › Bộ công cụ dựng video › "Cài ngay".',
    'ffmpeg_bad': 'ffmpeg đang có trên máy là bản rút gọn (thiếu {lack}). Chạy lại bộ cài: bộ cài bỏ qua bản này và tải bản đầy đủ vào thư mục .bds_studio\\bin.',
    'fonts': 'Giải nén lại TOÀN BỘ tệp zip bộ cài (đang thiếu tệp trong thư mục fonts) rồi chạy lại bộ cài.',
    'map_data': 'Giải nén lại TOÀN BỘ tệp zip bộ cài (đang thiếu tệp trong thư mục data) rồi chạy lại bộ cài.',
    'disk': 'Xoá bớt tệp/video cũ cho ổ đĩa đủ chỗ trống rồi chạy lại bộ cài.',
    'offline_runtime': 'Chạy lại bộ cài với --chon-video và chọn [2] Offline khi mạng ổn định; tạm thời Video AI chạy Online.',
    'render': 'Dựng thử chưa được – xem nhật ký {log}. Chạy lại bộ cài; vẫn lỗi thì gửi tệp install_report.json và {log} cho bộ phận hỗ trợ.',
}


def _res(id_, name, ok, required, detail, fix=''):
    return {'id': id_, 'ten': name, 'ket_qua': ('ĐẠT' if ok else 'LỖI') if ok is not None else 'BỎ QUA', 'bat_buoc': bool(required),
            'chi_tiet': detail, 'cach_sua': '' if ok or ok is None else fix}


def render_sample(out_mp4: Path, log_path: Path, timeout=600) -> dict:
    """Dựng 3 giây có phụ đề tiếng Việt bằng ĐÚNG đường dựng của máy dựng – y hệt bộ cài Mac (install_mac.command › run_selftest):
    flow.render_sub_png (Pillow + phông trong fonts/) rồi flow.ff (ffmpeg máy dựng tìm thấy, libx264) → ffprobe đo lại
    + đếm điểm ảnh chữ trên khung giây 2,5 (nền xanh tối, chữ trắng → không có phụ đề thì = 0)."""
    import flow                                     # app/flow.py (cần Pillow – chạy bằng Python của .venv)
    res = {'ok': False, 'seconds': 0, 'file': str(out_mp4), 'duration': 0, 'width': 0, 'height': 0,
           'subtitle': SELFTEST_TEXT.replace('**', ''), 'detail': ''}
    t0 = time.time()
    work = Path(tempfile.mkdtemp(prefix='bds_selftest_'))
    logs = []
    try:
        out_mp4.parent.mkdir(parents=True, exist_ok=True)
        sub = flow.render_sub_png(SELFTEST_TEXT, str(work / 'sub.png'))
        flow.ff(['-f', 'lavfi', '-i', f'color=c=0x14325a:s={flow.W}x{flow.H}:r={flow.FPS}:d=3', '-i', sub,
                 '-filter_complex', '[0:v][1:v]overlay=0:0[v]', '-map', '[v]', '-t', '3',
                 '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', str(out_mp4)], logs.append, 'dựng thử 3 giây')
        d = flow.ffprobe_json(str(out_mp4))
        v = next((x for x in d.get('streams', []) if x.get('codec_type') == 'video'), {})
        dur = float((d.get('format') or {}).get('duration') or 0)
        lit = subtitle_pixels(out_mp4)
        res.update(duration=round(dur, 2), width=v.get('width', 0), height=v.get('height', 0), subtitle_pixels=lit)
        checks = {'thời lượng 3 giây': 2.9 <= dur <= 3.1, f'khung {flow.W}×{flow.H}': (res['width'], res['height']) == (flow.W, flow.H),
                  'phụ đề hiện trên hình': lit >= 1500}
        bad = [k for k, ok in checks.items() if not ok]
        res['ok'] = not bad
        res['detail'] = (f'Dựng thử 3 giây có phụ đề tiếng Việt: được ({dur:.1f} giây, {flow.W}×{flow.H})' if not bad
                         else 'Video dựng thử sai: ' + ', '.join(bad) + f' ({dur:.2f} giây, {res["width"]}×{res["height"]})')
    except Exception as e:  # noqa: BLE001
        res['detail'] = f'Dựng thử 3 giây chưa được: {str(e)[:300]}'
    res['seconds'] = round(time.time() - t0, 1)
    try:
        log_path.write_text(''.join(logs) + res['detail'] + '\n', encoding='utf-8')
    except OSError:
        pass
    shutil.rmtree(work, ignore_errors=True)
    return res


def subtitle_pixels(mp4: Path) -> int:
    """Số điểm ảnh sáng (> 200) của khung giây 2,5 (thu nhỏ còn 1/4) – nền xanh tối (độ sáng ~45) nên chỉ chữ phụ đề vượt ngưỡng."""
    r = subprocess.run([common.which('ffmpeg') or 'ffmpeg', '-v', 'error', '-ss', '2.5', '-i', str(mp4), '-frames:v', '1',
                        '-vf', 'scale=iw/2:ih/2,format=gray', '-f', 'rawvideo', '-'], capture_output=True, timeout=60,
                       env=common.child_env())
    return sum(1 for b in r.stdout if b > 200) if r.returncode == 0 else 0


def cmd_selftest(m, a) -> int:
    mode, osf = a['mode'], a['os'] or os_family()
    t0 = time.time()
    in_venv = sys.prefix != sys.base_prefix
    py = _py_for_imports(in_venv) or sys.executable
    out = []
    ff_ok = False
    for it in items_for(m, mode):
        c = it['check']['type']
        if c == 'none' or it['id'] == 'offline_model':
            continue
        if it['id'] == 'venv' and not in_venv and not venv_python():
            out.append(_res('venv', it['title'], None, False, 'đang tự kiểm bằng Python ngoài .venv')); continue
        r = check_item(it, mode, py)
        if it['id'] == 'ffmpeg':
            ff_ok = bool(r['ok'])
            fix = FIX['ffmpeg_bad'].format(lack=', '.join(r.get('lack') or [])) if r.get('present') else FIX['ffmpeg']
        else:
            fix = FIX.get(it['id']) or FIX.get(it['kind']) or 'Chạy lại bộ cài.'
        if it['id'] == 'offline_runtime' and r['ok']:
            try:
                import videoai
                v = videoai.verify_runtime()
                r = {'ok': bool(v.get('ok')), 'detail': (f"torch {v.get('torch')} · " + ('CUDA' if v.get('cuda') else 'MPS' if v.get('mps') else 'chỉ CPU – rất chậm'))
                     if v.get('ok') else 'không nạp được: ' + str(v.get('error', ''))[-200:]}
            except Exception as e:  # noqa: BLE001
                r = {'ok': False, 'detail': f'không nạp được: {e}'}
        if it['level'] == 'optional' and not r['ok']:          # tuỳ chọn thiếu → không tính LỖI
            out.append(_res(it['id'], it['title'], None, False, 'tuỳ chọn – ' + r['detail'])); continue
        out.append(_res(it['id'], it['title'], r['ok'], it['level'] == 'required', r['detail'], fix))
    if mode == 'offline':
        mi = next(i for i in m['items'] if i['id'] == 'offline_model')
        r = check_item(mi, mode, py)
        out.append(_res('offline_model', mi['title'], True if r['ok'] else None, False, r['detail']))
    log = common.data_dir() / 'install_selftest.log'
    mp4 = common.data_dir() / 'install_selftest.mp4'
    pre_bad = [x['id'] for x in out if x['bat_buoc'] and x['ket_qua'] == 'LỖI' and x['id'] in ('python', 'pip_pillow', 'pip_numpy', 'fonts', 'map_data')]
    ff_level = next((it['level'] for it in items_for(m, mode) if it['id'] == 'ffmpeg'), None)
    if a.get('dry'):
        rv = {'ok': None, 'detail': 'chạy thử – sẽ dựng thử 3 giây có phụ đề tiếng Việt'}
    elif not ff_ok and ff_level != 'required':
        rv = {'ok': None, 'skipped': True, 'detail': 'Chưa cài Bộ công cụ dựng video – không dựng thử'}
    elif not ff_ok:
        rv = {'ok': False, 'detail': 'chưa dựng thử được vì thiếu ffmpeg bản đầy đủ'}
    elif pre_bad:
        rv = {'ok': False, 'detail': 'chưa dựng thử được vì thiếu: ' + ', '.join(pre_bad)}
    else:
        say('Dựng thử video 3 giây có phụ đề tiếng Việt (máy yếu có thể mất 1–3 phút)…')
        rv = render_sample(mp4, log)
    out.append(_res('render_3s', 'Dựng thử video 3 giây có phụ đề tiếng Việt', rv['ok'], rv['ok'] is not None, rv['detail'],
                    FIX['render'].format(log=log) if ff_ok and not pre_bad else 'Sửa các mục LỖI phía trên rồi chạy lại bộ cài.'))
    out.append(_res('tts', 'Giọng đọc (TTS)', None, False,
                    'Không thử: giọng đọc hiện chỉ có Vbee (dịch vụ trả phí, cần khoá của anh/chị) – không có TTS miễn phí/trên máy.'))
    fails = [x for x in out if x['bat_buoc'] and x['ket_qua'] == 'LỖI']
    # khoá giống "selftest" của bộ cài Mac (status, seconds, file, duration, width, height, subtitle, message) + từng mục ĐẠT/LỖI
    status = 'dry' if a.get('dry') else 'skipped' if rv.get('skipped') and not fails else 'ok' if not fails else 'failed'
    rep = {'status': status, 'seconds': round(time.time() - t0, 1), 'file': rv.get('file', ''), 'duration': rv.get('duration', 0),
           'width': rv.get('width', 0), 'height': rv.get('height', 0), 'subtitle': SELFTEST_TEXT.replace('**', ''),
           'message': rv['detail'] if not fails else 'Tự kiểm: LỖI ở ' + '; '.join(x['ten'] for x in fails),
           'schema': 1, 'tool': 'deps_video', 'mode': mode, 'os': osf, 'at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
           'ket_qua': 'ĐẠT' if not fails else 'LỖI', 'muc': out, 'chay_lai': '' if not fails else (a.get('rerun') or RERUN[osf].replace('--mode pack', '--mode ' + mode))}
    if a.get('dry'):
        rep['ket_qua'] = 'CHẠY THỬ'
    for x in out:
        say(f"  {x['ket_qua']:<6} {x['ten']} – {x['chi_tiet']}")
        if x['cach_sua']:
            say(f"         → Cách sửa: {x['cach_sua']}")
    if fails:
        say('  → ' + rep['chay_lai'])
    if a.get('out_json'):
        Path(a['out_json']).write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding='utf-8')
    if a.get('report'):
        merge_report(Path(a['report']), rep)
    kv_status = {'dry': 'dry', 'ok': 'ok', 'skipped': 'skipped', 'failed': 'warn'}[status]
    msg = ('Tự kiểm: ĐẠT – ' + rv['detail'] if status == 'ok' else
           'Chạy thử – sẽ dựng thử 3 giây có phụ đề tiếng Việt (kết quả vào báo cáo)' if status == 'dry' else
           'Tự kiểm: đủ thư viện/phông; ' + rv['detail'] + ' (Online – cài gói trong app khi cần dựng video trên máy)' if status == 'skipped' else
           'Tự kiểm: LỖI ở ' + '; '.join(x['ten'] for x in fails) + ' – ' + fails[0]['cach_sua'] + ' ' + rep['chay_lai'])
    write_kv(a.get('out'), status=kv_status, msg=msg, result=rep['ket_qua'])
    return 0


def merge_report(path: Path, rep: dict):
    """Ghi kết quả tự kiểm vào install_report.json (khoá 'selftest'), giữ nguyên phần còn lại (đọc được tệp có BOM của PowerShell)."""
    try:
        cur = json.loads(path.read_bytes().decode('utf-8-sig')) if path.is_file() else {}
    except (OSError, ValueError):
        cur = {}
    if not isinstance(cur, dict):
        cur = {}
    cur['selftest'] = rep
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, path)


def parse_args(argv):
    cmd = argv[0] if argv else ''
    a = {'mode': 'pack', 'os': '', 'out': '', 'out_json': '', 'report': '', 'rerun': '', 'python': '',
         'json': '--json' in argv, 'apply': '--apply' in argv, 'dry': '--dry' in argv}
    for k in ('mode', 'os', 'out', 'out-json', 'report', 'rerun', 'python'):
        if '--' + k in argv and argv.index('--' + k) + 1 < len(argv):
            a[k.replace('-', '_')] = argv[argv.index('--' + k) + 1]
    if a['mode'] == 'later':                 # "Để sau" (chỉ qua biến môi trường): như "Chỉ AI trên mạng" – không cài thêm
        a['mode'] = 'online'
    return cmd, a


def main(argv=None) -> int:
    cmd, a = parse_args(list(sys.argv[1:] if argv is None else argv))
    try:
        m = load()
    except (OSError, ValueError) as e:
        print(f'Không đọc được {manifest_path()}: {e}'); return 2
    if cmd == 'validate':
        err = validate(m)
        print('\n'.join(err) if err else 'deps_video.json hợp lệ'); return 1 if err else 0
    if a['mode'] not in MODES or (a['os'] and a['os'] not in OSES):
        print(f'--mode phải là {"|".join(MODES)}; --os phải là {"|".join(OSES)}'); return 2
    if cmd == 'plan':
        return cmd_plan(m, a)
    if cmd == 'check':
        return cmd_check(m, a)
    if cmd == 'selftest':
        return cmd_selftest(m, a)
    print(__doc__); return 2


if __name__ == '__main__':
    common.console_utf8()
    sys.exit(main())
