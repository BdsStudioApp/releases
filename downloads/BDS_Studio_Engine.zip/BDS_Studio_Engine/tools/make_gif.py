#!/usr/bin/env python3
"""MP4 -> GIF chất lượng tốt (bảng màu tối ưu). 
python3 tools/make_gif.py in.mp4 out.gif [--width 600] [--fps 12] [--crop 0:236:1080:1300] [--colors 128]"""
import subprocess, sys
for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
    try:
        _s.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
a = sys.argv[1:]; src, dst = a[0], a[1]
opt = lambda k, d: a[a.index(k)+1] if k in a else d
w, fps, crop, colors = opt('--width', '600'), opt('--fps', '12'), opt('--crop', ''), opt('--colors', '128')
vf = (f'crop={crop.split(":")[2]}:{crop.split(":")[3]}:{crop.split(":")[0]}:{crop.split(":")[1]},' if crop else '') + \
     f'fps={fps},scale={w}:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors={colors}:stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle'
subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', src, '-vf', vf, '-loop', '0', dst], check=True)
print('GIF:', dst)
