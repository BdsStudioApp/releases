@echo off
rem Bo cai May dung video BDS Studio cho Windows - bam dup tep nay (khong can quyen quan tri).
rem Goi phat hanh 17/11: khach bam "Cai dat voi 1 click.bat" o ngoai cung (goi tep nay trong _he_thong); bam dup tep nay truc tiep van chay duoc.
rem Khong lam video tren may nay: chon [2] o cau hoi dau, khong cai gi (dung web app tren trinh duyet/dien thoai).
rem Tuy chon: --dry-run (chi kiem tra) --ci (khong hoi) --no-launch --no-bench --video   Bien: BDS_MAKE_VIDEO=1|0
title Bo cai May dung video BDS Studio
chcp 65001 >nul
setlocal
set "BDS_RC=11"
rem Mở từ PowerShell 7 / Windows Terminal: PSModulePath trỏ module của bản 7 → Windows PowerShell 5.1 không nạp được
rem Get-ExecutionPolicy, Get-FileHash… (lỗi thật trên GitHub 17/11). Xoá trong phạm vi tệp này → 5.1 tự dựng lại đường mặc định.
set "PSModulePath="
rem Python in chữ Việt bằng UTF-8 (cửa sổ lệnh mặc định cp1252 → UnicodeEncodeError)
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist "%~dp0install_windows.ps1" (
  echo.
  echo ✗ Lỗi B1: chưa giải nén – bấm chuột phải tệp zip → Extract All ^(Giải nén tất cả^), mở thư mục BDS_Studio_Engine rồi bấm đúp lại "Cai dat voi 1 click"
  goto :end
)
rem Bỏ dấu "tải từ Internet" của tệp .ps1 (lệnh trong -Command không bị chính sách chạy script chặn)
set "BDS_PS1=%~dp0install_windows.ps1"
powershell -NoProfile -Command "Unblock-File -LiteralPath $env:BDS_PS1" >nul 2>&1
rem B0: máy công ty có thể khoá chạy script bằng chính sách nhóm (GPO) – khi đó -ExecutionPolicy Bypass không có tác dụng.
set "BDS_POLICY="
rem Gọi đủ tên module + try/catch: không đọc được chính sách thì coi như không khoá (bước sau vẫn báo lỗi nếu bị chặn thật).
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "$p = foreach ($s in 'MachinePolicy','UserPolicy') { try { [string](Microsoft.PowerShell.Security\Get-ExecutionPolicy -Scope $s -ErrorAction Stop) } catch { } }; $p = @($p | Where-Object { $_ -in 'Restricted','AllSigned' }); if ($p) { $p[0] }" 2^>nul`) do set "BDS_POLICY=%%P"
if defined BDS_POLICY (
  echo.
  echo ✗ Lỗi B0: máy này bị quản trị viên khoá chạy script PowerShell ^(chính sách nhóm: %BDS_POLICY%^) – nhờ bộ phận IT cho phép, hoặc cài trên máy cá nhân
  powershell -NoProfile -Command "$d = if ($env:BDS_DATA_DIR) { $env:BDS_DATA_DIR } else { Join-Path $env:USERPROFILE '.bds_studio' }; New-Item -ItemType Directory -Force -Path $d | Out-Null; $r = [ordered]@{ schema = 1; tool = 'install_windows'; mode = 'real'; os = 'windows'; started_at = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); finished_at = ''; steps = @([ordered]@{ id = 'B0'; label = 'Chính sách chạy script'; status = 'failed'; code = 'B0'; message = 'Lỗi B0: chính sách nhóm %BDS_POLICY% chặn chạy script PowerShell'; seconds = 0 }); error = [ordered]@{ code = 'B0'; message = 'Lỗi B0: chính sách nhóm %BDS_POLICY% chặn chạy script PowerShell' } }; [IO.File]::WriteAllText((Join-Path $d 'install_report.json'), (ConvertTo-Json -InputObject $r -Depth 5), (New-Object Text.UTF8Encoding $false))" >nul 2>&1
  set "BDS_RC=10"
  goto :end
)
rem -ExecutionPolicy Bypass chỉ áp dụng cho lần chạy này (không đổi cài đặt của máy, không cần quyền quản trị)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_windows.ps1" %*
set "BDS_RC=%ERRORLEVEL%"
:end
if not defined CI pause
exit /b %BDS_RC%
