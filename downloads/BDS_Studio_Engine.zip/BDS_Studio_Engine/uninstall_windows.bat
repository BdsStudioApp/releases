@echo off
rem Go BDS Studio khoi may Windows nay - Start Menu > BDS Studio > "Go cai dat BDS Studio" (hoac Cai dat > Ung dung > BDS Studio > Go cai dat).
rem Giu nguyen du lieu (thu muc .bds_studio: du an, khoa, mo hinh AI) va video. Tuy chon: --yes (khong hoi) --dry-run (chi in viec se lam)
title Go cai dat BDS Studio
chcp 65001 >nul
setlocal
set "BDS_RC=1"
rem mo tu PowerShell 7 / Windows Terminal: bo PSModulePath cua ban 7 (giong install_windows.bat)
set "PSModulePath="
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "BDS_PS1=%~dp0uninstall_windows.ps1"
powershell -NoProfile -Command "Unblock-File -LiteralPath $env:BDS_PS1" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall_windows.ps1" %*
set "BDS_RC=%ERRORLEVEL%"
if not defined CI pause
exit /b %BDS_RC%
