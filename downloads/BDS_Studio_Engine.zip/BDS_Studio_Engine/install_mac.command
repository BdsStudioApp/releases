#!/bin/bash
# Bộ cài Máy dựng video BDS Studio cho Mac (chip Apple M1/M2/M3/M4 và chip Intel).
# Câu hỏi ĐẦU TIÊN (trước Python, trước mọi thứ) – chủ 17/11 tối, giống bộ cài Windows:
#   [1] Có – dựng video trên máy này (video bản đồ/quy hoạch miễn phí; cài công cụ dựng ~150–300 MB) → cài như dưới
#   [2] Chỉ dùng AI trên mạng – không cài gì lên máy (60 giây → [2]) · [3] Không làm video – không cài gì
#   [2]/[3]: không kiểm/cài Python, không .venv, không ffmpeg, không lối tắt; ghi báo cáo ("video": false, [2] thêm "video_mode": "online"),
#   mở trang đầu web app (bản bán: LAUNCH_ORIGIN trong app/common.py; bản của anh không có → chỉ báo), thoát.
# [1] → Python + môi trường riêng (.venv), máy dựng chạy tại máy, lối tắt. B8 quét nhanh máy NGAY sau Python rồi hỏi:
#   [4] Dựng video trên máy (mặc định) · [2] Dựng + AI ngay trên máy (chỉ máy Mạnh, B9 cài thư viện AI)
#   · [1] Thôi – chỉ AI trên mạng (mặc định trên máy Cơ bản): DỪNG sau B8, không .venv, không ffmpeg.
#
# Nút khách bấm: "Cai dat voi 1 click.command" ở ngoài cùng thư mục BDS_Studio_Engine (ruột – tệp này, app/, fonts/… – trong
# _he_thong/); nút đó chỉ chuyển sang tệp này và đặt BDS_CLICK_PATH. Gói cũ/mã nguồn: chạy thẳng tệp này vẫn được.
# Cách chạy (lần đầu): mở Terminal, gõ "bash " rồi kéo "Cai dat voi 1 click" vào, Enter.  Chạy lại bao nhiêu lần cũng được:
# bước nào xong rồi thì bỏ qua, tải dở thì tải tiếp (bộ cài làm tiếp từ bước lỗi).
# Gatekeeper (bản tương đương bước Unblock-File của Windows): bộ cài chưa ký Developer ID/notarize → bấm đúp tệp tải từ mạng bị
#   chặn. Chạy qua "bash <tệp>" thì macOS không mở tệp bằng LaunchServices nên không hỏi. B1 gỡ cờ bằng
#   xattr -dr com.apple.quarantine cho cả thư mục (kể cả nút bấm ở ngoài _he_thong) để các lần bấm sau không bị chặn.
#   macOS 15 trở lên đã BỎ cách chuột phải → Mở; lỡ bấm đúp: System Settings › Privacy & Security › Open Anyway (≈ 1 giờ).
# Biểu tượng (quy tắc chủ 17/11): mọi thứ bộ cài tạo để khách bấm đều mang biểu tượng BDS Studio – BDS Studio.app,
#   "Tắt máy dựng BDS Studio.app" (Launchpad, giống mục Start Menu của Windows), lối tắt dự phòng .command, nút
#   "Cai dat voi 1 click" và start_mac.command (gắn biểu tượng bằng NSWorkspace setIcon:forFile:options: qua osascript).
# Cuối bộ cài (đã chọn Bộ công cụ dựng video): DỰNG THỬ 3 GIÂY có phụ đề tiếng Việt bằng đúng đường dựng của máy dựng
#   (app/flow.py: render_sub_png + ff) → ~/.bds_studio/install_selftest.mp4, kết quả ở "selftest" trong install_report.json.
# Phụ thuộc theo chế độ: deps_video.json (dùng chung với Windows) – hàm deps_plan sau B8 in bảng cần cài/dung lượng/thời gian,
#   bỏ mục đã có, bật ffmpeg nếu chế độ bắt buộc; mô hình lớn chỉ tải sau khi xác nhận (B9/app). "deps_manifest" vào báo cáo.
# Tuỳ chọn:  --dry-run  chỉ kiểm tra, không cài gì   ·  --ci  không hỏi, không mở trình duyệt (kiểm thử tự động)
#            --no-launch  cài xong không mở app   ·  --no-bench  bỏ đo thử dựng 10 giây
#            --video  có làm video + cài Bộ công cụ dựng video kể cả máy yếu · --no-video  không cài gói · --chon-video  hỏi lại
#            BDS_MAKE_VIDEO=1|online|0  trả lời sẵn câu hỏi đầu: dựng trên máy | chỉ AI trên mạng | không làm video (CI đặt 1)
# Biến môi trường (kiểm thử): BDS_PYTHON_SOURCE=auto|portable  BDS_FFMPEG_SOURCE=auto|brew|static
#                             BDS_DATA_DIR, BDS_CACHE_DIR, BDS_INSTALL_REPORT (giống máy dựng)
#                             BDS_VIDEO_MODE=online|offline|later  BDS_VIDEO_PACK=1|0  BDS_VIDEO_DOWNLOAD=now|later
#                             BDS_VIDEO_TIMEOUT=60  BDS_HW_TIER=co_ban|kha|manh (giả hạng máy, chỉ kiểm thử) – xem app/videomode.py
# Báo cáo máy đọc được: ~/.bds_studio/install_report.json (app đọc qua máy dựng: GET /install/report).
# Mã lỗi: B1 máy/thư mục · B2 Python · B3 ffmpeg · B4 thư viện Python · B5 biểu tượng/lối tắt · B6 bật thử máy dựng · B7 quét máy
#         · B8 quét nhanh + chọn cách xử lý video · B9 Video AI offline (B8/B9 không dừng bộ cài: ⚠ + dùng Online).
# Bộ cài thoát với mã 10 + số bước lỗi (B3 → 13); 0 = xong.
# Thứ tự chạy: B1 → B2 → B8 → B3 → B4 → B5 → B6 → B7 → B9 (mã bước giữ nguyên nghĩa cũ; màn hình đánh số theo thứ tự chạy).

set -u
cd "$(dirname "$0")" || exit 1
ENGINE_DIR="$(pwd -P)"
ENGINE_VERSION="$(sed -n "s/^VERSION = '\([^']*\)'.*/\1/p" app/common.py 2>/dev/null | head -n 1)"

DRY=0; CI_MODE=0; LAUNCH=1; BENCH=1; PACK_FLAG=""; ASK_VIDEO=0
for a in "$@"; do
  case "$a" in
    --dry-run) DRY=1 ;;
    --ci) CI_MODE=1 ;;
    --no-launch) LAUNCH=0 ;;
    --no-bench) BENCH=0 ;;
    --video) PACK_FLAG="yes" ;;
    --no-video) PACK_FLAG="no" ;;
    --chon-video) ASK_VIDEO=1 ;;
    *) echo "Tuỳ chọn lạ: $a (bỏ qua)" ;;
  esac
done
[ "${BDS_INSTALL_DRYRUN:-0}" = "1" ] && DRY=1
[ -n "${CI:-}" ] && CI_MODE=1
[ "$CI_MODE" = "1" ] && LAUNCH=0

DATA_DIR="${BDS_DATA_DIR:-$HOME/.bds_studio}"
case "$DATA_DIR/" in "$ENGINE_DIR"/*) DATA_DIR="$HOME/.bds_studio" ;; esac   # giống common.data_dir(): không nằm trong engine
CACHE_DIR="${BDS_CACHE_DIR:-$HOME/Library/Caches/BDS Studio}"
DL_DIR="$CACHE_DIR/downloads"
BIN_DIR="$DATA_DIR/bin"
PORTABLE_PY="$DATA_DIR/python"
if [ "$DRY" = "1" ]; then REPORT="$DATA_DIR/install_report_dry.json"; else REPORT="${BDS_INSTALL_REPORT:-$DATA_DIR/install_report.json}"; fi
VPY="$ENGINE_DIR/.venv/bin/python"
# Nút bấm của khách (tên không dấu – quyết định chủ 17/11). Nút đặt BDS_CLICK_PATH; chạy thẳng tệp này trong _he_thong thì tự tìm.
CLICK_NAME="Cai dat voi 1 click"
CLICK_PATH="${BDS_CLICK_PATH:-}"
if [ -z "$CLICK_PATH" ] && [ "$(basename "$ENGINE_DIR")" = "_he_thong" ] && [ -f "$ENGINE_DIR/../$CLICK_NAME.command" ]; then
  CLICK_PATH="$(cd "$ENGINE_DIR/.." && pwd -P)/$CLICK_NAME.command"
fi
[ -f "$CLICK_PATH" ] || CLICK_PATH=""
if [ -n "$CLICK_PATH" ]; then RERUN="bấm lại \"$CLICK_NAME\""; else RERUN="chạy lại install_mac.command"; fi
STOP_NAME="Tắt máy dựng BDS Studio"
APP_PATH="$HOME/Applications/BDS Studio.app"
TOTAL=9
STEP_NO=0

# Python dự phòng không cần quyền quản trị (python-build-standalone của Astral) – bản ghim, sha256 lấy từ SHA256SUMS
# của bản phát hành 20241016 (đã tải thử và đối chiếu ngày 16/11/2026).
PBS_BASE="https://github.com/astral-sh/python-build-standalone/releases/download/20241016"
PBS_ARM="cpython-3.12.7%2B20241016-aarch64-apple-darwin-install_only.tar.gz"
PBS_ARM_SHA="4c18852bf9c1a11b56f21bcf0df1946f7e98ee43e9e4c0c5374b2b3765cf9508"
PBS_X64="cpython-3.12.7%2B20241016-x86_64-apple-darwin-install_only.tar.gz"
PBS_X64_SHA="60c5271e7edc3c2ab47440b7abf4ed50fbc693880b474f74f05768f5b657045a"
# ffmpeg bản tĩnh (không cần Homebrew): martin-riedl.de có bản arm64 + Intel; evermeet.cx chỉ có bản Intel (chip Apple cần Rosetta).
# Hai nguồn này đổi bản liên tục (không ghim sha256 được) → bộ cài chạy thử "ffmpeg -version" sau khi tải, hỏng thì bỏ.
FF_MR="https://ffmpeg.martin-riedl.de/redirect/latest/macos"
FF_EM="https://evermeet.cx/ffmpeg/getrelease"

# ---------------- in ra + báo cáo ----------------
say() { printf '%s\n' "$*"; }
now_iso() { date -u +%Y-%m-%dT%H:%M:%SZ; }
json_str() {
  local s
  s=$(printf '%s' "${1:-}" | LC_ALL=C tr -d '\000-\010\013\014\016-\037')
  s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\n'/\\n}; s=${s//$'\r'/\\r}; s=${s//$'\t'/\\t}
  printf '"%s"' "$s"
}
STARTED="$(now_iso)"; FINISHED=""; STEPS=""; ERR_CODE=""; ERR_MSG=""
OS_VER="$(sw_vers -productVersion 2>/dev/null || uname -r)"; ARCH=""
PY=""; PY_VER=""; PY_SRC=""; FF=""; FF_VER=""; FF_SRC=""; TIER=""; VIDEO_MODE=""; VIDEO_PACK=""; MAKE_VIDEO_JSON="null"
SELFTEST_JSON="null"; DEPS_MANIFEST=""
CUR_ID=""; CUR_LABEL=""; CUR_T0=0

write_report() {
  mkdir -p "$(dirname "$REPORT")" 2>/dev/null || return 0
  local err="null" mode="real"
  [ "$DRY" = "1" ] && mode="dry"
  [ -n "$ERR_CODE" ] && err="{\"code\":$(json_str "$ERR_CODE"),\"message\":$(json_str "$ERR_MSG")}"
  {
    printf '{"schema":1,"tool":"install_mac","mode":%s,"os":"mac","os_version":%s,"arch":%s,' \
      "$(json_str "$mode")" "$(json_str "$OS_VER")" "$(json_str "$ARCH")"
    printf '"engine_dir":%s,"engine_version":%s,"started_at":%s,"finished_at":%s,' \
      "$(json_str "$ENGINE_DIR")" "$(json_str "$ENGINE_VERSION")" "$(json_str "$STARTED")" "$(json_str "$FINISHED")"
    printf '"python":%s,"python_source":%s,"ffmpeg":%s,"ffmpeg_source":%s,"tier":%s,"video":%s,"video_mode":%s,"video_pack":%s,' \
      "$(json_str "$PY_VER")" "$(json_str "$PY_SRC")" "$(json_str "$FF_VER")" "$(json_str "$FF_SRC")" "$(json_str "$TIER")" \
      "$MAKE_VIDEO_JSON" "$(json_str "$VIDEO_MODE")" "$(json_str "$VIDEO_PACK")"
    printf '"click_target":%s,"deps_manifest":%s,"selftest":%s,"steps":[%s],"error":%s}\n' \
      "$(json_str "$CLICK_PATH")" "$(json_str "$DEPS_MANIFEST")" "$SELFTEST_JSON" "$STEPS" "$err"
  } > "$REPORT.tmp" && mv -f "$REPORT.tmp" "$REPORT"
}

step() {   # step B3 "ffmpeg (công cụ dựng video)"
  CUR_ID="$1"; CUR_LABEL="$2"; CUR_T0=$(date +%s); STEP_NO=$((STEP_NO + 1))
  say ""
  say "[$STEP_NO/$TOTAL] $1 · $2…"
}
# Đọc tệp KHOÁ=giá trị do app/videomode.py ghi (B8/B9) → VM_STATUS VM_MSG VM_MODE VM_PACK VM_TIER
read_vm() {
  VM_STATUS=""; VM_MSG=""; VM_MODE=""; VM_PACK=""; VM_TIER=""
  [ -f "$1" ] || return 1
  local line k v
  while IFS= read -r line || [ -n "$line" ]; do
    k="${line%%=*}"; v="${line#*=}"
    case "$k" in
      STATUS) VM_STATUS="$v" ;; MSG) VM_MSG="$v" ;; MODE) VM_MODE="$v" ;; PACK) VM_PACK="$v" ;; TIER) VM_TIER="$v" ;;
    esac
  done < "$1"
  rm -f "$1"
  [ -n "$VM_STATUS" ]
}
done_step() {   # done_step ok|skipped|warn|dry|failed "thông báo"
  local st="$1" msg="${2:-}" secs code=""
  secs=$(( $(date +%s) - CUR_T0 ))
  [ "$st" = "failed" ] && code="$CUR_ID"
  [ -n "$STEPS" ] && STEPS="$STEPS,"
  STEPS="$STEPS{\"id\":$(json_str "$CUR_ID"),\"label\":$(json_str "$CUR_LABEL"),\"status\":$(json_str "$st"),\"code\":$(json_str "$code"),\"message\":$(json_str "$msg"),\"seconds\":$secs}"
  case "$st" in
    ok|skipped) say "   ✓ $msg" ;;
    warn) say "   ⚠ $msg" ;;
    dry) say "   ○ (chạy thử) $msg" ;;
    failed) say "   ✗ $msg" ;;
  esac
  write_report
}
pause_close() { [ "$CI_MODE" = "1" ] || read -r -p "Nhấn Enter để đóng..." _; }
fail() {   # fail "Lỗi B3: … – kiểm tra mạng, bấm chạy lại"
  ERR_CODE="$CUR_ID"; ERR_MSG="$1"
  done_step failed "$1"
  say ""
  say "=== CHƯA CÀI XONG – $1 ==="
  say "Bấm chạy lại bộ cài: phần đã xong được giữ, bộ cài làm tiếp từ bước ${CUR_ID}."
  say "Cần giúp: gửi tệp báo cáo $REPORT (không chứa mật khẩu hay khoá)."
  pause_close
  exit $(( 10 + ${CUR_ID#B} ))
}
# shellcheck disable=SC2329  # gọi qua trap
on_interrupt() {
  if [ -n "$CUR_ID" ]; then
    ERR_CODE="$CUR_ID"; ERR_MSG="Lỗi $CUR_ID: đã dừng giữa chừng – bấm chạy lại để làm tiếp"
    done_step failed "$ERR_MSG"
  fi
  exit 130
}
trap on_interrupt INT TERM

# Tải có làm tiếp (curl -C -), thử lại 3 lần, đối chiếu sha256 nếu có.   download URL ĐÍCH [SHA256]
download() {
  local url="$1" dest="$2" sha="${3:-}" part="$2.part" i prog="-#"
  mkdir -p "$(dirname "$dest")"
  [ "$CI_MODE" = "1" ] && prog="-sS"
  if [ -f "$dest" ] && { [ -z "$sha" ] || [ "$(shasum -a 256 "$dest" | awk '{print $1}')" = "$sha" ]; }; then return 0; fi
  rm -f "$dest"
  for i in 1 2 3; do
    if curl -fL "$prog" --connect-timeout 20 --retry 2 --retry-delay 3 -C - -o "$part" "$url"; then
      if [ -z "$sha" ] || [ "$(shasum -a 256 "$part" | awk '{print $1}')" = "$sha" ]; then mv -f "$part" "$dest"; return 0; fi
      say "   ⚠ Tệp tải về không khớp mã kiểm tra (lần $i) – tải lại từ đầu"
    fi
    rm -f "$part"     # máy chủ không cho tải tiếp / tệp hỏng → lần sau tải lại từ đầu
    sleep 2
  done
  return 1
}

# ≥ 3.12 (deps_video.json › python.min): app/scenes.py dùng f-string kiểu mới của 3.12
py_ok() { [ -x "$1" ] && "$1" -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 12) else 1)' >/dev/null 2>&1; }
find_python() {
  local c sys_py
  if [ "${BDS_PYTHON_SOURCE:-auto}" = "portable" ]; then
    if py_ok "$PORTABLE_PY/bin/python3"; then PY="$PORTABLE_PY/bin/python3"; PY_SRC="portable"; return 0; fi
    return 1
  fi
  for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3 "$PORTABLE_PY/bin/python3"; do
    if py_ok "$c"; then
      PY="$c"
      case "$c" in "$PORTABLE_PY"/*) PY_SRC="portable" ;; /opt/homebrew/*|/usr/local/*) PY_SRC="homebrew" ;; *) PY_SRC="python.org" ;; esac
      return 0
    fi
  done
  # /usr/bin/python3 chỉ là "vỏ" khi máy chưa có Command Line Tools – gọi vào sẽ bật hộp thoại cài Xcode → chỉ dùng khi đã có CLT
  sys_py="$(command -v python3 2>/dev/null || true)"
  if [ -n "$sys_py" ] && { [ "$sys_py" != "/usr/bin/python3" ] || xcode-select -p >/dev/null 2>&1; }; then
    if py_ok "$sys_py"; then PY="$sys_py"; PY_SRC="system"; return 0; fi
  fi
  return 1
}
ff_ok() { [ -x "$1" ] && "$1" -version >/dev/null 2>&1; }
find_ffmpeg() {
  local d
  for d in "$BIN_DIR" /opt/homebrew/bin /usr/local/bin; do
    if ff_ok "$d/ffmpeg" && ff_ok "$d/ffprobe"; then FF="$d/ffmpeg"; return 0; fi
  done
  d="$(command -v ffmpeg 2>/dev/null || true)"
  if [ -n "$d" ] && ff_ok "$d" && ff_ok "$(dirname "$d")/ffprobe"; then FF="$d"; return 0; fi
  return 1
}
# Bản tĩnh: tải zip của từng công cụ → chép vào ~/.bds_studio/bin → chạy thử (sai kiến trúc / hỏng thì bỏ).
install_static_tool() {   # install_static_tool ffmpeg|ffprobe URL NHÃN_NGUỒN
  local tool="$1" url="$2" z="$DL_DIR/$1-$3.zip" tmp="$DL_DIR/x_$1" f
  download "$url" "$z" || return 1
  rm -rf "$tmp"; mkdir -p "$tmp" "$BIN_DIR"
  unzip -o -q "$z" -d "$tmp" || { rm -f "$z"; return 1; }
  f="$(find "$tmp" -type f -name "$tool" | head -n 1)"
  if [ -z "$f" ]; then rm -rf "$tmp" "$z"; return 1; fi
  mv -f "$f" "$BIN_DIR/$tool"; chmod 755 "$BIN_DIR/$tool"
  xattr -d com.apple.quarantine "$BIN_DIR/$tool" 2>/dev/null || true
  rm -rf "$tmp"
  if ff_ok "$BIN_DIR/$tool"; then rm -f "$z"; return 0; fi
  rm -f "$BIN_DIR/$tool" "$z"; return 1
}
has_rosetta() { /usr/bin/arch -x86_64 /usr/bin/true >/dev/null 2>&1; }
install_static_ffmpeg() {
  local srcs s
  if [ "$ARCH" = "arm64" ]; then srcs="mr_arm64 em"; else srcs="em mr_amd64"; fi
  for s in $srcs; do
    case "$s" in
      em)
        if [ "$ARCH" = "arm64" ] && ! has_rosetta; then continue; fi
        say "   … tải ffmpeg bản tĩnh từ evermeet.cx (~80 MB)"
        if install_static_tool ffmpeg "$FF_EM/zip" em && install_static_tool ffprobe "$FF_EM/ffprobe/zip" em; then FF_SRC="static:evermeet"; return 0; fi ;;
      mr_*)
        say "   … tải ffmpeg bản tĩnh từ ffmpeg.martin-riedl.de (${s#mr_}, ~80 MB)"
        if install_static_tool ffmpeg "$FF_MR/${s#mr_}/release/ffmpeg.zip" "$s" && install_static_tool ffprobe "$FF_MR/${s#mr_}/release/ffprobe.zip" "$s"; then FF_SRC="static:martin-riedl"; return 0; fi ;;
    esac
    say "   ⚠ Nguồn này chưa được – thử nguồn khác"
  done
  return 1
}

# ---------------- biểu tượng cho mọi thứ khách bấm ----------------
# Ảnh biểu tượng: bộ ảnh riêng (nếu đã có) → AppIcon.icns của BDS Studio.app vừa tạo → icon-512.png đi kèm zip.
# Bộ ảnh riêng do tools/icons_build.mjs sinh, đóng sẵn trong zip Mac: assets/bds_studio.icns, bds_studio_stop.icns, bds_studio_install.icns
#   (thiếu tệp nào thì dùng biểu tượng chính – ngôi nhà vàng).
icon_image() {   # icon_image main|stop|install → đường dẫn ảnh (rỗng nếu không có)
  local c
  for c in "$ENGINE_DIR/assets/bds_studio_$1.icns" "$ENGINE_DIR/assets/bds_studio.icns" \
           "$APP_PATH/Contents/Resources/AppIcon.icns" "$ENGINE_DIR/assets/icon-512.png" "$ENGINE_DIR/../web/assets/icon-512.png"; do
    [ -s "$c" ] && { printf '%s' "$c"; return 0; }
  done
  return 1
}
# Gắn biểu tượng riêng cho MỘT tệp (.command…) bằng API của Apple: NSWorkspace setIcon:forFile:options: (AppKit) gọi qua
# osascript JavaScript – có sẵn trên mọi macOS, không cần quyền quản trị. Trả 0 khi macOS báo đã gắn.
set_file_icon() {   # set_file_icon ẢNH TỆP
  [ -s "$1" ] && [ -e "$2" ] || return 1
  [ "$(osascript -l JavaScript -e 'ObjC.import("AppKit");
function run(a) { var i = $.NSImage.alloc.initWithContentsOfFile(a[0]);
  return (!i.isNil() && $.NSWorkspace.sharedWorkspace.setIconForFileOptions(i, a[1], 0)) ? "ok" : "no"; }' "$1" "$2" 2>/dev/null)" = "ok" ]
}
# "Tắt máy dựng BDS Studio.app" cạnh BDS Studio.app (Launchpad) – tương đương mục Start Menu "Tắt máy dựng BDS Studio" của Windows.
# Applet AppleScript (osacompile, chương trình mồi chíp gốc như BDS Studio.app) gọi launcher của gói chính với --stop; biểu tượng
# BDS Studio (biến thể "tắt" nếu đã có); ký ad-hoc sau khi sửa Info.plist. Gói do bộ cài tạo có tệp đánh dấu → cài lại thì thay.
make_stop_app() {
  local stop="$HOME/Applications/$STOP_NAME.app" work tmp icon esc
  [ -x "$APP_PATH/Contents/Resources/launcher" ] && command -v osacompile >/dev/null 2>&1 || return 1
  if [ -e "$stop" ] && [ ! -f "$stop/Contents/Resources/bds_studio_app" ]; then return 2; fi   # gói trùng tên không phải của bộ cài
  work="$(mktemp -d "$HOME/Applications/.bds_stop.XXXXXX")" || return 1
  tmp="$work/$STOP_NAME.app"
  esc="${APP_PATH//\\/\\\\}"; esc="${esc//\"/\\\"}"
  printf '%s\n' "-- $STOP_NAME (bộ cài tạo – không sửa tay)" 'try' \
    "	do shell script \"/bin/bash \" & quoted form of \"$esc/Contents/Resources/launcher\" & \" --stop >/dev/null 2>&1\"" \
    'end try' > "$work/stop.applescript"
  if ! osacompile -o "$tmp" "$work/stop.applescript" >/dev/null 2>&1 || [ ! -f "$tmp/Contents/MacOS/applet" ]; then rm -rf "$work"; return 1; fi
  rm -f "$tmp/Contents/Resources/Assets.car" "$tmp/Contents/Resources/applet.icns"
  icon="$(icon_image stop)"
  case "$icon" in *.icns) cp -f "$icon" "$tmp/Contents/Resources/AppIcon.icns" ;; esac
  printf 'Gói do bộ cài BDS Studio tạo – cài lại sẽ thay gói này.\n' > "$tmp/Contents/Resources/bds_studio_app"
  if ! "$VPY" - "$tmp/Contents/Info.plist" "$APP_PATH/Contents/Info.plist" "$STOP_NAME" >/dev/null 2>&1 <<'PY'
import plistlib, sys
p, main, name = sys.argv[1:4]
d = plistlib.load(open(p, 'rb'))
try:
    m = plistlib.load(open(main, 'rb'))
except Exception:
    m = {}
d.pop('CFBundleIconName', None)
d.update({'CFBundleName': name, 'CFBundleDisplayName': name, 'CFBundleIconFile': 'AppIcon', 'LSUIElement': True,
          'CFBundleIdentifier': (m.get('CFBundleIdentifier') or 'vn.bdsstudio.engine') + '.stop',
          'CFBundleShortVersionString': m.get('CFBundleShortVersionString', '1.0'), 'CFBundleVersion': m.get('CFBundleVersion', '1.0'),
          'LSMinimumSystemVersion': '11.0'})
plistlib.dump(d, open(p, 'wb'), fmt=plistlib.FMT_XML, sort_keys=True)
PY
  then rm -rf "$work"; return 1; fi
  xattr -cr "$tmp" 2>/dev/null || true
  codesign --force --deep --sign - "$tmp" >/dev/null 2>&1 || true
  rm -rf "$stop" && mv "$tmp" "$stop"; rm -rf "$work"
  [ -f "$stop/Contents/Resources/AppIcon.icns" ] || return 3                 # tạo được nhưng chưa có biểu tượng
  touch "$stop"
  local lsr=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
  [ -x "$lsr" ] && "$lsr" -f "$stop" >/dev/null 2>&1
  return 0
}

# ---------------- phụ thuộc video theo chế độ (deps_video.json – nguồn sự thật duy nhất, dùng chung với bộ cài Windows) ----------------
# deps_plan (ngay sau B8, trước B3): tools/deps_video.py plan kiểm từng mục của chế độ đã chọn cho "mac", bỏ mục đã có, in dung lượng +
#   thời gian TRƯỚC khi tải. Mục ffmpeg "required" ở chế độ đó (NEED_FFMPEG=1) → bật Bộ công cụ dựng video ở B3, trừ khi khách chủ động
#   --no-video / BDS_VIDEO_PACK=0. Mô hình AI không bao giờ tải ở đây (B9 / app hỏi xác nhận đúng số GB).
# deps_manifest_hook (cuối): ghi trạng thái dùng tệp kê khai vào báo cáo ("used" | "present_unused" | "missing").
deps_mode() {
  if [ "$VIDEO_MODE" = "offline" ]; then echo offline; elif [ "$VIDEO_PACK_ON" = "1" ]; then echo pack; else echo online; fi
}
deps_plan() {
  local out="$DATA_DIR/install_deps_plan.txt" line k v need="" req="" bad="" est=""
  if [ ! -f "$ENGINE_DIR/deps_video.json" ] || [ ! -f "$ENGINE_DIR/tools/deps_video.py" ]; then DEPS_MANIFEST="missing"; return 0; fi
  [ -n "$PY" ] || { DEPS_MANIFEST="present_unused"; return 0; }
  rm -f "$out"
  local args=(-u tools/deps_video.py plan --mode "$(deps_mode)" --os mac --out "$out")
  if [ "$DRY" = "1" ]; then args+=(--dry); elif [ "$PACK_FLAG" != "no" ]; then
    case "${BDS_VIDEO_PACK:-}" in 0|no|false|khong) ;; *) args+=(--apply) ;; esac   # ghi video_pack=install vào video_mode.json
  fi
  PYTHONIOENCODING=utf-8 "$PY" "${args[@]}" || true
  [ -f "$out" ] || { DEPS_MANIFEST="present_unused"; return 0; }
  while IFS= read -r line || [ -n "$line" ]; do
    k="${line%%=*}"; v="${line#*=}"
    case "$k" in NEED_FFMPEG) need="$v" ;; FFMPEG_REQUIRED) req="$v" ;; FFMPEG_BAD) bad="$v" ;; FFMPEG_EST) est="$v" ;; esac
  done < "$out"
  rm -f "$out"
  DEPS_MANIFEST="used"
  if [ "$req" = "1" ] && [ "$VIDEO_PACK_ON" != "1" ] && [ "$PACK_FLAG" != "no" ]; then   # chủ 17/11: làm video trên máy → cài đủ
    case "${BDS_VIDEO_PACK:-}" in 0|no|false|khong) ;; *)
      VIDEO_PACK_ON=1; VIDEO_PACK="install"
      if [ "$need" = "1" ]; then say "   … Cách làm video này cần ffmpeg để dựng video trên máy – sẽ cài ở bước sau ($est)"; fi ;;
    esac
  fi
  if [ -n "$bad" ]; then say "   … ffmpeg có sẵn trên máy là bản rút gọn ($bad) – chạy lại bộ cài sau khi gỡ bản đó, hoặc cài Homebrew ffmpeg"; fi
  return 0
}
deps_manifest_hook() {
  [ "$DEPS_MANIFEST" = "used" ] && return 0
  if [ -f "$ENGINE_DIR/deps_video.json" ]; then DEPS_MANIFEST="present_unused"; else DEPS_MANIFEST="missing"; fi
}

# ---------------- dựng thử 3 giây có phụ đề tiếng Việt (cuối bộ cài) ----------------
# Dùng ĐÚNG đường dựng của máy dựng: flow.render_sub_png (Pillow + phông trong fonts/) rồi flow.ff (ffmpeg mà máy dựng tìm thấy,
# libx264 như khi dựng thật) → ffprobe đo lại. Kết quả JSON vào "selftest" của báo cáo; lỗi chỉ ⚠ (không dừng bộ cài).
run_selftest() {
  local line
  line="$(PYTHONIOENCODING=utf-8 "$VPY" - "$DATA_DIR/install_selftest.mp4" 2>>"$DATA_DIR/install_selftest.log" <<'PY'
import json, os, sys, tempfile, time
sys.path.insert(0, 'app')
out = sys.argv[1]
text = 'Dựng thử 3 giây – phụ đề **tiếng Việt**: Căn hộ view sông, sổ hồng riêng'
r = {'status': 'failed', 'seconds': 0, 'file': out, 'duration': 0, 'width': 0, 'height': 0, 'subtitle': text.replace('**', ''), 'message': ''}
t0 = time.time()
try:
    import flow
    work = tempfile.mkdtemp(prefix='bds_selftest_')
    sub = flow.render_sub_png(text, os.path.join(work, 'sub.png'))
    logs = []
    flow.ff(['-f', 'lavfi', '-i', f'color=c=0x14325a:s={flow.W}x{flow.H}:r={flow.FPS}:d=3', '-i', sub,
             '-filter_complex', '[0:v][1:v]overlay=0:0[v]', '-map', '[v]', '-t', '3',
             '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', out], logs.append, 'dựng thử 3 giây')
    d = flow.ffprobe_json(out)
    dur = float((d.get('format') or {}).get('duration') or 0)
    v = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    r.update(duration=round(dur, 2), width=v.get('width', 0), height=v.get('height', 0))
    ok = 2.9 <= dur <= 3.1 and (r['width'], r['height']) == (flow.W, flow.H)
    r['status'] = 'ok' if ok else 'failed'
    r['message'] = (f'Dựng thử 3 giây có phụ đề tiếng Việt: được ({dur:.1f} giây, {flow.W}×{flow.H})' if ok
                    else f'Video dựng thử sai: {dur:.2f} giây, {r["width"]}×{r["height"]}')
except Exception as e:  # noqa: BLE001
    r['message'] = f'Dựng thử 3 giây chưa được: {str(e)[:300]}'
r['seconds'] = round(time.time() - t0, 1)
print(json.dumps(r, ensure_ascii=False))
PY
)" || true
  case "$line" in
    '{'*'}') SELFTEST_JSON="$line" ;;
    *) SELFTEST_JSON="{\"status\":\"failed\",\"message\":$(json_str "Dựng thử 3 giây chưa chạy được – xem $DATA_DIR/install_selftest.log")}" ;;
  esac
}

# Web app dùng chung (bản bán): đúng nguồn biểu tượng BDS Studio dùng (app/common.py › BDS_LAUNCH_ORIGIN – tools/sale_build.mjs đặt).
WEB_APP="${BDS_LAUNCH_ORIGIN:-$(sed -n "s/.*BDS_LAUNCH_ORIGIN', '\([^']*\)'.*/\1/p" app/common.py 2>/dev/null | head -n 1)}"
WEB_APP="${WEB_APP%/}"
case "$WEB_APP" in https://*) ;; *) WEB_APP="" ;; esac

printf '\033]0;Bộ cài Máy dựng video BDS Studio\007' 2>/dev/null || true
say ""
say "=== BỘ CÀI MÁY DỰNG VIDEO BDS STUDIO (Mac) ==="
say "Thư mục: $ENGINE_DIR"
[ "$DRY" = "1" ] && say "(CHẠY THỬ – chỉ kiểm tra, không cài gì)"
mkdir -p "$DATA_DIR" 2>/dev/null

# ---------------- Câu hỏi đầu tiên: có làm video trên máy này không (trước Python, trước mọi thứ) ----------------
CUR_ID="BV"; CUR_LABEL="Có làm video trên máy tính này không"; CUR_T0=$(date +%s)
MAKE_VIDEO=""
# BDS_MAKE_VIDEO: 1 = dựng trên máy · online = chỉ AI trên mạng · 0 = không làm video (CI đặt 1)
case "${BDS_MAKE_VIDEO:-}" in 1) MAKE_VIDEO=1 ;; online) MAKE_VIDEO=2 ;; 0) MAKE_VIDEO=3 ;; esac
[ "$PACK_FLAG" = "yes" ] && MAKE_VIDEO=1                                  # --video = dựng trên máy
if [ -z "$MAKE_VIDEO" ] && py_ok "$VPY"; then
  MAKE_VIDEO=1; say "Máy này đã có Máy dựng video – chạy lại để cập nhật/sửa (không hỏi lại)."
fi
if [ -z "$MAKE_VIDEO" ]; then
  say ""
  say "Anh/chị có làm video trên máy tính này không?"
  say "   [1] Có – dựng video trên máy này (video bản đồ/quy hoạch miễn phí; cài công cụ dựng ~150–300 MB)"
  say "   [2] Chỉ dùng AI trên mạng – không cài gì lên máy (AI tính phí theo nhà cung cấp; không làm được video bản đồ/quy hoạch trên máy này)"
  say "   [3] Không làm video – không cài gì"
  if [ "$CI_MODE" = "1" ] || [ ! -t 0 ]; then
    say "   Gõ 1, 2 hoặc 3 rồi Enter (Enter hoặc chờ 60 giây = [2]): 2 (tự chọn)"; MAKE_VIDEO=2
  else
    while :; do
      ANS=""
      if ! read -r -t 60 -p "   Gõ 1, 2 hoặc 3 rồi Enter (Enter hoặc chờ 60 giây = [2]): " ANS; then say ""; say "   … hết 60 giây – tự chọn [2]"; ANS=2; fi
      case "$ANS" in 1|2|3) MAKE_VIDEO="$ANS"; break ;; "") MAKE_VIDEO=2; break ;; *) say "   Chỉ gõ 1 / 2 / 3 rồi Enter." ;; esac
    done
  fi
fi
if [ "$MAKE_VIDEO" != "1" ]; then
  # [2] Chỉ AI trên mạng / [3] Không làm video: KHÔNG kiểm/cài Python, không .venv, không ffmpeg, không lối tắt
  MAKE_VIDEO_JSON="false"
  if [ "$MAKE_VIDEO" = "2" ]; then
    VIDEO_MODE="online"; VIDEO_PACK="skip"; NOV_MSG="Chỉ làm video bằng AI trên mạng – không cài gì lên máy"
  else
    NOV_MSG="Không làm video trên máy này – không cài gì"
  fi
  [ -n "$WEB_APP" ] && NOV_MSG="$NOV_MSG; dùng app tại $WEB_APP"
  if [ "$DRY" = "1" ]; then done_step dry "$NOV_MSG"; else done_step ok "$NOV_MSG"; fi
  FINISHED="$(now_iso)"; CUR_ID=""; write_report
  say ""
  say "=== KHÔNG CÀI GÌ ==="
  if [ "$MAKE_VIDEO" = "2" ]; then
    say "Video làm bằng AI trên mạng ngay trong app (tính phí theo nhà cung cấp) – máy này không cần cài gì."
    say "Muốn làm video bản đồ/quy hoạch trên máy này: $RERUN, chọn [1]."
  else
    say "Máy dựng video chỉ cần khi dựng video ngay trên máy tính này. Các việc khác (khách hàng, nội dung, lịch, Video AI trên mạng…)"
    say "dùng app trên trình duyệt hoặc điện thoại, không cần cài gì. Muốn làm video sau: $RERUN, chọn [1] hoặc [2]."
  fi
  if [ -n "$WEB_APP" ]; then
    say "Mở app: $WEB_APP"
    if [ "$CI_MODE" != "1" ] && [ "$DRY" != "1" ]; then open "$WEB_APP/" 2>/dev/null || true; fi
  else
    say "Mở app trên trình duyệt như mọi khi."
  fi
  pause_close
  exit 0
fi
MAKE_VIDEO_JSON="true"
done_step ok "Có – dựng video trên máy này: cài Máy dựng video"

# ---------------- B1. Máy + thư mục ----------------
step B1 "Kiểm tra máy và thư mục cài"
ARCH="$(uname -m)"
[ "$(sysctl -n sysctl.proc_translated 2>/dev/null)" = "1" ] && ARCH="arm64"        # Terminal chạy qua Rosetta trên chip Apple
[ "$(uname -s)" = "Darwin" ] || fail "Lỗi B1: tệp này dành cho Mac"
OS_MAJOR="${OS_VER%%.*}"
case "$OS_MAJOR" in ''|*[!0-9]*) OS_MAJOR=0 ;; esac
[ "$OS_MAJOR" -lt 11 ] && fail "Lỗi B1: macOS $OS_VER quá cũ (cần macOS 11 Big Sur trở lên) – cập nhật macOS rồi chạy lại"
case "$ENGINE_DIR" in
  */AppTranslocation/*) fail "Lỗi B1: macOS đang chạy bộ cài từ chỗ tạm chỉ đọc – kéo thư mục BDS_Studio_Engine vào Tài liệu (Documents) rồi chạy lại" ;;
esac
if ! { touch "$ENGINE_DIR/.w_test" && rm -f "$ENGINE_DIR/.w_test"; } 2>/dev/null; then
  fail "Lỗi B1: không ghi được vào thư mục BDS_Studio_Engine – kéo cả thư mục BDS_Studio_Engine vào Tài liệu (Documents) rồi chạy lại"
fi
FREE_KB="$(df -Pk "$HOME" | awk 'NR==2 {print $4}')"; FREE_GB=$(( ${FREE_KB:-0} / 1048576 ))
[ "$FREE_GB" -lt 1 ] && fail "Lỗi B1: ổ đĩa còn dưới 1 GB – xoá bớt tệp rồi chạy lại"
# Gatekeeper – tương đương bước Unblock-File của Windows: Archive Utility gắn cờ com.apple.quarantine cho MỌI tệp giải nén từ
# zip tải về → bấm đúp tệp chưa ký bị chặn. Gỡ cờ cho cả thư mục cài + nút "Cai dat voi 1 click" (ở ngoài _he_thong).
QUAR_MSG=""
if [ "$DRY" != "1" ]; then
  if xattr -p com.apple.quarantine "$ENGINE_DIR/install_mac.command" >/dev/null 2>&1 \
     || { [ -n "$CLICK_PATH" ] && xattr -p com.apple.quarantine "$CLICK_PATH" >/dev/null 2>&1; }; then
    QUAR_MSG=" · đã gỡ cờ \"tải từ Internet\" (Gatekeeper)"
  fi
  xattr -dr com.apple.quarantine "$ENGINE_DIR" 2>/dev/null || true     # gỡ cờ "tải từ Internet" của các tệp trong bộ cài
  chmod +x "$ENGINE_DIR"/*.command 2>/dev/null || true
  if [ -n "$CLICK_PATH" ]; then
    xattr -d com.apple.quarantine "$CLICK_PATH" 2>/dev/null || true; chmod +x "$CLICK_PATH" 2>/dev/null || true
  fi
fi
CHIP="$(sysctl -n machdep.cpu.brand_string 2>/dev/null)"
if [ "$FREE_GB" -lt 5 ]; then done_step warn "macOS $OS_VER · $CHIP ($ARCH) · ổ trống chỉ $FREE_GB GB (nên ≥ 5 GB để dựng video)$QUAR_MSG"
else done_step ok "macOS $OS_VER · $CHIP ($ARCH) · ổ trống $FREE_GB GB$QUAR_MSG"; fi

# ---------------- B2. Python ----------------
step B2 "Python 3 (ngôn ngữ chạy máy dựng)"
if [ "${BDS_PYTHON_SOURCE:-auto}" != "portable" ] && py_ok "$VPY"; then PY="$VPY"; PY_SRC="venv"; else find_python; fi
if [ -n "$PY" ]; then
  PY_VER="$("$PY" -c 'import platform; print(platform.python_version())')"
  done_step ok "Đã có Python $PY_VER ($PY_SRC)"
elif [ "$DRY" = "1" ]; then
  done_step dry "Sẽ cài Python 3.12 (Homebrew nếu có, không thì bản riêng ~45 MB, không cần mật khẩu máy)"
else
  if [ "${BDS_PYTHON_SOURCE:-auto}" = "auto" ] && command -v brew >/dev/null 2>&1; then
    say "   … Homebrew đang cài Python (1–3 phút)"
    brew install python@3.12 >/dev/null 2>&1 || say "   ⚠ Homebrew chưa cài được Python – dùng bản riêng"
    find_python
  fi
  if [ -z "$PY" ]; then
    if [ "$ARCH" = "arm64" ]; then PBS_F="$PBS_ARM"; PBS_SHA="$PBS_ARM_SHA"; else PBS_F="$PBS_X64"; PBS_SHA="$PBS_X64_SHA"; fi
    PBS_TGZ="$DL_DIR/python-$ARCH.tar.gz"
    say "   … tải Python 3.12 bản riêng (~45 MB) vào $PORTABLE_PY"
    download "$PBS_BASE/$PBS_F" "$PBS_TGZ" "$PBS_SHA" || fail "Lỗi B2: không tải được Python – kiểm tra mạng, bấm chạy lại"
    rm -rf "$PORTABLE_PY.tmp"; mkdir -p "$PORTABLE_PY.tmp"
    if ! tar -xzf "$PBS_TGZ" -C "$PORTABLE_PY.tmp"; then rm -f "$PBS_TGZ"; fail "Lỗi B2: tệp Python tải về bị hỏng – bấm chạy lại"; fi
    rm -rf "$PORTABLE_PY"; mv "$PORTABLE_PY.tmp/python" "$PORTABLE_PY"; rm -rf "$PORTABLE_PY.tmp"
    xattr -dr com.apple.quarantine "$PORTABLE_PY" 2>/dev/null || true
    if py_ok "$PORTABLE_PY/bin/python3"; then PY="$PORTABLE_PY/bin/python3"; PY_SRC="portable"; fi
    rm -f "$PBS_TGZ"
  fi
  if [ -z "$PY" ]; then
    [ "$CI_MODE" = "1" ] || open "https://www.python.org/downloads/macos/"
    fail "Lỗi B2: chưa cài được Python – kiểm tra mạng, bấm chạy lại (hoặc cài Python từ python.org rồi chạy lại)"
  fi
  PY_VER="$("$PY" -c 'import platform; print(platform.python_version())')"
  done_step ok "Đã cài Python $PY_VER ($PY_SRC)"
fi

# ---------------- B8. Quét nhanh + chọn cách xử lý video ----------------
# Chạy NGAY sau B2 (trước ffmpeg): biết hạng máy rồi mới cài phần video nặng. Phần hỏi/lưu/hẹn giờ ở app/videomode.py
# (dùng chung với bộ cài Windows) – gọi bằng Python gốc vừa có ở B2, KHÔNG bắt đầu ra (để hiện câu hỏi + đọc phím).
step B8 "Quét nhanh máy + chọn cách xử lý video"
VIDEO_PACK_ON=1; [ "$PACK_FLAG" = "no" ] && VIDEO_PACK_ON=0    # đã chọn "Có – dựng trên máy": cài gói trừ khi B8 chọn [1] hoặc --no-video
VM_OUT="$DATA_DIR/install_video_choice.txt"
VM_ARGS=(-u app/videomode.py choose --out "$VM_OUT")
[ "$DRY" = "1" ] && VM_ARGS+=(--dry)
[ "$CI_MODE" = "1" ] && VM_ARGS+=(--ci)
[ "$ASK_VIDEO" = "1" ] && VM_ARGS+=(--ask)
[ -n "$PACK_FLAG" ] && VM_ARGS+=(--pack "$PACK_FLAG")
rm -f "$VM_OUT"
if [ -n "$PY" ]; then PYTHONIOENCODING=utf-8 "$PY" "${VM_ARGS[@]}" || true; fi
if read_vm "$VM_OUT"; then
  VIDEO_MODE="$VM_MODE"; VIDEO_PACK="$VM_PACK"; [ -n "$VM_TIER" ] && TIER="$VM_TIER"
  if [ "$VM_PACK" = "install" ]; then VIDEO_PACK_ON=1; else VIDEO_PACK_ON=0; fi
  done_step "$VM_STATUS" "$VM_MSG"
elif [ "$DRY" = "1" ] && [ -z "$PY" ]; then
  VIDEO_MODE="online"; VIDEO_PACK="install"
  done_step dry "Sẽ quét nhanh máy rồi hỏi: [4] Dựng video trên máy / [2] Dựng + AI ngay trên máy (máy Mạnh) / [1] Thôi – chỉ AI trên mạng"
else
  VIDEO_MODE="online"; if [ "$VIDEO_PACK_ON" = "1" ]; then VIDEO_PACK="install"; else VIDEO_PACK="skip"; fi
  done_step warn "Chưa quét nhanh được máy – dựng video trên máy như đã chọn ([4]); hạng máy xem lại ở B7"
fi
# B8 [1] "Thôi – chỉ làm video bằng AI trên mạng" (máy yếu mặc định) hoặc --no-video: DỪNG ở đây – không .venv, không ffmpeg, không lối tắt.
if [ "$VIDEO_PACK_ON" != "1" ]; then
  VIDEO_MODE="online"; VIDEO_PACK="skip"
  FINISHED="$(now_iso)"; CUR_ID=""; write_report
  say ""
  say "=== KHÔNG CÀI THÊM ==="
  say "Video làm bằng AI trên mạng ngay trong app (tính phí theo nhà cung cấp) – không dựng video trên máy này."
  say "Muốn làm video bản đồ/quy hoạch trên máy này: $RERUN, chọn [1] rồi [4] (thêm --chon-video để hỏi lại)."
  if [ -n "$WEB_APP" ]; then
    say "Mở app: $WEB_APP"
    if [ "$CI_MODE" != "1" ] && [ "$DRY" != "1" ]; then open "$WEB_APP/" 2>/dev/null || true; fi
  else
    say "Mở app trên trình duyệt như mọi khi."
  fi
  pause_close
  exit 0
fi
deps_plan     # bảng "cần cài gì · dung lượng · thời gian" theo deps_video.json, trước mọi lần tải

# ---------------- B3. ffmpeg ----------------
step B3 "ffmpeg – Bộ công cụ dựng video"
FF_MODE="${BDS_FFMPEG_SOURCE:-auto}"
if [ "$VIDEO_PACK_ON" = "1" ]; then
  if [ "$FF_MODE" = "static" ]; then
    if ff_ok "$BIN_DIR/ffmpeg" && ff_ok "$BIN_DIR/ffprobe"; then FF="$BIN_DIR/ffmpeg"; FF_SRC="static"; fi
  elif find_ffmpeg; then FF_SRC="existing"; fi
fi
if [ "$VIDEO_PACK_ON" = "0" ]; then
  # Không chọn Bộ công cụ dựng video → KHÔNG tải gì (kể cả máy Khá/Mạnh). ffmpeg có sẵn từ trước thì để nguyên, không đụng.
  FF_SRC="skipped"
  done_step skipped "Bỏ qua – Bộ công cụ dựng video chưa cài (không chọn): cài sau trong app (Video › Bộ công cụ dựng video › Cài ngay) hoặc chạy lại bộ cài với --video"
elif [ -n "$FF" ]; then
  FF_VER="$("$FF" -version 2>/dev/null | head -n 1 | awk '{print $3}')"
  done_step ok "Đã có ffmpeg $FF_VER ($FF)"
elif [ "$DRY" = "1" ]; then
  if [ "$FF_MODE" = "auto" ] && command -v brew >/dev/null 2>&1; then FF_HOW="Homebrew, dự phòng bản tĩnh"; else FF_HOW="bản tĩnh ~80 MB"; fi
  done_step dry "Sẽ cài ffmpeg ($FF_HOW)"
else
  if [ "$FF_MODE" != "static" ] && command -v brew >/dev/null 2>&1; then
    say "   … Homebrew đang cài ffmpeg (có thể 5–15 phút, cứ để chạy)"
    if brew install ffmpeg >/dev/null 2>&1 && find_ffmpeg; then FF_SRC="homebrew"; else say "   ⚠ Homebrew chưa cài được ffmpeg – dùng bản tĩnh"; fi
  fi
  if [ -z "$FF" ] && [ "$FF_MODE" != "brew" ] && install_static_ffmpeg; then FF="$BIN_DIR/ffmpeg"; fi
  [ -n "$FF" ] || fail "Lỗi B3: không tải được ffmpeg – kiểm tra mạng, bấm chạy lại"
  FF_VER="$("$FF" -version 2>/dev/null | head -n 1 | awk '{print $3}')"
  done_step ok "Đã cài ffmpeg $FF_VER ($FF_SRC)"
fi

# ---------------- B4. .venv + thư viện ----------------
step B4 "Môi trường riêng + thư viện Python của máy dựng"
REQ_SHA="$(shasum -a 256 requirements.txt | awk '{print $1}')"
venv_ready() { py_ok "$VPY" && [ "$(cat "$ENGINE_DIR/.venv/.bds_req_sha256" 2>/dev/null)" = "$REQ_SHA" ] && "$VPY" -c 'import PIL, numpy' >/dev/null 2>&1; }
if venv_ready; then
  done_step ok "Đã có (.venv, thư viện đúng requirements.txt)"
elif [ "$DRY" = "1" ]; then
  done_step dry "Sẽ tạo .venv và cài: $(tr '\n' ' ' < requirements.txt)"
else
  if [ -d .venv ] && ! py_ok "$VPY"; then say "   … .venv cũ bị hỏng (Python gốc đã đổi/xoá) – tạo lại"; rm -rf .venv; fi
  if [ ! -x "$VPY" ]; then "$PY" -m venv .venv || fail "Lỗi B4: không tạo được môi trường .venv – bấm chạy lại"; fi
  "$VPY" -m pip install --disable-pip-version-check --no-input -q --upgrade pip >/dev/null 2>&1 || true
  say "   … cài thư viện (1–3 phút)"
  pipi() { "$VPY" -m pip install --disable-pip-version-check --no-input -q "$@"; }
  if pipi -r requirements.txt || pipi -r requirements.txt; then
    echo "$REQ_SHA" > .venv/.bds_req_sha256
    done_step ok "Đã cài thư viện vào .venv"
  elif pipi "pillow>=10.0" "numpy>=1.26"; then
    done_step warn "Đã cài phần bắt buộc; thiếu thư viện phụ (keyring/pyzipper) – chạy lại bộ cài khi mạng ổn định"
  else
    fail "Lỗi B4: không cài được thư viện Python – kiểm tra mạng, bấm chạy lại"
  fi
fi

# ---------------- B5. Biểu tượng ----------------
# "BDS Studio.app" (biểu tượng ngôi nhà vàng) ở ~/Applications + liên kết trên màn hình nền: bấm là máy dựng chạy nền
# và mở trình duyệt, KHÔNG hiện cửa sổ Terminal (app/mac_app.py). Cài lại → thay gói cũ, xoá lối tắt "BDS Studio.command" cũ.
# Không tạo được gói → dự phòng lối tắt .command như bản cũ (mở có cửa sổ Terminal) – vẫn gắn biểu tượng BDS Studio.
# Thêm "Tắt máy dựng BDS Studio.app" (Launchpad) như mục Start Menu của Windows; gắn biểu tượng cho nút cài + start_mac.command.
step B5 "Biểu tượng 'BDS Studio' (màn hình nền + Launchpad)"
APP_PATH="$HOME/Applications/BDS Studio.app"
LAUNCHER="$HOME/Desktop/BDS Studio.command"
STOP_HINT="tắt bằng Terminal: bash ~/Applications/BDS\\ Studio.app/Contents/Resources/launcher --stop"
icon_log() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$DATA_DIR/install_shortcut.log" 2>/dev/null; }
stamp_icon() {   # stamp_icon main|install TỆP – gắn biểu tượng BDS Studio cho tệp khách bấm (lỗi chỉ ghi nhật ký)
  [ -e "$2" ] || return 0
  if set_file_icon "$(icon_image "$1")" "$2"; then icon_log "biểu tượng: $2"; else icon_log "chưa gắn được biểu tượng: $2"; fi
}
if [ "$DRY" = "1" ]; then
  done_step dry "Sẽ tạo $APP_PATH (biểu tượng ngôi nhà vàng, mở không hiện cửa sổ Terminal) + lối tắt trên màn hình nền + '$STOP_NAME' (Launchpad)"
else
  APP_RC=0
  APP_LINE="$(PYTHONIOENCODING=utf-8 "$VPY" app/mac_app.py --engine "$ENGINE_DIR" 2>>"$DATA_DIR/install_shortcut.log")" || APP_RC=$?
  if [ "$APP_RC" = "0" ] || [ "$APP_RC" = "3" ]; then
    STOP_RC=0; make_stop_app || STOP_RC=$?
    case "$STOP_RC" in
      0) APP_LINE="$APP_LINE + '$STOP_NAME' (Launchpad)" ;;
      3) APP_LINE="$APP_LINE + '$STOP_NAME' (chưa có biểu tượng)"; APP_RC=3 ;;
      2) APP_LINE="$APP_LINE – đã có '$STOP_NAME.app' không phải do bộ cài tạo (để nguyên; $STOP_HINT)"; APP_RC=3 ;;
      *) APP_LINE="$APP_LINE – chưa tạo được '$STOP_NAME' ($STOP_HINT)"; APP_RC=3 ;;
    esac
    if [ "$APP_RC" = "0" ]; then done_step ok "$APP_LINE"; else done_step warn "$APP_LINE"; fi
  elif mkdir -p "$HOME/Desktop" 2>/dev/null && printf '#!/bin/bash\n# Mở máy dựng BDS Studio (bộ cài tạo)\ncd %q && exec ./start_mac.command\n' "$ENGINE_DIR" > "$LAUNCHER" 2>/dev/null; then
    chmod +x "$LAUNCHER"; xattr -d com.apple.quarantine "$LAUNCHER" 2>/dev/null || true
    stamp_icon main "$LAUNCHER"
    done_step warn "${APP_LINE:-Không tạo được BDS Studio.app} – đã tạo lối tắt 'BDS Studio.command' (mở có cửa sổ Terminal)"
  else
    done_step warn "Không tạo được lối tắt – mở máy dựng bằng start_mac.command trong thư mục BDS_Studio_Engine"
  fi
  stamp_icon install "$CLICK_PATH"; stamp_icon main "$ENGINE_DIR/start_mac.command"; stamp_icon install "$ENGINE_DIR/install_mac.command"
fi

# ---------------- B6. Bật thử máy dựng ----------------
step B6 "Bật thử máy dựng tại máy (127.0.0.1)"
if [ "$DRY" = "1" ]; then
  done_step dry "Sẽ bật thử máy dựng ở cổng tạm rồi tắt"
else
  TEST_PORT="$("$VPY" -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')"
  PYTHONIOENCODING=utf-8 "$VPY" app/server.py --no-browser --port "$TEST_PORT" > "$DATA_DIR/install_server_test.log" 2>&1 &
  SRV_PID=$!
  HEALTH=""
  for _ in $(seq 1 40); do
    HEALTH="$(curl -s --noproxy "*" --max-time 2 "http://127.0.0.1:$TEST_PORT/health" 2>/dev/null || true)"
    case "$HEALTH" in *bds-studio-engine*) break ;; esac
    kill -0 "$SRV_PID" 2>/dev/null || break
    sleep 0.5
  done
  kill "$SRV_PID" 2>/dev/null; wait "$SRV_PID" 2>/dev/null
  case "$HEALTH" in
    *bds-studio-engine*) done_step ok "Máy dựng chạy được (đã tắt bản thử)" ;;
    *) fail "Lỗi B6: máy dựng không bật được – xem $DATA_DIR/install_server_test.log, bấm chạy lại" ;;
  esac
fi

# ---------------- B7. Quét máy ----------------
step B7 "Quét cấu hình máy (xếp hạng Cơ bản / Khá / Mạnh)"
if [ "$DRY" = "1" ]; then
  if [ "$BENCH" = "1" ]; then done_step dry "Sẽ quét CPU, RAM, GPU, ổ trống + đo thử dựng 10 giây"; else done_step dry "Sẽ quét CPU, RAM, GPU, ổ trống"; fi
else
  BARG="--no-bench"
  if [ "$BENCH" = "1" ] && [ "$VIDEO_PACK_ON" = "1" ] && [ -n "$FF" ]; then BARG="--bench"; say "   … đo thử dựng 10 giây video"; fi
  if LINE="$(PYTHONIOENCODING=utf-8 "$VPY" app/hwscan.py --save "$BARG" 2>/dev/null)"; then
    TIER="$("$VPY" -c 'import sys; sys.path.insert(0, "app"); import hwscan; print((hwscan.load() or {}).get("tier", ""))' 2>/dev/null)"
    done_step ok "$LINE"
  else
    done_step warn "Chưa quét được máy – mở app: Cài đặt → Máy của tôi → Quét lại máy"
  fi
fi

# ---------------- B9. Video AI offline (chỉ khi B8 chọn Offline) ----------------
# Cài thư viện chạy mô hình bằng ĐÚNG hàm của app (videoai.run_setup) rồi nạp thử; lỗi → chuyển Online, báo ⚠ (không dừng bộ cài).
step B9 "Video AI offline (thư viện chạy mô hình)"
if [ "$VIDEO_MODE" != "offline" ]; then
  if [ "$VIDEO_MODE" = "later" ]; then done_step skipped "Không cần – chọn để sau"; else done_step skipped "Không cần – Video AI chạy online"; fi
elif [ "$DRY" = "1" ]; then
  done_step dry "Sẽ cài thư viện chạy mô hình (torch + diffusers…) vào .venv rồi nạp thử"
else
  rm -f "$VM_OUT"
  VM_ARGS=(-u app/videomode.py offline --out "$VM_OUT")
  [ "$CI_MODE" = "1" ] && VM_ARGS+=(--ci)
  PYTHONIOENCODING=utf-8 "$VPY" "${VM_ARGS[@]}" || true
  if read_vm "$VM_OUT"; then
    [ -n "$VM_MODE" ] && VIDEO_MODE="$VM_MODE"
    done_step "$VM_STATUS" "$VM_MSG"
  else
    VIDEO_MODE="online"
    done_step warn "Lỗi B9: chưa cài được Video AI offline – tạm dùng Video AI Online (xem install_videoai.log, chạy lại bộ cài với --chon-video)"
  fi
fi

deps_manifest_hook
# Dựng thử 3 giây có phụ đề tiếng Việt – chỉ khi đã có Bộ công cụ dựng video (không chọn gói → không có ffmpeg để dựng).
if [ "$DRY" = "1" ]; then
  if [ "$VIDEO_PACK_ON" = "1" ]; then say "   ○ (chạy thử) Sẽ dựng thử 3 giây có phụ đề tiếng Việt (kết quả vào báo cáo)"; fi
elif [ "$VIDEO_PACK_ON" = "1" ] && [ -n "$FF" ]; then
  say ""
  say "Dựng thử 3 giây có phụ đề tiếng Việt…"
  run_selftest
  case "$SELFTEST_JSON" in
    *'"status": "ok"'*|*'"status":"ok"'*) say "   ✓ Dựng thử được – video mẫu: $DATA_DIR/install_selftest.mp4" ;;
    *) say "   ⚠ Dựng thử 3 giây chưa được – xem $DATA_DIR/install_selftest.log; trong app: Video › Tự kiểm tra › Tự sửa phần thiếu" ;;
  esac
else
  SELFTEST_JSON="{\"status\":\"skipped\",\"message\":\"Chưa cài Bộ công cụ dựng video – không dựng thử\"}"
fi
FINISHED="$(now_iso)"; CUR_ID=""; write_report
say ""
if [ "$DRY" = "1" ]; then
  say "=== CHẠY THỬ XONG – báo cáo: $REPORT ==="
  exit 0
fi
"$VPY" -c "
import sys; sys.path.insert(0, 'app'); import selfcheck
for i in selfcheck.check():
    print(('  ✓ ' if i['ok'] else ('  ✗ ' if i['required'] else '  ○ ')) + i['name'] + ('' if i['ok'] else ' – ' + i['fix']))
" 2>/dev/null
say ""
say "=== XONG BỘ CÀI MÁY DỰNG VIDEO. Phần mở rộng (AI trên máy…) cài sau trong app. Báo cáo: $REPORT ==="
if [ "$VIDEO_PACK_ON" = "0" ]; then say "Bộ công cụ dựng video chưa cài (tuỳ chọn) – cần dựng video trên máy: mở app › Video › Bộ công cụ dựng video › \"Cài ngay\"."; fi
if [ "$LAUNCH" = "1" ]; then
  say "Đang mở BDS Studio… (lần sau: bấm đúp 'BDS Studio' trên màn hình nền hoặc trong Launchpad)"
  if [ -x "$APP_PATH/Contents/Resources/launcher" ] && open "$APP_PATH" 2>/dev/null; then
    say "Máy dựng chạy nền (không có cửa sổ Terminal) – đóng cửa sổ này được. Tắt máy dựng: Launchpad → $STOP_NAME."
    say "Lần đầu macOS hỏi quyền vào thư mục → bấm Cho phép (OK)."
    exit 0
  fi
  exec ./start_mac.command
fi
exit 0
