# Bộ cài Máy dựng video BDS Studio

> **Không làm video trên máy tính này? Không cần cài gì.** Mở app trên trình duyệt hoặc điện thoại (bản mua: địa chỉ web app của anh/chị). Bộ cài này chỉ dành cho máy **dựng video**. Chạy bộ cài mà chọn **[2] Chỉ dùng AI trên mạng** hoặc **[3] Không làm video** ở câu hỏi đầu tiên thì bộ cài không cài gì, chỉ mở web app.

Máy dựng chạy trên máy tính của anh (Mac hoặc Windows), chỉ máy đó dùng được, không mở ra Internet.
Video làm xong nằm ở thư mục **BDS Studio → Video** trong thư mục cá nhân.

## Máy chủ Google (làm 1 lần, trước khi dùng app)
Máy chủ của app là một Sheet + Apps Script nằm trong Google của chính anh/chị. Cách dễ nhất: mở app → **Trợ lý cài đặt** → bước **Tạo máy chủ** → bấm **Tạo bản sao** → trong Sheet: **BDS Studio › Cài đặt** → **Cho phép** → làm theo hộp **Triển khai máy chủ** (6 cú bấm) → bấm **Mở BDS Studio và kết nối** (app tự nối).
Cách dự phòng (chưa có link Tạo bản sao) – 3 tệp trong thư mục `cai_tay/` của thư mục này (Trợ lý cũng có nút **Chép** từng tệp):
1. Mở <https://sheets.new> bằng đúng tài khoản Google sẽ giữ dữ liệu → đặt tên **BDS Studio – Dữ liệu**.
2. Trên Sheet: **Tiện ích mở rộng › Apps Script** (Extensions › Apps Script).
3. Bấm tệp **Mã.gs** (Code.gs) ở cột trái → Ctrl+A → dán nội dung `cai_tay/TatCa.gs` (mở bằng Notepad/TextEdit) → đổi tên tệp thành `TatCa`.
4. **+** › **Tập lệnh** (Script) → tên `CaiDat` → dán `cai_tay/CaiDat.gs`.
5. Bánh răng **Cài đặt dự án** → tick **Hiện tệp kê khai "appsscript.json"** → quay lại **< >** → bấm `appsscript.json` → Ctrl+A → dán `cai_tay/appsscript.json` → **Lưu**.
6. Quay lại Sheet → tải lại (F5) → **BDS Studio › Cài đặt** → làm như cách dễ nhất ở trên.

Không dùng Apps Script API: dự án Google Cloud mặc định do Google giữ, người dùng không bật được – bộ cài cũ `CaiMayChu.gs` đã bỏ. Sheet máy chủ không được chia sẻ cho ai.

## Bộ cài Máy dựng video cài gì
**Câu hỏi đầu tiên** (trước Python, trước mọi thứ) – *"Anh/chị có làm video trên máy tính này không?"*:
- **[1] Có – dựng video trên máy này** (video bản đồ/quy hoạch miễn phí; cài công cụ dựng ~150–300 MB) – hoặc `--video`, `BDS_MAKE_VIDEO=1`: cài như dưới. Máy đã có Máy dựng video thì chạy lại không hỏi câu này.
- **[2] Chỉ dùng AI trên mạng – không cài gì lên máy** (AI tính phí theo nhà cung cấp; không làm được video bản đồ/quy hoạch trên máy này) – `BDS_MAKE_VIDEO=online`. Không ai trả lời trong 60 giây → **[2]**.
- **[3] Không làm video – không cài gì** – `BDS_MAKE_VIDEO=0`.
- [2]/[3]: bộ cài **không kiểm, không cài Python**, không tạo `.venv`, không ffmpeg, không biểu tượng; mở trang đầu web app (bản mua) rồi thoát; báo cáo ghi `"video": false` ([2] thêm `"video_mode": "online"`). Muốn dựng video bản đồ/quy hoạch sau: chạy lại bộ cài, chọn [1].

Chọn [1]: bộ cài cài **đủ mọi thứ dựng video cần** theo `deps_video.json` (danh sách phụ thuộc theo từng cách làm video – dùng chung Windows/Mac): Python 3.12 trở lên (môi trường riêng `.venv`), thư viện (Pillow, numpy…), **ffmpeg** (dựng video bản đồ/quy hoạch), máy dựng chạy tại máy và biểu tượng **BDS Studio** (ngôi nhà vàng). Trước khi tải, bộ cài in bảng **cần cài gì · dung lượng · thời gian**; mục đã có thì bỏ qua. Cuối cùng bộ cài bật thử máy dựng, **quét cấu hình máy** (xếp hạng Cơ bản / Khá / Mạnh) và **dựng thử 3 giây có phụ đề tiếng Việt** (video mẫu `~/.bds_studio/install_selftest.mp4`; ĐẠT/LỖI từng mục, cách sửa và câu chạy lại ở mục `selftest` của báo cáo).
Phần mở rộng (AI soạn bài trên máy, tạo ảnh AI) **không** nằm trong bộ cài – cài sau trong app khi cần. Video AI chạy trên máy chỉ cài khi chọn **[2] Dựng + AI ngay trên máy** ở bước B8.

Thứ tự chạy: **B1 → B2 → B8 → B3 → B4 → B5 → B6 → B7 → B9** (màn hình đánh số `[1/9] … [9/9]` theo thứ tự chạy, kèm mã bước; mã B1–B7 giữ nguyên nghĩa cũ, B8/B9 là bước mới 17/11).
- Không cần mật khẩu quản trị máy. Lần đầu mất khoảng 5–15 phút (tuỳ mạng), tải khoảng 150–300 MB (Python + thư viện + ffmpeg; máy đã có thì ít hơn).
- **Chạy lại bao nhiêu lần cũng được**: bước nào xong rồi thì bỏ qua, tải dở thì tải tiếp. Gặp lỗi → sửa theo dòng "Lỗi Bn" rồi chạy lại.
- Mỗi lần chạy, bộ cài ghi báo cáo vào `~/.bds_studio/install_report.json` (Windows: `C:\Users\<tên>\.bds_studio\install_report.json`). Cần giúp thì gửi tệp này – trong đó không có mật khẩu hay khoá.

### Bước B8 – Quét nhanh máy + chọn cách dựng
Ngay sau khi có Python, bộ cài quét nhanh máy (CPU, RAM, card đồ hoạ/VRAM, ổ trống – cùng cách quét với B7, chưa dựng thử), in kết quả bằng tiếng Việt, giới thiệu Video AI trên mạng (**thu phí riêng, tuỳ mô hình/nhà cung cấp**: Flow/Veo, Veo API, Runway, Kling – app không ghi sẵn giá, báo chi phí trước mỗi lần tạo) rồi hỏi:
- **[4] Dựng video trên máy** – video bản đồ/quy hoạch miễn phí; cài công cụ dựng (~150–300 MB). Video AI vẫn làm trên mạng. Mặc định trên máy Khá/Mạnh. Máy hạng **Cơ bản** kèm cảnh báo: *Máy yếu: video dựng trên máy sẽ không đẹp và giật – chỉ nên dùng để làm video mẫu.*
- **[2] Dựng + AI ngay trên máy (chỉ máy Mạnh)** – như [4], thêm thư viện AI; AI chạy miễn phí nhưng nặng máy. Bộ cài in dung lượng: thư viện chạy mô hình (Mac: tải ~214 MB đo trên PyPI 17/11/2026; Windows: torch bản CUDA cho card NVIDIA tải từ download.pytorch.org – dung lượng hiện khi tải, cộng ~102 MB thư viện còn lại) + mô hình gợi ý theo VRAM (Wan 2.2 TI2V-5B 31,85 GB khi ≥ 24 GB VRAM; Wan 2.1 T2V-1.3B 26,94 GB khi ≥ 8 GB; CogVideoX-2B 12,83 GB – đo trên Hugging Face 17/11/2026). Hỏi thêm: tải mô hình **ngay** hay **để sau** (mặc định để sau – mô hình chỉ tải khi anh/chị xác nhận đúng số GB).
- **[1] Thôi – chỉ làm video bằng AI trên mạng**, không cài thêm gì lên máy (không làm được video bản đồ/quy hoạch trên máy này). Bộ cài **dừng ngay sau B8** – không `.venv`, không ffmpeg, không biểu tượng. Mặc định trên máy **Cơ bản**.

[2] chỉ hiện với máy hạng Mạnh; máy khác bộ cài ghi rõ vì sao không có ("cần card NVIDIA VRAM ≥ 12 GB + RAM ≥ 16 GB, hoặc Mac chip Apple Pro/Max/Ultra bộ nhớ chung ≥ 32 GB; ổ trống ≥ 40 GB").

- Không ai trả lời trong **60 giây** → máy Cơ bản **[1]**, máy Khá/Mạnh **[4]**. `--ci` không hỏi.
- Lựa chọn lưu ở `~/.bds_studio/video_mode.json` (Windows: `C:\Users\<tên>\.bds_studio\video_mode.json`) và trong báo cáo cài (`video_mode`, `video_pack`). App xem/đổi ở **Video AI › AI trên máy** và **Cài đặt › Máy của tôi**.
- **Chạy lại bộ cài giữ lựa chọn dựng trên máy cũ ([4]/[2]), không hỏi lại**; lần trước chọn [1] thì hỏi lại. Muốn chọn lại: chạy với `--chon-video`.
- Tuỳ chọn/biến môi trường (cài hàng loạt, kiểm thử): `BDS_MAKE_VIDEO=1|online|0` (câu hỏi đầu), `--video` (= [1] rồi [4]) / `--no-video` (dừng ở B8), `BDS_VIDEO_MODE=online|offline|later`, `BDS_VIDEO_PACK=1|0`, `BDS_VIDEO_DOWNLOAD=now|later`, `BDS_VIDEO_TIMEOUT=60`.

### Bước B9 – Video AI offline (chỉ khi chọn Offline)
Cài thư viện chạy mô hình (torch + diffusers…) vào `.venv` bằng đúng chức năng "Cài thư viện" của app, in tiến độ pip, rồi **nạp thử thật**. Windows: torch lấy từ kho CUDA chính thức của PyTorch (torch trên PyPI cho Windows chỉ chạy CPU); kho đó lỗi thì cài bản CPU và báo ⚠ (rất chậm). Chọn "tải ngay" thì tải mô hình qua đúng đường tải của app (đo lại dung lượng thật trên Hugging Face; khác số đã báo thì hỏi lại). Chạy lại bộ cài: thư viện đã có thì chỉ nạp thử (nhanh).
**Windows 11 Smart App Control** có thể chặn tệp thư viện chưa ký số của torch. Bộ cài đọc trạng thái (sổ đăng ký `HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy` › `VerifiedAndReputablePolicyState`: 0 tắt, 1 bật, 2 đánh giá) và nếu nạp thử lỗi thì **tự chuyển sang Online**, giải thích cách tắt (Bảo mật Windows › Kiểm soát ứng dụng và trình duyệt › Smart App Control – Microsoft ghi: tắt rồi muốn bật lại phải cài lại Windows).

## Mac (làm 1 lần) – chip Apple (M1–M4) và chip Intel, macOS 11 trở lên
Trong thư mục `BDS_Studio_Engine` chỉ có **một thứ để bấm: `Cai dat voi 1 click`** (tên không dấu); phần ruột nằm trong thư mục `_he_thong` – không cần mở.
1. Giải nén tệp `BDS_Studio_Video_Mac.zip` (bấm đúp – bộ cài riêng cho Mac; app tự đưa đúng tệp theo máy đang mở). Kéo thư mục `BDS_Studio_Engine` vào thư mục **Tài liệu** (Documents) cho gọn.
2. Mở **Terminal** (⌘ + Space, gõ Terminal), gõ `bash ` (có dấu cách), **kéo tệp `Cai dat voi 1 click` thả vào Terminal** → Enter.
3. Câu hỏi đầu: **[1] Có – dựng video trên máy này** (Enter/60 giây = [2] Chỉ dùng AI trên mạng – không cài gì, chỉ mở web app; [3] Không làm video). Chờ các dòng `[1/9] … [9/9]`; ở bước B8 chọn cách dựng (Enter = [4] Dựng video trên máy; máy Cơ bản = [1] Thôi – chỉ AI trên mạng, dừng không cài thêm). Máy chưa có Python 3.12+ thì bộ cài tự tải (Homebrew nếu có, không thì bản riêng – không hỏi mật khẩu); ffmpeg tải khi chọn [4] hoặc [2].
4. Đã chọn dựng trên máy ([4]/[2]): cuối bộ cài **dựng thử 3 giây có phụ đề tiếng Việt** bằng đúng đường dựng của máy dựng → video mẫu `~/.bds_studio/install_selftest.mp4`, kết quả ghi ở mục `selftest` của `install_report.json` (lỗi chỉ ⚠, không dừng bộ cài).
5. Xong, trình duyệt tự mở **trang đầu của app** (lần đầu là Trợ lý cài đặt – xem mục "Biểu tượng mở ở đâu"). Trên màn hình nền có biểu tượng **BDS Studio** (ngôi nhà vàng) – lần sau chỉ cần bấm đúp. Trong **Launchpad** (thư mục Ứng dụng của anh `~/Applications`) có **BDS Studio** và **Tắt máy dựng BDS Studio** (cùng biểu tượng BDS Studio), kéo vào Dock được. Bấm BDS Studio: máy dựng chạy nền, **không hiện cửa sổ Terminal**, trình duyệt tự mở app.
6. Lần đầu bấm biểu tượng, macOS có thể hỏi "BDS Studio muốn truy cập tệp trong thư mục Tài liệu" → bấm **Cho phép** (OK) – máy dựng nằm trong thư mục Tài liệu nên cần quyền này.

**Khách nhìn thấy gì ở mỗi cú bấm (Mac):**
| Bấm | Thấy gì | Biểu tượng |
|---|---|---|
| Tệp zip (bấm đúp) | Archive Utility giải nén ra `BDS_Studio_Engine` | zip (macOS) |
| `Cai dat voi 1 click` kéo vào Terminal | Cửa sổ Terminal: câu hỏi đầu → `[1/9] … [9/9]` | lần đầu: biểu tượng tệp lệnh của macOS (xem TODO dưới); sau lần cài đầu: BDS Studio |
| BDS Studio (màn hình nền / Launchpad / Dock) | Không cửa sổ nào; trình duyệt mở trang đầu app | BDS Studio (ngôi nhà vàng) |
| Tắt máy dựng BDS Studio (Launchpad) | Thông báo "Đã tắt máy dựng BDS Studio." | BDS Studio (biến thể "tắt" khi có bộ ảnh mới) |
| `BDS Studio.command` (chỉ khi không tạo được gói .app) | Cửa sổ Terminal của máy dựng | BDS Studio (gắn bằng NSWorkspace) |

**Cảnh báo của macOS (Gatekeeper) – nói thật:** bộ cài CHƯA được ký bằng chứng chỉ Apple (Apple Developer ID + notarize, khoảng 99 USD/năm – chưa mua). Vì vậy **bấm đúp** `Cai dat voi 1 click` tải từ mạng sẽ bị macOS chặn ("Apple không thể kiểm tra…" / "Not Opened"). Cách an toàn: chạy bằng Terminal như bước 2 (không phải tắt bảo vệ của máy).
- Nếu đã lỡ bấm đúp: bấm **Done**, rồi vào **System Settings → Privacy & Security**, kéo xuống mục Security, bấm **Open Anyway** (theo Apple, nút này chỉ hiện khoảng **1 giờ** sau lần bị chặn; macOS có thể hỏi mật khẩu đăng nhập máy). Từ **macOS 15 Sequoia**, cách cũ **chuột phải (Control-click) → Open không còn vượt Gatekeeper** – Apple bỏ từ bản này. macOS 11–14 vẫn dùng được chuột phải → Mở.
- Cách gỡ cờ bằng tay (tương đương bấm **Unblock** trên Windows): trong Terminal gõ `xattr -dr com.apple.quarantine ` (có dấu cách) rồi kéo thư mục `BDS_Studio_Engine` vào → Enter. Bộ cài tự làm đúng việc này ở bước B1 cho cả thư mục (kể cả `Cai dat voi 1 click` ở ngoài `_he_thong`), nên từ lần thứ hai bấm đúp không bị chặn nữa; dòng B1 ghi "đã gỡ cờ "tải từ Internet" (Gatekeeper)" khi có cờ.
- Biểu tượng `BDS Studio.app` và `Tắt máy dựng BDS Studio.app` do bộ cài **tạo ngay trên máy anh** (không tải từ mạng) nên không mang cờ đó – macOS không chặn, bấm đúp được ngay; gói chỉ được ký tại máy (ký "ad-hoc", không phải chứng chỉ Apple), không cần tắt bảo vệ nào. Máy chip Apple **không** cần cài Rosetta để mở các biểu tượng này (trừ khi dòng B5 báo "cách dự phòng").

**Vì sao nút cài trên Mac là tệp `.command` chứ không phải `.app`** (đã đối chiếu tài liệu Apple 17/11/2026): một `.app` chưa ký Developer ID/notarize bị Gatekeeper chặn **y như** tệp `.command` (cùng hộp "Not Opened", cùng đường Open Anyway) – không đỡ hơn chút nào. Tệ hơn: app tải về chạy lần đầu bị macOS chạy từ **đường dẫn ngẫu nhiên chỉ đọc (App Translocation, macOS 10.12+)** cho tới khi khách tự kéo app sang chỗ khác bằng Finder – app sẽ **không thấy thư mục `_he_thong`** đặt cạnh nó. Ngoài ra gói `.app` phải dựng trên Mac (osacompile); gói dựng trên máy đóng gói Linux mà chương trình chính là script thì Mac chip Apple đòi cài Rosetta. Vì vậy: nút cài = `Cai dat voi 1 click.command`; các biểu tượng mở/tắt máy dựng là `.app` thật do bộ cài dựng **trên máy khách** (không bị chuyển chỗ, không cờ quarantine).
Nguồn: Apple Developer News "Updates to runtime protection in macOS Sequoia" (6/8/2024) – https://developer.apple.com/news/?id=saqachfa ; Apple Support "Safely open apps on your Mac" – https://support.apple.com/102445 ; Mac User Guide "Open a Mac app from an unknown developer" – https://support.apple.com/guide/mac-help/mh40616/mac ; Apple DTS "App Translocation Notes" – https://developer.apple.com/forums/thread/724969 ; Apple DTS "Resolving Trusted Execution Problems" (cờ com.apple.quarantine, Archive Utility gắn cờ cho tệp giải nén) – https://developer.apple.com/forums/thread/706442 ; man xattr(1) trên macOS (`-d` xoá, `-r` cả thư mục).

**Việc còn chờ tích hợp (Mac):**
- ✓ (17/11) Tải riêng từng hệ điều hành (`tools/build_engine_zip.mjs`): `BDS_Studio_Video_Mac.zip` ngoài cùng chỉ có `Cai dat voi 1 click.command` + `Doc truoc.txt` (bản Mac) + `_he_thong/`; `BDS_Studio_Video_Windows.zip` tương tự với `Cai dat voi 1 click.bat`. `BDS_Studio_Engine.zip` (bố cục phẳng cũ) chỉ còn để máy dựng ≤ 1.0.5 tự cập nhật; máy dựng mới tự cập nhật bằng zip đúng hệ điều hành mình. Bộ cài chạy được cả bố cục cũ lẫn mới (nút tự tìm `_he_thong/install_mac.command`, không thấy thì `install_mac.command` cạnh nó).
- Biểu tượng của nút cài **ngay lần bấm đầu** (trước khi bộ cài chạy): zip dựng trên Linux không mang biểu tượng tệp của Mac. Cần thêm mục AppleDouble `__MACOSX/BDS_Studio_Engine/._Cai dat voi 1 click.command` (FinderInfo cờ "custom icon" + resource fork `icns`) – Archive Utility khôi phục khi giải nén. **Chưa làm, có chủ ý (17/11, đã tách zip riêng cho Mac):** chưa có máy Mac để kiểm Archive Utility áp biểu tượng từ mục AppleDouble do Node tự viết (định dạng resource fork + FinderInfo phải đúng từng byte; sai thì khách thấy tệp `._…` lạ hoặc mất quyền chạy) – làm khi có máy Mac thử được. `tools/goi_thu.mjs` và kiểm bản bán đã bỏ qua `__MACOSX` khi đếm thư mục ngoài cùng. Sau lần cài đầu, bộ cài tự gắn biểu tượng cho nút cài (NSWorkspace). ✓ (17/11) Bộ ảnh `.icns` do `tools/icons_build.mjs` sinh, đóng sẵn trong zip: `_he_thong/assets/bds_studio.icns`, `bds_studio_stop.icns`, `bds_studio_install.icns` (bộ cài tự dùng).
- `engine/deps_video.json` (kê phụ thuộc video theo chế độ – thợ khác đang viết): khi có, bộ cài Mac cài theo tệp này cho chế độ đã chọn (bỏ qua mục đã có, in dung lượng trước, mô hình lớn chỉ tải sau khi xác nhận). Hiện bộ cài chỉ ghi `deps_manifest` (`missing` / `present_unused`) vào báo cáo – xem hàm `deps_manifest_hook` trong `install_mac.command`.

## Windows (làm 1 lần) – Windows 10 (bản 1809 trở lên) hoặc Windows 11, 64-bit

> Bộ cài Windows đã được chạy thử trên máy Windows thật. Gặp lỗi thì gửi tệp `install_report.json` (xem trên) để sửa.

1. **Bỏ chặn tệp zip trước khi giải nén** (bắt buộc trên Windows 11 bật *Smart App Control*): bấm chuột phải tệp zip → **Properties** (Thuộc tính) → tick **Unblock** (Bỏ chặn) ở cuối thẻ General → **OK**. Bỏ qua bước này thì Windows 11 có thể hiện "Smart App Control blocked a file that may be unsafe" khi chạy bộ cài – khi đó xoá thư mục đã giải nén, bỏ chặn tệp zip rồi giải nén lại. Không thấy ô Unblock nghĩa là tệp không bị đánh dấu – làm tiếp bình thường.
   Bấm chuột phải tệp zip → **Extract All** (Giải nén tất cả). **Không** chạy ngay trong cửa sổ xem zip. **Không** cần chạy bằng quyền Administrator (chạy bằng quyền quản trị của tài khoản khác sẽ cài máy dựng vào tài khoản đó).
2. Mở thư mục `BDS_Studio_Engine`, bấm đúp **`Cai dat voi 1 click`** (loại tệp *Windows Batch File*; tệp `Cai dat voi 1 click.command` cùng tên là của Mac). Phần ruột nằm trong `_he_thong` – không cần mở; `_he_thong\install_windows.bat` vẫn chạy được như trước.
3. Câu hỏi đầu: **[1] Có – dựng video trên máy này** ([2] Chỉ dùng AI trên mạng / [3] Không làm video: không cài gì). Chờ các dòng `[1/9] … [9/9]` chạy xong; ở bước B8 chọn cách dựng (Enter = [4] Dựng video trên máy; máy Cơ bản = [1] dừng, không cài thêm). Máy chưa có Python 3.12+/ffmpeg thì bộ cài tự cài cho riêng tài khoản của anh (dùng winget nếu có, không thì tải thẳng) – không cần quyền quản trị.
4. Xong, trình duyệt tự mở **trang đầu của app** (lần đầu là Trợ lý cài đặt – xem mục "Biểu tượng mở ở đâu"). Lần sau bấm đúp **BDS Studio** (ngôi nhà vàng) trên màn hình nền hoặc trong **Start Menu → BDS Studio**: máy dựng chạy nền, **không hiện cửa sổ đen**.
   Không chuyển/đổi tên thư mục `BDS_Studio_Engine` sau khi cài (lối tắt trỏ vào `_he_thong`); lỡ chuyển thì bấm lại `Cai dat voi 1 click` ở chỗ mới.

**Khách nhìn thấy gì ở mỗi cú bấm (Windows)** – mọi lối tắt bộ cài tạo đều mang biểu tượng riêng (`_he_thong\assets\*.ico`, sinh bằng `tools/icons_build.mjs`), cài lại thì ghi đè đúng các lối tắt đó:
| Bấm | Thấy gì | Biểu tượng |
|---|---|---|
| `Cai dat voi 1 click` (thư mục `BDS_Studio_Engine`) | Cửa sổ lệnh "Bo cai May dung video BDS Studio": câu hỏi đầu → `[1/9] … [9/9]` | biểu tượng chung của tệp .bat (Windows không cho tệp .bat mang biểu tượng riêng – xem dưới) |
| **BDS Studio** (màn hình nền + Start Menu) | Không cửa sổ; trình duyệt mở trang đầu app | ngôi nhà vàng `bds_studio.ico` |
| Start Menu → **Bật máy dựng BDS Studio** | Cửa sổ "May dung BDS Studio – dong cua so nay la tat may dung" | nhà vàng + huy hiệu xanh lá ▶ `bds_studio_bat.ico` |
| Start Menu → **Tắt máy dựng BDS Studio** | Hộp thông báo "Đã tắt máy dựng BDS Studio." | nhà vàng + huy hiệu đỏ ■ `bds_studio_tat.ico` |
| Start Menu → **Cài đặt lại BDS Studio** | Bộ cài chạy lại (sửa lỗi, cập nhật, chọn lại cách làm video) | nhà vàng + huy hiệu xanh dương ↓ `bds_studio_cai.ico` |
| Start Menu → **Gỡ cài đặt BDS Studio** (hoặc Cài đặt → Ứng dụng → BDS Studio → Gỡ cài đặt) | Hỏi "Gõ 1 để GỠ"; gỡ lối tắt, mục Ứng dụng, `.venv`, Python/ffmpeg bộ cài tải, bộ nhớ tạm – **giữ** dữ liệu `.bds_studio`, mô hình Video AI, video | nhà vàng + huy hiệu xám ✕ `bds_studio_go.ico`; trong Cài đặt → Ứng dụng: ngôi nhà vàng |

Cửa sổ lệnh mở từ lối tắt Start Menu (Bật máy dựng, Cài đặt lại, Gỡ cài đặt) thường hiện biểu tượng của lối tắt trên thanh tiêu đề/thanh tác vụ (cửa sổ lệnh cổ điển conhost lấy biểu tượng từ lối tắt đã mở nó); máy đặt **Windows Terminal** làm cửa sổ lệnh mặc định (Windows 11 22H2+) thì hiện biểu tượng của Windows Terminal – không đổi được từ tệp .bat. Tiêu đề cửa sổ thì luôn đặt được (lệnh `title`).

**Vì sao nút cài là tệp .bat (không mang biểu tượng riêng)** – đã cân nhắc 17/11:
- Biểu tượng của tệp .bat do Windows quyết theo **loại tệp** (mọi .bat cùng một biểu tượng) – không tệp .bat nào tự mang biểu tượng riêng được.
- Lối tắt `.lnk` "Cai dat voi 1 click" trong zip (đích `%COMSPEC% /c …`, thư mục bắt đầu để trống): **không dùng**. (1) Smart App Control chặn tệp .lnk tải từ mạng **giống hệt** .bat (Microsoft công bố 2022 – danh sách gồm cả .lnk, .bat, .cmd), nên không đỡ được cảnh báo nào; (2) lối tắt trỏ `cmd.exe` kèm tham số nằm trong zip là đúng mẫu mã độc phổ biến – phần mềm diệt virus/Defender dễ chặn nhầm cả gói (nhóm phát hiện kiểu Trojan:Win32/WinLNK); (3) đường dẫn biểu tượng của .lnk là đường dẫn tuyệt đối – giải nén ở thư mục khác thì mất biểu tượng; chưa có máy Windows để kiểm cách Windows tìm đường dẫn tương đối. Tệp .exe bọc ngoài chưa ký số: không dùng (SmartScreen/Smart App Control chặn nặng hơn).
- `desktop.ini` cho thư mục `BDS_Studio_Engine` hiện ngôi nhà vàng: Microsoft yêu cầu thư mục mang thuộc tính *Read-only* hoặc *System* (PathMakeSystemFolder / `attrib +s`) – giải nén zip không đặt thuộc tính này nên không có tác dụng trước lần cài đầu, mà lại hiện thêm tệp `desktop.ini` lạ cho khách.
- Vì vậy: tên rõ ràng không dấu `Cai dat voi 1 click` + `Doc truoc.txt`; mọi thứ khách bấm **sau** lần đầu đều có biểu tượng riêng.
Nguồn: Microsoft Learn "How to Customize Folders with Desktop.ini" – https://learn.microsoft.com/en-us/windows/win32/shell/how-to-customize-folders-with-desktop-ini ; TechRadar / OnMSFT (8/2022, David Weston – Microsoft: Smart App Control chặn .lnk/.iso… có Mark of the Web) – https://www.techradar.com/news/windows-11-has-a-new-way-to-protect-you-from-your-own-bad-judgement ; Elastic Security Labs "Dismantling Smart App Control" (SmartScreen/SAC kiểm .lnk có Mark of the Web, CVE-2024-38217) – https://www.elastic.co/security-labs/dismantling-smart-app-control ; Microsoft Learn STARTUPINFO › STARTF_TITLEISLINKNAME (Windows truyền đường dẫn lối tắt .lnk cho cửa sổ lệnh khi mở từ lối tắt) – https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-startupinfow (cách conhost dùng nó để lấy biểu tượng: theo mã ReactOS, chưa kiểm trên máy Windows thật)

**Cảnh báo của Windows (SmartScreen) – nói thật:** bộ cài CHƯA được ký bằng chứng chỉ ký mã (chứng chỉ có phí, chưa mua – cần tra giá khi muốn bỏ cảnh báo). Windows có thể hiện:
- "Windows protected your PC" → bấm **More info** → **Run anyway**.
- "Open File – Security Warning" → bấm **Run**.
Phần mềm diệt virus đôi khi nghi ngờ tệp .bat/.ps1 mới; nếu bị chặn, cho phép thư mục `BDS_Studio_Engine` rồi chạy lại. Bộ cài chỉ chạy PowerShell với quyền bỏ qua chính sách **cho đúng lần chạy đó**, không đổi cài đặt bảo mật của máy. Máy công ty bị quản trị viên khoá chạy script (chính sách nhóm) → bộ cài báo **Lỗi B0**: nhờ bộ phận IT cho phép, hoặc cài trên máy cá nhân. Gõ `.\install_windows.bat` trong Windows Terminal / PowerShell 7 cũng được – bộ cài tự dùng Windows PowerShell có sẵn của máy.

## Mã lỗi của bộ cài
| Mã | Bước | Thường gặp → cách sửa |
|---|---|---|
| B0 | Chính sách chạy script (Windows) | Máy công ty khoá PowerShell → nhờ IT, hoặc dùng máy cá nhân |
| B1 | Kiểm tra máy và thư mục | Hệ điều hành quá cũ; chưa giải nén; thư mục không ghi được (chép `BDS_Studio_Engine` vào Tài liệu); ổ đầy |
| B2 | Python | Mất mạng giữa chừng → chạy lại; vẫn lỗi thì cài Python từ python.org (Windows: đánh dấu "Add python.exe to PATH") rồi chạy lại |
| B3 | ffmpeg (Bộ công cụ dựng video) | "Lỗi B3: không tải được ffmpeg – kiểm tra mạng, bấm chạy lại". Không chọn Bộ công cụ dựng video ([1]) → B3 "Bỏ qua" (không phải lỗi) |
| B4 | Thư viện Python | Mạng chập chờn → chạy lại (thư viện đã tải được giữ lại) |
| B5 | Biểu tượng BDS Studio (màn hình nền, Launchpad / Start Menu) + "Tắt máy dựng BDS Studio" (Launchpad / Start Menu) | Chỉ cảnh báo: chạy lại bộ cài; trong lúc chờ mở bằng `start_mac.command` / `start_windows.bat` trong thư mục `BDS_Studio_Engine`. Mac không tạo được `BDS Studio.app` thì bộ cài đặt lối tắt `BDS Studio.command` kiểu cũ (có cửa sổ Terminal). Chi tiết lỗi: `~/.bds_studio/install_shortcut.log` |
| B6 | Bật thử máy dựng | Xem tệp `~/.bds_studio/install_server_test.log`, chạy lại; vẫn lỗi thì gửi tệp đó + báo cáo cài đặt |
| B7 | Quét máy | Chỉ cảnh báo: vào app **Cài đặt → Máy của tôi → Quét lại máy** |
| B8 | Quét nhanh + chọn cách xử lý video (chạy ngay sau B2) | Chỉ cảnh báo, không dừng bộ cài: quét nhanh lỗi → không cài Bộ công cụ dựng video (chỉ khi có `--video`); đổi sau trong app |
| B9 | Video AI offline (chỉ khi chọn Offline) | Chỉ cảnh báo, không dừng bộ cài – tự chuyển Video AI Online: "Lỗi B9: … pip lỗi" → kiểm tra mạng, chạy lại với `--chon-video`; "Smart App Control chặn…" → xem mục B9 ở trên. Chi tiết: `~/.bds_studio/install_videoai.log` |

## Hạng máy (quét cấu hình)
Máy dựng đo thật trên máy này: chip/CPU, RAM, card đồ hoạ (NVIDIA: dung lượng VRAM; Mac chip Apple: bộ nhớ chung), ổ trống, hệ điều hành và **dựng thử 10 giây video 1080p**. Xếp hạng:
- **Cơ bản** (vd Mac 8 GB): AI online; Bộ công cụ dựng video là tuỳ chọn (máy yếu: video dựng trên máy không đẹp và giật – chỉ nên làm video mẫu); AI trên máy loại nhỏ (không chạy cùng lúc dựng video).
- **Khá** (RAM 16 GB, hoặc card NVIDIA 8 GB): thêm AI soạn trên máy mô hình vừa + tạo ảnh AI trên máy.
- **Mạnh** (Mac chip M Pro/Max/Ultra 32 GB trở lên, hoặc card NVIDIA 12 GB trở lên + RAM 16 GB): mở **Video AI chạy trên máy**, mô hình lớn, dựng song song qua đêm.
- Hạ hạng khi: CPU dưới 4 nhân; Mac chip Intel (tối đa Khá); dựng thử chậm hơn một nửa thời gian thực. Máy yếu **không hiện** lựa chọn nặng.
Xem lại trong app: **Cài đặt → Máy của tôi**. Nút **Quét lại máy** đo lại sau khi nâng cấp RAM/card.

## Biểu tượng BDS Studio mở ở đâu
Bộ cài (lúc xong), biểu tượng **BDS Studio** và `start_mac.command` / `start_windows.bat` đều mở **trang đầu** của app (không mở thẳng màn Video; lần đầu app tự hiện Trợ lý cài đặt), theo một quy tắc:
- **Địa chỉ app riêng của anh/chị (vd `https://tenkhach.bdsstudio.app`)**: lần đầu app ở địa chỉ đó nói chuyện với máy dựng, máy dựng ghi nhớ và **chỉ tin đúng địa chỉ đó** (`~/.bds_studio/app_origins.json`); biểu tượng mở thẳng địa chỉ này. Dùng tên miền riêng (vd `https://app.tenkhach.com`): app **Cài đặt → Máy của tôi**, hoặc `.venv/bin/python app/launcher.py --nguon-app https://app.tenkhach.com` (Windows `.venv\Scripts\python.exe app\launcher.py --nguon-app …`).
- **Chưa có địa chỉ app riêng**: dùng bản nằm sẵn trong máy dựng **http://127.0.0.1:8765/** (bản có địa chỉ app cố định thì thử địa chỉ đó 3 giây trước).
- **Các lần sau dùng lại đúng nơi đó** (lưu ở `~/.bds_studio/launch_origin.json`): địa chỉ máy chủ và đăng nhập của app gắn với nơi mở – đổi qua lại sẽ thấy app như mới.
- **Đổi**: app **Cài đặt → Máy của tôi → "Biểu tượng BDS Studio mở" → Đổi sang …**; hoặc Terminal/cửa sổ lệnh trong thư mục `BDS_Studio_Engine`: Mac `.venv/bin/python app/launcher.py --mo web` (hoặc `--mo may`), Windows `.venv\Scripts\python.exe app\launcher.py --mo web`.

## Mỗi lần làm video
1. Bấm đúp **BDS Studio** (ngôi nhà vàng). Máy dựng chạy nền, không có cửa sổ nào cần giữ; bấm lại lần nữa khi máy dựng đang chạy thì chỉ mở lại trình duyệt (luôn mở trang đầu của app, đúng nơi đã chọn – xem mục dưới).
2. Trong app: **Video & Ý tưởng → Video**. Ô "Máy dựng trên máy" phải hiện **Máy dựng sẵn sàng**.
3. Bấm **Tự kiểm tra** nếu có dấu ✗ → **Tự sửa phần thiếu**. Chưa cài Bộ công cụ dựng video (máy Cơ bản) → ô máy dựng hiện **Chưa cài Bộ công cụ dựng video – Cài ngay / Dùng Video AI online (thu phí riêng)**; bấm **Cài ngay** để tải ffmpeg (có thanh tiến độ).
4. Lần đầu: bấm **Khoá Vbee**, dán App-Id và Token (khoá lưu trong Keychain của máy, không nằm trong thư mục cài).

## Tắt máy dựng
- Windows: **Start Menu → BDS Studio → Tắt máy dựng BDS Studio**.
- Mac: **Launchpad → Tắt máy dựng BDS Studio** (biểu tượng BDS Studio); hoặc mở Terminal, gõ `bash ~/Applications/BDS\ Studio.app/Contents/Resources/launcher --stop`; khởi động lại máy cũng tắt.
- Cách cũ vẫn dùng được: `start_mac.command` / `start_windows.bat` trong thư mục `BDS_Studio_Engine` mở máy dựng **có cửa sổ lệnh** – đóng cửa sổ đó là tắt.
- Nhật ký máy dựng chạy nền: `~/.bds_studio/logs/engine.log` (Windows: `C:\Users\<tên>\.bds_studio\logs\engine.log`) – gửi kèm khi cần giúp.

## Khi gặp lỗi
1. App báo "Chưa bật máy dựng": bấm đúp **BDS Studio** rồi bấm **Thử kết nối lại**. Bấm biểu tượng mà không thấy gì: xem `~/.bds_studio/logs/engine.log`; nếu đã chuyển thư mục `BDS_Studio_Engine` sang chỗ khác thì chạy lại bộ cài để tạo lại biểu tượng.
2. Trên Mac dùng Safari mà không kết nối được: mở thẳng **http://127.0.0.1:8765** trên Mac.
3. Máy 8 GB RAM: khi đang dựng video, AI trên máy (Ollama) tạm nghỉ – app tự xếp hàng, chờ xong là chạy.
4. Đầy ổ: xoá video cũ trong **BDS Studio → Video**. Bộ nhớ tạm tự dọn, giới hạn 1,5 GB.

## Chuyển sang máy mới
1. Máy cũ: **Video → Chuyển máy → Tạo gói chuyển máy** (đặt mật khẩu). Tệp gói cũng được lưu trong **BDS Studio → Chuyen may**.
2. Máy mới: cài theo các bước trên.
3. Máy mới: **Video → Chuyển máy → Nhận từ máy cũ**, chọn tệp gói, nhập mật khẩu.
4. Nhập lại **Khoá Vbee** (khoá không đi theo gói để an toàn).
