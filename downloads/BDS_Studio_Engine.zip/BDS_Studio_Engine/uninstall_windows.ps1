﻿# Gỡ BDS Studio khỏi máy Windows này (uninstall_windows.bat gọi tệp này – Start Menu › BDS Studio › "Gỡ cài đặt BDS Studio",
# hoặc Cài đặt › Ứng dụng › BDS Studio › Gỡ cài đặt). Không cần quyền quản trị; chỉ gỡ những gì bộ cài đã tạo cho tài khoản này.
# GỠ:  máy dựng đang chạy (tắt) · lối tắt "BDS Studio" trên màn hình nền + thư mục Start Menu "BDS Studio"
#      · mục "BDS Studio" trong Cài đặt › Ứng dụng (HKCU) · môi trường Python riêng (.venv trong thư mục này)
#      · Python/ffmpeg bộ cài tải riêng (.bds_studio\python, .bds_studio\bin) · bộ nhớ tạm mặc định (%LOCALAPPDATA%\BDS Studio\Cache).
# GIỮ: dữ liệu và cài đặt (.bds_studio: dự án, khoá, mô hình Video AI, báo cáo), video đã làm (thư mục BDS Studio), thư mục
#      BDS_Studio_Engine (xoá tay sau khi gỡ). Python cài bằng winget (nếu có) là của chung máy – không gỡ.
# Tuỳ chọn: --yes (không hỏi – CI/kiểm thử) · --dry-run (chỉ in việc sẽ làm). Biến: BDS_DATA_DIR (như bộ cài).
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$Engine = $PSScriptRoot
Set-Location -LiteralPath $Engine
$Yes = $false; $Dry = $false
foreach ($a in $args) {
  switch -Regex ($a) {
    '^(--yes|-Yes)$' { $Yes = $true }
    '^(--dry-run|-DryRun)$' { $Dry = $true }
    default { Write-Host "Tuỳ chọn lạ: $a (bỏ qua)" }
  }
}
$DataDir = if ($env:BDS_DATA_DIR) { $env:BDS_DATA_DIR } else { Join-Path $env:USERPROFILE '.bds_studio' }
if ($DataDir.StartsWith($Engine, [StringComparison]::OrdinalIgnoreCase)) { $DataDir = Join-Path $env:USERPROFILE '.bds_studio' }
$VPy = Join-Path $Engine '.venv\Scripts\python.exe'
$Desktop = [Environment]::GetFolderPath('Desktop')
$StartDir = Join-Path ([Environment]::GetFolderPath('Programs')) 'BDS Studio'
$UninstallKey = 'Software\Microsoft\Windows\CurrentVersion\Uninstall\BDSStudio'
# Bộ nhớ tạm: CHỈ đường mặc định của máy dựng (không xoá thư mục do biến BDS_CACHE_DIR trỏ tới – có thể là thư mục khác của người dùng).
$CacheDir = Join-Path $env:LOCALAPPDATA 'BDS Studio\Cache'
$Items = @(
  @{ label = 'Lối tắt BDS Studio trên màn hình nền'; kind = 'file'; path = (Join-Path $Desktop 'BDS Studio.lnk') },
  @{ label = 'Thư mục BDS Studio trong Start Menu'; kind = 'dir'; path = $StartDir },
  @{ label = 'Môi trường Python riêng (.venv)'; kind = 'dir'; path = (Join-Path $Engine '.venv') },
  @{ label = 'Python bộ cài tải riêng'; kind = 'dir'; path = (Join-Path $DataDir 'python') },
  @{ label = 'Bộ công cụ dựng video (ffmpeg)'; kind = 'dir'; path = (Join-Path $DataDir 'bin') },
  @{ label = 'Bộ nhớ tạm (tệp tải về, ảnh xem trước)'; kind = 'dir'; path = $CacheDir }
)

Write-Host ''
Write-Host '=== GỠ BDS STUDIO KHỎI MÁY NÀY ===' -ForegroundColor Cyan
Write-Host 'Sẽ gỡ:'
Write-Host '   · tắt máy dựng nếu đang chạy'
foreach ($it in $Items) { if (Test-Path -LiteralPath $it.path) { Write-Host "   · $($it.label): $($it.path)" } }
Write-Host '   · mục "BDS Studio" trong Cài đặt › Ứng dụng'
Write-Host "GIỮ NGUYÊN: dữ liệu + cài đặt ($DataDir – dự án, khoá, mô hình Video AI), video đã làm, thư mục máy dựng $Engine."
if ($Dry) { Write-Host '(chạy thử – không gỡ gì)'; exit 0 }
if (-not $Yes) {
  if ([Console]::IsInputRedirected) { Write-Host 'Không hỏi được (không có bàn phím) – chạy lại với --yes để gỡ.'; exit 2 }
  Write-Host ''
  Write-Host '   Gõ 1 rồi Enter để GỠ · Enter (hoặc gõ 2) để thôi: ' -NoNewline -ForegroundColor Yellow
  $ans = [Console]::ReadLine()
  if ([string]$ans -notmatch '^\s*1\s*$') { Write-Host 'Đã thôi – không gỡ gì.'; exit 0 }
}

$bad = 0
if (Test-Path -LiteralPath $VPy) {
  Write-Host '   … tắt máy dựng'
  & $VPy -c "import sys; sys.path.insert(0, 'app'); import common, launcher; sys.exit(0 if not launcher.probe(common.PORT) else (0 if __import__('server').free_port(common.PORT) else 1))" 2>$null
  if ($LASTEXITCODE -ne 0) { Write-Host '   ⚠ Chưa tắt được máy dựng – khởi động lại máy rồi gỡ lại nếu còn sót tệp' -ForegroundColor Yellow }
}
foreach ($it in $Items) {
  if (-not (Test-Path -LiteralPath $it.path)) { continue }
  try {
    Remove-Item -LiteralPath $it.path -Recurse -Force -ErrorAction Stop
    Write-Host "   ✓ Đã gỡ $($it.label)" -ForegroundColor Green
  } catch {
    $bad++
    Write-Host "   ⚠ Chưa gỡ hết $($it.label) ($($it.path)): $($_.Exception.Message)" -ForegroundColor Yellow
  }
}
try { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($UninstallKey, $false); Write-Host '   ✓ Đã bỏ mục BDS Studio trong Cài đặt › Ứng dụng' -ForegroundColor Green }
catch { $bad++; Write-Host "   ⚠ Chưa bỏ được mục trong Cài đặt › Ứng dụng: $($_.Exception.Message)" -ForegroundColor Yellow }

Write-Host ''
if ($bad) { Write-Host '=== GỠ CHƯA HẾT – đóng các cửa sổ BDS Studio / khởi động lại máy rồi chạy lại "Gỡ cài đặt" ===' -ForegroundColor Yellow }
else { Write-Host '=== ĐÃ GỠ BDS STUDIO ===' -ForegroundColor Green }
Write-Host "Còn lại (của anh/chị, không tự xoá): dữ liệu $DataDir và thư mục máy dựng $(Split-Path -Parent $Engine) – xoá tay nếu không dùng nữa."
Write-Host 'Cài lại: bấm đúp "Cai dat voi 1 click" trong thư mục BDS_Studio_Engine (hoặc tải lại bộ cài).'
exit $(if ($bad) { 1 } else { 0 })
