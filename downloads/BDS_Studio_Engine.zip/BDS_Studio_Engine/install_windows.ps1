﻿# Bộ cài Máy dựng video BDS Studio cho Windows 10/11 (install_windows.bat gọi tệp này – bấm đúp tệp .bat, không chạy tệp này trực tiếp).
# Gói phát hành (17/11): khách bấm "Cai dat voi 1 click.bat" ở ngoài cùng thư mục BDS_Studio_Engine → _he_thong\install_windows.bat → tệp này
# ($Engine = thư mục chứa tệp này = _he_thong; .venv, lối tắt, biểu tượng đều tính từ đây – không phụ thuộc thư mục ngoài).
# Câu hỏi ĐẦU TIÊN (trước Python, trước mọi thứ) – chủ 17/11 tối:
#   [1] Có – dựng video trên máy này (video bản đồ/quy hoạch miễn phí; cài công cụ dựng ~150–300 MB) → cài như dưới
#   [2] Chỉ dùng AI trên mạng – không cài gì lên máy (60 giây → [2]) · [3] Không làm video – không cài gì
#   [2]/[3]: không kiểm/cài Python, không .venv, không ffmpeg, không lối tắt; ghi báo cáo ("video": false, [2] thêm "video_mode": "online"),
#   mở trang đầu web app (bản bán: LAUNCH_ORIGIN trong app\common.py; bản của anh không có → chỉ báo), thoát.
# [1] → Python + môi trường riêng (.venv), máy dựng chạy tại máy, lối tắt. B8 quét nhanh máy NGAY sau Python rồi hỏi:
#   [4] Dựng video trên máy (mặc định) · [2] Dựng + AI ngay trên máy (chỉ máy Mạnh, B9 cài thư viện AI)
#   · [1] Thôi – chỉ AI trên mạng (mặc định trên máy Cơ bản): DỪNG sau B8, không .venv, không ffmpeg.
# Phụ thuộc theo lựa chọn: deps_video.json (tools\deps_video.py plan in dung lượng/thời gian trước khi tải); cuối: tự kiểm + dựng thử 3 giây.
# KHÔNG cần quyền quản trị: Python cài cho riêng người dùng (winget --scope user hoặc bản riêng), ffmpeg đặt ở %USERPROFILE%\.bds_studio\bin.
#
# Chạy lại bao nhiêu lần cũng được: bước nào xong thì bỏ qua, tải dở thì tải tiếp (bộ cài làm tiếp từ bước lỗi).
# Tuỳ chọn: --dry-run (chỉ kiểm tra) · --ci (không hỏi, không mở trình duyệt) · --no-launch · --no-bench
#           --video (dựng trên máy + cài Bộ công cụ dựng video kể cả máy yếu) · --no-video (dừng ở B8, không cài gói) · --chon-video (hỏi lại)
#           BDS_MAKE_VIDEO=1|online|0 trả lời sẵn câu hỏi đầu: dựng trên máy | chỉ AI trên mạng | không làm video (CI đặt 1)
# Biến môi trường (kiểm thử): BDS_PYTHON_SOURCE=auto|winget|portable  BDS_FFMPEG_SOURCE=auto|winget|direct
#                             BDS_DATA_DIR, BDS_CACHE_DIR, BDS_INSTALL_REPORT (giống máy dựng)
#                             BDS_VIDEO_MODE=online|offline|later  BDS_VIDEO_PACK=1|0  BDS_VIDEO_DOWNLOAD=now|later
#                             BDS_VIDEO_TIMEOUT=60  BDS_HW_TIER=co_ban|kha|manh (giả hạng máy, chỉ kiểm thử) – xem app/videomode.py
# Báo cáo máy đọc được: %USERPROFILE%\.bds_studio\install_report.json (app đọc qua máy dựng: GET /install/report).
# Mã lỗi: B0 chính sách PowerShell (install_windows.bat) · B1 máy/thư mục · B2 Python · B3 ffmpeg · B4 thư viện Python
#         · B5 biểu tượng/lối tắt · B6 bật thử máy dựng · B7 quét máy · B8 quét nhanh + chọn cách xử lý video
#         · B9 Video AI offline.   Thoát với mã 10 + số bước lỗi (B3 → 13); 0 = xong. B8/B9 không dừng bộ cài (⚠ + dùng Online).
# Thứ tự chạy: B1 → B2 → B8 → B3 → B4 → B5 → B6 → B7 → B9 (mã bước giữ nguyên nghĩa cũ; màn hình đánh số theo thứ tự chạy).
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'          # thanh tiến độ của Invoke-WebRequest làm tải chậm hẳn trên PowerShell 5.1
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'                             # Python in/đọc chữ Việt bằng UTF-8 (cửa sổ lệnh Windows mặc định cp1252 → UnicodeEncodeError)
# KHÔNG dựa vào tự nạp module (autoload): mở từ PowerShell 7/Windows Terminal thì PSModulePath trỏ module của bản 7 →
# Get-FileHash, Get-ExecutionPolicy, Expand-Archive… "không tìm thấy" trên PowerShell 5.1 (gặp thật trên GitHub 17/11).
# install_windows.bat đã xoá PSModulePath trước khi gọi tệp này; ở đây chỉ dùng lệnh lõi + .NET (băm SHA-256, giải nén zip, lối tắt).
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

$Engine = $PSScriptRoot
Set-Location -LiteralPath $Engine
# Tên nút khách bấm để chạy lại bộ cài: gói mới có "Cai dat voi 1 click" ở thư mục ngoài (ruột ở _he_thong); mã nguồn/gói cũ: install_windows.bat.
$ClickName = if ($env:BDS_CLICK_PATH -or (Test-Path -LiteralPath (Join-Path (Split-Path -Parent $Engine) 'Cai dat voi 1 click.bat'))) { '"Cai dat voi 1 click"' } else { 'install_windows.bat' }
$Dry = $false; $CiMode = [bool]$env:CI; $Launch = $true; $Bench = $true; $PackFlag = ''; $AskVideo = $false
foreach ($a in $args) {
  switch -Regex ($a) {
    '^(--dry-run|-DryRun)$' { $Dry = $true }
    '^(--ci|-CI)$' { $CiMode = $true }
    '^(--no-launch|-NoLaunch)$' { $Launch = $false }
    '^(--no-bench|-NoBench)$' { $Bench = $false }
    '^(--video|-Video)$' { $PackFlag = 'yes' }
    '^(--no-video|-NoVideo)$' { $PackFlag = 'no' }
    '^(--chon-video|-ChonVideo)$' { $AskVideo = $true }
    default { Write-Host "Tuỳ chọn lạ: $a (bỏ qua)" }
  }
}
if ($env:BDS_INSTALL_DRYRUN -eq '1') { $Dry = $true }
if ($CiMode) { $Launch = $false }

$DataDir = if ($env:BDS_DATA_DIR) { $env:BDS_DATA_DIR } else { Join-Path $env:USERPROFILE '.bds_studio' }
if ($DataDir.StartsWith($Engine, [StringComparison]::OrdinalIgnoreCase)) { $DataDir = Join-Path $env:USERPROFILE '.bds_studio' }
$CacheDir = if ($env:BDS_CACHE_DIR) { $env:BDS_CACHE_DIR } else { Join-Path $env:LOCALAPPDATA 'BDS Studio\Cache' }
$DlDir = Join-Path $CacheDir 'downloads'
$BinDir = Join-Path $DataDir 'bin'
$PortablePy = Join-Path $DataDir 'python'
$Report = if ($Dry) { Join-Path $DataDir 'install_report_dry.json' } elseif ($env:BDS_INSTALL_REPORT) { $env:BDS_INSTALL_REPORT } else { Join-Path $DataDir 'install_report.json' }
$VPy = Join-Path $Engine '.venv\Scripts\python.exe'
$Total = 9
$StepNo = 0
$EngineVersion = ''
try { $m = Select-String -LiteralPath (Join-Path $Engine 'app\common.py') -Pattern "^VERSION = '([^']*)'" | Select-Object -First 1; if ($m) { $EngineVersion = $m.Matches[0].Groups[1].Value } } catch { }
$Sys32 = Join-Path $env:SystemRoot 'System32'
$CurlExe = Join-Path $Sys32 'curl.exe'          # dùng đúng curl/tar của Windows (Git for Windows có bản khác, không hiểu ổ C:\)
$TarExe = Join-Path $Sys32 'tar.exe'

# Python dự phòng không cần quyền quản trị (python-build-standalone của Astral) – bản ghim, sha256 lấy từ SHA256SUMS
# của bản phát hành 20241016 (đã tải thử và đối chiếu ngày 16/11/2026).
$PbsUrl = 'https://github.com/astral-sh/python-build-standalone/releases/download/20241016/cpython-3.12.7%2B20241016-x86_64-pc-windows-msvc-install_only.tar.gz'
$PbsSha = 'f05531bff16fa77b53be0776587b97b466070e768e6d5920894de988bdcd547a'
# ffmpeg tải thẳng: gyan.dev (bản essentials, có tệp .sha256 đi kèm) → dự phòng BtbN trên GitHub (đối chiếu checksums.sha256)
$FfGyan = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'
$FfBtbN = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip'
$FfBtbNSums = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/checksums.sha256'

# ---------------- in ra + báo cáo ----------------
$State = [ordered]@{
  schema = 1; tool = 'install_windows'; mode = $(if ($Dry) { 'dry' } else { 'real' }); os = 'windows'
  os_version = ''; arch = ''; engine_dir = $Engine; engine_version = $EngineVersion
  started_at = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); finished_at = ''
  python = ''; python_source = ''; ffmpeg = ''; ffmpeg_source = ''; tier = ''; video_mode = ''; video_pack = ''
  video = $null; steps = (New-Object System.Collections.ArrayList); error = $null
}
$Cur = @{ id = ''; label = ''; t0 = Get-Date }

function Write-Report {
  try {
    $dir = Split-Path -Parent $Report
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $json = ConvertTo-Json -InputObject $State -Depth 6
    [IO.File]::WriteAllText("$Report.tmp", $json, (New-Object System.Text.UTF8Encoding $false))
    Move-Item -LiteralPath "$Report.tmp" -Destination $Report -Force
  } catch { Write-Host "   (không ghi được báo cáo: $($_.Exception.Message))" }
}
function Start-Step($id, $label) {
  $Cur.id = $id; $Cur.label = $label; $Cur.t0 = Get-Date
  $script:StepNo++
  Write-Host ""
  Write-Host ("[{0}/{1}] {2} · {3}…" -f $script:StepNo, $Total, $id, $label) -ForegroundColor Cyan
}
function Complete-Step($status, $msg, $detail = '') {
  $secs = [int]((Get-Date) - $Cur.t0).TotalSeconds
  $code = if ($status -eq 'failed') { $Cur.id } else { '' }
  $st = [ordered]@{ id = $Cur.id; label = $Cur.label; status = $status; code = $code; message = $msg; seconds = $secs }
  if ($detail) { $st.detail = [string]$detail }
  [void]$State.steps.Add($st)
  switch ($status) {
    'ok' { Write-Host "   ✓ $msg" -ForegroundColor Green }
    'skipped' { Write-Host "   ✓ $msg" -ForegroundColor Green }
    'warn' { Write-Host "   ⚠ $msg" -ForegroundColor Yellow }
    'dry' { Write-Host "   ○ (chạy thử) $msg" }
    'failed' { Write-Host "   ✗ $msg" -ForegroundColor Red }
  }
  Write-Report
}
function Stop-Install($msg) {
  $State.error = [ordered]@{ code = $Cur.id; message = $msg }
  Complete-Step 'failed' $msg
  Write-Host ""
  Write-Host "=== CHƯA CÀI XONG – $msg ===" -ForegroundColor Red
  Write-Host "Bấm đúp lại $($ClickName): phần đã xong được giữ, bộ cài làm tiếp từ bước $($Cur.id)."
  Write-Host "Cần giúp: gửi tệp báo cáo $Report (không chứa mật khẩu hay khoá)."
  exit (10 + [int]$Cur.id.Substring(1))
}
function Say($msg) { Write-Host "   … $msg" }
function Get-Sha256($path) {   # thay Get-FileHash (hàm của module Utility – nạp hỏng khi PSModulePath lẫn PowerShell 7)
  try {
    $fs = [IO.File]::OpenRead($path)
    try {
      $h = [Security.Cryptography.SHA256]::Create()
      try { return ([BitConverter]::ToString($h.ComputeHash($fs)) -replace '-', '').ToLowerInvariant() } finally { $h.Dispose() }
    } finally { $fs.Dispose() }
  } catch { return '' }
}

# Tải có làm tiếp (curl.exe -C -), thử lại 3 lần, đối chiếu sha256 nếu có. Trả $true/$false.
function Get-File($url, $dest, $sha) {
  $dir = Split-Path -Parent $dest
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  if ((Test-Path -LiteralPath $dest) -and (-not $sha -or (Get-Sha256 $dest) -eq $sha.ToLowerInvariant())) { return $true }
  Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
  $part = "$dest.part"
  for ($i = 1; $i -le 3; $i++) {
    $got = $false
    if (Test-Path -LiteralPath $CurlExe) {
      $prog = if ($CiMode) { '-sS' } else { '-#' }
      & $CurlExe -fL $prog --connect-timeout 20 --retry 2 --retry-delay 3 -C - -o $part $url
      $got = ($LASTEXITCODE -eq 0)
    } else {
      try { Invoke-WebRequest -Uri $url -OutFile $part -UseBasicParsing -TimeoutSec 1800; $got = $true } catch { $got = $false }
    }
    if ($got -and (-not $sha -or (Get-Sha256 $part) -eq $sha.ToLowerInvariant())) {
      Move-Item -LiteralPath $part -Destination $dest -Force; return $true
    }
    if ($got) { Write-Host "   ⚠ Tệp tải về không khớp mã kiểm tra (lần $i) – tải lại từ đầu" -ForegroundColor Yellow }
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
  }
  return $false
}
function Get-Text($url) {
  try {
    $c = (Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 60).Content
    if ($c -is [byte[]]) { $c = [Text.Encoding]::UTF8.GetString($c) }   # máy chủ trả application/octet-stream
    return [string]$c
  } catch { return '' }
}
function Expand-Any($archive, $dest) {
  if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  if (Test-Path -LiteralPath $TarExe) {
    & $TarExe -xf $archive -C $dest
    if ($LASTEXITCODE -eq 0) { return $true }
  }
  if ($archive -like '*.zip') {   # .NET thay Expand-Archive (module Archive cũng nạp hỏng khi PSModulePath lẫn PowerShell 7)
    try {
      Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
      [IO.Compression.ZipFile]::ExtractToDirectory($archive, $dest); return $true
    } catch { return $false }
  }
  return $false
}

function Test-Py($exe, $pre) {
  if (-not $exe) { return $false }
  try {
    # ≥ 3.12 (deps_video.json › python.min): app\scenes.py dùng f-string kiểu mới của 3.12 – Python 3.9–3.11 nạp scenes.py báo SyntaxError
    & $exe @pre -c "import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 12) else 1)" 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
  } catch { return $false }
}
function Resolve-PyExe($exe, $pre) {   # 'py -3' → đường dẫn python.exe thật (để tạo .venv và ghi báo cáo)
  try { return ((& $exe @pre -c "import sys; print(sys.executable)" 2>$null) | Select-Object -First 1).Trim() } catch { return '' }
}
function Find-Python {
  $portable = Join-Path $PortablePy 'python.exe'
  if ($env:BDS_PYTHON_SOURCE -eq 'portable') {
    if (Test-Py $portable @()) { return @{ exe = $portable; src = 'portable' } }
    return $null
  }
  foreach ($pv in @('-3', '-3.14', '-3.13', '-3.12')) {   # 'py -3' có thể là 3.11 cũ trong khi máy có sẵn 3.12+
    if (Test-Py 'py' @($pv)) { $p = Resolve-PyExe 'py' @($pv); if ($p) { return @{ exe = $p; src = 'py-launcher' } } }
  }
  $cmd = Get-Command python -ErrorAction SilentlyContinue
  if ($cmd -and (Test-Py $cmd.Source @())) { return @{ exe = (Resolve-PyExe $cmd.Source @()); src = 'path' } }
  $userPys = @(Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python3*\python.exe') -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
  foreach ($c in $userPys) { if (Test-Py $c.FullName @()) { return @{ exe = $c.FullName; src = 'python.org/winget' } } }
  if (Test-Py $portable @()) { return @{ exe = $portable; src = 'portable' } }
  return $null
}
function Test-Ff($exe) {
  if (-not $exe -or -not (Test-Path -LiteralPath $exe)) { return $false }
  try { & $exe -version 2>$null | Out-Null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}
# ffmpeg của phần mềm khác trên PATH có thể là bản rút gọn (LGPL, không libx264) → máy dựng không nén được video.
# Kiểm nhanh đúng các mục deps_video.json › ffmpeg.check.ps1_quick (bản đầy đủ do tools\deps_video.py kiểm ở B10).
function Test-FfCaps($exe) {
  try {
    $enc = (& $exe -hide_banner -encoders 2>$null) -join "`n"
    $flt = (& $exe -hide_banner -filters 2>$null) -join "`n"
    foreach ($n in @('libx264', 'aac')) { if ($enc -notmatch "\s$n\s") { return $false } }
    foreach ($n in @('loudnorm', 'sidechaincompress')) { if ($flt -notmatch "\s$n\s") { return $false } }
    return $true
  } catch { return $false }
}
function Find-Ffmpeg {
  $cands = @((Join-Path $BinDir 'ffmpeg.exe'), (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\ffmpeg.exe'))
  $cmd = Get-Command ffmpeg -ErrorAction SilentlyContinue
  if ($cmd) { $cands += $cmd.Source }
  foreach ($c in $cands) {
    $probe = Join-Path (Split-Path -Parent $c) 'ffprobe.exe'
    if ((Test-Ff $c) -and (Test-Ff $probe) -and (Test-FfCaps $c)) { return $c }
  }
  return $null
}
function Copy-FfmpegFrom($root) {   # tìm ffmpeg.exe + ffprobe.exe trong thư mục đã giải nén → chép vào ~/.bds_studio/bin
  $ff = Get-ChildItem -Path $root -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  $fp = Get-ChildItem -Path $root -Recurse -Filter 'ffprobe.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $ff -or -not $fp) { return $false }
  New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
  Copy-Item -LiteralPath $ff.FullName -Destination (Join-Path $BinDir 'ffmpeg.exe') -Force
  Copy-Item -LiteralPath $fp.FullName -Destination (Join-Path $BinDir 'ffprobe.exe') -Force
  # bản "shared" cần các tệp .dll đi kèm
  Get-ChildItem -Path $ff.DirectoryName -Filter '*.dll' -ErrorAction SilentlyContinue | Copy-Item -Destination $BinDir -Force
  return (Test-Ff (Join-Path $BinDir 'ffmpeg.exe')) -and (Test-Ff (Join-Path $BinDir 'ffprobe.exe'))
}
function Get-WingetExe { $w = Get-Command winget -ErrorAction SilentlyContinue; if ($w) { return $w.Source } return $null }

# Hỏi có hẹn giờ (bàn phím thật). CI / đầu vào bị chuyển hướng → mặc định ngay. Dùng trước khi có Python nên viết bằng PowerShell.
function Read-Choice($prompt, $valid, $default, $seconds) {
  $redirected = $true
  try { $redirected = [Console]::IsInputRedirected } catch { }
  if ($CiMode -or $redirected) { Write-Host "$prompt$default (tự chọn)"; return $default }
  Write-Host -NoNewline $prompt
  $end = (Get-Date).AddSeconds($seconds); $buf = ''
  while ((Get-Date) -lt $end) {
    if ([Console]::KeyAvailable) {
      $k = [Console]::ReadKey($true)
      if ($k.Key -eq 'Enter') {
        Write-Host ''
        if ($buf -eq '') { return $default }
        if ($valid -contains $buf) { return $buf }
        Write-Host -NoNewline "   Chỉ gõ $($valid -join ' / ') rồi Enter: "; $buf = ''; $end = (Get-Date).AddSeconds($seconds); continue
      }
      if ($k.Key -eq 'Backspace') { if ($buf.Length) { $buf = $buf.Substring(0, $buf.Length - 1); Write-Host -NoNewline "`b `b" }; continue }
      $buf += $k.KeyChar; Write-Host -NoNewline $k.KeyChar; $end = (Get-Date).AddSeconds([Math]::Max(30, ($end - (Get-Date)).TotalSeconds))
    } else { Start-Sleep -Milliseconds 100 }
  }
  Write-Host ''; Write-Host "   … hết $seconds giây – tự chọn [$default]"; return $default
}
# Web app dùng chung (bản bán): đúng nguồn biểu tượng BDS Studio dùng (app\common.py › BDS_LAUNCH_ORIGIN – tools/sale_build.mjs đặt).
$WebApp = ''
try {
  $m = Select-String -LiteralPath (Join-Path $Engine 'app\common.py') -Pattern "BDS_LAUNCH_ORIGIN', '([^']*)'" | Select-Object -First 1
  if ($m) { $WebApp = $m.Matches[0].Groups[1].Value }
} catch { }
if ($env:BDS_LAUNCH_ORIGIN) { $WebApp = $env:BDS_LAUNCH_ORIGIN }
$WebApp = $WebApp.TrimEnd('/'); if ($WebApp -notmatch '^https://') { $WebApp = '' }

Write-Host ""
Write-Host "=== BỘ CÀI MÁY DỰNG VIDEO BDS STUDIO (Windows) ===" -ForegroundColor Yellow
try { $Host.UI.RawUI.WindowTitle = 'Bộ cài Máy dựng video BDS Studio' } catch { }
Write-Host "Thư mục: $Engine"
if ($Dry) { Write-Host "(CHẠY THỬ – chỉ kiểm tra, không cài gì)" }
New-Item -ItemType Directory -Force -Path $DataDir -ErrorAction SilentlyContinue | Out-Null

# ---------------- Câu hỏi đầu tiên: có làm video trên máy này không (trước Python, trước mọi thứ) ----------------
$Cur.id = 'BV'; $Cur.label = 'Có làm video trên máy tính này không'; $Cur.t0 = Get-Date
$MakeVideo = ''
# BDS_MAKE_VIDEO: 1 = dựng trên máy · online = chỉ AI trên mạng · 0 = không làm video (CI đặt 1)
if ($env:BDS_MAKE_VIDEO -in @('1', '0', 'online')) { $MakeVideo = @{ '1' = '1'; 'online' = '2'; '0' = '3' }[$env:BDS_MAKE_VIDEO] }
if ($PackFlag -eq 'yes') { $MakeVideo = '1' }                             # --video = dựng trên máy
if (-not $MakeVideo -and (Test-Py $VPy @())) {
  $MakeVideo = '1'; Write-Host 'Máy này đã có Máy dựng video – chạy lại để cập nhật/sửa (không hỏi lại).'
}
if (-not $MakeVideo) {
  Write-Host ''
  Write-Host 'Anh/chị có làm video trên máy tính này không?' -ForegroundColor Cyan
  Write-Host '   [1] Có – dựng video trên máy này (video bản đồ/quy hoạch miễn phí; cài công cụ dựng ~150–300 MB)'
  Write-Host '   [2] Chỉ dùng AI trên mạng – không cài gì lên máy (AI tính phí theo nhà cung cấp; không làm được video bản đồ/quy hoạch trên máy này)'
  Write-Host '   [3] Không làm video – không cài gì'
  $MakeVideo = Read-Choice '   Gõ 1, 2 hoặc 3 rồi Enter (Enter hoặc chờ 60 giây = [2]): ' @('1', '2', '3') '2' 60
}
if ($MakeVideo -ne '1') {
  # [2] Chỉ AI trên mạng / [3] Không làm video: KHÔNG kiểm/cài Python, không .venv, không ffmpeg, không lối tắt
  $State.video = $false
  if ($MakeVideo -eq '2') {
    $State.video_mode = 'online'; $State.video_pack = 'skip'
    $msg = 'Chỉ làm video bằng AI trên mạng – không cài gì lên máy' + $(if ($WebApp) { "; dùng app tại $WebApp" } else { '' })
  } else {
    $msg = 'Không làm video trên máy này – không cài gì' + $(if ($WebApp) { "; dùng app tại $WebApp" } else { '' })
  }
  Complete-Step $(if ($Dry) { 'dry' } else { 'ok' }) $msg
  $State.finished_at = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); Write-Report
  Write-Host ''
  Write-Host '=== KHÔNG CÀI GÌ ===' -ForegroundColor Green
  if ($MakeVideo -eq '2') {
    Write-Host 'Video làm bằng AI trên mạng ngay trong app (tính phí theo nhà cung cấp) – máy này không cần cài gì.'
    Write-Host "Muốn làm video bản đồ/quy hoạch trên máy này: bấm đúp lại $($ClickName), chọn [1]."
  } else {
    Write-Host 'Máy dựng video chỉ cần khi dựng video ngay trên máy tính này. Các việc khác (khách hàng, nội dung, lịch, Video AI trên mạng…)'
    Write-Host "dùng app trên trình duyệt hoặc điện thoại, không cần cài gì. Muốn làm video sau: bấm đúp lại $($ClickName), chọn [1] hoặc [2]."
  }
  if ($WebApp) {
    Write-Host "Mở app: $WebApp"
    if (-not $CiMode -and -not $Dry) { try { Start-Process ($WebApp + '/') } catch { } }
  } else { Write-Host 'Mở app trên trình duyệt như mọi khi.' }
  exit 0
}
$State.video = $true
Complete-Step 'ok' 'Có – dựng video trên máy này: cài Máy dựng video'

# ---------------- B1. Máy + thư mục ----------------
Start-Step 'B1' 'Kiểm tra máy và thư mục cài'
$osv = [Environment]::OSVersion.Version
$build = $osv.Build
$State.os_version = "$($osv.Major).$($osv.Minor).$build"
$State.arch = switch ($env:PROCESSOR_ARCHITECTURE) { 'AMD64' { 'x86_64' } 'ARM64' { 'arm64' } default { "$env:PROCESSOR_ARCHITECTURE".ToLower() } }
if ($env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { $State.arch = 'arm64' }
if (-not [Environment]::Is64BitOperatingSystem) { Stop-Install 'Lỗi B1: Windows 32-bit không chạy được máy dựng – cần Windows 10/11 bản 64-bit' }
if ($osv.Major -lt 10 -or $build -lt 17763) { Stop-Install "Lỗi B1: Windows quá cũ (bản $build) – cần Windows 10 bản 1809 trở lên hoặc Windows 11, cập nhật Windows rồi chạy lại" }
if ($Engine -match '\\AppData\\Local\\Temp\\' -or $Engine -match '\.zip\\') { Stop-Install 'Lỗi B1: đang chạy ngay trong tệp zip – bấm chuột phải tệp zip → Extract All (Giải nén tất cả) rồi chạy lại' }
try { $t = Join-Path $Engine '.w_test'; Set-Content -LiteralPath $t -Value 'ok' -ErrorAction Stop; Remove-Item -LiteralPath $t -Force }
catch { Stop-Install 'Lỗi B1: không ghi được vào thư mục BDS_Studio_Engine – chép cả thư mục BDS_Studio_Engine vào Tài liệu (Documents) rồi chạy lại' }
$freeGb = 0
try { $freeGb = [math]::Floor((New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($env:USERPROFILE))).AvailableFreeSpace / 1GB) } catch { }
if ($freeGb -lt 1) { Stop-Install 'Lỗi B1: ổ đĩa còn dưới 1 GB – xoá bớt tệp rồi chạy lại' }
if (-not $Dry) { Get-ChildItem -LiteralPath $Engine -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue }   # gỡ dấu "tải từ Internet"
$cpuName = ''
try { $cpuName = (Get-ItemProperty 'HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0' -ErrorAction Stop).ProcessorNameString.Trim() } catch { }
$osName = if ($build -ge 22000) { 'Windows 11' } else { 'Windows 10' }
$line = "$osName (bản $build) · $cpuName ($($State.arch)) · ổ trống $freeGb GB"
if ($State.arch -eq 'arm64') { Complete-Step 'warn' "$line – máy chip ARM: dùng bản x64 chạy giả lập, có thể chậm hơn" }
elseif ($freeGb -lt 5) { Complete-Step 'warn' "$line – nên trống ≥ 5 GB để dựng video" }
else { Complete-Step 'ok' $line }

# ---------------- B2. Python ----------------
Start-Step 'B2' 'Python 3 (ngôn ngữ chạy máy dựng)'
$PySrc = $env:BDS_PYTHON_SOURCE; if (-not $PySrc) { $PySrc = 'auto' }
$Py = $null
if ($PySrc -ne 'portable' -and (Test-Py $VPy @())) { $Py = @{ exe = $VPy; src = 'venv' } } else { $Py = Find-Python }
if ($Py) {
  $State.python = (& $Py.exe -c "import platform; print(platform.python_version())"); $State.python_source = $Py.src
  Complete-Step 'ok' "Đã có Python $($State.python) ($($Py.src))"
} elseif ($Dry) {
  Complete-Step 'dry' 'Sẽ cài Python 3.12 cho riêng người dùng (winget, dự phòng bản riêng ~30 MB) – không cần quyền quản trị'
} else {
  $wg = Get-WingetExe
  if ($wg -and $PySrc -in @('auto', 'winget')) {
    Say 'winget đang cài Python 3.12 cho riêng người dùng (1–3 phút)'
    & $wg install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity | Out-Host
    $Py = Find-Python
    if (-not $Py) { Write-Host '   ⚠ winget chưa cài được Python – dùng bản riêng' -ForegroundColor Yellow }
    else { $Py.src = 'winget' }
  }
  if (-not $Py -and $PySrc -ne 'winget') {
    Say "tải Python 3.12 bản riêng (~30 MB) vào $PortablePy"
    $tgz = Join-Path $DlDir 'python-win64.tar.gz'
    if (-not (Get-File $PbsUrl $tgz $PbsSha)) { Stop-Install 'Lỗi B2: không tải được Python – kiểm tra mạng, bấm chạy lại' }
    $tmp = "$PortablePy.tmp"
    if (-not (Expand-Any $tgz $tmp)) { Remove-Item -LiteralPath $tgz -Force -ErrorAction SilentlyContinue; Stop-Install 'Lỗi B2: tệp Python tải về bị hỏng – bấm chạy lại' }
    if (Test-Path -LiteralPath $PortablePy) { Remove-Item -LiteralPath $PortablePy -Recurse -Force }
    Move-Item -LiteralPath (Join-Path $tmp 'python') -Destination $PortablePy -Force
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $tgz -Force -ErrorAction SilentlyContinue
    $pe = Join-Path $PortablePy 'python.exe'
    if (Test-Py $pe @()) { $Py = @{ exe = $pe; src = 'portable' } }
  }
  if (-not $Py) {
    if (-not $CiMode) { Start-Process 'https://www.python.org/downloads/windows/' }
    Stop-Install 'Lỗi B2: chưa cài được Python – kiểm tra mạng, bấm chạy lại (hoặc cài Python từ python.org, nhớ đánh dấu "Add python.exe to PATH")'
  }
  $State.python = (& $Py.exe -c "import platform; print(platform.python_version())"); $State.python_source = $Py.src
  Complete-Step 'ok' "Đã cài Python $($State.python) ($($Py.src))"
}

# ---------------- B8. Quét nhanh + chọn cách xử lý video ----------------
# Chạy NGAY sau B2 (trước ffmpeg): biết hạng máy rồi mới cài phần video nặng. Phần hỏi/lưu/hẹn giờ nằm ở app\videomode.py
# (dùng chung với bộ cài Mac, kiểm thử được) – gọi bằng Python gốc vừa có ở B2, KHÔNG bắt đầu ra (để hiện câu hỏi + đọc phím).
Start-Step 'B8' 'Quét nhanh máy + chọn cách xử lý video'
$VideoPack = ($PackFlag -ne 'no')      # đã chọn "Có – dựng trên máy": cài Bộ công cụ dựng video trừ khi B8 chọn [1] hoặc --no-video
$VmOut = Join-Path $DataDir 'install_video_choice.txt'
$vm = @{}
if ($Py) {
  $vmArgs = @('-u', (Join-Path $Engine 'app\videomode.py'), 'choose', '--out', $VmOut)
  if ($Dry) { $vmArgs += '--dry' }
  if ($CiMode) { $vmArgs += '--ci' }
  if ($AskVideo) { $vmArgs += '--ask' }
  if ($PackFlag) { $vmArgs += @('--pack', $PackFlag) }
  Remove-Item -LiteralPath $VmOut -Force -ErrorAction SilentlyContinue
  & $Py.exe @vmArgs
  if (Test-Path -LiteralPath $VmOut) {
    foreach ($l in [IO.File]::ReadAllLines($VmOut)) { $i = $l.IndexOf('='); if ($i -gt 0) { $vm[$l.Substring(0, $i)] = $l.Substring($i + 1) } }
    Remove-Item -LiteralPath $VmOut -Force -ErrorAction SilentlyContinue
  }
}
if ($vm.STATUS) {
  $VideoPack = ($vm.PACK -eq 'install'); $State.video_mode = $vm.MODE; $State.video_pack = $vm.PACK
  if ($vm.TIER) { $State.tier = $vm.TIER }
  Complete-Step $vm.STATUS $vm.MSG
} elseif ($Dry -and -not $Py) {
  $State.video_mode = 'online'; $State.video_pack = 'install'
  Complete-Step 'dry' 'Sẽ quét nhanh máy rồi hỏi: [4] Dựng video trên máy / [2] Dựng + AI ngay trên máy (máy Mạnh) / [1] Thôi – chỉ AI trên mạng'
} else {
  $State.video_mode = 'online'; $State.video_pack = $(if ($VideoPack) { 'install' } else { 'skip' })
  Complete-Step 'warn' 'Chưa quét nhanh được máy – dựng video trên máy như đã chọn ([4]); hạng máy xem lại ở B7'
}
# B8 [1] "Thôi – chỉ làm video bằng AI trên mạng" (máy yếu mặc định) hoặc --no-video: DỪNG ở đây – không .venv, không ffmpeg, không lối tắt.
if ($vm.STOP -eq '1' -or ($PackFlag -eq 'no' -and -not $VideoPack)) {
  $State.video_mode = 'online'; $State.video_pack = 'skip'
  $State.finished_at = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); Write-Report
  Write-Host ''
  Write-Host '=== KHÔNG CÀI THÊM ===' -ForegroundColor Green
  Write-Host 'Video làm bằng AI trên mạng ngay trong app (tính phí theo nhà cung cấp) – không dựng video trên máy này.'
  Write-Host "Muốn làm video bản đồ/quy hoạch trên máy này: bấm đúp lại $($ClickName), chọn [1] rồi [4] (thêm --chon-video để hỏi lại)."
  if ($WebApp) {
    Write-Host "Mở app: $WebApp"
    if (-not $CiMode -and -not $Dry) { try { Start-Process ($WebApp + '/') } catch { } }
  } else { Write-Host 'Mở app trên trình duyệt như mọi khi.' }
  exit 0
}

# ---------------- Phụ thuộc theo cách làm video đã chọn (deps_video.json – nguồn sự thật duy nhất, dùng chung với bộ cài Mac) ----------------
# tools\deps_video.py plan (Python gốc của B2, chỉ thư viện chuẩn): kiểm từng mục, bỏ mục đã có, in dung lượng + thời gian TRƯỚC khi tải.
# Mục ffmpeg "required" ở chế độ đã chọn (NEED_FFMPEG=1) → bật cài Bộ công cụ dựng video ở B3, trừ khi khách chủ động --no-video /
# BDS_VIDEO_PACK=0. Mô hình AI không bao giờ tải ở đây (B9 / app hỏi xác nhận đúng số GB).
$DvMode = if ($State.video_mode -eq 'offline') { 'offline' } elseif ($VideoPack) { 'pack' } else { 'online' }
$DvTool = Join-Path $Engine 'tools\deps_video.py'
$State.deps_manifest = 'missing'
if ($Py -and (Test-Path -LiteralPath $DvTool) -and (Test-Path -LiteralPath (Join-Path $Engine 'deps_video.json'))) {
  $DvOut = Join-Path $DataDir 'install_deps_plan.txt'
  Remove-Item -LiteralPath $DvOut -Force -ErrorAction SilentlyContinue
  $dvArgs = @('-u', $DvTool, 'plan', '--mode', $DvMode, '--os', 'windows', '--out', $DvOut)
  if ($Dry) { $dvArgs += '--dry' } elseif (-not ($PackFlag -eq 'no' -or $env:BDS_VIDEO_PACK -in @('0', 'no', 'false', 'khong'))) { $dvArgs += '--apply' }   # ghi video_pack=install
  & $Py.exe @dvArgs
  $dv = @{}
  if (Test-Path -LiteralPath $DvOut) {
    foreach ($l in [IO.File]::ReadAllLines($DvOut)) { $i = $l.IndexOf('='); if ($i -gt 0) { $dv[$l.Substring(0, $i)] = $l.Substring($i + 1) } }
    Remove-Item -LiteralPath $DvOut -Force -ErrorAction SilentlyContinue
  }
  if ($dv.STATUS) {
    $State.deps_manifest = 'used'; $State.deps_plan = [ordered]@{ mode = $DvMode; message = $dv.MSG; download_bytes = $dv.DL_BYTES }
    $optOut = ($PackFlag -eq 'no') -or ($env:BDS_VIDEO_PACK -in @('0', 'no', 'false', 'khong'))
    if ($dv.FFMPEG_REQUIRED -eq '1' -and -not $VideoPack -and -not $optOut) {
      $VideoPack = $true; $State.video_pack = 'install'                # chủ 17/11: làm video trên máy → cài đủ (kể cả [1] Online)
      if ($dv.NEED_FFMPEG -eq '1') { Say "Cách làm video này cần ffmpeg để dựng video trên máy – sẽ cài ở bước sau ($($dv.FFMPEG_EST))" }
    }
    if ($dv.FFMPEG_BAD) { Say "ffmpeg có sẵn trên máy là bản rút gọn ($($dv.FFMPEG_BAD)) – sẽ tải bản đầy đủ vào $BinDir" }
  } else { $State.deps_manifest = 'present_unused' }
}

# ---------------- B3. ffmpeg ----------------
Start-Step 'B3' 'ffmpeg – Bộ công cụ dựng video'
$FfMode = $env:BDS_FFMPEG_SOURCE; if (-not $FfMode) { $FfMode = 'auto' }
$Ff = $null
if ($FfMode -eq 'direct') {
  $c = Join-Path $BinDir 'ffmpeg.exe'
  if ((Test-Ff $c) -and (Test-Ff (Join-Path $BinDir 'ffprobe.exe'))) { $Ff = $c; $State.ffmpeg_source = 'direct' }
} else {
  $Ff = Find-Ffmpeg; if ($Ff) { $State.ffmpeg_source = 'existing' }
}
if (-not $VideoPack) {
  # Không chọn Bộ công cụ dựng video → KHÔNG tải gì (kể cả máy Khá/Mạnh). ffmpeg có sẵn từ trước thì để nguyên, không đụng.
  $State.ffmpeg_source = 'skipped'; $Ff = $null
  Complete-Step 'skipped' 'Bỏ qua – Bộ công cụ dựng video chưa cài (không chọn): cài sau trong app (Video › Bộ công cụ dựng video › Cài ngay) hoặc chạy lại bộ cài với --video'
} elseif ($Ff) {
  $State.ffmpeg = ((& $Ff -version 2>$null | Select-Object -First 1) -split ' ')[2]
  Complete-Step 'ok' "Đã có ffmpeg $($State.ffmpeg) ($Ff)"
} elseif ($Dry) {
  Complete-Step 'dry' 'Sẽ cài ffmpeg (winget, dự phòng tải thẳng bản essentials ~100 MB) – không cần quyền quản trị'
} else {
  $wg = Get-WingetExe
  if ($wg -and $FfMode -in @('auto', 'winget')) {
    Say 'winget đang cài ffmpeg (2–5 phút)'
    & $wg install --id Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity | Out-Host
    $pkgRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
    $pkg = Get-ChildItem -Path $pkgRoot -Directory -Filter 'Gyan.FFmpeg*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($pkg -and (Copy-FfmpegFrom $pkg.FullName)) { $Ff = Join-Path $BinDir 'ffmpeg.exe'; $State.ffmpeg_source = 'winget' }
    elseif (Find-Ffmpeg) { $Ff = Find-Ffmpeg; $State.ffmpeg_source = 'winget' }
    else { Write-Host '   ⚠ winget chưa cài được ffmpeg – tải thẳng' -ForegroundColor Yellow }
  }
  if (-not $Ff -and $FfMode -ne 'winget') {
    $sources = @(
      @{ name = 'gyan.dev'; url = $FfGyan; sha = { (Get-Text "$FfGyan.sha256").Trim().Split(' ')[0] } },
      @{ name = 'GitHub BtbN'; url = $FfBtbN; sha = { $l = (Get-Text $FfBtbNSums) -split "`n" | Where-Object { $_.Trim() -match 'ffmpeg-master-latest-win64-gpl\.zip$' } | Select-Object -First 1; if ($l) { $l.Split(' ')[0] } else { '' } } }
    )
    foreach ($s in $sources) {
      Say "tải ffmpeg từ $($s.name) (~100–200 MB)"
      $sha = & $s.sha
      if ($sha -notmatch '^[0-9a-fA-F]{64}$') { $sha = '' }    # nguồn không cho mã kiểm tra → kiểm bằng chạy thử
      $zip = Join-Path $DlDir ("ffmpeg-" + ($s.name -replace '[^A-Za-z0-9]', '') + '.zip')
      if (-not (Get-File $s.url $zip $sha)) { Write-Host '   ⚠ Nguồn này chưa được – thử nguồn khác' -ForegroundColor Yellow; continue }
      $x = Join-Path $DlDir 'x_ffmpeg'
      if ((Expand-Any $zip $x) -and (Copy-FfmpegFrom $x)) {
        $Ff = Join-Path $BinDir 'ffmpeg.exe'; $State.ffmpeg_source = "direct:$($s.name)"
        Remove-Item -LiteralPath $x -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
        break
      }
      Remove-Item -LiteralPath $x -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
      Write-Host '   ⚠ Tệp ffmpeg hỏng – thử nguồn khác' -ForegroundColor Yellow
    }
  }
  if (-not $Ff) { Stop-Install 'Lỗi B3: không tải được ffmpeg – kiểm tra mạng, bấm chạy lại' }
  $State.ffmpeg = ((& $Ff -version 2>$null | Select-Object -First 1) -split ' ')[2]
  Complete-Step 'ok' "Đã cài ffmpeg $($State.ffmpeg) ($($State.ffmpeg_source))"
}

# ---------------- B4. .venv + thư viện ----------------
Start-Step 'B4' 'Môi trường riêng + thư viện Python của máy dựng'
$ReqSha = Get-Sha256 (Join-Path $Engine 'requirements.txt')
$Marker = Join-Path $Engine '.venv\.bds_req_sha256'
function Test-VenvReady {
  if (-not (Test-Py $VPy @())) { return $false }
  if (-not $ReqSha -or -not (Test-Path -LiteralPath $Marker) -or ([string](Get-Content -LiteralPath $Marker -Raw)).Trim() -ne $ReqSha) { return $false }
  & $VPy -c "import PIL, numpy" 2>$null | Out-Null
  return ($LASTEXITCODE -eq 0)
}
if (Test-VenvReady) {
  Complete-Step 'ok' 'Đã có (.venv, thư viện đúng requirements.txt)'
} elseif ($Dry) {
  Complete-Step 'dry' ('Sẽ tạo .venv và cài: ' + ((Get-Content -LiteralPath (Join-Path $Engine 'requirements.txt')) -join ' '))
} else {
  if ((Test-Path -LiteralPath (Join-Path $Engine '.venv')) -and -not (Test-Py $VPy @())) {
    Say '.venv cũ bị hỏng (Python gốc đã đổi/xoá) – tạo lại'
    Remove-Item -LiteralPath (Join-Path $Engine '.venv') -Recurse -Force
  }
  if (-not (Test-Path -LiteralPath $VPy)) {
    & $Py.exe -m venv (Join-Path $Engine '.venv')
    if (-not (Test-Path -LiteralPath $VPy)) { Stop-Install 'Lỗi B4: không tạo được môi trường .venv – bấm chạy lại' }
  }
  & $VPy -m pip install --disable-pip-version-check --no-input -q --upgrade pip 2>$null | Out-Null
  Say 'cài thư viện (1–3 phút)'
  $req = Join-Path $Engine 'requirements.txt'
  & $VPy -m pip install --disable-pip-version-check --no-input -q -r $req
  if ($LASTEXITCODE -ne 0) { & $VPy -m pip install --disable-pip-version-check --no-input -q -r $req }
  if ($LASTEXITCODE -eq 0) {
    [IO.File]::WriteAllText($Marker, $ReqSha, (New-Object System.Text.UTF8Encoding $false))
    Complete-Step 'ok' 'Đã cài thư viện vào .venv'
  } else {
    & $VPy -m pip install --disable-pip-version-check --no-input -q "pillow>=10.0" "numpy>=1.26"
    if ($LASTEXITCODE -eq 0) { Complete-Step 'warn' 'Đã cài phần bắt buộc; thiếu thư viện phụ (keyring/pyzipper) – chạy lại bộ cài khi mạng ổn định' }
    else { Stop-Install 'Lỗi B4: không cài được thư viện Python – kiểm tra mạng, bấm chạy lại' }
  }
}

# ---------------- B5. Biểu tượng ----------------
# Mọi lối tắt khách bấm đều mang biểu tượng riêng của BDS Studio (assets\*.ico, tools/icons_build.mjs) – KHÔNG để biểu tượng mặc định cmd/PowerShell:
#   Màn hình nền  BDS Studio                  → pythonw app\launcher.py (máy dựng chạy nền, không cửa sổ đen) · bds_studio.ico (ngôi nhà vàng)
#   Start Menu › BDS Studio:
#     BDS Studio                              → như trên · bds_studio.ico
#     Bật máy dựng BDS Studio                 → start_windows.bat (cửa sổ máy dựng, đóng cửa sổ = tắt) · bds_studio_bat.ico (▶)
#     Tắt máy dựng BDS Studio                 → pythonw app\launcher.py --stop · bds_studio_tat.ico (■)   (chỉ khi có pythonw.exe)
#     Cài đặt lại BDS Studio                  → install_windows.bat (chạy lại bộ cài: sửa/cập nhật) · bds_studio_cai.ico (↓)
#     Gỡ cài đặt BDS Studio                   → uninstall_windows.bat · bds_studio_go.ico (✕)
#   Cài đặt › Ứng dụng (Settings › Apps): mục "BDS Studio" của riêng tài khoản (HKCU, không cần quyền quản trị) · bds_studio.ico,
#     nút Gỡ cài đặt ở đó chạy uninstall_windows.bat.
# Cài lại → ghi đè đúng các lối tắt/mục đó (cùng tên, cùng đích, cùng biểu tượng) – chạy bao nhiêu lần cũng ra cùng kết quả.
# Thiếu pythonw.exe → "BDS Studio" trỏ start_windows.bat như bản cũ (vẫn mang biểu tượng). Thiếu tệp .ico riêng → dùng bds_studio.ico.
Start-Step 'B5' "Biểu tượng 'BDS Studio' (màn hình nền + Start Menu)"
$Desktop = [Environment]::GetFolderPath('Desktop')
$StartDir = Join-Path ([Environment]::GetFolderPath('Programs')) 'BDS Studio'
$PyW = Join-Path $Engine '.venv\Scripts\pythonw.exe'
$Assets = Join-Path $Engine 'assets'
$Ico = Join-Path $Assets 'bds_studio.ico'
$LauncherPy = Join-Path $Engine 'app\launcher.py'
$StartBat = Join-Path $Engine 'start_windows.bat'
$InstallBat = Join-Path $Engine 'install_windows.bat'
$UninstallBat = Join-Path $Engine 'uninstall_windows.bat'
$UninstallKey = 'Software\Microsoft\Windows\CurrentVersion\Uninstall\BDSStudio'
# Ghi lối tắt bằng IShellLinkW (Unicode): WScript.Shell đổi ký tự ngoài bảng mã máy thành '?' → KHÔNG lưu được
# 'Tắt máy dựng BDS Studio.lnk' (chữ ắ/ự/ạ không có trong cp1252 – gặp thật trên GitHub 17/11), cũng hỏng khi tên người
# dùng có dấu (C:\Users\Tên\…). Máy chặn biên dịch Add-Type → dự phòng WScript.Shell: lưu tên tạm ASCII rồi đổi tên bằng .NET.
$ShellLinkCs = @'
using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
namespace BdsStudio {
  [ComImport, Guid("000214F9-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  internal interface IShellLinkW {
    void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszFile, int cch, IntPtr pfd, uint fFlags);
    void GetIDList(out IntPtr ppidl);
    void SetIDList(IntPtr pidl);
    void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cch);
    void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);
    void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszDir, int cch);
    void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);
    void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszArgs, int cch);
    void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);
    void GetHotkey(out short pwHotkey);
    void SetHotkey(short wHotkey);
    void GetShowCmd(out int piShowCmd);
    void SetShowCmd(int iShowCmd);
    void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszIconPath, int cch, out int piIcon);
    void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
    void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, uint dwReserved);
    void Resolve(IntPtr hwnd, uint fFlags);
    void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
  }
  [ComImport, Guid("00021401-0000-0000-C000-000000000046")]
  internal class CShellLink { }
  public static class ShellLink {
    public static void Save(string path, string target, string args, string workDir, string desc, string icon) {
      IShellLinkW l = (IShellLinkW)new CShellLink();
      try {
        l.SetPath(target);
        l.SetArguments(args ?? "");
        l.SetWorkingDirectory(workDir ?? "");
        l.SetDescription(desc ?? "");
        if (!String.IsNullOrEmpty(icon)) { l.SetIconLocation(icon, 0); }
        ((IPersistFile)l).Save(path, true);
      } finally { Marshal.FinalReleaseComObject(l); }
    }
    public static string Target(string path) {
      IShellLinkW l = (IShellLinkW)new CShellLink();
      try {
        ((IPersistFile)l).Load(path, 0);
        StringBuilder sb = new StringBuilder(1024);
        l.GetPath(sb, sb.Capacity, IntPtr.Zero, 0);
        return sb.ToString();
      } finally { Marshal.FinalReleaseComObject(l); }
    }
  }
}
'@
$LnkLog = Join-Path $DataDir 'install_shortcut.log'
function Write-LnkLog($msg) { try { [IO.File]::AppendAllText($LnkLog, ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss ') + $msg + "`r`n"), (New-Object System.Text.UTF8Encoding $false)) } catch { } }
$UseShellLinkW = $false
if (-not $Dry) {
  try {
    if (-not ('BdsStudio.ShellLink' -as [type])) { Add-Type -TypeDefinition $ShellLinkCs -Language CSharp -ErrorAction Stop }
    $UseShellLinkW = $true
  } catch { Write-LnkLog "Add-Type IShellLinkW lỗi (dùng WScript.Shell): $($_.Exception.Message)" }
}
function Get-BdsIcon($file) {
  $p = Join-Path $Assets $file
  if (Test-Path -LiteralPath $p) { return $p }
  if (Test-Path -LiteralPath $Ico) { return $Ico }
  return ''
}
# Đích + tham số của lối tắt theo loại. 'open'/'stop' cần pythonw.exe (không cửa sổ đen); thiếu → 'open' trỏ start_windows.bat.
function Get-BdsTarget($kind) {
  $hasPyW = (Test-Path -LiteralPath $PyW) -and (Test-Path -LiteralPath $LauncherPy)
  switch ($kind) {
    'open' { if ($hasPyW) { return @($PyW, ('"{0}"' -f $LauncherPy)) } else { return @($StartBat, '') } }
    'stop' { if ($hasPyW) { return @($PyW, ('"{0}" --stop' -f $LauncherPy)) } else { return $null } }
    'engine' { return @($StartBat, '') }
    'install' { return @($InstallBat, '') }
    'uninstall' { if (Test-Path -LiteralPath $UninstallBat) { return @($UninstallBat, '') } else { return $null } }
  }
  return $null
}
# Danh sách lối tắt (nơi, tên, loại, biểu tượng, mô tả) – tests/unit/windows_icons.test.mjs đọc bảng này: mỗi dòng PHẢI có biểu tượng.
$BdsShortcuts = @(
  @{ dir = 'desktop'; name = 'BDS Studio.lnk'; kind = 'open'; icon = 'bds_studio.ico'; desc = 'Mở BDS Studio (máy dựng chạy nền)' },
  @{ dir = 'start'; name = 'BDS Studio.lnk'; kind = 'open'; icon = 'bds_studio.ico'; desc = 'Mở BDS Studio (máy dựng chạy nền)' },
  @{ dir = 'start'; name = 'Bật máy dựng BDS Studio.lnk'; kind = 'engine'; icon = 'bds_studio_bat.ico'; desc = 'Bật máy dựng trong cửa sổ riêng (đóng cửa sổ là tắt)' },
  @{ dir = 'start'; name = 'Tắt máy dựng BDS Studio.lnk'; kind = 'stop'; icon = 'bds_studio_tat.ico'; desc = 'Tắt máy dựng BDS Studio đang chạy nền' },
  @{ dir = 'start'; name = 'Cài đặt lại BDS Studio.lnk'; kind = 'install'; icon = 'bds_studio_cai.ico'; desc = 'Chạy lại bộ cài (sửa lỗi, cập nhật, chọn lại cách làm video)' },
  @{ dir = 'start'; name = 'Gỡ cài đặt BDS Studio.lnk'; kind = 'uninstall'; icon = 'bds_studio_go.ico'; desc = 'Gỡ BDS Studio khỏi máy này (giữ dữ liệu và video)' }
)
function New-BdsShortcut($path, $target, $targs, $desc, $icon) {
  $done = $false; $chk = ''
  if ($UseShellLinkW) {
    try {
      [BdsStudio.ShellLink]::Save($path, $target, $targs, $Engine, $desc, $icon)
      $chk = [BdsStudio.ShellLink]::Target($path); $done = $true
    } catch { Write-LnkLog "IShellLinkW lỗi với $path (thử WScript.Shell): $($_.Exception.Message)" }
  }
  if (-not $done) {
    # WScript.Shell chỉ chắc với tên ASCII: lưu tên tạm cùng thư mục → đọc lại → đổi sang tên thật (đổi tên bằng .NET, Unicode)
    $tmp = Join-Path (Split-Path -Parent $path) ('bds_lnk_' + [Diagnostics.Process]::GetCurrentProcess().Id + '.lnk')
    $Ws = New-Object -ComObject WScript.Shell
    $Lnk = $Ws.CreateShortcut($tmp)
    $Lnk.TargetPath = $target
    $Lnk.Arguments = $targs
    $Lnk.WorkingDirectory = $Engine
    $Lnk.Description = $desc
    if ($icon) { $Lnk.IconLocation = "$icon,0" }
    $Lnk.Save()
    $chk = $Ws.CreateShortcut($tmp).TargetPath
    if ([IO.File]::Exists($path)) { [IO.File]::Delete($path) }
    [IO.File]::Move($tmp, $path)
  }
  # đọc lại: lối tắt phải trỏ đúng tệp có thật (đường dẫn có ký tự ngoài bảng mã máy từng bị ghi sai) → báo để mở bằng start_windows.bat
  if (-not $chk -or -not (Test-Path -LiteralPath $chk)) { throw "lối tắt $path trỏ sai: '$chk'" }
  if (-not [IO.File]::Exists($path)) { throw "chưa thấy tệp $path sau khi lưu" }
}
function Set-BdsShortcut($sc) {
  $t = Get-BdsTarget $sc.kind
  if (-not $t) { return $false }
  $dir = if ($sc.dir -eq 'desktop') { $Desktop } else { $StartDir }
  New-BdsShortcut (Join-Path $dir $sc.name) $t[0] $t[1] $sc.desc (Get-BdsIcon $sc.icon)
  return $true
}
# Mục "BDS Studio" trong Cài đặt › Ứng dụng (của riêng tài khoản này – HKCU, không cần quyền quản trị): biểu tượng + nút Gỡ cài đặt.
function Set-BdsUninstallEntry {
  if (-not (Test-Path -LiteralPath $UninstallBat)) { return }
  $k = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($UninstallKey)
  try {
    $cmd = Join-Path $env:SystemRoot 'System32\cmd.exe'
    $k.SetValue('DisplayName', 'BDS Studio')
    $k.SetValue('DisplayIcon', "$Ico,0")
    if ($EngineVersion) { $k.SetValue('DisplayVersion', $EngineVersion) }
    $k.SetValue('Publisher', 'BDS Studio')
    $k.SetValue('InstallLocation', $Engine)
    $k.SetValue('UninstallString', ('"{0}" /c ""{1}""' -f $cmd, $UninstallBat))
    $k.SetValue('NoModify', 1, [Microsoft.Win32.RegistryValueKind]::DWord)
    $k.SetValue('NoRepair', 1, [Microsoft.Win32.RegistryValueKind]::DWord)
  } finally { $k.Close() }
}
if ($Dry) {
  Complete-Step 'dry' "Sẽ tạo $Desktop\BDS Studio.lnk + Start Menu (Bật/Tắt máy dựng, Cài đặt lại, Gỡ cài đặt – mỗi mục một biểu tượng; mở không hiện cửa sổ đen)"
} else {
  try {
    [void](Set-BdsShortcut $BdsShortcuts[0])
    $startOk = $true; $startErr = ''
    try {
      if (-not (Test-Path -LiteralPath $StartDir)) { New-Item -ItemType Directory -Force -Path $StartDir -ErrorAction Stop | Out-Null }
      foreach ($sc in ($BdsShortcuts | Where-Object { $_.dir -eq 'start' })) { [void](Set-BdsShortcut $sc) }
    } catch { $startOk = $false; $startErr = "Start Menu: $($_.Exception.Message)"; Write-LnkLog $startErr }
    try { Set-BdsUninstallEntry } catch { Write-LnkLog "Mục Cài đặt › Ứng dụng: $($_.Exception.Message)" }
    $msg = "Đã tạo 'BDS Studio' trên màn hình nền" + $(if ($startOk) { ' + Start Menu' } else { ' (chưa thêm được vào Start Menu)' })
    if (-not (Test-Path -LiteralPath $PyW)) { Complete-Step 'warn' "$msg – chưa có pythonw.exe nên mở có cửa sổ đen như cũ" $startErr }
    elseif (-not (Test-Path -LiteralPath $Ico)) { Complete-Step 'warn' "$msg – thiếu assets\bds_studio.ico (dùng biểu tượng mặc định)" $startErr }
    elseif (-not $startOk) { Complete-Step 'warn' $msg $startErr }
    else { Complete-Step 'ok' $msg }
  } catch {
    $e = "Màn hình nền: $($_.Exception.Message)"; Write-LnkLog $e
    Complete-Step 'warn' 'Không tạo được lối tắt – mở máy dựng bằng start_windows.bat trong thư mục _he_thong của BDS_Studio_Engine' $e
  }
}

# ---------------- B6. Bật thử máy dựng ----------------
Start-Step 'B6' 'Bật thử máy dựng tại máy (127.0.0.1)'
if ($Dry) {
  Complete-Step 'dry' 'Sẽ bật thử máy dựng ở cổng tạm rồi tắt'
} else {
  $port = (& $VPy -c "import socket; s = socket.socket(); s.bind(('127.0.0.1', 0)); print(s.getsockname()[1])").Trim()
  $log = Join-Path $DataDir 'install_server_test.log'
  $proc = Start-Process -FilePath $VPy -ArgumentList @('app\server.py', '--no-browser', '--port', $port) -WorkingDirectory $Engine `
    -NoNewWindow -PassThru -RedirectStandardOutput $log -RedirectStandardError "$log.err"
  # hỏi /health bằng Python, bỏ qua proxy của máy (proxy công ty có thể chặn 127.0.0.1)
  $probe = "import sys, urllib.request as u; o = u.build_opener(u.ProxyHandler({})); sys.exit(0 if b'bds-studio-engine' in o.open('http://127.0.0.1:$port/health', timeout=2).read() else 1)"
  $okHealth = $false
  for ($i = 0; $i -lt 40 -and -not $okHealth; $i++) {
    Start-Sleep -Milliseconds 500
    & $VPy -c $probe 2>$null | Out-Null
    $okHealth = ($LASTEXITCODE -eq 0)
    if ($proc.HasExited) { break }
  }
  try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { }
  if ($okHealth) { Complete-Step 'ok' 'Máy dựng chạy được (đã tắt bản thử)' }
  else { Stop-Install "Lỗi B6: máy dựng không bật được – xem $log, bấm chạy lại" }
}

# ---------------- B7. Quét máy ----------------
Start-Step 'B7' 'Quét cấu hình máy (xếp hạng Cơ bản / Khá / Mạnh)'
if ($Dry) {
  Complete-Step 'dry' ('Sẽ quét CPU, RAM, GPU, ổ trống' + $(if ($Bench) { ' + đo thử dựng 10 giây' } else { '' }))
} else {
  $hwArgs = @('app\hwscan.py', '--save')
  if ($Bench -and $VideoPack -and (Find-Ffmpeg)) { $hwArgs += '--bench'; Say 'đo thử dựng 10 giây video' }
  $hwLine = (& $VPy @hwArgs 2>$null | Select-Object -Last 1)
  if ($LASTEXITCODE -eq 0 -and $hwLine) {
    $State.tier = (& $VPy -c "import sys; sys.path.insert(0, 'app'); import hwscan; print((hwscan.load() or {}).get('tier', ''))" 2>$null | Select-Object -Last 1)
    Complete-Step 'ok' $hwLine
  } else { Complete-Step 'warn' 'Chưa quét được máy – mở app: Cài đặt → Máy của tôi → Quét lại máy' }
}

# ---------------- B9. Video AI offline (chỉ khi B8 chọn Offline) ----------------
# Cài thư viện chạy mô hình bằng ĐÚNG hàm của app (videoai.run_setup), nạp thử; Smart App Control chặn → Online + giải thích.
Start-Step 'B9' 'Video AI offline (thư viện chạy mô hình)'
if ($State.video_mode -ne 'offline') {
  Complete-Step 'skipped' ('Không cần – ' + $(if ($State.video_mode -eq 'later') { 'chọn để sau' } else { 'Video AI chạy online' }))
} elseif ($Dry) {
  Complete-Step 'dry' 'Sẽ cài thư viện chạy mô hình (torch bản CUDA + diffusers…) vào .venv rồi nạp thử; Smart App Control chặn → chuyển Online'
} else {
  $vm = @{}
  Remove-Item -LiteralPath $VmOut -Force -ErrorAction SilentlyContinue
  $vmArgs = @('-u', (Join-Path $Engine 'app\videomode.py'), 'offline', '--out', $VmOut)
  if ($CiMode) { $vmArgs += '--ci' }
  & $VPy @vmArgs
  if (Test-Path -LiteralPath $VmOut) {
    foreach ($l in [IO.File]::ReadAllLines($VmOut)) { $i = $l.IndexOf('='); if ($i -gt 0) { $vm[$l.Substring(0, $i)] = $l.Substring($i + 1) } }
    Remove-Item -LiteralPath $VmOut -Force -ErrorAction SilentlyContinue
  }
  if ($vm.MODE) { $State.video_mode = $vm.MODE }
  if ($vm.STATUS) { Complete-Step $vm.STATUS $vm.MSG }
  else { $State.video_mode = 'online'; Complete-Step 'warn' 'Lỗi B9: chưa cài được Video AI offline – tạm dùng Video AI Online (xem install_videoai.log, chạy lại bộ cài với --chon-video)' }
}

# ---------------- Tự kiểm cuối: dựng thử 3 giây có phụ đề tiếng Việt (giống bộ cài Mac) ----------------
# tools\deps_video.py selftest (Python của .venv): ĐẠT/LỖI từng mục bắt buộc của chế độ đã chọn + dựng thử bằng đúng đường dựng
# của máy dựng (flow.render_sub_png + flow.ff, libx264) → %USERPROFILE%\.bds_studio\install_selftest.mp4; kết quả ở "selftest"
# của install_report.json (khoá giống Mac: status, seconds, file, duration, width, height, subtitle, message + muc, chay_lai).
# Giọng đọc không thử (chỉ có Vbee trả phí). Lỗi chỉ ⚠ + cách sửa tiếng Việt + câu chạy lại (không dừng bộ cài).
if ($Dry) {
  Write-Host '   ○ (chạy thử) Sẽ dựng thử 3 giây có phụ đề tiếng Việt (kết quả vào báo cáo)'
} elseif ((Test-Path -LiteralPath $DvTool) -and (Test-Py $VPy @())) {
  Write-Host ''
  Write-Host 'Tự kiểm cách làm video đã chọn + dựng thử 3 giây có phụ đề tiếng Việt…' -ForegroundColor Cyan
  # chế độ đã chọn ở B8 (giữ 'online' cho [1] dù đã bật cài ffmpeg); B9 lùi Offline → Online thì kiểm như Online
  if ($DvMode -eq 'offline' -and $State.video_mode -ne 'offline') { $DvMode = 'online' }
  $StKv = Join-Path $DataDir 'install_selftest.txt'; $StJson = Join-Path $DataDir 'install_selftest.json'
  Remove-Item -LiteralPath $StKv, $StJson -Force -ErrorAction SilentlyContinue
  # không truyền dấu " trong tham số cho python.exe (PowerShell 5.1 tách sai tham số có dấu " lồng)
  $rerun = 'Bấm đúp lại ' + ($ClickName -replace '"', '') + ' – phần đã xong được giữ, bộ cài làm tiếp và tự kiểm lại.'
  & $VPy -u $DvTool selftest --mode $DvMode --os windows --out $StKv --out-json $StJson --rerun $rerun
  $st = $null
  try { $st = [IO.File]::ReadAllText($StJson, [Text.Encoding]::UTF8) | ConvertFrom-Json } catch { }
  if ($st) {
    $State.selftest = $st
    if ($st.status -eq 'ok') { Write-Host "   ✓ Dựng thử được – video mẫu: $($st.file)" -ForegroundColor Green }
    elseif ($st.status -eq 'skipped') { Write-Host "   ○ $($st.message)" }
    else { Write-Host "   ⚠ $($st.message) – $($st.chay_lai)" -ForegroundColor Yellow }
  } else {
    $State.selftest = [ordered]@{ status = 'failed'; message = "Tự kiểm chưa chạy được – xem $(Join-Path $DataDir 'install_selftest.log'), bấm đúp lại $ClickName" }
    Write-Host "   ⚠ $($State.selftest.message)" -ForegroundColor Yellow
  }
  Remove-Item -LiteralPath $StKv, $StJson -Force -ErrorAction SilentlyContinue
} else {
  $State.selftest = [ordered]@{ status = 'skipped'; message = 'Chưa có máy dựng (.venv) – không tự kiểm' }
}

$State.finished_at = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); Write-Report
Write-Host ""
if ($Dry) { Write-Host "=== CHẠY THỬ XONG – báo cáo: $Report ===" -ForegroundColor Green; exit 0 }
& $VPy -c "import sys; sys.path.insert(0, 'app'); import selfcheck; [print(('  OK ' if i['ok'] else ('  THIẾU ' if i['required'] else '  (tuỳ chọn) ')) + i['name'] + ('' if i['ok'] else ' - ' + i['fix'])) for i in selfcheck.check()]"
Write-Host ""
Write-Host "=== XONG BỘ CÀI MÁY DỰNG VIDEO. Phần mở rộng (AI trên máy…) cài sau trong app. Báo cáo: $Report ===" -ForegroundColor Green
if (-not $VideoPack) { Write-Host 'Bộ công cụ dựng video chưa cài (tuỳ chọn) – cần dựng video trên máy: mở app › Video › Bộ công cụ dựng video › "Cài ngay".' }
if ($Launch) {
  Write-Host "Đang mở BDS Studio… (lần sau: bấm đúp 'BDS Studio' trên màn hình nền hoặc Start Menu)"
  if ((Test-Path -LiteralPath $PyW) -and (Test-Path -LiteralPath $LauncherPy)) {
    Start-Process -FilePath $PyW -ArgumentList @("`"$LauncherPy`"") -WorkingDirectory $Engine
    Write-Host 'Máy dựng chạy nền (không có cửa sổ đen) – đóng cửa sổ này được. Tắt máy dựng: Start Menu → BDS Studio → Tắt máy dựng BDS Studio.'
  } else {
    Start-Process -FilePath (Join-Path $Engine 'start_windows.bat') -WorkingDirectory $Engine
  }
}
exit 0
