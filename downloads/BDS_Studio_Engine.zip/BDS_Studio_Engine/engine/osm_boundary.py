#!/usr/bin/env python3
"""Turn an Overpass `out geom;` result for an administrative boundary into an item polygon (area_ll).

python3 osm_boundary.py result.json ["Vĩnh Hưng"] [--simplify 15] [--all] > boundary.json
Accepts an Overpass `out geom;` result OR a Nominatim search result (polygon_geojson=1).
Prints {"name", "osm_id", "admin_level", "area_ll": [[lat, lon], ...], "area_km2"} for the best match.

Overpass query (run where the network allows it, e.g. the Composio workbench; send a User-Agent header):
  [out:json][timeout:120];
  rel["boundary"="administrative"]["name"~"Vĩnh Hưng"](south,west,north,east);
  out geom;
Nominatim (faster, usually enough):
  -> keep type "administrative" (current ward); type "historic" = the pre-2025 ward of the same name.
After the 7/2025 merger OSM may still hold old wards: check "start_date"/name against the merger resolution;
if the new ward = several old ones, fetch them all and merge with --union.
"""
import json, math, sys


def stitch(ways):
    """join way segments (lists of (lat,lon)) into closed rings"""
    segs = [list(w) for w in ways if len(w) > 1]; rings = []
    key = lambda p: (round(p[0], 7), round(p[1], 7))
    while segs:
        ring = segs.pop(0)
        changed = True
        while key(ring[0]) != key(ring[-1]) and changed:
            changed = False
            for i, s in enumerate(segs):
                if key(s[0]) == key(ring[-1]): ring += s[1:]
                elif key(s[-1]) == key(ring[-1]): ring += s[::-1][1:]
                elif key(s[-1]) == key(ring[0]): ring = s[:-1] + ring
                elif key(s[0]) == key(ring[0]): ring = s[::-1][:-1] + ring
                else: continue
                segs.pop(i); changed = True; break
        rings.append(ring)
    return rings


def area_km2(ring):
    lat0 = sum(p[0] for p in ring)/len(ring); kx = 111.32*math.cos(math.radians(lat0)); ky = 110.57
    xy = [(p[1]*kx, p[0]*ky) for p in ring]
    return abs(sum(a[0]*b[1] - b[0]*a[1] for a, b in zip(xy, xy[1:] + xy[:1])))/2


def simplify(ring, tol_m):
    """Douglas-Peucker in metres"""
    if len(ring) < 4 or tol_m <= 0: return ring
    if tuple(ring[0]) == tuple(ring[-1]):            # closed ring: simplify two halves separately
        h = len(ring)//2
        return simplify(ring[:h + 1], tol_m)[:-1] + simplify(ring[h:], tol_m)
    lat0 = ring[0][0]; kx = 111320*math.cos(math.radians(lat0)); ky = 110570
    P = [(p[1]*kx, p[0]*ky) for p in ring]; keep = [False]*len(P); keep[0] = keep[-1] = True; st = [(0, len(P)-1)]
    while st:
        a, b = st.pop(); (x1, y1), (x2, y2) = P[a], P[b]; L = math.hypot(x2-x1, y2-y1) or 1e-9; md, mi = 0, -1
        for i in range(a+1, b):
            d = abs((y2-y1)*P[i][0] - (x2-x1)*P[i][1] + x2*y1 - y2*x1)/L
            if d > md: md, mi = d, i
        if md > tol_m: keep[mi] = True; st += [(a, mi), (mi, b)]
    return [p for p, k in zip(ring, keep) if k]


def main():
    a = sys.argv[1:]
    data = json.load(open(a[0], encoding='utf-8'))
    name = next((x for x in a[1:] if not x.startswith('--')), None)
    tol = float(a[a.index('--simplify')+1]) if '--simplify' in a else 15
    if isinstance(data, list):                     # Nominatim result
        out = []
        for x in data:
            g = x.get('geojson') or {}
            polys = [g['coordinates']] if g.get('type') == 'Polygon' else (g.get('coordinates', []) if g.get('type') == 'MultiPolygon' else [])
            if not polys: continue
            ring = max(([(p[1], p[0]) for p in poly[0]] for poly in polys), key=area_km2)
            out.append(dict(name=x.get('name'), osm_id=x.get('osm_id'), kind=x.get('type'), display=x.get('display_name'),
                            area_km2=round(area_km2(ring), 3), area_ll=[[round(p[0], 6), round(p[1], 6)] for p in simplify(ring, tol)]))
        if name: out = [r for r in out if name.lower() in (r['name'] or '').lower()] or out
        out.sort(key=lambda r: (r['kind'] != 'administrative', -r['area_km2']))
        if not out: sys.exit('Không có polygon trong kết quả Nominatim')
        print(json.dumps(out if '--all' in a else out[0], ensure_ascii=False))
        for r in out: print(f"# {r['name']} | {r['kind']} | osm {r['osm_id']} | {r['area_km2']} km² | {len(r['area_ll'])} điểm", file=sys.stderr)
        return
    rels = [e for e in data.get('elements', []) if e.get('type') == 'relation']
    if name: rels = [e for e in rels if e.get('tags', {}).get('name', '').lower().endswith(name.lower())] or rels
    if not rels: sys.exit('Không có relation nào trong kết quả')
    out = []
    for e in rels:
        ways = [[(g['lat'], g['lon']) for g in m['geometry']] for m in e.get('members', [])
                if m.get('type') == 'way' and m.get('role') in ('outer', '') and m.get('geometry')]
        rings = stitch(ways)
        if not rings: continue
        ring = max(rings, key=area_km2)
        out.append(dict(name=e['tags'].get('name'), osm_id=e['id'], admin_level=e['tags'].get('admin_level'),
                        start_date=e['tags'].get('start_date'), area_km2=round(area_km2(ring), 3),
                        closed=ring[0] == ring[-1], area_ll=[[round(p[0], 6), round(p[1], 6)] for p in simplify(ring, tol)]))
    out.sort(key=lambda r: -r['area_km2'])
    if '--all' in a: print(json.dumps(out, ensure_ascii=False))
    else: print(json.dumps(out[0], ensure_ascii=False))
    for r in out: print(f"# {r['name']} | osm {r['osm_id']} | cấp {r['admin_level']} | {r['area_km2']} km² | {len(r['area_ll'])} điểm | kín={r['closed']}", file=sys.stderr)


if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()
