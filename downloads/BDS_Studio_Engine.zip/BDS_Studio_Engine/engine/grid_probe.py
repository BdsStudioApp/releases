#!/usr/bin/env python3
"""Draw a coordinate grid over the OSM geo data so you can read item coordinates (10 m units).

python3 grid_probe.py geo.txt X0 X1 Y0 Y1 out.png [px_per_m=0.12] [step_m=500]
  X0..Y1 in metres (same frame as the geo file). Grid labels = 10 m units, usable directly as "xy"/"path".
  Orange = roads under construction (RM/RT/RP), yellow = motorway, white = trunk, grey = primary.
"""
import sys
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, __import__('os').path.dirname(__file__))
from render_map import load_geo

def crop(F, X0, X1, Y0, Y1, s, fn, step=500):
    W = int((X1-X0)*s); H = int((Y1-Y0)*s); im = Image.new('RGB', (W, H), (14, 24, 40)); d = ImageDraw.Draw(im)
    f = lambda p: ((p[0]-X0)*s, (Y1-p[1])*s)
    for t, p in F:
        if t[0] == 'A' and len(p) > 2: d.polygon([f(q) for q in p], fill=(40, 110, 170))
    for t, p in F:
        if t.startswith('R'):
            c = {'m': (240, 180, 50), 't': (230, 220, 200), 'p': (130, 150, 170)}.get(t[1], (255, 120, 30)); d.line([f(a) for a in p], fill=c, width=3)
    fo = ImageFont.truetype('/usr/share/fonts/opentype/inter/Inter-Regular.otf', 12)
    for x in range(X0 - X0 % step, X1, step): d.line([((x-X0)*s, 0), ((x-X0)*s, H)], fill=(80, 80, 80)); d.text(((x-X0)*s+2, 2), str(x//10), font=fo, fill=(255, 255, 0))
    for y in range(Y0 - Y0 % step, Y1, step): d.line([(0, (Y1-y)*s), (W, (Y1-y)*s)], fill=(80, 80, 80)); d.text((2, (Y1-y)*s+2), str(y//10), font=fo, fill=(255, 255, 0))
    im.save(fn)

if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    a = sys.argv[1:]
    crop(load_geo(a[0]), *map(int, a[1:5]), float(a[6]) if len(a) > 6 else 0.12, a[5], int(a[7]) if len(a) > 7 else 500)
    print('saved', a[5])
