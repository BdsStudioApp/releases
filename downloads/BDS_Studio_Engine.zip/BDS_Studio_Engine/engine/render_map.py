#!/usr/bin/env python3
"""Planning-map video renderer (merged v3): real OSM vector basemap + animated overlays.

  python3 render_map.py cfg.json out.mp4            # full render (+ .srt + _cover.jpg)
  python3 render_map.py cfg.json out.mp4 stills     # one still per scene + contact.jpg
  python3 render_map.py cfg.json out.mp4 check      # lint config (ids, timing, sources, map edges, distances)
  python3 render_map.py cfg.json out.mp4 cover      # cover image only

Geo data (optional): lines "TAG:x,y dx,dy ..." in 10 m units (y north) around config 'origin'.
Tags: A* water polygons (Ar river, Al lake), W* river centerlines, B boundary,
      Rm/Rt/Rp motorway/trunk/primary (+b bridge), RM/RT/RP under construction.
Without 'geo' the basemap is a dark schematic; items with "water": true become rivers.
Coordinates: "xy"/"path"/"area"/"center" in 10 m units, or "ll"/"path_ll"/"area_ll"/"center_ll" in [lat, lon].
Scenes can also show a photo/video ("media", Ken Burns, AI label + credit), a news panel
("panel": bars | line | compare | timeline | quote | calc) and a ward spotlight ("spotlight": area id).
Subtitles may be "text" or {"text": shown, "say": read by the voice}. Optional satellite base layer.
Needs python3 + Pillow (+ numpy optional), ffmpeg/ffprobe, Inter font. No network.
"""
import json, math, os, re, subprocess, sys, shutil, random, multiprocessing as mp
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

# Pillow draws text at full opacity even when the fill colour has alpha < 255 (Pillow 12): every text fade-in
# would pop instead. Draw semi-transparent text on a small RGBA layer and composite it instead.
_orig_text = ImageDraw.ImageDraw.text
def _alpha_text(self, xy, text, fill=None, font=None, anchor=None, *args, **kw):
    if isinstance(fill, tuple) and len(fill) == 4 and fill[3] < 255 and getattr(self, '_image', None) is not None:
        a = fill[3]
        if a <= 2: return
        sf = kw.get('stroke_fill'); sw = kw.get('stroke_width', 0)
        x0, y0, x1, y1 = self.textbbox(xy, text, font=font, anchor=anchor, stroke_width=sw)
        x0, y0, x1, y1 = int(x0) - 2, int(y0) - 2, int(x1) + 3, int(y1) + 3
        if x1 <= x0 or y1 <= y0: return
        layer = Image.new('RGBA', (x1 - x0, y1 - y0), (0, 0, 0, 0)); ld = ImageDraw.Draw(layer)
        kw2 = dict(kw)
        if isinstance(sf, tuple): kw2['stroke_fill'] = sf[:3] + (255,) if len(sf) == 4 else sf
        _orig_text(ld, (xy[0] - x0, xy[1] - y0), text, fill[:3] + (255,), font, anchor, *args, **kw2)
        layer.putalpha(layer.getchannel('A').point(lambda v: v*a//255))
        base = self._image
        if base.mode == 'RGBA': base.alpha_composite(layer, (x0, y0)) if x0 >= 0 and y0 >= 0 else base.paste(layer, (x0, y0), layer)
        else: base.paste(layer, (x0, y0), layer)
        return
    return _orig_text(self, xy, text, fill, font, anchor, *args, **kw)
ImageDraw.ImageDraw.text = _alpha_text

FPS = 30
W, H = 1080, 1920
FD = os.environ.get('BDS_FONT_DIR') or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'fonts') + os.sep
FALLBACK = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'fonts', 'Inter-Bold.otf')
READ_CPS = 3.3          # Vietnamese voice-over, words per second
_fc = {}

LAYOUTS = {
    # TikTok/Reels/Shorts: text kept out of the top bar, right icon column and bottom caption area
    # safe core 1080 x (288..1250): brand/title start below the For You tabs, last subtitle line ends at ~1250
    '9:16': dict(W=1080, H=1920, safe_r=150, brand_y=290, title_y=336, title_maxw=0.70,
                 map_cx=0.46, map_cy=0.46, map_cy_card=0.345, fit_w=0.80, fit_h=0.36, fit_h_card=0.18,
                 card=(40, 0.455, 930), sub_y=0.633, sub_bottom=True, sub_cx=0.465, sub_maxw=0.80, sub_size=46,
                 safe_top=288, safe_bottom=1250, footer_y=1520, hook_size=96, names_y=(480, 0.60)),
    # YouTube / Facebook landscape
    '16:9': dict(W=1920, H=1080, safe_r=40, brand_y=50, title_y=110, title_maxw=0.50,
                 map_cx=0.50, map_cy=0.52, map_cy_card=0.54, map_cx_card=0.33, fit_w=0.85, fit_h=0.70,
                 fit_h_card=0.62, fit_w_card=0.52, card=(1180, 0.24, 700), sub_y=0.820, sub_cx=0.5,
                 sub_maxw=0.70, sub_size=44, footer_y=1050, hook_size=88, names_y=(260, 0.78)),
}
L = LAYOUTS['9:16']

STATUS = {
    'existing':     ('#C9D3DC', 'ĐANG KHAI THÁC'),
    'construction': ('#FF8A3D', 'ĐANG THI CÔNG'),
    'planned':      ('#2ED3E6', 'THEO QUY HOẠCH'),
    'approved':     ('#2ED3E6', 'ĐÃ PHÊ DUYỆT'),
    'draft':        ('#B388FF', 'DỰ THẢO'),
    'done':         ('#5BD17A', 'ĐÃ HOÀN THÀNH'),
}
DASHED = {'planned', 'approved', 'draft'}


# ---------------- helpers ----------------
def font(w, s):
    k = (w, int(s))
    if k not in _fc:
        p = FD + f'Inter-{w}.otf'
        _fc[k] = ImageFont.truetype(p if os.path.exists(p) else FALLBACK, int(s))
    return _fc[k]

def rgb(h, a=255): h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4)) + (a,)
def clamp(t): return max(0., min(1., t))
def ease(t): t = clamp(t); return 4*t*t*t if t < .5 else 1 - (-2*t+2)**3/2
def eout(t): t = clamp(t); return 1 - (1-t)**3
def eback(t): t = clamp(t); c = 1.70158; return 1 + (c+1)*(t-1)**3 + c*(t-1)**2
def plain(s): return (s.get('text', '') if isinstance(s, dict) else s).replace('**', '')

def normalize_subs(cfg):
    """{"text","say"} subtitles -> display text in subs, spoken text kept in sc['_say']"""
    for sc in cfg.get('scenes', []):
        subs = sc.get('subs', [])
        if any(isinstance(x, dict) for x in subs):
            sc['_say'] = [x.get('say') or x.get('text', '') if isinstance(x, dict) else x for x in subs]
            sc['subs'] = [x.get('text', '') if isinstance(x, dict) else x for x in subs]

def wrap(d, text, f, mw):
    out, cur = [], ''
    for w in text.split():
        t = (cur + ' ' + w).strip()
        if d.textlength(t, font=f) <= mw: cur = t
        else:
            if cur: out.append(cur)
            cur = w
    if cur: out.append(cur)
    return out

PUNCT = '?!.,:;…)»"'
def tokens(s):
    """'Vốn **19.000 tỷ** đồng?' -> [(word, emphasised)] ; punctuation glued to previous word"""
    out = []
    for i, part in enumerate(s.split('**')):
        ws = part.split()
        if ws and out and i > 0 and not part[:1].isspace() and ws[0][:1] in PUNCT:
            m = re.match(r'[' + re.escape(PUNCT) + r']+', ws[0]).group(0)
            out[-1] = (out[-1][0] + m, out[-1][1]); ws[0] = ws[0][len(m):]
            if not ws[0]: ws = ws[1:]
        for w in ws:
            if out and all(c in PUNCT for c in w): out[-1] = (out[-1][0] + w, out[-1][1])
            else: out.append((w, i % 2 == 1))
    return out

def wrap_tokens(d, toks, f, mw):
    lines, cur = [], []
    for t in toks:
        if cur and d.textlength(' '.join(w for w, _ in cur + [t]), font=f) > mw: lines.append(cur); cur = [t]
        else: cur.append(t)
    if cur: lines.append(cur)
    return lines

def cumlen(pts):
    acc = [0.]
    for a, b in zip(pts, pts[1:]): acc.append(acc[-1] + math.dist(a, b))
    return acc

def at_dist(pts, acc, s):
    if s <= 0: return pts[0]
    if s >= acc[-1]: return pts[-1]
    lo, hi = 0, len(acc) - 1
    while hi - lo > 1:
        m = (lo + hi)//2
        if acc[m] < s: lo = m
        else: hi = m
    t = (s - acc[lo])/((acc[hi] - acc[lo]) or 1)
    return (pts[lo][0] + (pts[hi][0]-pts[lo][0])*t, pts[lo][1] + (pts[hi][1]-pts[lo][1])*t)

def sub_path(pts, acc, s0, s1):
    return [at_dist(pts, acc, s0)] + [p for p, a in zip(pts, acc) if s0 < a < s1] + [at_dist(pts, acc, s1)]

def dashed(d, sp, fill, width, on=26, off=18, phase=0.):
    if len(sp) < 2: return
    acc = cumlen(sp); s = -(phase % (on + off))
    while s < acc[-1]:
        a, b = max(0, s), min(acc[-1], s + on)
        if b > a: d.line(sub_path(sp, acc, a, b), fill=fill, width=width, joint='curve')
        s += on + off

NUM_RE = re.compile(r'\d[\d.]*(?:,\d+)?')
def count_up(label, frac):
    """animate the first number of a Vietnamese-formatted label ('~19.000 tỷ', '54,2% (10/2026)')"""
    m = NUM_RE.search(label or '')
    if not m or frac >= 1 or re.search(r'\d\s*[–-]\s*\d', label): return label   # ranges (30–45) stay static
    raw = m.group(0); dec = len(raw.split(',')[1]) if ',' in raw else 0
    th = '.' in raw and len(raw.split(',')[0].split('.')[-1]) == 3
    try: v = float(raw.replace('.', '').replace(',', '.')) if th else float(raw.replace(',', '.'))
    except ValueError: return label
    s = f'{v*eout(frac):,.{dec}f}'.replace(',', '§').replace('.', ',').replace('§', '.' if th else '')
    return label[:m.start()] + s + label[m.end():]


def draw_trains(d, sp, col, a, tg, it):
    """Little trains (2-3 cars) running back and forth along a drawn line: it['train'] = true or {"n":2,"speed":160,"cars":3,"size":1}."""
    cfg = it['train'] if isinstance(it.get('train'), dict) else {}
    sacc = cumlen(sp); L_ = sacc[-1]
    if L_ < 60: return
    n = cfg.get('n', max(1, min(3, int(L_ // 700) + 1))); v = cfg.get('speed', 150); cars = cfg.get('cars', 3); k = cfg.get('size', 1.0)
    cl, cw, gap = 26*k, 13*k, 4*k; lane = cfg.get('lane', cw*0.8)
    for j in range(n):
        pos = (tg*v + j*L_/n*2 + cfg.get('phase', 0)) % (2*L_)
        fwd = pos < L_; s0 = pos if fwd else 2*L_ - pos
        for c in range(cars):
            sc = s0 - (c*(cl+gap) if fwd else -c*(cl+gap))
            if not (0 < sc < L_): continue
            x0, y0 = at_dist(sp, sacc, max(0, sc - cl/2)); x1, y1 = at_dist(sp, sacc, min(L_, sc + cl/2))
            dx, dy = x1 - x0, y1 - y0; ln = math.hypot(dx, dy) or 1; nx, ny = -dy/ln*cw/2, dx/ln*cw/2
            ox, oy = -dy/ln*lane*(1 if fwd else -1), dx/ln*lane*(1 if fwd else -1)      # each direction on its own track
            x0, y0, x1, y1 = x0+ox, y0+oy, x1+ox, y1+oy
            poly = [(x0+nx, y0+ny), (x1+nx, y1+ny), (x1-nx, y1-ny), (x0-nx, y0-ny)]
            d.polygon(poly, fill=(255, 255, 255, int(250*a)), outline=(8, 12, 20, int(255*a)), width=max(2, int(3*k)))
            mx, my = (x0+x1)/2, (y0+y1)/2      # coloured stripe along the car
            d.line([(mx-dx/ln*cl*0.32, my-dy/ln*cl*0.32), (mx+dx/ln*cl*0.32, my+dy/ln*cl*0.32)], fill=col[:3]+(int(255*a),), width=max(2, int(4*k)))
            if c == 0:
                hx, hy = (x1, y1) if fwd else (x0, y0)
                d.ellipse([hx-3*k, hy-3*k, hx+3*k, hy+3*k], fill=col[:3]+(int(255*a),))


def train_positions(sp, it, tg):
    """Centre point of every car of every train on this line at time tg (same maths as draw_trains) — used to check collisions."""
    cfg = it['train'] if isinstance(it.get('train'), dict) else {}
    sacc = cumlen(sp); L_ = sacc[-1]; out = []
    if L_ < 60: return out
    n = cfg.get('n', max(1, min(3, int(L_ // 700) + 1))); v = cfg.get('speed', 150); cars = cfg.get('cars', 3); k = cfg.get('size', 1.0)
    cl, cw, gap = 26*k, 13*k, 4*k; lane = cfg.get('lane', cw*0.8)
    for j in range(n):
        pos = (tg*v + j*L_/n*2 + cfg.get('phase', 0)) % (2*L_); fwd = pos < L_; s0 = pos if fwd else 2*L_ - pos
        for c in range(cars):
            sc = s0 - (c*(cl+gap) if fwd else -c*(cl+gap))
            if not (0 < sc < L_): continue
            x0, y0 = at_dist(sp, sacc, max(0, sc-1)); x1, y1 = at_dist(sp, sacc, min(L_, sc+1)); dx, dy = x1-x0, y1-y0; ln = math.hypot(dx, dy) or 1
            x, y = at_dist(sp, sacc, sc); sg = 1 if fwd else -1
            out.append((x - dy/ln*lane*sg, y + dx/ln*lane*sg))
    return out

def draw_stations(d, sp, it, prog, a, placed):
    """Station dots along a line (appear as the line is drawn) + optional names; it['_st'] = [(dist_px, x, y, name, label)]."""
    col = it['_col']; r = it.get('station_r', 7)
    sacc = cumlen(sp); L_ = sacc[-1]
    for frac, x, y, name, lab in it.get('_st', []):
        if frac > prog: continue
        d.ellipse([x-r, y-r, x+r, y+r], fill=(255, 255, 255, int(255*a)), outline=col[:3]+(int(255*a),), width=max(2, r//2))
        if lab and name:
            f = font('Bold', it.get('station_font', 19)); tw = d.textlength(name, font=f); h = f.size + 6
            for dx_, dy_ in ((r+6, -h/2), (-r-6-tw, -h/2), (-tw/2, -r-4-h), (-tw/2, r+4)):
                bx = (x+dx_-4, y+dy_, x+dx_+tw+4, y+dy_+h)
                if bx[0] < 8 or bx[2] > W-8: continue
                if any(not (bx[2] < q[0] or bx[0] > q[2] or bx[3] < q[1] or bx[1] > q[3]) for q in placed): continue
                d.rounded_rectangle(bx, 6, fill=(6, 10, 18, int(200*a))); d.text((bx[0]+4, bx[1]+3), name, font=f, fill=(255, 255, 255, int(255*a)))
                placed.append(bx); break

def draw_badges(d, sp, it, prog, a):
    """Round line-number badges sitting on the line at the given fractions (it['badge'] = '14', it['badges'] = [0.3, 0.7])."""
    if not it.get('badge'): return
    col = it['_col']; sacc = cumlen(sp); L_ = sacc[-1]; r = it.get('badge_r', 22); f = font('Black', int(r*0.95))
    for fr in it.get('badges', [0.5]):
        if fr > prog: continue
        x, y = at_dist(sp, sacc, L_*fr)
        d.ellipse([x-r-3, y-r-3, x+r+3, y+r+3], fill=(255, 255, 255, int(255*a)))
        d.ellipse([x-r, y-r, x+r, y+r], fill=col[:3]+(int(255*a),))
        d.text((x, y+1), str(it['badge']), font=f, fill=(255, 255, 255, int(255*a)), anchor='mm', stroke_width=2, stroke_fill=(0, 0, 0, int(120*a)))

def km_label(m):
    km = m/1000; return '≈ ' + (f'{km:.1f}'.replace('.', ',') if km < 10 else f'{km:.0f}') + ' km'

def load_geo(path):
    F = []
    for l in open(path, encoding='utf-8'):
        l = l.strip()
        if not l or ':' not in l or l.startswith('#'): continue
        tag, body = l.split(':', 1); x = y = 0; pts = []
        for d in body.split():
            dx, dy = map(int, d.split(',')); x += dx; y += dy; pts.append((x*10., y*10.))
        F.append((tag, pts))
    return F


# ---------------- basemap ----------------
class Base:
    """Pre-rendered basemap pyramid (meters -> pixels). Real OSM data if 'geo', else schematic."""
    def __init__(self, cfg, feats, water_items, ll2m=None, base_dir='.'):
        self.S = cfg.get('base_m_per_px', 4.0)
        self.X0, self.X1, self.Y0, self.Y1 = cfg['extent_m']
        bw, bh = int((self.X1-self.X0)/self.S), int((self.Y1-self.Y0)/self.S)
        st = cfg.get('style', {})
        land1, land2 = rgb(st.get('land_top', '#0D1B2C')), rgb(st.get('land_bottom', '#08111D'))
        im = Image.new('RGB', (bw, bh)); dd = ImageDraw.Draw(im)
        for yy in range(0, bh, 4):
            t = yy/bh; dd.rectangle([0, yy, bw, yy+4], fill=tuple(int(land1[i]*(1-t)+land2[i]*t) for i in range(3)))
        random.seed(3)
        tex = Image.effect_noise((max(1, bw//8), max(1, bh//8)), 40).resize((bw, bh), Image.BILINEAR).filter(ImageFilter.GaussianBlur(6))
        im = Image.composite(Image.new('RGB', (bw, bh), (22, 38, 58)), im, tex.point(lambda v: max(0, v-110)//3))
        P = lambda p: ((p[0]-self.X0)/self.S, (self.Y1-p[1])/self.S)
        sat = cfg.get('satellite')
        if sat and ll2m and os.path.exists(os.path.join(base_dir, sat['file'])):
            s_, w_, n_, e_ = sat['bbox_ll']; (x0, y1), (x1, y0) = P(ll2m(n_, w_)), P(ll2m(s_, e_))
            simg = Image.open(os.path.join(base_dir, sat['file'])).convert('RGB').resize((max(1, int(x1 - x0)), max(1, int(y0 - y1))), Image.LANCZOS)
            from PIL import ImageEnhance
            simg = ImageEnhance.Color(simg).enhance(sat.get('saturation', 0.85))
            simg = ImageEnhance.Brightness(simg).enhance(sat.get('brightness', 0.55))
            im.paste(simg, (int(x0), int(y1)))
        wm = Image.new('L', (bw, bh), 0); wd = ImageDraw.Draw(wm)
        for t, p in feats:
            if t.startswith('A') and len(p) > 2: wd.polygon([P(q) for q in p], fill=255)
        for t, p in feats:
            if t == 'Wb': wd.line([P(q) for q in p], fill=255, width=max(2, int(18/self.S)))
        for it in water_items:
            wd.line([P(q) for q in it['_path']], fill=255, width=max(3, int(it.get('width_m', 500)/self.S)), joint='curve')
        glow = wm.filter(ImageFilter.GaussianBlur(int(60/self.S)+2))
        im = Image.composite(Image.new('RGB', (bw, bh), rgb(st.get('water_glow', '#1C6FA8'))[:3]), im, glow.point(lambda v: int(v*0.45)))
        inner = wm.filter(ImageFilter.GaussianBlur(int(25/self.S)+1))
        water = Image.new('RGB', (bw, bh), rgb(st.get('water', '#174F7C'))[:3])
        light = Image.new('RGB', (bw, bh), rgb(st.get('water_edge', '#3FA7E0'))[:3])
        edge = ImageChops.subtract(wm, inner).point(lambda v: min(255, v*2))
        if not (sat and sat.get('water') is False):
            im = Image.composite(Image.composite(light, water, edge), im, wm)
        d = ImageDraw.Draw(im, 'RGBA')
        def lines(tags, color, wm_, casing=None, dash=None):
            wpx = max(1, int(wm_/self.S))
            for t, p in feats:
                if t not in tags: continue
                q = [P(a) for a in p]
                if casing: d.line(q, fill=casing, width=wpx+max(2, wpx//2), joint='curve')
                if dash: dashed(d, q, color, wpx, dash/self.S, dash/self.S)
                else: d.line(q, fill=color, width=wpx, joint='curve')
        lines({'Rp', 'Rpb'}, (120, 140, 165, 150), 9, casing=(5, 10, 18, 140))
        lines({'Rt', 'Rtb'}, (225, 220, 205, 220), 16, casing=(5, 10, 18, 200))
        lines({'Rm', 'Rmb'}, (245, 185, 66, 235), 24, casing=(40, 25, 5, 220))
        lines({'RP', 'RPb', 'RT', 'RTb', 'RM', 'RMb'}, (255, 138, 61, 150), 14, dash=90)
        lines({'B'}, (255, 255, 255, 110), 5, dash=70)
        self.levels = [im]
        for _ in range(3):
            prev = self.levels[-1]; self.levels.append(prev.resize((max(1, prev.width//2), max(1, prev.height//2)), Image.LANCZOS))

    def view(self, cam, vw):
        cx, cy, wm_ = cam; mpp = wm_/W
        lvl = 0
        while lvl < 3 and mpp/(self.S*(2**(lvl+1))) >= 1.0: lvl += 1
        S = self.S*(2**lvl)
        left, right = cx - W*vw[0]*mpp, cx + W*(1-vw[0])*mpp
        top, bottom = cy + H*vw[1]*mpp, cy - H*(1-vw[1])*mpp
        box = ((left-self.X0)/S, (self.Y1-top)/S, (right-self.X0)/S, (self.Y1-bottom)/S)
        return self.levels[lvl].transform((W, H), Image.EXTENT, box, resample=Image.BICUBIC, fillcolor=(8, 17, 29))


# ---------------- video ----------------
class Video:
    def __init__(self, cfg, base_dir='.'):
        self.cfg = cfg; self.dir = base_dir
        b = cfg.get('brand', {})
        self.acc = rgb(b.get('accent', '#FF8A3D')); self.hi = rgb(b.get('highlight', '#FFE14D'))
        o = cfg.get('origin', [21.0, 105.88]); self.lat0, self.lon0 = o
        self.kx = 111320*math.cos(math.radians(self.lat0)); self.ky = 110570
        self.items = {it['id']: it for it in cfg.get('items', [])}
        for it in self.items.values():
            if 'll' in it: it['_p'] = self.ll(*it['ll'])
            elif 'xy' in it: it['_p'] = (it['xy'][0]*10., it['xy'][1]*10.)
            if 'path_ll' in it: it['_path'] = [self.ll(*q) for q in it['path_ll']]
            elif 'path' in it: it['_path'] = [(a*10., b_*10.) for a, b_ in it['path']]
            if 'area_ll' in it: it['_area'] = [self.ll(*q) for q in it['area_ll']]
            elif 'area' in it: it['_area'] = [(a*10., b_*10.) for a, b_ in it['area']]
            if '_path' in it: it['_L'] = cumlen(it['_path'])
            if '_p' not in it:
                src = it.get('_area') or it.get('_path')
                if it.get('_area'): it['_p'] = (sum(p[0] for p in src)/len(src), sum(p[1] for p in src)/len(src))
                elif src: it['_p'] = at_dist(src, it['_L'], it['_L'][-1]*it.get('marker_at', 0.5))
        geo = cfg.get('geo'); self.feats = load_geo(os.path.join(base_dir, geo)) if geo else []
        if 'extent_m' not in cfg:
            xs, ys = [], []
            for it in self.items.values():
                for p in it.get('_path', []) + it.get('_area', []) + ([it['_p']] if '_p' in it else []): xs.append(p[0]); ys.append(p[1])
            for _, p in self.feats:
                for q in p: xs.append(q[0]); ys.append(q[1])
            m = cfg.get('extent_margin_m', 8000)
            cfg['extent_m'] = [min(xs)-m, max(xs)+m, min(ys)-m, max(ys)+m] if xs else [-8000, 8000, -14000, 14000]
        self.names = []
        if cfg.get('names'):
            for l in open(os.path.join(base_dir, cfg['names']), encoding='utf-8'):
                l = l.strip()
                if l.count('|') != 4 or l.startswith('#'): continue
                k, c, n, x, y = l.split('|'); self.names.append((k, c, n, int(x)*10., int(y)*10.))
        self.base = Base(cfg, self.feats, [it for it in self.items.values() if it.get('water') and '_path' in it], self.ll, base_dir)
        self._media = {}
        self.mapless = not self.feats and not self.items
        self._lab_memo = {}; self._scene = 0
        self._item_names = {w for it in self.items.values() if it.get('name') for w in (it['name'].lower(), it['name'].lower().replace('phường ', '').replace('xã ', ''))}
        self.shade = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(self.shade)   # legibility gradients
        for y in range(0, 300, 4): sd.rectangle([0, y, W, y+4], fill=(0, 0, 0, int(150*(1-y/300))))
        bot = int(H*0.45)
        for y in range(0, bot, 6): sd.rectangle([0, H-y-6, W, H-y], fill=(0, 0, 0, int(170*(1-y/bot))))

    def ll(self, lat, lon): return ((lon - self.lon0)*self.kx, (lat - self.lat0)*self.ky)

    # ---- camera ----
    def view(self, has_card):
        return (L.get('map_cx_card', L['map_cx']) if has_card else L['map_cx'], L['map_cy_card'] if has_card else L['map_cy'])

    def camera(self, spec, has_card):
        fh = spec.get('vh') or (L['fit_h_card'] if has_card else L['fit_h'])
        fw = L.get('fit_w_card', L['fit_w']) if has_card else L['fit_w']
        if 'fit' in spec:
            xs, ys = [], []
            for iid in spec['fit']:
                it = self.items[iid]
                for p in it.get('_path', []) + it.get('_area', []) + ([it['_p']] if '_p' in it else []): xs.append(p[0]); ys.append(p[1])
            pad = 1 + spec.get('pad', 0.4)
            cx, cy = (min(xs)+max(xs))/2, (min(ys)+max(ys))/2
            w = max((max(xs)-min(xs))*pad/fw, (max(ys)-min(ys))*pad*W/(H*fh), spec.get('min_m', spec.get('min_km', 3)*1000))
        else:
            cx, cy = self.ll(*spec['center_ll']) if 'center_ll' in spec else (spec['center'][0]*10., spec['center'][1]*10.)
            w = spec.get('width_m', spec.get('km', 5)*1000)
        return (cx, cy + spec.get('shift_m', 0), w)

    def lerp(self, a, b, t):
        t = ease(t)
        return (a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, math.exp(math.log(a[2])+(math.log(b[2])-math.log(a[2]))*t))

    def scr(self, cam, p, vw):
        s = W/cam[2]; return (W*vw[0] + (p[0]-cam[0])*s, H*vw[1] + (cam[1]-p[1])*s)

    def visible_box(self, cam, vw):
        mpp = cam[2]/W
        return (cam[0] - W*vw[0]*mpp, cam[0] + W*(1-vw[0])*mpp, cam[1] - H*(1-vw[1])*mpp, cam[1] + H*vw[1]*mpp)

    # ---- map overlays ----
    def big_labels(self, d, cam, labels, alpha, vw):
        boxes = []
        for lb in labels:
            p = self.ll(*lb['ll']) if 'll' in lb else (lb['xy'][0]*10., lb['xy'][1]*10.)
            X, Y = self.scr(cam, p, vw)
            f = font('Black', lb.get('size', 44)); t = ' '.join(lb['text'].upper())
            bb = d.textbbox((X, Y), t, font=f, anchor='mm')
            if any(bb[0] < q[2] and bb[2] > q[0] and bb[1] < q[3] and bb[3] > q[1] for q in boxes): continue
            boxes.append(bb)
            d.text((X+2, Y+2), t, font=f, fill=(0, 0, 0, int(alpha*120)), anchor='mm')
            d.text((X, Y), t, font=f, fill=(255, 255, 255, int(alpha*lb.get('alpha', 70))), anchor='mm')

    def place_names(self, d, cam, alpha, vw, placed):
        if alpha <= 0: return
        mpp = cam[2]/W; y0, y1 = L['names_y'][0], H*L['names_y'][1]; mine = []
        for k, c, n, x, y in self.names:
            big = c in ('town', 'city')
            if k == 'P' and (big or mpp < 20): f = font('SemiBold', 26 if big else 23); box = 0
            elif k == 'N' and mpp < 14: f = font('Medium', 20); box = 1
            else: continue
            if n.lower() in self._item_names: continue          # already labelled as an item
            X, Y = self.scr(cam, (x, y), vw)
            if not (20 < X < W - L['safe_r'] and y0 < Y < y1): continue
            t = n.upper() if k == 'P' else n; tw = d.textlength(t, font=f)
            r = (X - tw/2 - 10, Y - 16, X + tw/2 + 10, Y + 16)
            if any(r[0] < q[2] and r[2] > q[0] and r[1] < q[3] and r[3] > q[1] for q in placed + mine): continue
            mine.append(r)
            if box:
                d.rounded_rectangle([X-tw/2-8, Y-14, X+tw/2+8, Y+14], 8, fill=(10, 16, 26, int(alpha*170)))
                d.text((X, Y), t, font=f, fill=(230, 210, 170, int(alpha*220)), anchor='mm')
            else:
                d.text((X, Y), t, font=f, fill=(255, 255, 255, int(alpha*(150 if big else 115))), anchor='mm')

    def color_of(self, it):
        st = STATUS.get(it.get('status'))
        return rgb(it['color']) if it.get('color') else (rgb(st[0]) if st else rgb('#FFD54F'))

    def draw_area(self, im, d, cam, it, a, tg, vw):
        col = self.color_of(it); sp = [self.scr(cam, q, vw) for q in it['_area']]
        ov = Image.new('RGBA', (W, H)); ImageDraw.Draw(ov).polygon(sp, fill=col[:3] + (int(it.get('fill_alpha', 55)*a),))
        im.paste(ov, (0, 0), ov)
        ring = sp + [sp[0]]
        if it.get('status') in DASHED: dashed(d, ring, col[:3] + (int(230*a),), 4, 18, 12, tg*30)
        else: d.line(ring, fill=col[:3] + (int(230*a),), width=4, joint='curve')

    def draw_path(self, d, cam, it, prog, alpha, tg, vw):
        self._post_path(cam, it, vw)
        pts, Lc = it['_path'], it['_L']
        if prog < 1: pts = sub_path(pts, Lc, 0, Lc[-1]*prog)
        sp = [self.scr(cam, p, vw) for p in pts]
        if len(sp) < 2: return
        col = self.color_of(it); a = alpha/255
        if it.get('style') == 'line':     # plain thin line (existing roads, context)
            d.line(sp, fill=(0, 0, 0, int(140*a)), width=it.get('width_px', 6)+5, joint='curve')
            d.line(sp, fill=col[:3]+(int(230*a),), width=it.get('width_px', 6), joint='curve')
            if it.get('train') and prog >= 1: draw_trains(d, sp, col, a, tg, it)
        elif it.get('status') in DASHED and prog >= 1 and not it.get('solid'):
            for w_, a_ in ((30, 30), (18, 55)): d.line(sp, fill=col[:3]+(int(a*a_),), width=w_, joint='curve')
            dashed(d, sp, col[:3]+(int(255*a),), 9, 30, 20, tg*40)
        else:
            for w_, a_ in ((34, 35), (22, 60), (12, 140)): d.line(sp, fill=col[:3]+(int(a*a_),), width=w_, joint='curve')
            d.line(sp, fill=(255, 245, 230, int(255*a)), width=5, joint='curve')
        if prog < 1:
            x, y = sp[-1]; r = 14; d.ellipse([x-r, y-r, x+r, y+r], fill=(255, 255, 255, int(230*a)))
        elif it.get('train'):
            draw_trains(d, sp, col, a, tg, it)
        elif it.get('flow'):
            sacc = cumlen(sp); gap = it.get('flow_gap', 120); k = (tg*it.get('flow_speed', 90)) % gap
            while k < sacc[-1]:
                x, y = at_dist(sp, sacc, k); d.ellipse([x-5, y-5, x+5, y+5], fill=(255, 255, 255, int(220*a))); k += gap

    def _post_path(self, cam, it, vw):
        it['_col'] = self.color_of(it)
        if it.get('stations') and '_stm' not in it:      # station -> (fraction along path, metres)
            P = it['_path']; Lc = it['_L']; res = []
            for st in it['stations']:
                p = self.ll(st[0], st[1]); best = None
                for i, (a_, b_) in enumerate(zip(P, P[1:])):
                    vx, vy = b_[0]-a_[0], b_[1]-a_[1]; L2 = vx*vx+vy*vy or 1e-9
                    t = max(0, min(1, ((p[0]-a_[0])*vx + (p[1]-a_[1])*vy)/L2)); q = (a_[0]+vx*t, a_[1]+vy*t)
                    dd = math.dist(p, q)
                    if best is None or dd < best[0]: best = (dd, (Lc[i] + math.sqrt(L2)*t)/max(1e-9, Lc[-1]), q)
                res.append((best[1], best[2], st[2] if len(st) > 2 else '', st[3] if len(st) > 3 else False))
            it['_stm'] = res
        if it.get('stations'):
            it['_st'] = [(fr, *self.scr(cam, q, vw), nm, lb) for fr, q, nm, lb in it['_stm']]

    def path_extras(self, d, cam, it, prog, alpha, vw, placed):
        if '_path' not in it or prog <= 0: return
        self._post_path(cam, it, vw)
        pts, Lc = it['_path'], it['_L']
        sp = [self.scr(cam, p, vw) for p in pts]; a = alpha/255
        draw_stations(d, sp, it, prog, a, placed); draw_badges(d, sp, it, prog, a)

    def marker(self, d, cam, it, alpha, focused, tg, popa, vw):
        x, y = self.scr(cam, it['_p'], vw); col = self.color_of(it); kind = it.get('kind', 'dot')
        sc = 0.6 + 0.4*eback(popa)
        if focused and it.get('pulse', True):
            for k in range(2):
                ph = (tg*0.8 + k*0.5) % 1.0; r = (18 + ph*70)*sc
                d.ellipse([x-r, y-r, x+r, y+r], outline=col[:3]+(int(alpha*(1-ph)*0.8),), width=4)
        r = (20 if focused else 15)*sc
        if kind == 'star':
            pts = [(x + (r*1.6 if k % 2 == 0 else r*0.68)*math.cos(-math.pi/2 + k*math.pi/5),
                    y + (r*1.6 if k % 2 == 0 else r*0.68)*math.sin(-math.pi/2 + k*math.pi/5)) for k in range(10)]
            d.polygon(pts, fill=col[:3]+(alpha,), outline=(255, 255, 255, alpha))
        elif kind in ('metro', 'station'):
            d.rounded_rectangle([x-r, y-r, x+r, y+r], 8, fill=col[:3]+(alpha,), outline=(255, 255, 255, alpha), width=3)
            d.text((x, y), 'M', font=font('Black', int(r*1.2)), fill=(10, 10, 10, alpha), anchor='mm')
        elif kind == 'interchange':
            d.polygon([(x, y-r*1.2), (x+r*1.2, y), (x, y+r*1.2), (x-r*1.2, y)], fill=col[:3]+(alpha,), outline=(255, 255, 255, alpha))
        else:
            r = (13 if focused else 10)*sc
            d.ellipse([x-r-6, y-r-6, x+r+6, y+r+6], fill=(0, 0, 0, int(alpha*0.5)))
            d.ellipse([x-r, y-r, x+r, y+r], fill=col[:3]+(alpha,), outline=(255, 255, 255, alpha), width=3)

    def plan_label(self, d, it, x, y, alpha, focused, placed):
        """find a non-overlapping box for the label; returns draw spec or None (secondary label dropped)."""
        st = STATUS.get(it.get('status')); col = self.color_of(it)
        side0 = it.get('label_side', 'right'); off = it.get('label_offset', [60, -40])
        fn = font('ExtraBold', 34 if focused else 27); fc = font('Bold', 20 if focused else 17)
        name = it['name'].upper(); chip = (it.get('tag') or (st[1] if st else '')).upper()
        tw = d.textlength(name, font=fn); cw = d.textlength(chip, font=fc) if chip else 0
        bw = max(tw, cw) + 26; h1 = fn.size + 16; ch = fc.size + 10 if chip else 0
        rl = W - L['safe_r']; best = None
        cands = [(dy, side, xm) for xm in (1, 2.2) for dy in (0, -56, 56, -112, 112, -170, 170, -230, 230) for side in (side0, 'left' if side0 == 'right' else 'right')]
        key = (self._scene, it['id']); memo = self._lab_memo.get(key)
        if memo in cands: cands.remove(memo); cands.insert(0, memo)      # sticky: keep last position -> no jumping
        for dy, side, xm in cands:
            if True:
                lx = x + (off[0]*xm if side == 'right' else -off[0]*xm); ly = y + off[1] + dy
                bx0 = lx if side == 'right' else lx - bw
                r = (bx0 - 6, ly - h1/2 - ch - 6, bx0 + bw + 6, ly + h1/2 + 6)
                if bx0 < 20 or bx0 + bw > rl or r[1] < 0 or r[3] > H: continue
                if not any(r[0] < q[2] and r[2] > q[0] and r[1] < q[3] and r[3] > q[1] for q in placed):
                    best = (side, bx0, ly, r); self._lab_memo[key] = (dy, side, xm); break
        if not best:
            if not (focused or it.get('always_label')): return None
            side = side0; ly = y + off[1]
            bx0 = max(20, min(x + off[0] if side == 'right' else x - off[0] - bw, rl - bw))
            best = (side, bx0, ly, (bx0, ly - h1/2 - ch, bx0 + bw, ly + h1/2))
        placed.append(best[3])
        return dict(x=x, y=y, side=best[0], bx0=best[1], ly=best[2], bw=bw, tw=tw, cw=cw, h1=h1, ch=ch,
                    name=name, chip=chip, fn=fn, fc=fc, col=col, alpha=alpha, focused=focused)

    def draw_label(self, d, s):
        x, y, bx0, ly, a, col = s['x'], s['y'], s['bx0'], s['ly'], s['alpha'], s['col']
        d.line([(x, y), (bx0 if s['side'] == 'right' else bx0 + s['bw'], ly)], fill=(255, 255, 255, int(a*0.7)), width=2)
        if s['chip']:
            d.rectangle([bx0, ly - s['h1']/2 - s['ch'], bx0 + s['cw'] + 20, ly - s['h1']/2], fill=col[:3]+(a,))
            d.text((bx0 + 10, ly - s['h1']/2 - s['ch']/2), s['chip'], font=s['fc'], fill=(12, 12, 12, a), anchor='lm')
        d.rectangle([bx0, ly - s['h1']/2, bx0 + s['tw'] + 26, ly + s['h1']/2], fill=(255, 255, 255, a) if s['focused'] else (10, 16, 26, int(a*0.92)))
        d.text((bx0 + 13, ly), s['name'], font=s['fn'], fill=(10, 14, 22, a) if s['focused'] else (255, 255, 255, a), anchor='lm')

    def measure(self, d, cam, m, prog, vw, placed=None):
        a, b = self.items[m[0]]['_p'], self.items[m[1]]['_p']
        lab = m[2] if len(m) > 2 else km_label(math.dist(a, b))
        pa, pb = self.scr(cam, a, vw), self.scr(cam, b, vw)
        if placed is not None:
            tw = d.textlength(lab, font=font('ExtraBold', 30)); mx, my = (pa[0]+pb[0])/2, (pa[1]+pb[1])/2
            placed.append((mx-tw/2-24, my-34, mx+tw/2+24, my+34))
        if prog > 0: dashed(d, [pa, (pa[0] + (pb[0]-pa[0])*prog, pa[1] + (pb[1]-pa[1])*prog)], (255, 255, 255, 230), 4, 16, 10)
        if prog >= 1:
            mx, my = (pa[0]+pb[0])/2, (pa[1]+pb[1])/2; f = font('ExtraBold', 30); tw = d.textlength(lab, font=f)
            d.rounded_rectangle([mx-tw/2-16, my-26, mx+tw/2+16, my+26], 26, fill=(255, 255, 255, 240))
            d.text((mx, my), lab, font=f, fill=(10, 14, 22, 255), anchor='mm')

    # ---- chrome / text ----
    def chrome(self, d, cam, scale=True):
        b = self.cfg.get('brand', {}); f = font('ExtraBold', 30); t = b.get('channel', ''); y = L['brand_y']
        d.rounded_rectangle([40, y-26, 40+d.textlength(t, font=f)+36, y+26], 12, fill=(0, 0, 0, 160))
        d.text((58, y), t, font=f, fill=self.acc[:3]+(255,), anchor='lm')
        if scale and self.cfg.get('scale_bar', True):
            mpp = cam[2]/W; nice = min([200, 500, 1000, 2000, 5000, 10000, 20000], key=lambda v: abs(v - 160*mpp)); px = nice/mpp
            xr = W - 40 if W < H else W - 60; sy = y + 6; x0 = xr - px
            d.rectangle([x0, sy, xr, sy+8], fill=(255, 255, 255, 200)); d.rectangle([x0, sy, x0+px/2, sy+8], fill=(30, 30, 30, 200))
            d.text(((x0+xr)/2, sy-8), f'{nice/1000:g} km'.replace('.', ','), font=font('Bold', 21), fill=(255, 255, 255, 210), anchor='mb')
            nx = x0 - 36
            d.polygon([(nx, sy-26), (nx-13, sy+10), (nx, sy+2), (nx+13, sy+10)], fill=(255, 255, 255, 210))
            d.text((nx, sy-30), 'B', font=font('Bold', 18), fill=(255, 255, 255, 200), anchor='mb')
        note = self.cfg.get('footer', ''); f2 = font('Medium', 20); ls = wrap(d, note, f2, W - 40 - L['safe_r'])
        for i, ln in enumerate(ls):
            d.text((40, L['footer_y'] - (len(ls)-1-i)*26), ln, font=f2, fill=(255, 255, 255, 140), anchor='ls', stroke_width=2, stroke_fill=(0, 0, 0, 170))

    def legend(self, d, vis, y):
        sts = []
        for iid in vis:
            st = self.items[iid].get('status')
            if st in STATUS and STATUS[st][1] not in [STATUS[x][1] for x in sts]: sts.append(st)
        x = 40; f = font('Bold', 19)
        for st in sts:
            lab = STATUS[st][1]; tw = d.textlength(lab, font=f)
            if x + tw + 44 > W - L['safe_r']: x = 40; y += 40
            d.rounded_rectangle([x, y, x+tw+40, y+32], 16, fill=(0, 0, 0, 150))
            d.ellipse([x+10, y+9, x+24, y+23], fill=rgb(STATUS[st][0]))
            d.text((x+30, y+16), lab, font=f, fill=(255, 255, 255, 220), anchor='lm'); x += tw + 50
        return y + 32

    def title_rect(self, d, title):
        fk = font('Bold', 26); ft = font('Black', title.get('size', 54))
        lines = wrap(d, title['text'].upper(), ft, W*L['title_maxw'])
        h = 66 + len(lines)*ft.size*1.12 + 16
        w = max(max(d.textlength(l, font=ft) for l in lines), d.textlength(title.get('kicker', '').upper(), font=fk)) + 60
        return lines, w, h, fk, ft

    def title_box(self, d, title, t_in):
        lines, wbox, h, fk, ft = self.title_rect(d, title)
        a = eout(t_in); x0, y0 = 40 + (1-a)*-60, L['title_y']
        d.rectangle([x0, y0, x0+wbox, y0+h], fill=(0, 0, 0, int(175*a)))
        d.rectangle([x0, y0, x0+8, y0+h], fill=self.acc[:3]+(int(255*a),))
        d.text((x0+28, y0+22), title.get('kicker', '').upper(), font=fk, fill=self.acc[:3]+(int(255*a),))
        y = y0 + 64
        for l in lines: d.text((x0+28, y), l, font=ft, fill=(255, 255, 255, int(255*a))); y += ft.size*1.12
        return y0 + h

    def card_h(self, d, card):
        fr = font('SemiBold', 29); cw = L['card'][2]
        lh = sum(30 + 32*len(wrap(d, plain(it), fr, cw-120)[:2]) for it in card.get('list', []))
        return 30 + (56 if card.get('title') else 0) + (120 if card.get('big') else 0) + len(card.get('rows', []))*46 + lh + (100 if 'progress' in card else 0) + 18

    def card(self, d, card, t_in, reveal=None):
        if not card or t_in <= 0: return
        a = eout(t_in); x0, yf, cw = L['card']; x1 = x0 + cw; y0 = H*yf + (1-a)*40; A = int(255*a)
        fh = font('ExtraBold', 34); fr = font('SemiBold', 29); fv = font('ExtraBold', 29); fb = font('Black', 72)
        h = self.card_h(d, card); cu = clamp((t_in - 0.3)/1.2)
        d.rounded_rectangle([x0, y0, x1, y0+h], 20, fill=(8, 14, 24, int(232*a)), outline=self.acc[:3]+(int(170*a),), width=2)
        y = y0 + 26
        if card.get('title'): d.text((x0+30, y), card['title'], font=fh, fill=(255, 255, 255, A)); y += 56
        big = card.get('big')
        if big:
            d.text((x0+30, y-6), count_up(big['value'], cu), font=fb, fill=self.acc[:3]+(A,))
            vw_ = d.textlength(big['value'], font=fb)
            d.text((x0+44+vw_, y+52), big.get('unit', ''), font=fv, fill=(255, 255, 255, A), anchor='ls')
            if big.get('note'): d.text((x0+30, y+98), big['note'], font=font('Medium', 22), fill=(190, 204, 218, A), anchor='ls')
            y += 120
        for k, v in card.get('rows', []):
            d.text((x0+30, y), k, font=fr, fill=(190, 204, 218, A))
            d.text((x1-30, y), v, font=fv, fill=(255, 255, 255, A), anchor='ra'); y += 46
        for i, it in enumerate(card.get('list', [])):
            ia = (eout(reveal[i]) if reveal and i < len(reveal) else eout((t_in - 0.4 - i*0.35)/0.5))*a; wl = wrap(d, plain(it), fr, cw-120)[:2]
            if ia < 0.02: y += 30 + 32*len(wl); continue          # not revealed yet (alpha 0 text is still drawn by Pillow)
            d.ellipse([x0+30, y+4, x0+64, y+38], fill=self.acc[:3]+(int(255*ia),))
            d.text((x0+47, y+21), str(i+1), font=font('Black', 21), fill=(10, 10, 10, int(255*ia)), anchor='mm')
            for j, ln in enumerate(wl): d.text((x0+82, y+4+j*32), ln, font=fr, fill=(255, 255, 255, int(255*ia)))
            y += 30 + 32*len(wl)
        if 'progress' in card:
            p = card['progress']; pa = eout((t_in-0.3)/1.2); bx0, bx1 = x0+30, x1-30; by = y + 46
            d.rounded_rectangle([bx0, by, bx1, by+24], 12, fill=(255, 255, 255, int(40*a)))
            d.rounded_rectangle([bx0, by, bx0+max(24, (bx1-bx0)*p/100*pa), by+24], 12, fill=self.acc[:3]+(A,))
            lab = card.get('progress_label', f'{p:.1f}%'.replace('.', ','))
            d.text((bx1, by-6), count_up(lab, pa), font=fv, fill=self.acc[:3]+(A,), anchor='rb')
            if card.get('progress_caption'):
                d.text((bx0, by-6), card['progress_caption'], font=font('SemiBold', 24), fill=(190, 204, 218, A), anchor='lb')

    def subtitle(self, d, text, a, frac):
        if self.cfg.get('burn_subs', True) is False: return
        f = font('ExtraBold', L['sub_size']); toks = tokens(text)
        lines = wrap_tokens(d, toks, f, W*L['sub_maxw'])
        lens = [len(w)+1 for w, _ in toks]; tot = sum(lens); acc = 0; cur = len(toks)-1
        for i, n in enumerate(lens):
            acc += n
            if acc/tot >= frac: cur = i; break
        karaoke = self.cfg.get('sub_style', 'karaoke') == 'karaoke'
        cx = W*L['sub_cx']; lh = L['sub_size'] + 18; sp = d.textlength(' ', font=f); idx = 0
        y = H*L['sub_y'] - ((len(lines)-1)*lh if L.get('sub_bottom') else 0)
        for ln in lines:
            tw = d.textlength(' '.join(w for w, _ in ln), font=f)
            d.rounded_rectangle([cx-tw/2-18, y-lh/2, cx+tw/2+18, y+lh/2], 8, fill=(0, 0, 0, int(220*a)))
            x = cx - tw/2
            for w, emph in ln:
                col = self.hi[:3] if (karaoke and idx == cur) else (self.acc[:3] if emph else (255, 255, 255))
                d.text((x, y), w, font=f, fill=col+(int(255*a),), anchor='lm'); x += d.textlength(w, font=f) + sp; idx += 1
            y += lh

    def hook(self, im, hk, tl, dur, first=False):
        # first scene: no slow build — the dark veil and first words are on screen at frame 0, the rest pops within ~0.6 s
        t0, gap, pd = (-0.5, 0.06, 0.22) if first else (0.15, 0.13, 0.35)
        ov = Image.new('RGBA', (W, H), (0, 0, 0, int(150*(1 if first else clamp(tl/0.3))*(1 - clamp((tl-dur+0.5)/0.5)))))
        im.paste(ov, (0, 0), ov); d = ImageDraw.Draw(im, 'RGBA')
        size = hk.get('size', L['hook_size']); f = font('Black', size)
        lines = wrap_tokens(d, tokens(hk['text'].upper()), f, W*0.82)
        lh = size*1.15; y = H*hk.get('y', 0.40) - (len(lines)-1)*lh/2; i = 0; out = clamp((tl-dur+0.4)/0.4)
        for ln in lines:
            ws = [d.textlength(w, font=f) for w, _ in ln]; sp = d.textlength(' ', font=f)
            x = W*0.47 - (sum(ws) + sp*(len(ln)-1))/2
            for (w, emph), ww in zip(ln, ws):
                p = eback((tl - t0 - i*gap)/pd)*(1-out)
                if p > 0.02:
                    d.text((x+ww/2, y), w, font=font('Black', max(8, size*(0.5+0.5*p))), fill=(self.acc[:3] if emph else (255, 255, 255)) + (int(255*clamp(p)),),
                           anchor='mm', stroke_width=5, stroke_fill=(0, 0, 0, int(220*clamp(p))))
                x += ww + sp; i += 1
            y += lh
        if hk.get('sub'):
            a = clamp((tl - t0 - 0.15 - i*gap)/0.3)*(1-out); fs = font('Bold', 40)
            for j, ln in enumerate(wrap(d, hk['sub'], fs, W*0.78)):
                d.text((W*0.47, y+10+j*52), ln, font=fs, fill=(255, 255, 255, int(220*a)), anchor='mm')

    # ---- timeline ----
    def build(self):
        t = 0.; vis = []; prev = None; self.plan = []; self.srt = []
        for sc in self.cfg['scenes']:
            if 'dur' not in sc:
                sc['dur'] = round(max(4.0, sum(len(plain(s).split()) for s in sc.get('subs', []))/READ_CPS + 0.8), 2)
            for i in sc.get('show', []) + sc.get('pop', []) + sc.get('draw', []):
                if i not in vis: vis.append(i)
            for i in sc.get('hide', []):
                if i in vis: vis.remove(i)
            spec = sc.get('camera') or (self.plan[-1]['spec'] if self.plan else {'center': [0, 0], 'km': 10})
            has_card = bool(sc.get('card')); cam = self.camera(spec, has_card); segs = []
            if sc.get('sub_times'):
                st_ = sc['sub_times']
                for k, ((a, b), s) in enumerate(zip(st_, sc['subs'])): segs.append((t+a, t + (max(b, sc['dur']) if k == len(st_) - 1 else b), s))
            else:
                subs = sc.get('subs', []); tot = sum(len(plain(s)) for s in subs) or 1; lead = sc.get('sub_delay', 0.); st = t + lead
                for s in subs:
                    dd = (sc['dur']-lead)*len(plain(s))/tot; segs.append((st, st+dd, s)); st += dd
            self.srt += [(a, b, plain(s)) for a, b, s in segs]
            self.plan.append(dict(sc=sc, t0=t, cam0=prev or cam, cam1=cam, vis=list(vis), subs=segs, spec=spec))
            prev = cam; t += sc['dur']
        self.total = t
        self.titles = []; cur = None
        for P in self.plan: self.titles.append(cur); cur = P['sc'].get('title') or cur

    def reserved(self, d, sc, i, has_card):
        R = [(0, 0, W, L['brand_y'] + 34)]
        title = sc.get('title') or self.titles[i]
        if title and not sc.get('hook'):
            _, w, h, _, _ = self.title_rect(d, title)
            R.append((40, L['title_y'], 40 + w, L['title_y'] + h + (50 if sc.get('legend', self.cfg.get('legend')) else 0)))
        if has_card:
            x0, yf, cw = L['card']; R.append((x0, H*yf, x0 + cw, H*yf + self.card_h(d, sc['card']) + 40))
        if sc.get('panel'): R.append(self.panel_rect(sc['panel']))
        if sc.get('subs') and self.cfg.get('burn_subs', True) is not False and not sc.get('hook'):
            lh = L['sub_size'] + 18; cx = W*L['sub_cx']; mw = W*L['sub_maxw']/2 + 20
            R.append((cx - mw, H*L['sub_y'] - lh*1.5, cx + mw, H*L['sub_y'] + lh/2) if L.get('sub_bottom') else (cx - mw, H*L['sub_y'] - lh/2, cx + mw, H*L['sub_y'] + lh*1.5))
        R.append((0, L['footer_y'] - 50, W, H))
        return R

    def frame(self, k, i, clean=False):
        P = self.plan[i]; sc = P['sc']; tl = k/FPS; tg = P['t0'] + tl; dur = sc['dur']; self._scene = i
        move = min(sc.get('move', 1.5), dur*0.4) if P['cam0'] != P['cam1'] else 0.001
        cam = self.lerp(P['cam0'], P['cam1'], tl/move)
        drift = sc.get('drift', self.cfg.get('drift', 0.04))
        if drift and dur > move: cam = (cam[0], cam[1], cam[2]*(1 - drift*ease((tl-move)/(dur-move))))
        punch = sc.get('beat', self.cfg.get('beat', 0.03))
        if punch and P['subs']:      # each new subtitle line after the first pushes the camera in a little
            n = sum(ease((tg - a0)/0.35) for a0, _, _ in P['subs'][1:] if tg > a0)
            cam = (cam[0], cam[1], cam[2]*(1 - punch)**n)
        has_card = bool(sc.get('card')); vw = self.view(has_card)
        if i > 0 and bool(self.plan[i-1]['sc'].get('card')) != has_card:
            pv = self.view(not has_card); e = ease(tl/max(move, 0.5)); vw = (pv[0]+(vw[0]-pv[0])*e, pv[1]+(vw[1]-pv[1])*e)
        media = sc.get('media')
        im = self.media_frame(sc, i, tl, dur) if media else self.base.view(cam, vw).convert('RGB')
        d = ImageDraw.Draw(im, 'RGBA')
        im.paste(self.shade, (0, 0), self.shade)
        if media: return self.finish(im, d, sc, P, i, tl, tg, dur, cam, clean, media=True)
        if sc.get('panel') and not sc.get('panel_map'):      # news panel: map only as a dark backdrop
            im.paste(Image.new('RGB', (W, H), (4, 8, 14)), (0, 0), Image.new('L', (W, H), 165))
            return self.finish(im, d, sc, P, i, tl, tg, dur, cam, clean, media=False, move=move)
        focus = set(sc.get('focus', [])); dim = sc.get('dim', 0.4); draw = sc.get('draw', []); pops = sc.get('pop', [])
        crowd = (not focus) and W/cam[2] < self.cfg.get('label_min_px_per_km', 100)/1000
        placed = self.reserved(d, sc, i, has_card)
        self.big_labels(d, cam, sc.get('labels', []), eout(tl/0.8), vw)
        for iid in P['vis']:
            it = self.items[iid]
            if '_area' not in it: continue
            pa = eout((tl - move*0.5 - 0.3*pops.index(iid))/0.6) if iid in pops else 1.0
            if pa > 0: self.draw_area(im, d, cam, it, pa*(1 if (not focus or iid in focus) else dim), tg, vw)
        if sc.get('spotlight') in self.items: self.spotlight(im, d, cam, self.items[sc['spotlight']], eout((tl - move*0.5)/0.8), vw, placed)
        for iid in P['vis']:
            it = self.items[iid]
            if '_path' not in it or it.get('water'): continue
            prog = ease((tl - move*0.6)/max(0.8, sc.get('draw_time', 2.2))) if iid in draw else 1.0
            if prog > 0: self.draw_path(d, cam, it, prog, 255 if (not focus or iid in focus) else int(255*dim), tg, vw)
        for iid in P['vis']:
            it = self.items[iid]
            if '_path' not in it or it.get('water') or not (it.get('stations') or it.get('badge')): continue
            prog = ease((tl - move*0.6)/max(0.8, sc.get('draw_time', 2.2))) if iid in draw else 1.0
            self.path_extras(d, cam, it, prog, 255 if (not focus or iid in focus) else int(255*dim), vw, placed)
        for m in sc.get('measure', []): self.measure(d, cam, m, ease((tl - move)/0.8), vw, placed)
        labs = []
        for iid in P['vis']:
            it = self.items[iid]
            if it.get('marker') is False or '_p' not in it or it.get('water'): continue
            pa = eout((tl - move*0.5 - 0.3*pops.index(iid))/0.5) if iid in pops else 1.0
            if pa <= 0: continue
            foc = (not focus) or iid in focus; a = int(255*pa*(1 if foc else dim))
            if not ('_area' in it and it.get('marker') is not True): self.marker(d, cam, it, a, bool(focus) and iid in focus, tg, pa, vw)
            if it.get('name') and not it.get('hide_label') and iid != sc.get('spotlight') and ((foc and not crowd) or it.get('always_label')):
                labs.append((not (bool(focus) and iid in focus), not it.get('always_label'), iid, a))
        specs = []
        if not clean:
            for _, _, iid, a in sorted(labs, key=lambda z: z[:2]):
                it = self.items[iid]; x, y = self.scr(cam, it['_p'], vw)
                s = self.plan_label(d, it, x, y, a, bool(focus) and iid in focus, placed)
                if s: specs.append(s)
        self.place_names(d, cam, 0 if (clean or sc.get('names', True) is False) else 1.0, vw, placed)
        for s in specs: self.draw_label(d, s)
        return self.finish(im, d, sc, P, i, tl, tg, dur, cam, clean, move=move)

    def finish(self, im, d, sc, P, i, tl, tg, dur, cam, clean, media=False, move=0.6):
        hk = None if clean else sc.get('hook')
        if hk: self.hook(im, hk, tl, dur, first=(i == 0)); d = ImageDraw.Draw(im, 'RGBA')
        self.chrome(d, cam, scale=not (media or self.mapless or (sc.get('panel') and not sc.get('panel_map'))))
        if media: self.media_labels(d, sc['media'])
        if clean: return im
        if sc.get('panel') and not hk: self.panel(im, d, sc['panel'], (tl - 0.25)/0.6, tl)
        if not hk:
            title = sc.get('title') or self.titles[i]
            if title:
                yb = self.title_box(d, title, tl/0.6 if sc.get('title') else 1)
                if sc.get('legend', self.cfg.get('legend', False)): self.legend(d, P['vis'], yb + 14)
            cd = sc.get('card') or {}; reveal = None
            if cd.get('list') and 'list_from_sub' in cd and P['subs']:      # each item appears when its subtitle line starts
                k0 = cd['list_from_sub']
                reveal = [((tg - P['subs'][k0 + j][0])/0.4) if k0 + j < len(P['subs']) else 1.0 for j in range(len(cd['list']))]
            self.card(d, sc.get('card'), (tl - move*0.8)/0.6, reveal)
            for a0, b0, s in P['subs']:
                if a0 <= tg < b0: self.subtitle(d, s, min(1, (tg-a0)/0.12), (tg-a0)/max(0.01, b0-a0)); break
        if sc.get('fade_out') and not (i == len(self.plan) - 1 and self.cfg.get('loop_end', True)) and tl > dur - sc['fade_out']:
            im = Image.blend(im, Image.new('RGB', (W, H)), clamp((tl-(dur-sc['fade_out']))/sc['fade_out']))
        return im

    # ---- media (photo / video b-roll) ----
    def media_frame(self, sc, i, tl, dur):
        m = sc['media']; src = os.path.join(self.dir, m['src'])
        if i not in self._media:
            ext = os.path.splitext(src)[1].lower()
            if ext in ('.mp4', '.mov', '.webm', '.mkv', '.m4v'):
                import tempfile
                tmp = tempfile.mkdtemp(prefix=f'media{i}_')
                subprocess.run(['ffmpeg', '-v', 'error', '-ss', str(m.get('start', 0)), '-i', src, '-t', f'{dur+0.5:.2f}', '-an',
                                '-vf', f'scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={FPS}', '-q:v', '3',
                                os.path.join(tmp, 'f%05d.jpg')], check=True)
                self._media[i] = ('video', sorted(os.path.join(tmp, f) for f in os.listdir(tmp)))
            else:
                img = Image.open(src).convert('RGB'); ar, tar = img.width/img.height, W/H
                fit = m.get('fit') or ('cover' if abs(ar - tar)/tar < 0.35 else 'contain')
                self._media[i] = ('image', img, fit)
        kind = self._media[i][0]
        if kind == 'video':
            fr = self._media[i][1]; im = Image.open(fr[min(int(tl*FPS), len(fr)-1)]).convert('RGB')
        else:
            _, img, fit = self._media[i]; z0, z1 = (1.0, 1.12) if m.get('zoom', 'in') == 'in' else (1.12, 1.0)
            z = z0 + (z1 - z0)*ease(tl/max(dur, 0.1)); pan = m.get('pan', [0, 0])
            if fit == 'cover':
                s_ = max(W/img.width, H/img.height)*z; cw, ch = W/s_, H/s_
                cx = img.width/2 + pan[0]*img.width*0.08*ease(tl/dur); cy = img.height/2 + pan[1]*img.height*0.08*ease(tl/dur)
                box = (cx - cw/2, cy - ch/2, cx + cw/2, cy + ch/2)
                im = img.transform((W, H), Image.EXTENT, box, resample=Image.BILINEAR)
            else:
                bg = img.resize((max(1, W//8), max(1, int(W//8*img.height/img.width))))
                bg = bg.resize((W, int(W*img.height/img.width)) if img.height/img.width > H/W else (int(H*img.width/img.height), H))
                bg = bg.filter(ImageFilter.GaussianBlur(30)).crop((0, 0, W, H)) if bg.width >= W and bg.height >= H else bg.resize((W, H))
                im = Image.blend(bg.convert('RGB'), Image.new('RGB', (W, H)), 0.45)
                fw = W - 80; fh = int(fw*img.height/img.width)
                if fh > H*0.55: fh = int(H*0.55); fw = int(fh*img.width/img.height)
                fg = img.resize((int(fw*z), int(fh*z)), Image.LANCZOS)
                ox = (W - fg.width)//2; oy = int(H*L['map_cy']) - fg.height//2
                im.paste(fg, (ox, oy))
        return im

    def media_labels(self, d, m):
        y = L['footer_y'] - 64
        if m.get('ai'):
            # BDS Studio: không chèn chữ nhãn "AI" lên hình (người dùng tự bật nhãn nội dung AI của nền tảng khi đăng)
            t = m.get('label') or ('ẢNH MINH HOẠ' if not str(m.get('src', '')).lower().endswith(('.mp4', '.mov', '.webm')) else 'VIDEO MINH HOẠ')   # label: gói Video AI (cảnh 3D/phong thủy)
            f = font('Bold', 20); tw = d.textlength(t, font=f)
            d.rounded_rectangle([40, y - 18, 40 + tw + 24, y + 16], 8, fill=(0, 0, 0, 170))
            d.text((52, y), t, font=f, fill=(255, 225, 120, 235), anchor='lm'); y -= 42
        if m.get('credit'):
            d.text((40, y), m['credit'], font=font('Medium', 20), fill=(255, 255, 255, 200), anchor='lm', stroke_width=2, stroke_fill=(0, 0, 0, 180))

    # ---- ward / zone spotlight ----
    def spotlight(self, im, d, cam, it, a, vw, placed):
        if a <= 0 or '_area' not in it: return
        sp = [self.scr(cam, q, vw) for q in it['_area']]
        mask = Image.new('L', (W, H), int(150*a)); ImageDraw.Draw(mask).polygon(sp, fill=0)
        im.paste(Image.new('RGB', (W, H), (0, 0, 0)), (0, 0), mask)
        col = self.color_of(it) if it.get('status') or it.get('color') else self.acc
        ring = sp + [sp[0]]
        for w_, al in ((22, 40), (12, 90)): d.line(ring, fill=col[:3] + (int(al*a),), width=w_, joint='curve')
        d.line(ring, fill=(255, 255, 255, int(235*a)), width=4, joint='curve')
        if it.get('name') and not it.get('hide_label'):
            x, y = self.scr(cam, it['_p'], vw); f = font('Black', it.get('size', 46)); t = it['name'].upper()
            d.text((x, y), t, font=f, fill=(255, 255, 255, int(255*a)), anchor='mm', stroke_width=6, stroke_fill=(0, 0, 0, int(220*a)))
            tw = d.textlength(t, font=f); placed.append((x - tw/2 - 10, y - 40, x + tw/2 + 10, y + 40))

    # ---- news panels ----
    def panel_rect(self, pn):
        x0 = 40; cw = L['card'][2]; y0 = H*(0.29 if W < H else 0.22)      # below a 2-line title
        h = pn.get('height') or {'bars': 110 + (116 if pn.get('stacked', True) else 78)*len(pn.get('items', [])), 'line': 560, 'compare': 150 + 74*len(pn.get('rows', [])),
                                 'timeline': 110 + 108*len(pn.get('steps', [])), 'quote': 470, 'calc': 280 + 56*len(pn.get('lines', []))}.get(pn['type'], 480)
        if W > H: x0 = L['card'][0]; y0 = H*0.2
        lim = (H*L['sub_y'] - 1.5*(L['sub_size'] + 18) - y0) if (W < H and L.get('sub_bottom')) else (H*0.40 if W < H else H*0.62)
        return (x0, y0, x0 + cw, y0 + min(h, lim))      # never runs into a 2-line subtitle

    def panel(self, im, d, pn, t_in, tl):
        if t_in <= 0: return
        a = eout(t_in); A = int(255*a); x0, y0, x1, y1 = self.panel_rect(pn); y0 += (1 - a)*30; y1 += (1 - a)*30
        d.rounded_rectangle([x0, y0, x1, y1], 20, fill=(8, 14, 24, int(236*a)), outline=self.acc[:3] + (int(170*a),), width=2)
        fh = font('ExtraBold', 34); fr = font('SemiBold', 28); fv = font('ExtraBold', 30); y = y0 + 26
        if pn.get('title'): d.text((x0 + 30, y), pn['title'], font=fh, fill=(255, 255, 255, A)); y += 58
        p = clamp((t_in - 0.2)/1.2); typ = pn['type']; ix0, ix1 = x0 + 30, x1 - 30
        if typ == 'bars':
            items = pn['items']; mx = max(v[1] for v in items) or 1; lw = pn.get('label_w', 240); hi = pn.get('highlight', -1)
            stacked = pn.get('stacked', any(d.textlength(it[0], font=fr) > lw - 16 for it in items))
            for k, it in enumerate(items):
                lab, val = it[0], it[1]; disp = it[2] if len(it) > 2 else (f'{val:g}'.replace('.', ',') + pn.get('unit', ''))
                pk = eout((t_in - 0.2 - k*0.12)/0.9)
                if stacked:
                    d.text((ix0, y + 4), lab, font=fr, fill=(210, 220, 230, A), anchor='lt'); y += 38; lw_ = 0
                else:
                    d.text((ix0, y + 22), lab, font=fr, fill=(210, 220, 230, A), anchor='lm'); lw_ = lw
                vcol = max(d.textlength(str(v[2]) if len(v) > 2 else f'{v[1]:g}' + pn.get('unit', ''), font=fv) for v in items) + 24
                bx0 = ix0 + lw_; bx1 = ix1 - vcol; bw = (bx1 - bx0)*val/mx*pk
                c = self.acc[:3] if (k == hi or hi == -2) else (90, 130, 170)
                d.rounded_rectangle([bx0, y + 6, bx0 + max(8, bw), y + 40], 8, fill=c + (A,))
                d.text((ix1, y + 22), count_up(disp, pk), font=fv, fill=(255, 255, 255, A), anchor='rm'); y += 78
        elif typ == 'line':
            pts = pn['points']; vals = [v for _, v in pts]; lo, hi_ = min(vals), max(vals); pad = (hi_ - lo)*0.25 or 1
            lo -= pad; hi_ += pad; cx0, cx1, cy0, cy1 = ix0 + 10, ix1 - 10, y + 50, y1 - 100
            P_ = [(cx0 + (cx1 - cx0)*k/max(1, len(pts) - 1), cy1 - (cy1 - cy0)*(v - lo)/(hi_ - lo)) for k, (_, v) in enumerate(pts)]
            for g in range(4):
                gy = cy0 + (cy1 - cy0)*g/3; d.line([(cx0, gy), (cx1, gy)], fill=(255, 255, 255, int(25*a)), width=1)
            n = p*(len(P_) - 1); k = int(n); part = P_[:k + 1]
            if k < len(P_) - 1: f_ = n - k; part = part + [(P_[k][0] + (P_[k+1][0] - P_[k][0])*f_, P_[k][1] + (P_[k+1][1] - P_[k][1])*f_)]
            if len(part) > 1:
                d.line(part, fill=self.acc[:3] + (int(70*a),), width=14, joint='curve'); d.line(part, fill=self.acc[:3] + (A,), width=5, joint='curve')
            for q, (lab, v) in zip(P_[:k + 1], pts):
                d.ellipse([q[0] - 7, q[1] - 7, q[0] + 7, q[1] + 7], fill=(255, 255, 255, A))
            for idx in sorted({0, len(pts)//2, len(pts) - 1}):
                d.text((P_[idx][0], cy1 + 30), pts[idx][0], font=font('Medium', 22), fill=(190, 204, 218, A), anchor='mm')
            last = part[-1]; lv = pts[min(k + (1 if k < len(pts) - 1 else 0), len(pts) - 1)][1] if p >= 1 else None
            if p >= 1:
                lab = (f'{pts[-1][1]:g}'.replace('.', ',') + pn.get('unit', ''))
                tw = d.textlength(lab, font=fv); bx = min(last[0] - tw/2, ix1 - tw - 20)
                d.rounded_rectangle([bx - 12, last[1] - 62, bx + tw + 12, last[1] - 18], 10, fill=self.acc[:3] + (A,))
                d.text((bx, last[1] - 40), lab, font=fv, fill=(10, 10, 10, A), anchor='lm')
        elif typ == 'compare':
            cL, cR = ix0 + (ix1 - ix0)*0.50, ix0 + (ix1 - ix0)*0.80
            d.text((cL, y + 10), pn.get('left', 'TRƯỚC'), font=font('Bold', 24), fill=(190, 204, 218, A), anchor='mm')
            d.text((cR, y + 10), pn.get('right', 'SAU'), font=font('Bold', 24), fill=self.acc[:3] + (A,), anchor='mm'); y += 40
            for k, row in enumerate(pn['rows']):
                ra = int(255*eout((t_in - 0.3 - k*0.25)/0.5)*a)
                d.line([(ix0, y), (ix1, y)], fill=(255, 255, 255, int(30*a)), width=1)
                d.text((ix0, y + 37), row[0], font=fr, fill=(220, 228, 236, ra), anchor='lm')
                d.text((cL, y + 37), row[1], font=fv, fill=(200, 210, 220, ra), anchor='mm')
                d.text((cR, y + 37), row[2], font=fv, fill=self.acc[:3] + (ra,), anchor='mm'); y += 74
        elif typ == 'timeline':
            cur = pn.get('current', -1); lx = ix0 + 18
            steps = pn['steps']; d.line([(lx, y + 18), (lx, y + 18 + 108*(len(steps) - 1))], fill=(255, 255, 255, int(60*a)), width=4)
            for k, st in enumerate(steps):
                ra = eout((t_in - 0.2 - k*0.25)/0.5)*a; done = cur < 0 or k <= cur; c = self.acc[:3] if k == cur else ((255, 255, 255) if done else (120, 135, 150))
                r = 14 if k == cur else 10
                if k == cur:
                    ph = (tl*0.8) % 1; rr = 14 + 26*ph; d.ellipse([lx - rr, y + 18 - rr, lx + rr, y + 18 + rr], outline=c + (int(200*(1 - ph)*ra),), width=3)
                d.ellipse([lx - r, y + 18 - r, lx + r, y + 18 + r], fill=c + (int(255*ra),))
                d.text((lx + 36, y + 4), st[0], font=font('ExtraBold', 28), fill=c + (int(255*ra),))
                for j, ln in enumerate(wrap(d, st[1], font('Medium', 26), ix1 - lx - 40)[:2]):
                    d.text((lx + 36, y + 42 + j*30), ln, font=font('Medium', 26), fill=(220, 228, 236, int(235*ra)))
                y += 108
        elif typ == 'quote':
            d.text((ix0, y - 10), '“', font=font('Black', 110), fill=self.acc[:3] + (A,)); y += 70
            fq = font('Bold', pn.get('size', 38))
            for ln in wrap(d, pn['text'], fq, ix1 - ix0)[:6]:
                d.text((ix0, y), ln, font=fq, fill=(255, 255, 255, A)); y += fq.size*1.3
            if pn.get('source'): d.text((ix0, y + 14), '— ' + pn['source'], font=font('SemiBold', 26), fill=(190, 204, 218, A))
        elif typ == 'calc':
            for k, (kk, vv) in enumerate(pn.get('lines', [])):
                ra = int(255*eout((t_in - 0.2 - k*0.2)/0.5)*a)
                d.text((ix0, y), kk, font=fr, fill=(200, 210, 220, ra)); d.text((ix1, y), vv, font=fv, fill=(255, 255, 255, ra), anchor='ra'); y += 56
            if pn.get('result'):
                ra = eout((t_in - 0.4 - 0.2*len(pn.get('lines', [])))/0.6)*a
                d.line([(ix0, y + 4), (ix1, y + 4)], fill=(255, 255, 255, int(60*ra)), width=2); y += 22
                d.text((ix0, y + 20), pn['result'][0], font=font('ExtraBold', 30), fill=(255, 255, 255, int(255*ra)))
                d.text((ix1, y + 6), count_up(pn['result'][1], ra), font=font('Black', 52), fill=self.acc[:3] + (int(255*ra),), anchor='ra')
        if pn.get('note'): d.text((x0 + 30, y1 - 22), pn['note'], font=font('Medium', 21), fill=(170, 185, 200, A), anchor='ls')

    def cover(self, path):
        cv = self.cfg.get('cover', {}); i = min(cv.get('scene', 1), len(self.plan)-1); P = self.plan[i]
        im = self.frame(int(P['sc']['dur']*FPS) - 2, i, clean=True).convert('RGBA')
        im.alpha_composite(Image.new('RGBA', (W, H), (0, 0, 0, 120))); d = ImageDraw.Draw(im)
        text = cv.get('text') or self.cfg['scenes'][0].get('hook', {}).get('text') or (self.cfg['scenes'][0].get('title') or {}).get('text', 'QUY HOẠCH')
        size = cv.get('size', 120 if W < H else 110); f = font('Black', size); y = H*cv.get('y', 0.36); rows = []
        for raw in text.split('\n'): rows += wrap_tokens(d, tokens(raw.upper()), f, W*0.84)
        for ln in rows:
            sp = d.textlength(' ', font=f); tw = sum(d.textlength(w, font=f) for w, _ in ln) + sp*(len(ln)-1); x = W*0.47 - tw/2
            for w, emph in ln:
                ww = d.textlength(w, font=f)
                if emph: d.rectangle([x-10, y-size*0.62, x+ww+10, y+size*0.62], fill=self.acc)
                d.text((x, y), w, font=f, fill=(10, 10, 10) if emph else (255, 255, 255), anchor='lm', stroke_width=0 if emph else 6, stroke_fill=(0, 0, 0))
                x += ww + sp
            y += size*1.25
        if cv.get('sub'):
            fs = font('ExtraBold', 44)
            for ln in wrap(d, cv['sub'], fs, W*0.8):
                d.text((W*0.47, y+20), ln, font=fs, fill=(255, 255, 255), anchor='mm', stroke_width=4, stroke_fill=(0, 0, 0)); y += 58
        im.convert('RGB').save(path, quality=92)


# ---------------- lint ----------------
BAD = re.compile(r'(chắc chắn tăng|x2|x3|tăng giá mạnh|mua ngay|cơ hội vàng|đón sóng|không mua là|bắt đáy|cháy hàng)', re.I)

def lint(cfg, V):
    warn = []; ids = set(V.items); X0, X1, Y0, Y1 = cfg['extent_m']
    for i, P in enumerate(V.plan):
        sc = P['sc']; n = i + 1
        refs = sc.get('show', []) + sc.get('pop', []) + sc.get('draw', []) + sc.get('focus', []) + sc.get('hide', [])
        refs += (sc.get('camera') or {}).get('fit', []) + ([sc['spotlight']] if sc.get('spotlight') else []) + [x for m in sc.get('measure', []) for x in m[:2]]
        warn += [f'Cảnh {n}: id không tồn tại "{r}"' for r in refs if r not in ids]
        for s in sc.get('subs', []):
            if len(plain(s)) > 75: warn.append(f'Cảnh {n}: câu phụ đề dài {len(plain(s))} ký tự (nên ≤ 75, dễ thành 3 dòng): "{plain(s)[:40]}…"')
        words = sum(len(plain(s).split()) for s in sc.get('subs', []))
        if words and sc['dur'] < words/READ_CPS*0.85 and not sc.get('sub_times') and not cfg.get('fit_to_audio') and '_voice_len' not in sc:
            warn.append(f'Cảnh {n}: {words} chữ cần ~{words/READ_CPS:.1f}s đọc nhưng dur={sc["dur"]}s')
        if sc['dur'] > 10.5 and not (sc.get('card') or {}).get('list') and i < len(V.plan) - 1:
            warn.append(f'Cảnh {n}: dài {sc["dur"]:.1f}s — nên ≤ 10 s, mỗi câu 3–5 s, tách cảnh hoặc bớt câu')
        if sc.get('card') and L.get('safe_bottom'):
            d0 = ImageDraw.Draw(Image.new('RGB', (8, 8))); cb = H*L['card'][1] + V.card_h(d0, sc['card'])
            lines = max([len(wrap(d0, plain(s), font('ExtraBold', L['sub_size']), W*L['sub_maxw'])) for s in sc.get('subs', [])] or [1])
            st = H*L['sub_y'] - (lines - 0.5)*(L['sub_size'] + 18)
            if cb > st: warn.append(f'Cảnh {n}: thẻ cao tới {cb:.0f}px, đè phụ đề (bắt đầu {st:.0f}px) — bớt dòng trong thẻ')
        if sc.get('panel') and sc.get('card'): warn.append(f'Cảnh {n}: có cả panel và card — dễ chồng nhau, nên dùng một')
        m = sc.get('media')
        if m and not os.path.exists(os.path.join(V.dir, m.get('src', ''))): warn.append(f'Cảnh {n}: không thấy file media {m.get("src")}')
        if m and not m.get('ai') and not m.get('credit') and not m.get('own'): warn.append(f'Cảnh {n}: ảnh/video thật cần "credit" (tác giả/nguồn) hoặc "own": true nếu là tư liệu tự quay')
        card = sc.get('card') or {}
        if 'progress' in card and not re.search(r'\d{1,2}/\d{4}', card.get('progress_label', '') + card.get('progress_caption', '') + ' '.join(v for _, v in card.get('rows', []))):
            warn.append(f'Cảnh {n}: thẻ tiến độ chưa ghi tháng số liệu (vd "54,2% (10/2026)")')
        for s in sc.get('subs', []) + [sc.get('hook', {}).get('text', '')]:
            if BAD.search(s): warn.append(f'Cảnh {n}: câu mang tính cam kết/kêu gọi mua: "{plain(s)}"')
        if cfg.get('geo') and not sc.get('media') and not (sc.get('panel') and not sc.get('panel_map')):
            bx = V.visible_box(P['cam1'], V.view(bool(sc.get('card'))))
            if bx[0] < X0 or bx[1] > X1 or bx[2] < Y0 or bx[3] > Y1:
                warn.append(f'Cảnh {n}: khung hình vượt vùng dữ liệu bản đồ (lộ mép) — thu hẹp camera hoặc tải vùng rộng hơn')
    ft = cfg.get('footer', '').lower()
    if cfg.get('geo') and 'openstreetmap' not in ft: warn.append('Footer thiếu "© OpenStreetMap contributors" (bắt buộc theo giấy phép ODbL)')
    if 'nguồn' not in ft and 'số liệu' not in ft: warn.append('Footer thiếu nguồn số liệu')
    if not (cfg['scenes'][-1].get('card') or {}).get('list'): warn.append('Cảnh cuối nên là checklist (card.list) + mời theo dõi')
    return warn


# ---------------- render / audio ----------------
_V = None

def render_scene(args):
    i, path = args; V = _V; P = V.plan[i]; n = int(round(P['sc']['dur']*FPS))
    xf = 0 if (i == 0 or P['sc'].get('cut')) else int(FPS*V.cfg.get('crossfade', 0.25))
    prev = V.frame(int(round(V.plan[i-1]['sc']['dur']*FPS)) - 1, i-1) if xf else None
    pr = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                           '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', path], stdin=subprocess.PIPE)
    loop = int(FPS*0.5) if (i == len(V.plan) - 1 and V.cfg.get('loop_end', True)) else 0
    first = V.frame(0, 0) if loop else None
    for k in range(n):
        f = V.frame(k, i)
        if k < xf: f = Image.blend(prev, f, ease((k+1)/(xf+1)))
        if loop and k >= n - loop: f = Image.blend(f, first, ease((k - (n - loop) + 1)/loop))
        pr.stdin.write(f.tobytes())
    pr.stdin.close()
    if pr.wait() != 0: raise RuntimeError(f'ffmpeg failed on scene {i}')
    return i

def probe(p):
    return float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', p], capture_output=True, text=True).stdout.strip())

def fmt(t):
    ms = int(round(t*1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'

def prepare_audio(cfg, base):
    for sc in cfg['scenes']:
        v = sc.get('voice')
        if v and os.path.exists(os.path.join(base, v)):
            md = sc.get('min_dur', 4.5 if (sc.get('panel') or sc.get('media')) else 3.0)
            sc['_voice_len'] = probe(os.path.join(base, v)); sc['dur'] = round(max(md, sc['_voice_len'] + sc.get('voice_pad', 0.45)), 2)
    v = cfg.get('voice') or cfg.get('audio')
    if v and cfg.get('fit_to_audio') and os.path.exists(os.path.join(base, v)) and not any(sc.get('sub_times') for sc in cfg['scenes']):
        al = probe(os.path.join(base, v)) + 0.8
        for sc in cfg['scenes']:
            if 'dur' not in sc: sc['dur'] = max(4.0, sum(len(plain(s).split()) for s in sc.get('subs', []))/READ_CPS + 0.8)
        k = al/sum(sc['dur'] for sc in cfg['scenes'])
        for sc in cfg['scenes']: sc['dur'] = round(sc['dur']*k, 3)
        print(f'fit_to_audio: x{k:.3f} -> {al:.1f}s')

def sfx_track(cfg, V, path, sr=44100):
    """Royalty-free SFX synthesised here: whoosh on scene changes, pop on hook/markers, click on checklist items."""
    import numpy as np, wave
    T = V.total; buf = np.zeros(int(sr*(T + 1)), dtype=np.float32); rng = np.random.default_rng(7)
    def env(n, a=0.15): x = np.linspace(0, 1, n); return np.minimum(1, x/a) * (1 - x)**2
    def whoosh():
        n = int(sr*0.45); w = rng.standard_normal(n).astype(np.float32)
        out = np.zeros(n, np.float32); y = 0.; fc = np.linspace(0.02, 0.35, n)**1.5      # sweeping one-pole low-pass
        for k in range(n): y += fc[k]*(w[k] - y); out[k] = y
        return out/np.abs(out).max()*0.16*env(n, 0.55)
    def pop():
        n = int(sr*0.09); t = np.arange(n)/sr; f = 950*np.exp(-t*28) + 260
        return (np.sin(2*np.pi*np.cumsum(f)/sr)*0.22*np.exp(-t*38)).astype(np.float32)
    def click():
        n = int(sr*0.03); t = np.arange(n)/sr
        return (np.sin(2*np.pi*2100*t)*0.16*np.exp(-t*160)).astype(np.float32)
    S = dict(whoosh=whoosh(), pop=pop(), click=click()); ev = []
    for i, P in enumerate(V.plan):
        sc = P['sc']; t0 = P['t0']
        if i > 0 and not sc.get('cut'): ev.append((t0 - 0.18, 'whoosh'))
        if sc.get('hook'): ev.append((t0 + (0.0 if i == 0 else 0.15), 'pop'))
        move = min(sc.get('move', 1.5), sc['dur']*0.4) if P['cam0'] != P['cam1'] else 0.001
        for j, _ in enumerate(sc.get('pop', [])): ev.append((t0 + move*0.5 + 0.3*j, 'pop'))
        cd = sc.get('card') or {}
        if cd.get('list') and 'list_from_sub' in cd:
            for j in range(len(cd['list'])):
                if cd['list_from_sub'] + j < len(P['subs']): ev.append((P['subs'][cd['list_from_sub'] + j][0], 'click'))
    for t, kind in ev:
        a = S[kind]; k = int(max(0, t)*sr); buf[k:k+len(a)] += a[:max(0, len(buf)-k)]
    pcm = (np.clip(buf, -1, 1)*32767).astype('<i2')
    with wave.open(path, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(pcm.tobytes())
    return len(ev)

def mix_audio(cfg, base, V, silent, out):
    vf = [(P['t0'], os.path.join(base, P['sc']['voice'])) for P in V.plan if P['sc'].get('voice') and os.path.exists(os.path.join(base, P['sc']['voice']))]
    gv = cfg.get('voice') or cfg.get('audio')
    if gv and os.path.exists(os.path.join(base, gv)): vf.append((cfg.get('voice_offset', 0.0), os.path.join(base, gv)))
    music = cfg.get('music'); music = os.path.join(base, music) if music else None
    if music and not os.path.exists(music): music = None
    sfx = None
    if cfg.get('sfx', True):
        sfx = os.path.splitext(out)[0] + '_sfx.wav'; print('sfx:', sfx_track(cfg, V, sfx), 'hiệu ứng')
    if not vf and not music and not sfx: shutil.move(silent, out); return
    T = V.total; args = ['ffmpeg', '-y', '-loglevel', 'error', '-i', silent]; filt = []; labs = []; n = 1
    for t0, f in vf:
        args += ['-i', f]; ms = int(t0*1000)
        filt.append(f'[{n}:a]aresample=44100,aformat=channel_layouts=stereo,adelay={ms}|{ms}[v{n}]'); labs.append(f'[v{n}]'); n += 1
    if vf: filt.append(''.join(labs) + f'amix=inputs={len(labs)}:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=44100,apad,atrim=0:{T:.3f}[voice]')
    if music:
        args += ['-stream_loop', '-1', '-i', music]; mv = cfg.get('music_volume', 0.14 if vf else 0.6)
        filt.append(f'[{n}:a]aresample=44100,aformat=channel_layouts=stereo,atrim=0:{T:.3f},volume={mv},afade=t=in:d=1,afade=t=out:st={max(0, T-2):.3f}:d=2[mus]')
        if vf: filt += ['[voice]asplit=2[vo][sc]', '[mus][sc]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=400[duck]', '[vo][duck]amix=inputs=2:normalize=0[aout]']
        else: filt.append('[mus]anull[aout]')
    else: filt.append('[voice]anull[aout]' if vf else 'anullsrc=r=44100:cl=stereo,atrim=0:%.3f[aout]' % T)
    if sfx:
        args += ['-i', sfx]; n += 1 if music else 0
        filt[-1] = filt[-1].rsplit('[aout]', 1)[0] + '[pre]'
        filt.append(f'[{len(vf) + (2 if music else 1)}:a]aresample=44100,aformat=channel_layouts=stereo,volume={cfg.get("sfx_volume", 1.0)}[fx]')
        filt.append('[pre][fx]amix=inputs=2:normalize=0:duration=first[aout]')
    args += ['-filter_complex', ';'.join(filt), '-map', '0:v', '-map', '[aout]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-t', f'{T:.3f}', '-movflags', '+faststart', out]
    subprocess.run(args, check=True); os.remove(silent)
    if sfx and os.path.exists(sfx): os.remove(sfx)

def main():
    global _V, W, H, L
    cfg_p = sys.argv[1]; out = sys.argv[2]; mode = sys.argv[3] if len(sys.argv) > 3 else ''
    cfg = json.load(open(cfg_p, encoding='utf-8')); base = os.path.dirname(os.path.abspath(cfg_p))
    L = LAYOUTS[cfg.get('format', '9:16')]; W, H = L['W'], L['H']
    os.makedirs(os.path.dirname(os.path.abspath(out)) or '.', exist_ok=True)
    normalize_subs(cfg)
    prepare_audio(cfg, base)
    V = Video(cfg, base); V.build(); _V = V
    for w in lint(cfg, V): print('⚠', w)
    stem = os.path.splitext(out)[0]
    if mode == 'check':
        for i, sc in enumerate(cfg['scenes'], 1):
            for m in sc.get('measure', []):
                print(f'Cảnh {i}: {m[0]} → {m[1]} = {math.dist(V.items[m[0]]["_p"], V.items[m[1]]["_p"])/1000:.2f} km (đường chim bay)')
            print(f'Cảnh {i}: {sc["dur"]:.1f}s')
        print(f'{len(V.plan)} cảnh, {V.total:.1f}s'); return
    if mode == 'cover': V.cover(stem + '_cover.jpg'); print('cover:', stem + '_cover.jpg'); return
    work = stem + '_scenes'; os.makedirs(work, exist_ok=True)
    if mode == 'stills':
        th = []
        for i, P in enumerate(V.plan):
            p = f'{work}/still_{i:02d}.png'; V.frame(int(P['sc']['dur']*FPS) - 1 - int(FPS*0.4), i).save(p); th.append(p)
        cols = 4 if H > W else 3; tw, tht = W//4, H//4; rows = math.ceil(len(th)/cols)
        sh = Image.new('RGB', (cols*tw + (cols+1)*8, rows*tht + (rows+1)*8), (40, 40, 40)); dd = ImageDraw.Draw(sh)
        for j, p in enumerate(th):
            x = 8 + (j % cols)*(tw+8); y = 8 + (j//cols)*(tht+8)
            sh.paste(Image.open(p).resize((tw, tht)), (x, y)); dd.text((x+8, y+6), str(j+1), font=font('Black', 28), fill=(255, 230, 0))
        sh.save(f'{work}/contact.jpg', quality=88); print('stills:', f'{work}/contact.jpg', f'{V.total:.1f}s'); return
    jobs = [(i, f'{work}/{i:02d}.mp4') for i in range(len(V.plan))]
    procs = int(cfg.get('workers', max(1, min(len(jobs), os.cpu_count() or 2))))
    if procs > 1 and 'fork' in mp.get_all_start_methods():
        with mp.get_context('fork').Pool(procs) as pool:
            for i in pool.imap_unordered(render_scene, jobs): print(f'scene {i+1}/{len(jobs)}', flush=True)
    else:
        for j in jobs: render_scene(j); print(f'scene {j[0]+1}/{len(jobs)}', flush=True)
    lst = f'{work}/list.txt'; open(lst, 'w').write(''.join(f"file '{os.path.abspath(f)}'\n" for _, f in jobs))
    silent = stem + '_silent.mp4'
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', '-movflags', '+faststart', silent], check=True)
    mix_audio(cfg, base, V, silent, out)
    with open(stem + '.srt', 'w', encoding='utf-8') as f:
        for i, (a, b, s) in enumerate(V.srt, 1): f.write(f'{i}\n{fmt(a)} --> {fmt(b)}\n{s}\n\n')
    if cfg.get('make_cover', True): V.cover(stem + '_cover.jpg')
    meta = dict(duration=round(V.total, 2), has_ai=any((sc.get('media') or {}).get('ai') for sc in cfg['scenes']),
                credits=sorted({sc['media']['credit'] for sc in cfg['scenes'] if (sc.get('media') or {}).get('credit')}))
    json.dump(meta, open(stem + '_meta.json', 'w', encoding='utf-8'), ensure_ascii=False)
    if not cfg.get('keep_scenes'): shutil.rmtree(work, ignore_errors=True)
    print('OK', out, f'{V.total:.1f}s')

if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()
