#!/usr/bin/env python3
"""Voice every subtitle line with Vbee (Batch API) and fit the video config to the voice.

python3 vbee_tts.py cfg.json cfg_voiced.json [--voice CODE] [--speed 1.1] [--gap 0.25]

* One Vbee request per subtitle line (parallel), so subtitle timings match the voice exactly.
* A subtitle may be a string or {"text": "shown on screen", "say": "how to read it"}
  (use "say" to spell numbers/abbreviations: "54,2%" -> "năm mươi tư phẩy hai phần trăm").
* Writes voice/scene_XX.wav (lead silence + lines + gaps) and, per scene: "voice", "voice_pad", "sub_times".
* Cache: voice/cache/<hash>.mp3 — re-running after a text edit only re-voices changed lines.

Credentials: App-Id from env VBEE_APP_ID (or --app-id / cfg.vbee.app_id).
Token: env VBEE_TOKEN if set, else the placeholder "proxy-injected" (a cloud network proxy injects the real token).
Endpoints (docs api-docs.vbee.vn): POST https://api.vbee.vn/v1/tts (mode async, webhookUrl required)
-> GET https://api.vbee.vn/v1/tts/requests/{id} -> audioLink (valid 3 minutes, host vbee.vn).
"""
import argparse, hashlib, json, os, subprocess, sys, time, wave, urllib.request
from concurrent.futures import ThreadPoolExecutor

API = 'https://api.vbee.vn/v1/tts'
SR = 44100


def plain(s): return s.replace('**', '')


def http(method, url, headers, body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r: return r.status, r.read()
    except urllib.error.HTTPError as e: return e.code, e.read()


def voice_line(text, voice, speed, hdr, cache_dir, retries=2):
    key = hashlib.sha1(f'{voice}|{speed}|{text}'.encode()).hexdigest()[:16]
    out = os.path.join(cache_dir, key + '.mp3')
    if os.path.exists(out) and os.path.getsize(out) > 1000: return out
    for attempt in range(retries + 1):
        st, b = http('POST', API, hdr, {'text': text, 'voiceCode': voice, 'mode': 'async', 'outputFormat': 'mp3',
                                        'bitrate': 128, 'speed': speed, 'webhookUrl': 'https://example.com/vbee-callback'})
        if st not in (200, 201):
            if attempt < retries: time.sleep(2); continue
            raise RuntimeError(f'Vbee submit {st}: {b[:200]!r}')
        rid = json.loads(b)['requestId']
        t0 = time.time()
        while time.time() - t0 < 180:
            time.sleep(1.5)
            st, b = http('GET', f'{API}/requests/{rid}', hdr)
            d = json.loads(b) if b else {}
            if d.get('status') == 'COMPLETED' and d.get('audioLink'):
                with urllib.request.urlopen(d['audioLink'], timeout=60) as r: data = r.read()
                open(out, 'wb').write(data); return out
            if d.get('status') == 'FAILED' or 'error' in d: break
        if attempt < retries: time.sleep(2)
    raise RuntimeError(f'Vbee failed for: {text[:60]}')


def pcm(path):
    """decode to mono s16 44.1k, trim leading/trailing silence"""
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 's16le', '-ac', '1', '-ar', str(SR), '-'],
                         capture_output=True, check=True).stdout
    import array
    a = array.array('h', raw)
    thr = 600; i0, i1 = 0, len(a)
    while i0 < i1 and abs(a[i0]) < thr: i0 += 1
    while i1 > i0 and abs(a[i1 - 1]) < thr: i1 -= 1
    i0 = max(0, i0 - int(0.03 * SR)); i1 = min(len(a), i1 + int(0.08 * SR))
    return a[i0:i1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cfg'); ap.add_argument('out')
    ap.add_argument('--voice', default=None); ap.add_argument('--speed', type=float, default=None)
    ap.add_argument('--gap', type=float, default=0.25, help='silence between lines (s)')
    ap.add_argument('--lead', type=float, default=0.35, help='silence at scene start (s)')
    ap.add_argument('--tail', type=float, default=0.45, help='silence after last line of a scene (s)')
    ap.add_argument('--app-id', default=None); ap.add_argument('--workers', type=int, default=6)
    a = ap.parse_args()
    cfg = json.load(open(a.cfg, encoding='utf-8')); base = os.path.dirname(os.path.abspath(a.cfg))
    vb = cfg.get('vbee', {})
    voice = a.voice or vb.get('voice', 'hn_male_manhdung_news_48k-fhg'); speed = a.speed or vb.get('speed', 1.1)
    app_id = a.app_id or os.environ.get('VBEE_APP_ID') or vb.get('app_id')
    if not app_id: sys.exit('Thiếu App-Id: đặt biến môi trường VBEE_APP_ID')
    hdr = {'Content-Type': 'application/json', 'App-Id': app_id,
           'Authorization': 'Bearer ' + os.environ.get('VBEE_TOKEN', 'proxy-injected')}
    vdir = os.path.join(base, 'voice'); cdir = os.path.join(vdir, 'cache'); os.makedirs(cdir, exist_ok=True)

    jobs = []
    for si, sc in enumerate(cfg['scenes']):
        for li, s in enumerate(sc.get('subs', [])):
            say = s.get('say') if isinstance(s, dict) else None
            say = say or plain(s['text'] if isinstance(s, dict) else s)
            jobs.append((si, li, say))
    print(f'{len(jobs)} câu, giọng {voice}, tốc độ {speed}, ~{sum(len(j[2]) for j in jobs)} ký tự')
    with ThreadPoolExecutor(a.workers) as ex:
        files = list(ex.map(lambda j: voice_line(j[2], voice, speed, hdr, cdir), jobs))
    import array
    by_scene = {}
    for (si, li, _), f in zip(jobs, files): by_scene.setdefault(si, []).append(pcm(f))
    for si, sc in enumerate(cfg['scenes']):
        clips = by_scene.get(si)
        if not clips: continue
        buf = array.array('h', [0]*int(a.lead*SR)); times = []
        for k, c in enumerate(clips):
            t0 = len(buf)/SR; buf.extend(c); times.append([round(t0, 3), round(len(buf)/SR, 3)])
            if k < len(clips) - 1: buf.extend([0]*int(a.gap*SR))
        p = os.path.join(vdir, f'scene_{si:02d}.wav')
        with wave.open(p, 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(buf.tobytes())
        # subtitles stay on screen until the next line starts (no flicker in gaps)
        for k in range(len(times) - 1): times[k][1] = times[k+1][0]
        times[-1][1] = round(len(buf)/SR + a.tail, 3)
        sc['voice'] = os.path.relpath(p, base); sc['voice_pad'] = a.tail; sc['sub_times'] = times
        sc.pop('dur', None)
        print(f'cảnh {si+1}: {len(buf)/SR + a.tail:.2f}s, {len(clips)} câu')
    cfg.pop('fit_to_audio', None); cfg.pop('audio', None)
    json.dump(cfg, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('OK', a.out)


if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()
