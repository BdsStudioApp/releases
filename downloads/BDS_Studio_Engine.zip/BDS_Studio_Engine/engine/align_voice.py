#!/usr/bin/env python3
"""Fit scene durations + subtitle timings of a video config to a recorded voice-over.

python3 align_voice.py config.json voice.mp3 config_aligned.json [--music music.mp3] [--tail 1.2] [--noise -32dB]

Reads every scene's "subs" in order, detects pauses in the voice (ffmpeg silencedetect),
snaps each subtitle boundary to the nearest pause (in order, weighted by text length),
then rewrites scene "dur" and "sub_times" so picture, subtitles and voice line up.
"""
import json, re, subprocess, sys

def probe_dur(p):
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', p]).decode())

def silences(p, noise='-32dB', d=0.28):
    err = subprocess.run(['ffmpeg', '-hide_banner', '-i', p, '-af', f'silencedetect=noise={noise}:d={d}', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    st = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', err)]
    en = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', err)]
    return list(zip(st, en + [None]*(len(st)-len(en))))

def main():
    a = sys.argv[1:]
    cfg_p, voice, out = a[0], a[1], a[2]
    music = a[a.index('--music')+1] if '--music' in a else None
    tail = float(a[a.index('--tail')+1]) if '--tail' in a else 1.2
    cfg = json.load(open(cfg_p, encoding='utf-8'))
    total = probe_dur(voice)
    noise = a[a.index('--noise')+1] if '--noise' in a else '-32dB'
    sil = silences(voice, noise)
    # speech start / end
    s0 = sil[0][1] if sil and sil[0][0] < 0.05 and sil[0][1] else 0.0
    s1 = sil[-1][0] if sil and (sil[-1][1] is None or sil[-1][1] >= total - 0.05) else total
    mids = [((x + (y if y else total))/2) for x, y in sil if x > s0 + 0.2 and x < s1 - 0.2]
    lines = [(si, s) for si, sc in enumerate(cfg['scenes']) for s in sc.get('subs', [])]
    n = len(lines)
    w = [max(1, len((s.get('say') or s.get('text', '')) if isinstance(s, dict) else s.replace('**', ''))) for _, s in lines]; tw = sum(w)
    # target boundaries proportional to text length, snapped monotonically to pauses
    bounds = [s0]; acc = 0; used = -1
    for i in range(n-1):
        acc += w[i]; target = s0 + (s1 - s0)*acc/tw
        cand = [(abs(m - target), j) for j, m in enumerate(mids) if j > used and m > bounds[-1] + 0.4]
        remaining = n - 1 - i
        if cand and len([1 for j, _ in enumerate(mids) if j > used]) >= 1:
            dist, j = min(cand)
            if dist < 2.5: used = j; bounds.append(mids[j]); continue
        bounds.append(max(target, bounds[-1] + 0.6))
    bounds.append(s1)
    # scene boundaries
    first_line = {}
    for k, (si, _) in enumerate(lines): first_line.setdefault(si, k)
    starts = []
    for si in range(len(cfg['scenes'])):
        if si == 0: starts.append(0.0)
        elif si in first_line: starts.append(bounds[first_line[si]] - 0.15)
        else: starts.append(starts[-1] + cfg['scenes'][si].get('dur', 3))
    end = s1 + tail
    for si, sc in enumerate(cfg['scenes']):
        t0 = starts[si]; t1 = starts[si+1] if si+1 < len(starts) else end
        sc['dur'] = round(max(2.0, t1 - t0), 3)
        sc['sub_times'] = []
        for k, (sj, s) in enumerate(lines):
            if sj != si: continue
            a0 = max(0.0, bounds[k] - t0); b0 = min(sc['dur'], bounds[k+1] - t0 + (0 if k+1 < n else tail))
            sc['sub_times'].append([round(a0, 3), round(b0, 3)])
    cfg['voice'] = voice; cfg.pop('fit_to_audio', None)
    if music: cfg['music'] = music
    json.dump(cfg, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    if len(mids) < n - 1: print(f'⚠ chỉ tìm thấy {len(mids)} khoảng nghỉ cho {n} câu: thử --noise -28dB, hoặc sửa phụ đề cho khớp lời đọc thật')
    print(f'voice {total:.1f}s, speech {s0:.2f}-{s1:.2f}, pauses {len(mids)}, lines {n}, video {sum(s["dur"] for s in cfg["scenes"]):.1f}s')
    for si, sc in enumerate(cfg['scenes']): print(f'  scene {si+1}: {sc["dur"]:.2f}s  subs {sc["sub_times"]}')

if __name__ == '__main__':
    for _s in (sys.stdout, sys.stderr):   # cửa sổ lệnh Windows (cp1252/cp437) không in được chữ Việt → ép UTF-8
        try:
            _s.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    main()