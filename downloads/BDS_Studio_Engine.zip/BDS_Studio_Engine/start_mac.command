#!/bin/bash
# Mở máy dựng BDS Studio – trình duyệt tự mở http://127.0.0.1:8765. Đóng cửa sổ này = tắt máy dựng.
cd "$(dirname "$0")" || exit 1
if [ -x .venv/bin/python ]; then PY=.venv/bin/python; else PY=python3; fi
export PYTHONIOENCODING=utf-8
exec "$PY" app/server.py "$@"
