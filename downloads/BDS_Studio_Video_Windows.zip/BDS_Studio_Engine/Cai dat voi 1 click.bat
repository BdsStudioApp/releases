@echo off
rem "Cai dat voi 1 click" - nut cai May dung video BDS Studio cho Windows: bam dup tep nay (khong can quyen quan tri).
rem Quyet dinh chu 17/11: ten khong dau (trinh giai nen cua Windows lam hong ten tep co dau), ruot nam trong thu muc "_he_thong".
rem Tep nay chi chuyen sang bo cai that: _he_thong\install_windows.bat (goi moi) hoac install_windows.bat canh no (ma nguon / goi cu).
rem Moi tuy chon duoc chuyen nguyen (--dry-run, --ci, --video...) - xem dau tep install_windows.bat.
rem Tep .bat khong mang bieu tuong rieng duoc (Windows luon ve bieu tuong chung cua loai tep .bat) - xem engine/HUONG_DAN_CAI.md.
title Cai dat BDS Studio
setlocal
set "BDS_CLICK_PATH=%~f0"
set "BDS_INNER=%~dp0_he_thong\install_windows.bat"
if not exist "%BDS_INNER%" set "BDS_INNER=%~dp0install_windows.bat"
if not exist "%BDS_INNER%" goto :missing
call "%BDS_INNER%" %*
exit /b %ERRORLEVEL%
:missing
chcp 65001 >nul
echo.
echo ✗ Lỗi B1: thiếu thư mục _he_thong cạnh "Cai dat voi 1 click" – chưa giải nén. Bấm chuột phải tệp zip → Extract All ^(Giải nén tất cả^), mở thư mục BDS_Studio_Engine rồi bấm đúp lại "Cai dat voi 1 click"
if not defined CI pause
exit /b 11
