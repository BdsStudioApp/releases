#!/bin/bash
# "Cai dat voi 1 click" – nút cài Máy dựng video BDS Studio cho Mac (quyết định chủ 17/11: tên không dấu, ruột trong "_he_thong").
# Cách chạy (lần đầu, an toàn với Gatekeeper): mở Terminal, gõ "bash " (có dấu cách), KÉO tệp này thả vào Terminal, Enter.
# Tệp này chỉ chuyển sang bộ cài thật: _he_thong/install_mac.command (gói mới) hoặc install_mac.command cạnh nó (gói cũ / mã nguồn).
# Mọi tuỳ chọn được chuyển nguyên (--dry-run, --ci, --video…) – xem đầu tệp install_mac.command.
# Vì sao là .command chứ không phải .app: xem engine/HUONG_DAN_CAI.md › "Vì sao nút cài trên Mac là tệp .command".
HERE="$(cd "$(dirname "$0")" 2>/dev/null && pwd -P)" || { echo "✗ Lỗi B1: không mở được thư mục chứa bộ cài"; exit 11; }
for t in "$HERE/_he_thong/install_mac.command" "$HERE/install_mac.command"; do
  if [ -f "$t" ]; then
    BDS_CLICK_PATH="$HERE/$(basename "$0")" exec /bin/bash "$t" "$@"
  fi
done
echo ""
echo "✗ Lỗi B1: thiếu thư mục _he_thong cạnh \"Cai dat voi 1 click\" – bấm đúp lại tệp zip để giải nén đủ, rồi chạy lại"
[ -t 0 ] && [ -z "${CI:-}" ] && read -r -p "Nhấn Enter để đóng..." _
exit 11
